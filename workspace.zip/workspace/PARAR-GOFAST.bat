@echo off
cd /d "%~dp0"
title GoFast Produções - Parar

echo Encerrando o servidor GoFast Produções...
taskkill /FI "WINDOWTITLE eq GoFast Produções - Servidor*" /T /F >nul 2>&1
if errorlevel 1 (
  echo Nenhum servidor com a janela esperada foi encontrado.
  echo Se necessario, feche manualmente a janela do servidor.
) else (
  echo Servidor encerrado.
)
pause
