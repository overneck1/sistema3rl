-- GoFast Produções 2.1 - Internal team and operating cost control
CREATE TABLE IF NOT EXISTS internal_employees (
  id varchar PRIMARY KEY DEFAULT gen_random_uuid(),
  empresa_id varchar NOT NULL,
  name text NOT NULL,
  role text NOT NULL,
  salary numeric(12,2) NOT NULL,
  transport_daily numeric(12,2) NOT NULL DEFAULT 0,
  benefits_monthly numeric(12,2) NOT NULL DEFAULT 0,
  employer_charges_monthly numeric(12,2) NOT NULL DEFAULT 0,
  work_days_per_month integer NOT NULL DEFAULT 22,
  hours_per_day numeric(5,2) NOT NULL DEFAULT 8,
  admission_date timestamp,
  active boolean NOT NULL DEFAULT true,
  notes text,
  created_at timestamp NOT NULL DEFAULT now(),
  updated_at timestamp NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_internal_employees_empresa ON internal_employees(empresa_id);

CREATE TABLE IF NOT EXISTS internal_cost_items (
  id varchar PRIMARY KEY DEFAULT gen_random_uuid(),
  empresa_id varchar NOT NULL,
  description text NOT NULL,
  category text NOT NULL,
  cost_type varchar NOT NULL DEFAULT 'fixed',
  recurrence varchar NOT NULL DEFAULT 'monthly',
  amount numeric(12,2) NOT NULL,
  work_days_per_month integer NOT NULL DEFAULT 22,
  active boolean NOT NULL DEFAULT true,
  effective_date timestamp NOT NULL DEFAULT now(),
  notes text,
  created_at timestamp NOT NULL DEFAULT now(),
  updated_at timestamp NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_internal_cost_items_empresa ON internal_cost_items(empresa_id);
CREATE INDEX IF NOT EXISTS idx_internal_cost_items_active ON internal_cost_items(empresa_id, active);
