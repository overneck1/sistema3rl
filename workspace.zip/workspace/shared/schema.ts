import { sql } from "drizzle-orm";
import { pgTable, text, varchar, integer, numeric, timestamp, boolean, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";
import { relations } from "drizzle-orm";

// Seamstresses table
export const seamstresses = pgTable("seamstresses", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  empresaId: varchar("empresa_id"),
  name: text("name").notNull(),
  phone: text("phone").notNull(),
  pix: text("pix"),
  address: text("address").notNull(),
  neighborhood: text("neighborhood").notNull(),
  numberOfWorkers: integer("number_of_workers").notNull().default(1),
  skills: text("skills").array().notNull(),
  machines: text("machines").array().notNull(),
  status: varchar("status", { enum: ["active", "paused", "blocked"] }).notNull().default("active"),
  ratingDeadline: numeric("rating_deadline", { precision: 3, scale: 2 }).default("5.0"),
  ratingFinish: numeric("rating_finish", { precision: 3, scale: 2 }).default("5.0"),
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Productions table (from suppliers)
export const productions = pgTable("productions", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  empresaId: varchar("empresa_id"),
  productionCode: varchar("production_code").unique().notNull(),
  supplier: text("supplier").notNull(),
  productName: text("product_name"),
  date: timestamp("date").notNull(),
  deliveryDate: timestamp("delivery_date").notNull(),
  quantity: integer("quantity").notNull(),
  types: text("types").array(),
  labels: text("labels"),
  trims: text("trims"),
  pricePerUnit: numeric("price_per_unit", { precision: 10, scale: 2 }).notNull(),
  status: varchar("status", { enum: ["em_separacao", "para_entrega", "em_producao", "para_recolha", "concluido"] }).notNull().default("em_separacao"),
  paymentStatus: varchar("payment_status", { enum: ["Pendente", "Recebido"] }).notNull().default("Pendente"),
  expectedPaymentDate: timestamp("expected_payment_date"),
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Production Variants table (size, color, quantity)
export const productionVariants = pgTable("production_variants", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  empresaId: varchar("empresa_id"),
  productionId: varchar("production_id").notNull().references(() => productions.id),
  size: text("size").notNull(),
  color: text("color").notNull(),
  quantity: integer("quantity").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Batch Variant Allocations table (tracks which variants are allocated to which batches)
export const batchVariantAllocations = pgTable("batch_variant_allocations", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  empresaId: varchar("empresa_id"),
  batchId: varchar("batch_id").notNull().references(() => batches.id),
  variantId: varchar("variant_id").notNull().references(() => productionVariants.id),
  quantity: integer("quantity").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Batches/Lots table
export const batches = pgTable("batches", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  empresaId: varchar("empresa_id"),
  batchCode: varchar("batch_code").unique().notNull(),
  productionId: varchar("production_id").notNull().references(() => productions.id),
  seamstressId: varchar("seamstress_id").references(() => seamstresses.id),
  assignmentType: varchar("assignment_type", { enum: ["external", "internal"] }).notNull().default("external"),
  quantity: integer("quantity").notNull(),
  sendDate: timestamp("send_date").notNull(),
  expectedReturnDate: timestamp("expected_return_date").notNull(),
  pricePerUnit: numeric("price_per_unit", { precision: 10, scale: 2 }).notNull(),
  internalDailyCostSnapshot: numeric("internal_daily_cost_snapshot", { precision: 12, scale: 2 }),
  status: varchar("status", { enum: ["em_separacao", "para_entrega", "em_producao", "para_recolha", "concluido"] }).notNull().default("em_separacao"),
  returnedDate: timestamp("returned_date"),
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Quality Control table
export const qualityControls = pgTable("quality_controls", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  empresaId: varchar("empresa_id"),
  batchId: varchar("batch_id").notNull().references(() => batches.id),
  seamstress: text("seamstress").notNull(),
  sewingQuality: boolean("sewing_quality").notNull(),
  measurements: boolean("measurements").notNull(),
  cleaning: boolean("cleaning").notNull(),
  trims: boolean("trims").notNull(),
  labels: boolean("labels").notNull(),
  classification: varchar("classification", { enum: ["approved", "rejected", "rework"] }).notNull(),
  notes: text("notes"),
  photoUrls: text("photo_urls").array(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Payments table
export const payments = pgTable("payments", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  empresaId: varchar("empresa_id"),
  batchId: varchar("batch_id").notNull().references(() => batches.id),
  seamstressId: varchar("seamstress_id").notNull().references(() => seamstresses.id),
  amount: numeric("amount", { precision: 10, scale: 2 }).notNull(),
  status: varchar("status", { enum: ["pending", "paid", "overdue"] }).notNull().default("pending"),
  dueDate: timestamp("due_date"),
  paidDate: timestamp("paid_date"),
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Internal employee payments: salary and transport are tracked independently.
export const internalEmployeePayments = pgTable("internal_employee_payments", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  empresaId: varchar("empresa_id").notNull(),
  employeeId: varchar("employee_id").notNull().references(() => internalEmployees.id),
  paymentType: varchar("payment_type", { enum: ["salary", "salary_advance", "transport", "transport_advance"] }).notNull(),
  competence: varchar("competence").notNull(),
  amount: numeric("amount", { precision: 12, scale: 2 }).notNull(),
  paymentDate: timestamp("payment_date").notNull(),
  paymentMethod: varchar("payment_method", { enum: ["pix", "bank_transfer", "cash", "other"] }).notNull().default("pix"),
  status: varchar("status", { enum: ["pending", "paid", "cancelled"] }).notNull().default("paid"),
  receiptNumber: varchar("receipt_number").notNull(),
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

// Editable financial plan allocations: partners and configurable cash boxes.
export const financialPlanAllocations = pgTable("financial_plan_allocations", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  empresaId: varchar("empresa_id").notNull(),
  name: text("name").notNull(),
  allocationType: varchar("allocation_type", { enum: ["partner", "cash_box"] }).notNull(),
  percentage: numeric("percentage", { precision: 7, scale: 3 }).notNull().default("0"),
  active: boolean("active").notNull().default(true),
  sortOrder: integer("sort_order").notNull().default(0),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

// Extra Costs table
export const extraCosts = pgTable("extra_costs", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  empresaId: varchar("empresa_id"),
  description: text("description").notNull(),
  amount: numeric("amount", { precision: 10, scale: 2 }).notNull(),
  category: text("category").notNull(),
  date: timestamp("date").notNull(),
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Advances table (adiantamentos para costureiras)
export const advances = pgTable("advances", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  empresaId: varchar("empresa_id"),
  seamstressId: varchar("seamstress_id").notNull().references(() => seamstresses.id),
  amount: numeric("amount", { precision: 10, scale: 2 }).notNull(),
  date: timestamp("date").notNull(),
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Batch Deliveries table (entregas parciais de lotes)
export const batchDeliveries = pgTable("batch_deliveries", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  empresaId: varchar("empresa_id"),
  batchId: varchar("batch_id").notNull().references(() => batches.id),
  deliveredQuantity: integer("delivered_quantity").notNull(),
  deliveredAt: timestamp("delivered_at").notNull(),
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Internal employees (direct company staff)
export const internalEmployees = pgTable("internal_employees", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  empresaId: varchar("empresa_id").notNull(),
  name: text("name").notNull(),
  role: text("role").notNull(),
  salary: numeric("salary", { precision: 12, scale: 2 }).notNull(),
  transportDaily: numeric("transport_daily", { precision: 12, scale: 2 }).notNull().default("0"),
  benefitsMonthly: numeric("benefits_monthly", { precision: 12, scale: 2 }).notNull().default("0"),
  employerChargesMonthly: numeric("employer_charges_monthly", { precision: 12, scale: 2 }).notNull().default("0"),
  workDaysPerMonth: integer("work_days_per_month").notNull().default(22),
  hoursPerDay: numeric("hours_per_day", { precision: 5, scale: 2 }).notNull().default("8"),
  admissionDate: timestamp("admission_date"),
  active: boolean("active").notNull().default(true),
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

// Recurring/structural costs of the internal operation
export const internalCostItems = pgTable("internal_cost_items", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  empresaId: varchar("empresa_id").notNull(),
  description: text("description").notNull(),
  category: text("category").notNull(),
  costType: varchar("cost_type", { enum: ["fixed", "variable", "semi_variable"] }).notNull().default("fixed"),
  recurrence: varchar("recurrence", { enum: ["daily", "weekly", "monthly", "annual", "one_time"] }).notNull().default("monthly"),
  amount: numeric("amount", { precision: 12, scale: 2 }).notNull(),
  workDaysPerMonth: integer("work_days_per_month").notNull().default(22),
  active: boolean("active").notNull().default(true),
  effectiveDate: timestamp("effective_date").defaultNow().notNull(),
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

// WhatsApp Messages table
export const whatsappMessages = pgTable("whatsapp_messages", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  empresaId: varchar("empresa_id"),
  remoteJid: text("remote_jid").notNull(),
  senderName: text("sender_name"),
  senderPhone: text("sender_phone"),
  message: text("message").notNull(),
  direction: varchar("direction", { enum: ["incoming", "outgoing"] }).notNull(),
  timestamp: timestamp("timestamp").defaultNow().notNull(),
  isRead: boolean("is_read").default(false),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Suppliers table
export const suppliers = pgTable("suppliers", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  empresaId: varchar("empresa_id"),
  name: text("name").notNull(),
  phone: text("phone"),
  email: text("email"),
  address: text("address"),
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Activity Logs for audit trail
export const activityLogs = pgTable("activity_logs", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  action: text("action").notNull(),
  entity: text("entity").notNull(),
  entityId: varchar("entity_id").notNull(),
  changes: jsonb("changes"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Relations
export const seamstressesRelations = relations(seamstresses, ({ many }) => ({
  batches: many(batches),
  payments: many(payments),
}));

export const productionsRelations = relations(productions, ({ many }) => ({
  batches: many(batches),
  variants: many(productionVariants),
}));

export const productionVariantsRelations = relations(productionVariants, ({ one, many }) => ({
  production: one(productions, { fields: [productionVariants.productionId], references: [productions.id] }),
  batchAllocations: many(batchVariantAllocations),
}));

export const batchVariantAllocationsRelations = relations(batchVariantAllocations, ({ one }) => ({
  batch: one(batches, { fields: [batchVariantAllocations.batchId], references: [batches.id] }),
  variant: one(productionVariants, { fields: [batchVariantAllocations.variantId], references: [productionVariants.id] }),
}));

export const batchesRelations = relations(batches, ({ one, many }) => ({
  production: one(productions, { fields: [batches.productionId], references: [productions.id] }),
  seamstress: one(seamstresses, { fields: [batches.seamstressId], references: [seamstresses.id] }),
  qualityControl: one(qualityControls, { fields: [batches.id], references: [qualityControls.batchId] }),
  payments: many(payments),
  deliveries: many(batchDeliveries),
}));

export const batchDeliveriesRelations = relations(batchDeliveries, ({ one }) => ({
  batch: one(batches, { fields: [batchDeliveries.batchId], references: [batches.id] }),
}));

export const qualityControlsRelations = relations(qualityControls, ({ one }) => ({
  batch: one(batches, { fields: [qualityControls.batchId], references: [batches.id] }),
}));

export const paymentsRelations = relations(payments, ({ one }) => ({
  batch: one(batches, { fields: [payments.batchId], references: [batches.id] }),
  seamstress: one(seamstresses, { fields: [payments.seamstressId], references: [seamstresses.id] }),
}));

export const extraCostsRelations = relations(extraCosts, ({}) => ({}));

export const whatsappMessagesRelations = relations(whatsappMessages, ({}) => ({}));

// Insert schemas
export const insertSeamstressSchema = createInsertSchema(seamstresses).pick({
  name: true,
  phone: true,
  pix: true,
  address: true,
  neighborhood: true,
  numberOfWorkers: true,
  skills: true,
  machines: true,
  status: true,
  ratingDeadline: true,
  ratingFinish: true,
  notes: true,
});

export const insertProductionSchema = createInsertSchema(productions)
  .pick({
    supplier: true,
    productName: true,
    date: true,
    deliveryDate: true,
    quantity: true,
    types: true,
    labels: true,
    trims: true,
    pricePerUnit: true,
    status: true,
    paymentStatus: true,
    expectedPaymentDate: true,
    notes: true,
  })
  .extend({
    date: z.coerce.date(),
    deliveryDate: z.coerce.date(),
    expectedPaymentDate: z.coerce.date().optional(),
  });

export const insertProductionVariantSchema = createInsertSchema(productionVariants).pick({
  productionId: true,
  size: true,
  color: true,
  quantity: true,
});

export const insertBatchVariantAllocationSchema = createInsertSchema(batchVariantAllocations).pick({
  batchId: true,
  variantId: true,
  quantity: true,
});

export const insertBatchSchema = createInsertSchema(batches)
  .pick({
    productionId: true,
    seamstressId: true,
    assignmentType: true,
    quantity: true,
    sendDate: true,
    expectedReturnDate: true,
    pricePerUnit: true,
    internalDailyCostSnapshot: true,
    status: true,
    notes: true,
  })
  .extend({
    sendDate: z.coerce.date(),
    expectedReturnDate: z.coerce.date(),
    internalDailyCostSnapshot: z.coerce.string().optional().nullable(),
  });

export const insertQualityControlSchema = createInsertSchema(qualityControls).pick({
  batchId: true,
  seamstress: true,
  sewingQuality: true,
  measurements: true,
  cleaning: true,
  trims: true,
  labels: true,
  classification: true,
  notes: true,
  photoUrls: true,
});

export const insertPaymentSchema = createInsertSchema(payments).pick({
  batchId: true,
  seamstressId: true,
  amount: true,
  status: true,
  dueDate: true,
  paidDate: true,
  notes: true,
}).extend({
  amount: z.coerce.string(),
  dueDate: z.coerce.date().optional(),
  paidDate: z.coerce.date().optional(),
});

export const insertInternalEmployeeSchema = createInsertSchema(internalEmployees).pick({
  name: true, role: true, salary: true, transportDaily: true, benefitsMonthly: true,
  employerChargesMonthly: true, workDaysPerMonth: true, hoursPerDay: true, admissionDate: true, active: true, notes: true,
}).extend({
  salary: z.coerce.string(), transportDaily: z.coerce.string(), benefitsMonthly: z.coerce.string(),
  employerChargesMonthly: z.coerce.string(), hoursPerDay: z.coerce.string(), admissionDate: z.coerce.date().optional(),
});

export const insertInternalCostItemSchema = createInsertSchema(internalCostItems).pick({
  description: true, category: true, costType: true, recurrence: true, amount: true,
  workDaysPerMonth: true, active: true, effectiveDate: true, notes: true,
}).extend({ amount: z.coerce.string(), effectiveDate: z.coerce.date().optional() });

export const insertInternalEmployeePaymentSchema = createInsertSchema(internalEmployeePayments).pick({
  employeeId: true, paymentType: true, competence: true, amount: true, paymentDate: true,
  paymentMethod: true, status: true, receiptNumber: true, notes: true,
}).extend({ amount: z.coerce.string(), paymentDate: z.coerce.date() });

export const insertFinancialPlanAllocationSchema = createInsertSchema(financialPlanAllocations).pick({
  name: true, allocationType: true, percentage: true, active: true, sortOrder: true,
}).extend({ percentage: z.coerce.string(), sortOrder: z.coerce.number().int().optional() });

export const insertExtraCostSchema = createInsertSchema(extraCosts).pick({
  description: true,
  amount: true,
  category: true,
  date: true,
  notes: true,
}).extend({
  amount: z.coerce.string(),
  date: z.coerce.date(),
});

// Types
export type Seamstress = typeof seamstresses.$inferSelect;
export type InsertSeamstress = z.infer<typeof insertSeamstressSchema>;

export type Production = typeof productions.$inferSelect;
export type InsertProduction = z.infer<typeof insertProductionSchema>;

export type ProductionVariant = typeof productionVariants.$inferSelect;
export type InsertProductionVariant = z.infer<typeof insertProductionVariantSchema>;

export type BatchVariantAllocation = typeof batchVariantAllocations.$inferSelect;
export type InsertBatchVariantAllocation = z.infer<typeof insertBatchVariantAllocationSchema>;

export type Batch = typeof batches.$inferSelect;
export type InsertBatch = z.infer<typeof insertBatchSchema>;

export type QualityControl = typeof qualityControls.$inferSelect;
export type InsertQualityControl = z.infer<typeof insertQualityControlSchema>;

export type Payment = typeof payments.$inferSelect;
export type InsertPayment = z.infer<typeof insertPaymentSchema>;

export type InternalEmployee = typeof internalEmployees.$inferSelect;
export type InsertInternalEmployee = z.infer<typeof insertInternalEmployeeSchema>;
export type InternalCostItem = typeof internalCostItems.$inferSelect;
export type InsertInternalCostItem = z.infer<typeof insertInternalCostItemSchema>;

export type ExtraCost = typeof extraCosts.$inferSelect;
export type InsertExtraCost = z.infer<typeof insertExtraCostSchema>;

export const insertAdvanceSchema = createInsertSchema(advances).pick({
  seamstressId: true,
  amount: true,
  date: true,
  notes: true,
}).extend({
  amount: z.coerce.string(),
  date: z.coerce.date(),
});
export type Advance = typeof advances.$inferSelect;
export type InsertAdvance = z.infer<typeof insertAdvanceSchema>;

export const insertBatchDeliverySchema = createInsertSchema(batchDeliveries).pick({
  batchId: true,
  deliveredQuantity: true,
  deliveredAt: true,
  notes: true,
}).extend({
  deliveredAt: z.coerce.date(),
});
export type BatchDelivery = typeof batchDeliveries.$inferSelect;
export type InsertBatchDelivery = z.infer<typeof insertBatchDeliverySchema>;

export type ActivityLog = typeof activityLogs.$inferSelect;

export type WhatsAppMessage = typeof whatsappMessages.$inferSelect;
export type InsertWhatsAppMessage = z.infer<typeof insertWhatsAppMessageSchema>;

export const insertWhatsAppMessageSchema = createInsertSchema(whatsappMessages).pick({
  remoteJid: true,
  senderName: true,
  senderPhone: true,
  message: true,
  direction: true,
  timestamp: true,
  isRead: true,
}).extend({
  timestamp: z.coerce.date().optional(),
});

export const insertSupplierSchema = createInsertSchema(suppliers).pick({
  name: true,
  phone: true,
  email: true,
  address: true,
  notes: true,
});

export type Supplier = typeof suppliers.$inferSelect;
export type InsertSupplier = z.infer<typeof insertSupplierSchema>;

// ==========================================
// MULTI-TENANT SAAS TABLES (MASTER DATABASE)
// ==========================================

// Admin Master table (superadmins who manage companies)
export const admins = pgTable("admins", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  email: text("email").notNull().unique(),
  password: text("password").notNull(),
  role: varchar("role", { enum: ["superadmin", "admin"] }).notNull().default("admin"),
  isActive: boolean("is_active").notNull().default(true),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

// Companies/Tenants table
export const empresas = pgTable("empresas", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  code: varchar("code").notNull().unique(),
  subdomain: varchar("subdomain").unique(),
  databaseName: text("database_name").notNull().unique(),
  databaseUrl: text("database_url"),
  status: varchar("status", { enum: ["active", "suspended", "pending"] }).notNull().default("pending"),
  plan: varchar("plan", { enum: ["basic", "premium", "enterprise"] }).notNull().default("basic"),
  ownerName: text("owner_name"),
  ownerEmail: text("owner_email"),
  ownerPhone: text("owner_phone"),
  expiresAt: timestamp("expires_at"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

// Company Users table (for each company's database)
export const usuarios = pgTable("usuarios", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  empresaId: varchar("empresa_id").notNull(),
  name: text("name").notNull(),
  email: text("email").notNull(),
  password: text("password").notNull(),
  role: varchar("role", { enum: ["admin_empresa", "operador", "financeiro", "visualizador"] }).notNull().default("operador"),
  isActive: boolean("is_active").notNull().default(true),
  lastLoginAt: timestamp("last_login_at"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

// Audit Logs for multi-tenant system
export const auditLogs = pgTable("audit_logs", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  empresaId: varchar("empresa_id"),
  userId: varchar("user_id"),
  userType: varchar("user_type", { enum: ["admin", "usuario"] }).notNull(),
  action: text("action").notNull(),
  entity: text("entity").notNull(),
  entityId: varchar("entity_id"),
  details: jsonb("details"),
  ipAddress: text("ip_address"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Insert schemas for multi-tenant
export const insertAdminSchema = createInsertSchema(admins).pick({
  name: true,
  email: true,
  password: true,
  role: true,
  isActive: true,
});

export const insertEmpresaSchema = createInsertSchema(empresas).pick({
  name: true,
  code: true,
  subdomain: true,
  databaseName: true,
  databaseUrl: true,
  status: true,
  plan: true,
  ownerName: true,
  ownerEmail: true,
  ownerPhone: true,
  expiresAt: true,
}).extend({
  expiresAt: z.coerce.date().optional(),
});

export const insertUsuarioSchema = createInsertSchema(usuarios).pick({
  empresaId: true,
  name: true,
  email: true,
  password: true,
  role: true,
  isActive: true,
});

export const insertAuditLogSchema = createInsertSchema(auditLogs).pick({
  empresaId: true,
  userId: true,
  userType: true,
  action: true,
  entity: true,
  entityId: true,
  details: true,
  ipAddress: true,
});

// Types for multi-tenant
export type Admin = typeof admins.$inferSelect;
export type InsertAdmin = z.infer<typeof insertAdminSchema>;

export type Empresa = typeof empresas.$inferSelect;
export type InsertEmpresa = z.infer<typeof insertEmpresaSchema>;

export type Usuario = typeof usuarios.$inferSelect;
export type InsertUsuario = z.infer<typeof insertUsuarioSchema>;

export type AuditLog = typeof auditLogs.$inferSelect;
export type InsertAuditLog = z.infer<typeof insertAuditLogSchema>;
