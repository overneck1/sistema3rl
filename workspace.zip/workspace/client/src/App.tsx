import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { AuthProvider, useAuth } from "@/lib/auth";
import { ThemeProvider } from "@/components/theme-provider";
import { ThemeToggle } from "@/components/theme-toggle";
import NotFound from "@/pages/not-found";
import Dashboard from "@/pages/dashboard";
import Seamstresses from "@/pages/seamstresses";
import SeamstressDetail from "@/pages/seamstress-detail";
import Productions from "@/pages/productions";
import Batches from "@/pages/batches";
import Payments from "@/pages/payments";
import ExtraCosts from "@/pages/extra-costs";
import Financeiro from "@/pages/financeiro";
import MonthlyKanban from "@/pages/monthly-kanban";
import Overview from "@/pages/overview";
import Profits from "@/pages/profits";
import WhatsAppCentral from "@/pages/whatsapp";
import WhatsAppRedirect from "@/pages/whatsapp-redirect";
import WhatsAppChat from "@/pages/whatsapp-chat";
import Suppliers from "@/pages/suppliers";
import FilteredBatches from "@/pages/cards/filtered-batches";
import FilteredProductions from "@/pages/cards/filtered-productions";
import FinancialDashboard from "@/pages/financial-dashboard";
import FinancialHistoryDetail from "@/pages/financial-history-detail";
import AgenteGoFast from "@/pages/agente-gofast";
import InternalCosts from "@/pages/internal-costs";
import InternalPayments from "@/pages/internal-payments";
import LoginPage from "@/pages/login";
import AdminPage from "@/pages/admin";
import UsersPage from "@/pages/users";
import { LayoutDashboard, Users, Package, Boxes, DollarSign, Plus, Calendar, Eye, MessageCircle, BarChart3, Zap, Building2, Bot, LogOut, Shield, Factory, WalletCards } from "lucide-react";
import { useState, useEffect } from "react";
import { Link, useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { InstallButton } from "@/components/install-button";

function AppRouter() {
  return (
    <Switch>
      <Route path="/login" component={LoginPage} />
      <Route path="/admin" component={AdminPage} />
      <Route path="/users" component={UsersPage} />
      <Route path="/" component={Dashboard} />
      <Route path="/overview" component={Overview} />
      <Route path="/profits" component={Profits} />
      <Route path="/seamstresses" component={Seamstresses} />
      <Route path="/seamstresses/:id" component={SeamstressDetail} />
      <Route path="/productions" component={Productions} />
      <Route path="/monthly-kanban" component={MonthlyKanban} />
      <Route path="/batches" component={Batches} />
      <Route path="/payments" component={Payments} />
      <Route path="/financeiro" component={Financeiro} />
      <Route path="/financial-dashboard" component={FinancialDashboard} />
      <Route path="/financial-history/:type" component={FinancialHistoryDetail} />
      <Route path="/extra-costs" component={ExtraCosts} />
      <Route path="/internal-costs" component={InternalCosts} />
      <Route path="/internal-payments" component={InternalPayments} />
      <Route path="/whatsapp" component={WhatsAppCentral} />
      <Route path="/whatsapp-chat" component={WhatsAppChat} />
      <Route path="/whatsapp-redirect" component={WhatsAppRedirect} />
      <Route path="/cards/batches" component={FilteredBatches} />
      <Route path="/cards/productions" component={FilteredProductions} />
      <Route path="/suppliers" component={Suppliers} />
      <Route path="/agente-gofast" component={AgenteGoFast} />
      <Route component={NotFound} />
    </Switch>
  );
}

function Navigation() {
  const [location, navigate] = useLocation();
  const { user, logout, isLoading } = useAuth();
  const [collapsed, setCollapsed] = useState(true);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const handleLogout = () => {
    logout();
    navigate("/login");
  };

  const links = [
    { href: "/", label: "Dashboard", icon: LayoutDashboard },
    { href: "/overview", label: "Visão Geral", icon: Eye },
    { href: "/seamstresses", label: "Costureiras externas", icon: Users },
    { href: "/internal-costs", label: "Estrutura interna", icon: Factory },
    { href: "/internal-payments", label: "Pagamentos internos", icon: WalletCards },
    { href: "/productions", label: "Produções", icon: Package },
    { href: "/monthly-kanban", label: "Kanban Mensal", icon: Calendar },
    { href: "/batches", label: "Lotes", icon: Boxes },
    { href: "/financeiro", label: "Financeiro", icon: BarChart3 },
    { href: "/payments", label: "Pagamentos", icon: DollarSign },
    { href: "/extra-costs", label: "Custos Extras", icon: Plus },
    { href: "/financial-dashboard", label: "💰 Plano Financeiro", icon: Zap },
    { href: "/agente-gofast", label: "Agente GoFast", icon: Bot },
    { href: "/users", label: "Usuários e acessos", icon: Shield },
    { href: "/whatsapp", label: "WhatsApp", icon: MessageCircle },
    { href: "/suppliers", label: "Fornecedores", icon: Building2 },
  ];

  return (
    <>
      {/* Mobile Menu Overlay */}
      {mobileMenuOpen && (
        <div 
          className="fixed inset-0 bg-black/50 z-40 md:hidden"
          onClick={() => setMobileMenuOpen(false)}
        />
      )}
      {/* Sidebar - Hidden on mobile, visible on desktop */}
      <aside className={`fixed top-0 left-0 h-screen bg-card border-r border-border transition-all z-50 ${
        mobileMenuOpen ? "translate-x-0" : "-translate-x-full"
      } md:translate-x-0 ${collapsed ? "md:w-20" : "md:w-64"} w-64`}>
        <div className="p-4 border-b border-border flex items-center justify-between">
          <div><div className="text-lg font-semibold tracking-tight" data-testid="text-app-title">GoFast</div><div className="text-[10px] uppercase tracking-[0.18em] text-muted-foreground">Produções</div></div>
          <Button
            variant="ghost"
            size="icon"
            className="md:hidden"
            onClick={() => setMobileMenuOpen(false)}
            data-testid="button-close-mobile-menu"
          >
            ✕
          </Button>
        </div>
        <nav className="space-y-2 p-4 overflow-y-auto max-h-[calc(100vh-80px)]">
          {links.map((link) => {
            const Icon = link.icon;
            const isActive = location === link.href;
            return (
              <Link key={link.href} href={link.href}>
                <Button
                  variant={isActive ? "default" : "ghost"}
                  className="w-full justify-start gap-3"
                  data-testid={`button-nav-${link.href}`}
                  onClick={() => setMobileMenuOpen(false)}
                >
                  <Icon className="w-4 h-4" />
                  {(!collapsed || mobileMenuOpen) && <span>{link.label}</span>}
                </Button>
              </Link>
            );
          })}
        </nav>
      </aside>
      {/* Main Content */}
      <main className={`transition-all ml-0 ${collapsed ? "md:ml-20" : "md:ml-64"}`}>
        <header className="border-b border-border p-3 md:p-4 flex items-center justify-between sticky top-0 bg-background z-30">
          <div className="flex items-center gap-2 md:gap-4">
            <Button
              variant="ghost"
              size="icon"
              onClick={() => {
                if (window.innerWidth < 768) {
                  setMobileMenuOpen(!mobileMenuOpen);
                } else {
                  setCollapsed(!collapsed);
                }
              }}
              data-testid="button-toggle-sidebar"
            >
              ☰
            </Button>
            <h2 className="text-sm md:text-lg font-semibold tracking-tight">Centro de Operações</h2>
            {user?.type === "usuario" && (
              <span className="text-xs text-muted-foreground hidden md:inline">
                {(user as any).empresaName}
              </span>
            )}
          </div>
          <div className="flex items-center gap-2">
            {user && (
              <>
                <span className="text-xs text-muted-foreground hidden md:inline">
                  {user.name}
                </span>
                <Link href="/admin">
                  <Button variant="ghost" size="icon" data-testid="button-admin-panel">
                    <Shield className="w-4 h-4" />
                  </Button>
                </Link>
                <Button variant="ghost" size="icon" onClick={handleLogout} data-testid="button-logout">
                  <LogOut className="w-4 h-4" />
                </Button>
              </>
            )}
            {!user && (
              <Link href="/login">
                <Button variant="outline" size="sm" data-testid="button-login">
                  Entrar
                </Button>
              </Link>
            )}
            <ThemeToggle />
            <InstallButton />
          </div>
        </header>
        <div className="p-2 md:p-4">
          <AppRouter />
        </div>
      </main>
    </>
  );
}

function ProtectedRoute({ children }: { children: React.ReactNode }) {
  const { user, isLoading } = useAuth();
  const [, navigate] = useLocation();
  
  useEffect(() => {
    if (!isLoading && !user) {
      navigate("/login");
    }
  }, [user, isLoading, navigate]);

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
      </div>
    );
  }

  if (!user) {
    return null;
  }

  return <>{children}</>;
}

function MainApp() {
  const [location, navigate] = useLocation();
  const { user, isLoading } = useAuth();
  
  useEffect(() => {
    if (isLoading) return;
    
    // Login page - redirect if already logged in
    if (location === "/login" && user) {
      if (user.type === "admin") {
        navigate("/admin");
      } else {
        navigate("/");
      }
      return;
    }
    
    // Admin page - redirect to login if not authenticated
    if (location === "/admin" && !user) {
      navigate("/login");
      return;
    }
    
    // Other pages - redirect to login if not authenticated
    if (location !== "/login" && location !== "/admin" && !user) {
      navigate("/login");
    }
  }, [location, user, isLoading, navigate]);
  
  // Loading state
  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
      </div>
    );
  }
  
  // Login page - always accessible
  if (location === "/login") {
    if (user) return null; // Will redirect via useEffect
    return <AppRouter />;
  }
  
  // Admin page - only for admins
  if (location === "/admin") {
    if (!user) return null; // Will redirect via useEffect
    return <AppRouter />;
  }
  
  // All other pages - require authentication
  if (!user) {
    return null; // Will redirect via useEffect
  }
  
  return <Navigation />;
}

export default function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <ThemeProvider defaultTheme="dark" storageKey="gofast-ui-theme">
        <AuthProvider>
          <TooltipProvider>
            <MainApp />
            <Toaster />
          </TooltipProvider>
        </AuthProvider>
      </ThemeProvider>
    </QueryClientProvider>
  );
}
