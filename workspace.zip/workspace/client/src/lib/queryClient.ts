import { QueryClient, QueryFunction } from "@tanstack/react-query";
import { getAuthHeader, getApiBaseUrl } from "./auth";

const TENANT_AWARE_RESOURCES = [
  "/api/seamstresses",
  "/api/productions",
  "/api/batches",
  "/api/payments",
  "/api/advances",
  "/api/extra-costs",
  "/api/quality-controls",
  "/api/suppliers",
  "/api/dashboard",
  "/api/alerts",
  "/api/production-variants",
  "/api/batch-variants",
  "/api/batch-deliveries",
  "/api/variants",
  "/api/internal-costs",
  "/api/internal-costs/dashboard",
  "/api/internal-employees",
  "/api/internal-cost-items",
  "/api/internal-employee-payments",
  "/api/financial-plan",
];

function transformApiUrl(url: string): string {
  const baseUrl = getApiBaseUrl();
  if (baseUrl !== "/api/tenant") {
    return url;
  }
  
  const shouldTransform = TENANT_AWARE_RESOURCES.some(resource => 
    url === resource || url.startsWith(resource + "/") || url.startsWith(resource + "?")
  );
  
  if (shouldTransform && !url.startsWith("/api/tenant")) {
    return url.replace("/api/", "/api/tenant/");
  }
  return url;
}

async function throwIfResNotOk(res: Response) {
  if (!res.ok) {
    if (res.status === 401) {
      localStorage.removeItem("gofast_token");
      localStorage.removeItem("gofast_user");
    }
    const text = (await res.text()) || res.statusText;
    throw new Error(`${res.status}: ${text}`);
  }
}

export async function apiRequest(
  method: string,
  url: string,
  data?: unknown | undefined,
  timeout: number = 120000, // 120 seconds default for WhatsApp messages
): Promise<Response> {
  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort(), timeout);

  try {
    const authHeaders = getAuthHeader();
    const headers: Record<string, string> = {
      ...authHeaders,
    };
    if (data) {
      headers["Content-Type"] = "application/json";
    }

    const transformedUrl = transformApiUrl(url);
    const res = await fetch(transformedUrl, {
      method,
      headers,
      body: data ? JSON.stringify(data) : undefined,
      credentials: "include",
      signal: controller.signal,
    });

    clearTimeout(timeoutId);
    await throwIfResNotOk(res);
    return res;
  } catch (error) {
    clearTimeout(timeoutId);
    throw error;
  }
}

type UnauthorizedBehavior = "returnNull" | "throw";
export const getQueryFn: <T>(options: {
  on401: UnauthorizedBehavior;
}) => QueryFunction<T> =
  ({ on401: unauthorizedBehavior }) =>
  async ({ queryKey }) => {
    const authHeaders = getAuthHeader();
    const url = transformApiUrl(queryKey.join("/") as string);
    const res = await fetch(url, {
      credentials: "include",
      headers: authHeaders,
    });

    if (unauthorizedBehavior === "returnNull" && res.status === 401) {
      return null;
    }

    await throwIfResNotOk(res);
    return await res.json();
  };

export const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      queryFn: getQueryFn({ on401: "throw" }),
      refetchInterval: false,
      refetchOnWindowFocus: true,
      staleTime: 30000, // 30 seconds - data stays fresh for 30s
      gcTime: 300000, // 5 minutes - cache garbage collection
      retry: 1,
    },
    mutations: {
      retry: false,
    },
  },
});
