import { createContext, useContext, useState, useEffect, ReactNode } from "react";

interface AdminUser {
  id: string;
  email: string;
  name: string;
  role: "superadmin" | "admin";
  type: "admin";
}

interface UsuarioUser {
  id: string;
  email: string;
  name: string;
  role: "admin_empresa" | "operador" | "financeiro" | "visualizador";
  empresaId: string;
  empresaCode: string;
  empresaName: string;
  databaseName: string;
  type: "usuario";
}

type User = AdminUser | UsuarioUser;

interface AuthContextType {
  user: User | null;
  token: string | null;
  isLoading: boolean;
  login: (email: string, password: string, type: "admin" | "usuario") => Promise<boolean>;
  logout: () => void;
  isAdmin: boolean;
  isUsuario: boolean;
}

const AuthContext = createContext<AuthContextType | null>(null);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [token, setToken] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const savedToken = localStorage.getItem("gofast_token");
    const savedUser = localStorage.getItem("gofast_user");
    
    if (savedToken && savedUser) {
      setToken(savedToken);
      setUser(JSON.parse(savedUser));
    }
    setIsLoading(false);
  }, []);

  const login = async (email: string, password: string, type: "admin" | "usuario"): Promise<boolean> => {
    try {
      const response = await fetch("/api/auth/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email, password, type }),
      });

      if (!response.ok) {
        return false;
      }

      const data = await response.json();
      
      if (data.success) {
        const userData = type === "admin" ? data.admin : data.usuario;
        setToken(data.token);
        setUser(userData);
        localStorage.setItem("gofast_token", data.token);
        localStorage.setItem("gofast_user", JSON.stringify(userData));
        return true;
      }
      return false;
    } catch {
      return false;
    }
  };

  const logout = () => {
    setToken(null);
    setUser(null);
    localStorage.removeItem("gofast_token");
    localStorage.removeItem("gofast_user");
  };

  const isAdmin = user?.type === "admin";
  const isUsuario = user?.type === "usuario";

  return (
    <AuthContext.Provider value={{ user, token, isLoading, login, logout, isAdmin, isUsuario }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error("useAuth must be used within AuthProvider");
  }
  return context;
}

export function getAuthHeader(): Record<string, string> {
  const token = localStorage.getItem("gofast_token");
  if (token) {
    return { Authorization: `Bearer ${token}` };
  }
  return {};
}

export function getApiBaseUrl(): string {
  const savedUser = localStorage.getItem("gofast_user");
  if (savedUser) {
    const user = JSON.parse(savedUser);
    if (user.type === "usuario") {
      return "/api/tenant";
    }
  }
  return "/api";
}

export function getApiUrl(path: string): string {
  const base = getApiBaseUrl();
  if (path.startsWith("/")) {
    return `${base}${path}`;
  }
  return `${base}/${path}`;
}
