import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { FileText, Receipt } from "lucide-react";

export type PrintFormat = "a4" | "cupom";

interface PrintFormatDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onSelectFormat: (format: PrintFormat) => void;
  title?: string;
}

export const PrintFormatDialog = ({
  open,
  onOpenChange,
  onSelectFormat,
  title = "Escolha o formato de impressão"
}: PrintFormatDialogProps) => {
  const handleSelect = (format: PrintFormat) => {
    onSelectFormat(format);
    onOpenChange(false);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle data-testid="text-print-format-title">{title}</DialogTitle>
        </DialogHeader>
        <div className="grid grid-cols-2 gap-4 py-4">
          <Button
            variant="outline"
            className="flex flex-col items-center gap-3 h-auto py-6 hover-elevate"
            onClick={() => handleSelect("a4")}
            data-testid="button-print-a4"
          >
            <FileText className="w-10 h-10 text-primary" />
            <div className="text-center">
              <p className="font-semibold">Folha A4</p>
              <p className="text-xs text-muted-foreground">210mm x 297mm</p>
            </div>
          </Button>
          <Button
            variant="outline"
            className="flex flex-col items-center gap-3 h-auto py-6 hover-elevate"
            onClick={() => handleSelect("cupom")}
            data-testid="button-print-cupom"
          >
            <Receipt className="w-10 h-10 text-primary" />
            <div className="text-center">
              <p className="font-semibold">Cupom Fiscal</p>
              <p className="text-xs text-muted-foreground">80mm largura</p>
            </div>
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
};

export const getCupomBaseStyles = () => `
  * { margin: 0; padding: 0; box-sizing: border-box; }
  body { 
    font-family: 'Courier New', monospace; 
    background-color: #fff; 
    padding: 5mm;
    width: 80mm;
    font-size: 14px;
    font-weight: bold;
    line-height: 1.4;
  }
  .container { width: 100%; font-weight: bold; }
  .cupom { font-weight: bold; }
  .header { 
    text-align: center; 
    border-bottom: 2px dashed #000; 
    padding-bottom: 4mm; 
    margin-bottom: 4mm;
    font-weight: bold;
    font-size: 22px;
  }
  .header h1 { font-size: 22px; font-weight: bold; margin-bottom: 3px; }
  .header p { font-size: 14px; font-weight: bold; }
  .title { font-size: 18px; font-weight: bold; text-align: center; margin-bottom: 3mm; }
  .divider { border-top: 2px dashed #000; margin: 4mm 0; }
  .section { margin-bottom: 4mm; font-weight: bold; }
  .section-title { 
    font-weight: bold; 
    text-transform: uppercase; 
    font-size: 14px; 
    margin-bottom: 3mm;
    border-bottom: 2px solid #000;
    padding-bottom: 2mm;
  }
  .row { 
    display: flex; 
    justify-content: space-between; 
    padding: 2mm 0;
    font-size: 13px;
    font-weight: bold;
  }
  .row-label { font-weight: bold; }
  .row-value { font-weight: bold; text-align: right; }
  .total-row { 
    display: flex; 
    justify-content: space-between; 
    padding: 3mm 0;
    font-size: 16px;
    font-weight: bold;
    border-top: 2px dashed #000;
    margin-top: 3mm;
  }
  .total { font-size: 15px; font-weight: bold; text-align: center; padding: 2mm 0; }
  .info { font-size: 13px; font-weight: bold; text-align: center; padding: 1mm 0; }
  .item { 
    padding: 3mm 0; 
    border-bottom: 1px dotted #666;
    font-size: 13px;
    font-weight: bold;
  }
  .item:last-child { border-bottom: none; }
  .item-name { font-weight: bold; margin-bottom: 2mm; font-size: 14px; }
  .item-header { font-weight: bold; font-size: 14px; margin-bottom: 2mm; }
  .item-row { display: flex; justify-content: space-between; font-weight: bold; font-size: 12px; padding: 1mm 0; }
  .item-details { color: #333; font-weight: bold; }
  .footer { 
    text-align: center; 
    margin-top: 4mm; 
    padding-top: 4mm; 
    border-top: 2px dashed #000; 
    font-size: 12px;
    font-weight: bold;
  }
  .center { text-align: center; font-weight: bold; }
  .bold { font-weight: bold; }
  table { width: 100%; border-collapse: collapse; font-size: 13px; font-weight: bold; }
  table th { text-align: left; font-weight: bold; padding: 2mm 0; border-bottom: 2px solid #000; font-size: 13px; }
  table td { padding: 2mm 0; border-bottom: 1px dotted #666; font-weight: bold; font-size: 12px; }
  @media print {
    @page { 
      size: 80mm auto; 
      margin: 0; 
    }
    body { 
      width: 80mm; 
      padding: 3mm;
      font-weight: bold;
    }
  }
`;

export const printContent = (content: string) => {
  const printWindow = window.open("", "", "width=800,height=600");
  if (printWindow) {
    printWindow.document.write(content);
    printWindow.document.close();
    printWindow.print();
  }
};
