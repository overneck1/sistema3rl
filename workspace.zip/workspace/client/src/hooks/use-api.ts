import { useAuth } from "@/lib/auth";

export function useApiUrl() {
  const { user } = useAuth();
  
  const getUrl = (path: string) => {
    if (user?.type === "usuario") {
      return `/api/tenant${path}`;
    }
    return `/api${path}`;
  };
  
  return { getUrl, isTenant: user?.type === "usuario" };
}

export function getApiUrl(path: string, userType?: "admin" | "usuario") {
  if (userType === "usuario") {
    return `/api/tenant${path}`;
  }
  return `/api${path}`;
}
