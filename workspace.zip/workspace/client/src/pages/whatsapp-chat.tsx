import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Send, Phone, MessageCircle, Loader2 } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { queryClient } from "@/lib/queryClient";
import { Link } from "wouter";

const WhatsAppChat = () => {
  const [selectedSeamstressId, setSelectedSeamstressId] = useState<string>("");
  const [messageText, setMessageText] = useState("");
  const [sentMessages, setSentMessages] = useState<
    { seamstressId: string; message: string; timestamp: Date; direction: "sent" | "received" }[]
  >([]);

  // Fetch seamstresses
  const { data: seamstresses = [] } = useQuery({
    queryKey: ["/api/seamstresses"],
  });

  // Send message mutation
  const sendMessageMutation = useMutation({
    mutationFn: async () => {
      if (!selectedSeamstressId || !messageText.trim()) return;

      const seamstress = (seamstresses as any[]).find(
        (s: any) => s.id === selectedSeamstressId
      );
      if (!seamstress?.phone) {
        throw new Error("Número da costureira não encontrado");
      }

      const res = await apiRequest("POST", "/api/whatsapp/send-message", {
        phoneNumber: seamstress.phone,
        message: messageText,
      });
      return res.json();
    },
    onSuccess: () => {
      if (selectedSeamstressId) {
        setSentMessages((prev) => [
          ...prev,
          {
            seamstressId: selectedSeamstressId,
            message: messageText,
            timestamp: new Date(),
            direction: "sent",
          },
        ]);
      }
      setMessageText("");
      queryClient.invalidateQueries({ queryKey: ["/api/whatsapp/status"] });
    },
    onError: (error: any) => {
      alert(`Erro ao enviar mensagem: ${error.message}`);
    },
  });

  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (messageText.trim() && selectedSeamstressId) {
      sendMessageMutation.mutate();
    }
  };

  const selectedSeamstress = (seamstresses as any[]).find(
    (s: any) => s.id === selectedSeamstressId
  );

  const filteredMessages = sentMessages.filter(
    (m) => m.seamstressId === selectedSeamstressId
  );

  return (
    <div className="h-screen flex flex-col">
      {/* Header */}
      <div className="border-b border-border p-4 flex items-center justify-between bg-card">
        <div>
          <h1 className="text-2xl font-bold text-foreground">Conversas WhatsApp</h1>
          <p className="text-sm text-muted-foreground mt-1">
            Envie mensagens direto para as costureiras
          </p>
        </div>
        <Link href="/whatsapp">
          <Button variant="outline" data-testid="button-back-to-central">
            Voltar à Central
          </Button>
        </Link>
      </div>

      {/* Main Content */}
      <div className="flex flex-1 overflow-hidden">
        {/* Seamstresses Sidebar */}
        <div className="w-72 border-r border-border overflow-y-auto bg-background">
          <div className="p-4 space-y-2">
            <h2 className="font-semibold text-foreground mb-4">Costureiras</h2>
            {((seamstresses || []) as any[]).map((seamstress) => (
              <Button
                key={seamstress.id}
                variant={selectedSeamstressId === seamstress.id ? "default" : "ghost"}
                className="w-full justify-start text-left h-auto py-3"
                onClick={() => setSelectedSeamstressId(seamstress.id)}
                data-testid={`button-select-seamstress-${seamstress.id}`}
              >
                <div className="w-full">
                  <div className="font-medium text-sm">{seamstress.name}</div>
                  <div className="text-xs opacity-70 flex items-center gap-1 mt-1">
                    <Phone className="w-3 h-3" />
                    {seamstress.phone}
                  </div>
                </div>
              </Button>
            ))}
          </div>
        </div>

        {/* Chat Area */}
        <div className="flex-1 flex flex-col bg-background">
          {selectedSeamstress ? (
            <>
              {/* Chat Header */}
              <div className="border-b border-border p-4 bg-card flex items-center gap-3">
                <MessageCircle className="w-5 h-5 text-[#25D366]" />
                <div>
                  <p className="font-medium text-foreground">{selectedSeamstress.name}</p>
                  <p className="text-xs text-muted-foreground">{selectedSeamstress.phone}</p>
                </div>
              </div>

              {/* Messages Area */}
              <div className="flex-1 overflow-y-auto p-4 space-y-3">
                {filteredMessages.length === 0 ? (
                  <div className="h-full flex items-center justify-center text-center">
                    <div className="text-muted-foreground">
                      <MessageCircle className="w-12 h-12 mx-auto opacity-30 mb-2" />
                      <p>Nenhuma mensagem enviada ainda</p>
                      <p className="text-sm mt-1">Comece uma conversa!</p>
                    </div>
                  </div>
                ) : (
                  filteredMessages.map((msg, idx) => (
                    <div
                      key={idx}
                      className={`flex ${msg.direction === "sent" ? "justify-end" : "justify-start"}`}
                    >
                      <div
                        className={`max-w-xs px-4 py-2 rounded-lg ${
                          msg.direction === "sent"
                            ? "bg-[#25D366] text-white rounded-br-none"
                            : "bg-muted text-foreground rounded-bl-none"
                        }`}
                      >
                        <p className="break-words">{msg.message}</p>
                        <p className={`text-xs mt-1 ${msg.direction === "sent" ? "text-green-100" : "text-muted-foreground"}`}>
                          {msg.timestamp.toLocaleTimeString("pt-BR", {
                            hour: "2-digit",
                            minute: "2-digit",
                          })}
                        </p>
                      </div>
                    </div>
                  ))
                )}
              </div>

              {/* Message Input */}
              <form
                onSubmit={handleSendMessage}
                className="border-t border-border p-4 bg-card flex gap-2"
              >
                <Input
                  type="text"
                  placeholder="Digite uma mensagem..."
                  value={messageText}
                  onChange={(e) => setMessageText(e.target.value)}
                  disabled={sendMessageMutation.isPending}
                  data-testid="input-message"
                  className="flex-1"
                />
                <Button
                  type="submit"
                  disabled={sendMessageMutation.isPending || !messageText.trim()}
                  className="gap-2"
                  data-testid="button-send-message"
                >
                  {sendMessageMutation.isPending ? (
                    <Loader2 className="w-4 h-4 animate-spin" />
                  ) : (
                    <Send className="w-4 h-4" />
                  )}
                  Enviar
                </Button>
              </form>
            </>
          ) : (
            <div className="h-full flex items-center justify-center">
              <Card className="p-8 bg-card border-card-border card-tech text-center max-w-sm">
                <MessageCircle className="w-16 h-16 mx-auto opacity-30 mb-4" />
                <p className="text-muted-foreground">
                  Selecione uma costureira na lista para abrir a conversa
                </p>
              </Card>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default WhatsAppChat;
