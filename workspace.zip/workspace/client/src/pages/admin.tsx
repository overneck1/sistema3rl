import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient }from "@/lib/queryClient";
import { useAuth, getAuthHeader } from "@/lib/auth";
import { useLocation } from "wouter";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { 
  Building2, Users, Plus, LogOut, Shield, CheckCircle, XCircle, 
  Clock, LayoutDashboard, Settings, Trash2, Edit, UserPlus, KeyRound, Eye, EyeOff, Copy
} from "lucide-react";

interface Empresa {
  id: string;
  name: string;
  code: string;
  subdomain?: string;
  databaseName: string;
  status: "active" | "suspended" | "pending";
  plan: "basic" | "premium" | "enterprise";
  ownerName?: string;
  ownerEmail?: string;
  ownerPhone?: string;
  createdAt: string;
}

interface DashboardStats {
  totalEmpresas: number;
  empresasAtivas: number;
  empresasSuspensas: number;
  empresasPendentes: number;
  totalUsuarios: number;
  planos: {
    basic: number;
    premium: number;
    enterprise: number;
  };
}

interface Usuario {
  id: string;
  empresaId: string;
  name: string;
  email: string;
  role: string;
  isActive: boolean;
  lastLoginAt: string | null;
  createdAt: string;
  empresaName: string;
  empresaCode: string;
}

export default function AdminPage() {
  const { user, logout, isAdmin } = useAuth();
  const [, navigate] = useLocation();
  const { toast } = useToast();
  const [showNewEmpresa, setShowNewEmpresa] = useState(false);
  const [showNewUsuario, setShowNewUsuario] = useState(false);
  const [selectedEmpresa, setSelectedEmpresa] = useState<Empresa | null>(null);
  const [activeTab, setActiveTab] = useState<"dashboard" | "empresas" | "usuarios" | "settings">("dashboard");
  const [showResetPassword, setShowResetPassword] = useState(false);
  const [resetPasswordResult, setResetPasswordResult] = useState<{password: string; name: string; email: string} | null>(null);

  const [newEmpresa, setNewEmpresa] = useState({
    name: "",
    code: "",
    plan: "basic",
    ownerName: "",
    ownerEmail: "",
    ownerPhone: "",
  });

  const [newUsuario, setNewUsuario] = useState({
    name: "",
    email: "",
    password: "",
    role: "operador",
  });

  if (!isAdmin) {
    navigate("/login");
    return null;
  }

  const { data: stats } = useQuery<DashboardStats>({
    queryKey: ["/api/admin/dashboard"],
    queryFn: async () => {
      const res = await fetch("/api/admin/dashboard", { headers: getAuthHeader() });
      return res.json();
    },
  });

  const { data: empresas = [] } = useQuery<Empresa[]>({
    queryKey: ["/api/admin/empresas"],
    queryFn: async () => {
      const res = await fetch("/api/admin/empresas", { headers: getAuthHeader() });
      return res.json();
    },
  });

  const isSuperadmin = user?.type === "admin" && (user as any).role === "superadmin";

  const { data: allUsuarios = [] } = useQuery<Usuario[]>({
    queryKey: ["/api/admin/all-usuarios"],
    queryFn: async () => {
      const res = await fetch("/api/admin/all-usuarios", { headers: getAuthHeader() });
      return res.json();
    },
    enabled: isSuperadmin,
  });

  const createEmpresaMutation = useMutation({
    mutationFn: async (data: typeof newEmpresa) => {
      const res = await fetch("/api/admin/empresas", {
        method: "POST",
        headers: { "Content-Type": "application/json", ...getAuthHeader() },
        body: JSON.stringify(data),
      });
      if (!res.ok) throw new Error("Erro ao criar empresa");
      return res.json();
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/empresas"] });
      queryClient.invalidateQueries({ queryKey: ["/api/admin/dashboard"] });
      setShowNewEmpresa(false);
      setNewEmpresa({ name: "", code: "", plan: "basic", ownerName: "", ownerEmail: "", ownerPhone: "" });
      toast({ title: "Empresa criada", description: data?.emailDelivery?.sent ? "Empresa criada e credenciais enviadas por email." : "Empresa criada. Configure o email transacional para enviar as credenciais automaticamente." });
    },
    onError: () => {
      toast({ title: "Erro", description: "Erro ao criar empresa", variant: "destructive" });
    },
  });

  const updateEmpresaMutation = useMutation({
    mutationFn: async ({ id, data }: { id: string; data: Partial<Empresa> }) => {
      const res = await fetch(`/api/admin/empresas/${id}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json", ...getAuthHeader() },
        body: JSON.stringify(data),
      });
      if (!res.ok) throw new Error("Erro ao atualizar empresa");
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/empresas"] });
      queryClient.invalidateQueries({ queryKey: ["/api/admin/dashboard"] });
      toast({ title: "Sucesso", description: "Empresa atualizada!" });
    },
  });

  const deleteEmpresaMutation = useMutation({
    mutationFn: async (id: string) => {
      const res = await fetch(`/api/admin/empresas/${id}`, {
        method: "DELETE",
        headers: getAuthHeader(),
      });
      if (!res.ok) throw new Error("Erro ao excluir empresa");
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/empresas"] });
      queryClient.invalidateQueries({ queryKey: ["/api/admin/dashboard"] });
      toast({ title: "Sucesso", description: "Empresa excluída!" });
    },
  });

  const createUsuarioMutation = useMutation({
    mutationFn: async ({ empresaId, data }: { empresaId: string; data: typeof newUsuario }) => {
      const res = await fetch(`/api/admin/empresas/${empresaId}/usuarios`, {
        method: "POST",
        headers: { "Content-Type": "application/json", ...getAuthHeader() },
        body: JSON.stringify(data),
      });
      if (!res.ok) throw new Error("Erro ao criar usuário");
      return res.json();
    },
    onSuccess: () => {
      setShowNewUsuario(false);
      setNewUsuario({ name: "", email: "", password: "", role: "operador" });
      queryClient.invalidateQueries({ queryKey: ["/api/admin/all-usuarios"] });
      queryClient.invalidateQueries({ queryKey: ["/api/admin/dashboard"] });
      toast({ title: "Sucesso", description: "Usuário criado com sucesso!" });
    },
    onError: () => {
      toast({ title: "Erro", description: "Erro ao criar usuário", variant: "destructive" });
    },
  });

  const resetPasswordMutation = useMutation({
    mutationFn: async (userId: string) => {
      const res = await fetch(`/api/admin/usuarios/${userId}/reset-password`, {
        method: "POST",
        headers: { "Content-Type": "application/json", ...getAuthHeader() },
      });
      if (!res.ok) throw new Error("Erro ao resetar senha");
      return res.json();
    },
    onSuccess: (data) => {
      setResetPasswordResult({
        password: data.temporaryPassword,
        name: data.userName,
        email: data.userEmail,
      });
      setShowResetPassword(true);
      toast({ title: "Sucesso", description: "Senha resetada com sucesso!" });
    },
    onError: () => {
      toast({ title: "Erro", description: "Erro ao resetar senha", variant: "destructive" });
    },
  });

  const handleLogout = () => {
    logout();
    navigate("/login");
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "active":
        return <Badge className="bg-green-600"><CheckCircle className="w-3 h-3 mr-1" />Ativa</Badge>;
      case "suspended":
        return <Badge className="bg-red-600"><XCircle className="w-3 h-3 mr-1" />Suspensa</Badge>;
      case "pending":
        return <Badge className="bg-yellow-600"><Clock className="w-3 h-3 mr-1" />Pendente</Badge>;
      default:
        return <Badge>{status}</Badge>;
    }
  };

  const getPlanBadge = (plan: string) => {
    switch (plan) {
      case "basic":
        return <Badge variant="outline">Básico</Badge>;
      case "premium":
        return <Badge className="bg-purple-600">Premium</Badge>;
      case "enterprise":
        return <Badge className="bg-blue-600">Enterprise</Badge>;
      default:
        return <Badge variant="outline">{plan}</Badge>;
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <header className="border-b border-border bg-card">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Shield className="w-8 h-8 text-purple-500" />
            <div>
              <h1 className="text-xl font-bold">Admin Master</h1>
              <p className="text-sm text-muted-foreground">GoFast Produções SaaS</p>
            </div>
          </div>
          <div className="flex items-center gap-4">
            <span className="text-sm text-muted-foreground">
              Olá, <span className="font-semibold">{user?.name}</span>
            </span>
            <Button variant="outline" size="sm" onClick={handleLogout} data-testid="button-logout">
              <LogOut className="w-4 h-4 mr-2" />
              Sair
            </Button>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-6">
        <div className="flex gap-2 mb-6">
          <Button
            variant={activeTab === "dashboard" ? "default" : "outline"}
            onClick={() => setActiveTab("dashboard")}
            data-testid="button-tab-dashboard"
          >
            <LayoutDashboard className="w-4 h-4 mr-2" />
            Dashboard
          </Button>
          <Button
            variant={activeTab === "empresas" ? "default" : "outline"}
            onClick={() => setActiveTab("empresas")}
            data-testid="button-tab-empresas"
          >
            <Building2 className="w-4 h-4 mr-2" />
            Empresas
          </Button>
          {isSuperadmin && (
            <Button
              variant={activeTab === "usuarios" ? "default" : "outline"}
              onClick={() => setActiveTab("usuarios")}
              data-testid="button-tab-usuarios"
            >
              <Users className="w-4 h-4 mr-2" />
              Usuários
            </Button>
          )}
          <Button
            variant={activeTab === "settings" ? "default" : "outline"}
            onClick={() => setActiveTab("settings")}
            data-testid="button-tab-settings"
          >
            <Settings className="w-4 h-4 mr-2" />
            Configurações
          </Button>
        </div>

        {activeTab === "dashboard" && (
          <div className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              <Card className="p-6 bg-gradient-to-br from-blue-900/20 to-blue-800/10 border-blue-600/30">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-blue-400">Total de Empresas</p>
                    <p className="text-3xl font-bold mt-1">{stats?.totalEmpresas || 0}</p>
                  </div>
                  <Building2 className="w-10 h-10 text-blue-500" />
                </div>
              </Card>

              <Card className="p-6 bg-gradient-to-br from-green-900/20 to-green-800/10 border-green-600/30">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-green-400">Empresas Ativas</p>
                    <p className="text-3xl font-bold mt-1">{stats?.empresasAtivas || 0}</p>
                  </div>
                  <CheckCircle className="w-10 h-10 text-green-500" />
                </div>
              </Card>

              <Card className="p-6 bg-gradient-to-br from-red-900/20 to-red-800/10 border-red-600/30">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-red-400">Suspensas</p>
                    <p className="text-3xl font-bold mt-1">{stats?.empresasSuspensas || 0}</p>
                  </div>
                  <XCircle className="w-10 h-10 text-red-500" />
                </div>
              </Card>

              <Card className="p-6 bg-gradient-to-br from-purple-900/20 to-purple-800/10 border-purple-600/30">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-purple-400">Total de Usuários</p>
                    <p className="text-3xl font-bold mt-1">{stats?.totalUsuarios || 0}</p>
                  </div>
                  <Users className="w-10 h-10 text-purple-500" />
                </div>
              </Card>
            </div>

            <Card className="p-6">
              <h3 className="font-semibold mb-4">Distribuição por Plano</h3>
              <div className="grid grid-cols-3 gap-4">
                <div className="text-center p-4 bg-muted rounded-lg">
                  <p className="text-2xl font-bold">{stats?.planos?.basic || 0}</p>
                  <p className="text-sm text-muted-foreground">Básico</p>
                </div>
                <div className="text-center p-4 bg-purple-900/20 rounded-lg">
                  <p className="text-2xl font-bold text-purple-400">{stats?.planos?.premium || 0}</p>
                  <p className="text-sm text-muted-foreground">Premium</p>
                </div>
                <div className="text-center p-4 bg-blue-900/20 rounded-lg">
                  <p className="text-2xl font-bold text-blue-400">{stats?.planos?.enterprise || 0}</p>
                  <p className="text-sm text-muted-foreground">Enterprise</p>
                </div>
              </div>
            </Card>
          </div>
        )}

        {activeTab === "empresas" && (
          <div className="space-y-6">
            <div className="flex justify-between items-center">
              <h2 className="text-2xl font-bold">Empresas Cadastradas</h2>
              <Dialog open={showNewEmpresa} onOpenChange={setShowNewEmpresa}>
                <DialogTrigger asChild>
                  <Button data-testid="button-new-empresa">
                    <Plus className="w-4 h-4 mr-2" />
                    Nova Empresa
                  </Button>
                </DialogTrigger>
                <DialogContent className="max-w-md">
                  <DialogHeader>
                    <DialogTitle>Criar Nova Empresa</DialogTitle>
                  </DialogHeader>
                  <div className="space-y-4 mt-4">
                    <div>
                      <Label>Nome da Empresa</Label>
                      <Input
                        value={newEmpresa.name}
                        onChange={(e) => setNewEmpresa({ ...newEmpresa, name: e.target.value })}
                        placeholder="Ex: Confecções Maria"
                        data-testid="input-empresa-name"
                      />
                    </div>
                    <div>
                      <Label>Código (único)</Label>
                      <Input
                        value={newEmpresa.code}
                        onChange={(e) => setNewEmpresa({ ...newEmpresa, code: e.target.value.toUpperCase() })}
                        placeholder="Ex: MARIA001"
                        data-testid="input-empresa-code"
                      />
                    </div>
                    <div>
                      <Label>Plano</Label>
                      <Select value={newEmpresa.plan} onValueChange={(v) => setNewEmpresa({ ...newEmpresa, plan: v })}>
                        <SelectTrigger data-testid="select-empresa-plan">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="basic">Básico</SelectItem>
                          <SelectItem value="premium">Premium</SelectItem>
                          <SelectItem value="enterprise">Enterprise</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div>
                      <Label>Nome do Proprietário</Label>
                      <Input
                        value={newEmpresa.ownerName}
                        onChange={(e) => setNewEmpresa({ ...newEmpresa, ownerName: e.target.value })}
                        placeholder="Ex: Maria Silva"
                        data-testid="input-empresa-owner-name"
                      />
                    </div>
                    <div>
                      <Label>Email do Proprietário</Label>
                      <Input
                        type="email"
                        value={newEmpresa.ownerEmail}
                        onChange={(e) => setNewEmpresa({ ...newEmpresa, ownerEmail: e.target.value })}
                        placeholder="maria@email.com"
                        data-testid="input-empresa-owner-email"
                      />
                    </div>
                    <div>
                      <Label>Telefone do Proprietário</Label>
                      <Input
                        value={newEmpresa.ownerPhone}
                        onChange={(e) => setNewEmpresa({ ...newEmpresa, ownerPhone: e.target.value })}
                        placeholder="(11) 99999-9999"
                        data-testid="input-empresa-owner-phone"
                      />
                    </div>
                    <Button
                      className="w-full"
                      onClick={() => createEmpresaMutation.mutate(newEmpresa)}
                      disabled={!newEmpresa.name || !newEmpresa.code || createEmpresaMutation.isPending}
                      data-testid="button-submit-empresa"
                    >
                      {createEmpresaMutation.isPending ? "Criando..." : "Criar Empresa"}
                    </Button>
                  </div>
                </DialogContent>
              </Dialog>
            </div>

            <div className="grid gap-4">
              {empresas.map((empresa) => (
                <Card key={empresa.id} className="p-6">
                  <div className="flex items-start justify-between">
                    <div className="space-y-2">
                      <div className="flex items-center gap-3">
                        <h3 className="text-xl font-semibold">{empresa.name}</h3>
                        {getStatusBadge(empresa.status)}
                        {getPlanBadge(empresa.plan)}
                      </div>
                      <div className="text-sm text-muted-foreground space-y-1">
                        <p>Código: <span className="font-mono">{empresa.code}</span></p>
                        <p>Banco: <span className="font-mono text-xs">{empresa.databaseName}</span></p>
                        {empresa.ownerName && <p>Proprietário: {empresa.ownerName}</p>}
                        {empresa.ownerEmail && <p>Email: {empresa.ownerEmail}</p>}
                        <p>Criada em: {new Date(empresa.createdAt).toLocaleDateString("pt-BR")}</p>
                      </div>
                    </div>
                    <div className="flex gap-2">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => {
                          setSelectedEmpresa(empresa);
                          setShowNewUsuario(true);
                        }}
                        data-testid={`button-add-user-${empresa.id}`}
                      >
                        <UserPlus className="w-4 h-4" />
                      </Button>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => {
                          const newStatus = empresa.status === "active" ? "suspended" : "active";
                          updateEmpresaMutation.mutate({ id: empresa.id, data: { status: newStatus } });
                        }}
                        data-testid={`button-toggle-status-${empresa.id}`}
                      >
                        {empresa.status === "active" ? <XCircle className="w-4 h-4" /> : <CheckCircle className="w-4 h-4" />}
                      </Button>
                      <Button
                        variant="destructive"
                        size="sm"
                        onClick={() => {
                          if (confirm("Tem certeza que deseja excluir esta empresa?")) {
                            deleteEmpresaMutation.mutate(empresa.id);
                          }
                        }}
                        data-testid={`button-delete-${empresa.id}`}
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                </Card>
              ))}

              {empresas.length === 0 && (
                <Card className="p-12 text-center">
                  <Building2 className="w-16 h-16 mx-auto text-muted-foreground mb-4" />
                  <h3 className="text-xl font-semibold mb-2">Nenhuma empresa cadastrada</h3>
                  <p className="text-muted-foreground mb-4">Clique no botão acima para criar a primeira empresa</p>
                </Card>
              )}
            </div>
          </div>
        )}

        {activeTab === "usuarios" && isSuperadmin && (
          <div className="space-y-6">
            <div className="flex justify-between items-center">
              <h2 className="text-2xl font-bold">Todos os Usuários</h2>
              <Badge className="bg-purple-600">
                <Shield className="w-3 h-3 mr-1" />
                Acesso Superadmin
              </Badge>
            </div>

            <Card className="overflow-hidden">
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead className="bg-muted">
                    <tr>
                      <th className="px-4 py-3 text-left text-sm font-medium">Nome</th>
                      <th className="px-4 py-3 text-left text-sm font-medium">Email</th>
                      <th className="px-4 py-3 text-left text-sm font-medium">Empresa</th>
                      <th className="px-4 py-3 text-left text-sm font-medium">Cargo</th>
                      <th className="px-4 py-3 text-left text-sm font-medium">Status</th>
                      <th className="px-4 py-3 text-left text-sm font-medium">Último Login</th>
                      <th className="px-4 py-3 text-left text-sm font-medium">Ações</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-border">
                    {allUsuarios.map((usuario) => (
                      <tr key={usuario.id} className="hover:bg-muted/50">
                        <td className="px-4 py-3 text-sm font-medium">{usuario.name}</td>
                        <td className="px-4 py-3 text-sm">{usuario.email}</td>
                        <td className="px-4 py-3 text-sm">
                          <div>
                            <span className="font-medium">{usuario.empresaName}</span>
                            <span className="text-muted-foreground ml-2 font-mono text-xs">({usuario.empresaCode})</span>
                          </div>
                        </td>
                        <td className="px-4 py-3 text-sm">
                          <Badge variant="outline">
                            {usuario.role === "admin_empresa" ? "Admin" : 
                             usuario.role === "operador" ? "Operador" :
                             usuario.role === "financeiro" ? "Financeiro" : "Visualizador"}
                          </Badge>
                        </td>
                        <td className="px-4 py-3 text-sm">
                          {usuario.isActive ? (
                            <Badge className="bg-green-600">Ativo</Badge>
                          ) : (
                            <Badge className="bg-red-600">Inativo</Badge>
                          )}
                        </td>
                        <td className="px-4 py-3 text-sm text-muted-foreground">
                          {usuario.lastLoginAt 
                            ? new Date(usuario.lastLoginAt).toLocaleDateString("pt-BR", { 
                                day: "2-digit", 
                                month: "2-digit", 
                                year: "2-digit",
                                hour: "2-digit",
                                minute: "2-digit"
                              }) 
                            : "Nunca"}
                        </td>
                        <td className="px-4 py-3 text-sm">
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => resetPasswordMutation.mutate(usuario.id)}
                            disabled={resetPasswordMutation.isPending}
                            data-testid={`button-reset-password-${usuario.id}`}
                          >
                            <KeyRound className="w-4 h-4 mr-1" />
                            Resetar Senha
                          </Button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

              {allUsuarios.length === 0 && (
                <div className="p-12 text-center">
                  <Users className="w-16 h-16 mx-auto text-muted-foreground mb-4" />
                  <h3 className="text-xl font-semibold mb-2">Nenhum usuário cadastrado</h3>
                  <p className="text-muted-foreground">Crie empresas e adicione usuários a elas</p>
                </div>
              )}
            </Card>

            <Card className="p-6 bg-yellow-900/20 border-yellow-600/30">
              <div className="flex items-start gap-3">
                <Shield className="w-6 h-6 text-yellow-500 flex-shrink-0 mt-1" />
                <div>
                  <h4 className="font-semibold text-yellow-400">Informação de Segurança</h4>
                  <p className="text-sm text-muted-foreground mt-1">
                    As senhas dos usuários são armazenadas de forma segura (hash). Para acessar uma conta, 
                    você pode resetar a senha do usuário e uma nova senha temporária será gerada e exibida.
                    Informe a nova senha ao usuário para que ele possa acessar o sistema.
                  </p>
                </div>
              </div>
            </Card>
          </div>
        )}

        {activeTab === "settings" && (
          <Card className="p-6">
            <h2 className="text-2xl font-bold mb-4">Configurações do Sistema</h2>
            <p className="text-muted-foreground">Configurações avançadas em desenvolvimento...</p>
          </Card>
        )}
      </div>

      <Dialog open={showNewUsuario} onOpenChange={setShowNewUsuario}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Novo Usuário - {selectedEmpresa?.name}</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 mt-4">
            <div>
              <Label>Nome</Label>
              <Input
                value={newUsuario.name}
                onChange={(e) => setNewUsuario({ ...newUsuario, name: e.target.value })}
                placeholder="Nome completo"
                data-testid="input-usuario-name"
              />
            </div>
            <div>
              <Label>Email</Label>
              <Input
                type="email"
                value={newUsuario.email}
                onChange={(e) => setNewUsuario({ ...newUsuario, email: e.target.value })}
                placeholder="email@empresa.com"
                data-testid="input-usuario-email"
              />
            </div>
            <div>
              <Label>Senha</Label>
              <Input
                type="password"
                value={newUsuario.password}
                onChange={(e) => setNewUsuario({ ...newUsuario, password: e.target.value })}
                placeholder="********"
                data-testid="input-usuario-password"
              />
            </div>
            <div>
              <Label>Cargo</Label>
              <Select value={newUsuario.role} onValueChange={(v) => setNewUsuario({ ...newUsuario, role: v })}>
                <SelectTrigger data-testid="select-usuario-role">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="admin_empresa">Admin da Empresa</SelectItem>
                  <SelectItem value="operador">Operador</SelectItem>
                  <SelectItem value="financeiro">Financeiro</SelectItem>
                  <SelectItem value="visualizador">Visualizador</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <Button
              className="w-full"
              onClick={() => {
                if (selectedEmpresa) {
                  createUsuarioMutation.mutate({ empresaId: selectedEmpresa.id, data: newUsuario });
                }
              }}
              disabled={!newUsuario.name || !newUsuario.email || !newUsuario.password || createUsuarioMutation.isPending}
              data-testid="button-submit-usuario"
            >
              {createUsuarioMutation.isPending ? "Criando..." : "Criar Usuário"}
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      <Dialog open={showResetPassword} onOpenChange={setShowResetPassword}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Senha Resetada com Sucesso</DialogTitle>
          </DialogHeader>
          {resetPasswordResult && (
            <div className="space-y-4 mt-4">
              <div className="p-4 bg-green-900/20 border border-green-600/30 rounded-lg">
                <p className="text-sm text-green-400 mb-2">Nova senha gerada para:</p>
                <p className="font-semibold">{resetPasswordResult.name}</p>
                <p className="text-sm text-muted-foreground">{resetPasswordResult.email}</p>
              </div>
              
              <div className="space-y-2">
                <Label>Nova Senha Temporária</Label>
                <div className="flex gap-2">
                  <Input
                    readOnly
                    value={resetPasswordResult.password}
                    className="font-mono text-lg"
                    data-testid="input-new-password"
                  />
                  <Button
                    variant="outline"
                    size="icon"
                    onClick={() => {
                      navigator.clipboard.writeText(resetPasswordResult.password);
                      toast({ title: "Copiado!", description: "Senha copiada para a área de transferência" });
                    }}
                    data-testid="button-copy-password"
                  >
                    <Copy className="w-4 h-4" />
                  </Button>
                </div>
              </div>

              <div className="p-3 bg-yellow-900/20 border border-yellow-600/30 rounded-lg">
                <p className="text-sm text-yellow-400">
                  Importante: Anote ou copie esta senha agora. Ela não será exibida novamente.
                  O usuário deve alterar a senha após o primeiro login.
                </p>
              </div>

              <Button
                className="w-full"
                onClick={() => {
                  setShowResetPassword(false);
                  setResetPasswordResult(null);
                }}
                data-testid="button-close-reset-dialog"
              >
                Fechar
              </Button>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
