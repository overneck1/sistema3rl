import { useState } from "react";
import { useLocation } from "wouter";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useAuth } from "@/lib/auth";
import { Building2, Shield, Loader2 } from "lucide-react";

export default function LoginPage() {
  const [, navigate] = useLocation();
  const { login } = useAuth();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [loginType, setLoginType] = useState<"admin" | "usuario">("usuario");
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState("");

  const demoEmpresa = { email: "demo@3rltextil.com", password: "demo123" };
  const demoAdmin = { email: "admin@gofast.com", password: "admin123" };

  const submitLogin = async (nextEmail: string, nextPassword: string, nextType: "admin" | "usuario") => {
    setError("");
    setIsLoading(true);
    const success = await login(nextEmail, nextPassword, nextType);
    setIsLoading(false);
    if (success) {
      navigate(nextType === "admin" ? "/admin" : "/");
      return;
    }
    setError("Email ou senha inválidos");
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    await submitLogin(email, password, loginType);
  };

  const fillDemo = (type: "admin" | "usuario") => {
    const creds = type === "admin" ? demoAdmin : demoEmpresa;
    setLoginType(type);
    setEmail(creds.email);
    setPassword(creds.password);
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900 p-4">
      <Card className="w-full max-w-md p-8">
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold bg-gradient-to-r from-cyan-400 to-purple-500 bg-clip-text text-transparent">
            GoFast Produções
          </h1>
          <p className="text-muted-foreground mt-2">Sistema de Gestão de Produção</p>
        </div>

        <div className="flex gap-2 mb-6">
          <Button
            type="button"
            variant={loginType === "usuario" ? "default" : "outline"}
            className="flex-1"
            onClick={() => setLoginType("usuario")}
            data-testid="button-login-usuario"
          >
            <Building2 className="w-4 h-4 mr-2" />
            Empresa
          </Button>
          <Button
            type="button"
            variant={loginType === "admin" ? "default" : "outline"}
            className="flex-1"
            onClick={() => setLoginType("admin")}
            data-testid="button-login-admin"
          >
            <Shield className="w-4 h-4 mr-2" />
            Admin Master
          </Button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <Label htmlFor="email">Email</Label>
            <Input
              id="email"
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="seu@email.com"
              required
              data-testid="input-email"
            />
          </div>

          <div>
            <Label htmlFor="password">Senha</Label>
            <Input
              id="password"
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="********"
              required
              data-testid="input-password"
            />
          </div>

          {error && (
            <div className="text-red-500 text-sm text-center" data-testid="text-error">
              {error}
            </div>
          )}

          <Button type="submit" className="w-full" disabled={isLoading} data-testid="button-submit-login">
            {isLoading ? (
              <>
                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                Entrando...
              </>
            ) : (
              "Entrar"
            )}
          </Button>
        </form>

        <div className="mt-6 rounded-lg border bg-muted/40 p-4 space-y-3" data-testid="demo-credentials">
          <p className="text-sm font-semibold text-foreground">Conta de demonstração</p>
          <p className="text-xs text-muted-foreground">
            Use estas credenciais para avaliar produções, lotes, costureiras e finanças.
          </p>
          <div className="text-sm space-y-1">
            <p><span className="text-muted-foreground">Email:</span> {demoEmpresa.email}</p>
            <p><span className="text-muted-foreground">Senha:</span> {demoEmpresa.password}</p>
            <p><span className="text-muted-foreground">Tipo:</span> Empresa</p>
          </div>
          <Button
            type="button"
            className="w-full"
            variant="secondary"
            disabled={isLoading}
            onClick={() => {
              fillDemo("usuario");
              void submitLogin(demoEmpresa.email, demoEmpresa.password, "usuario");
            }}
            data-testid="button-demo-login"
          >
            Entrar com conta de demonstração
          </Button>
          <p className="text-xs text-muted-foreground">
            Admin Master: {demoAdmin.email} / {demoAdmin.password}
          </p>
        </div>
      </Card>
    </div>
  );
}
