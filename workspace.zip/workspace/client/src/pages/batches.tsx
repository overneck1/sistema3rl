import { getAuthHeader } from "../lib/auth";
import React, { useState, useMemo, useEffect, useRef } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { apiRequest } from "@/lib/queryClient";
import { queryClient } from "@/lib/queryClient";
import { Plus, Edit2, Trash2, Printer, Check, ChevronDown, ChevronUp, Package } from "lucide-react";
import { Progress } from "@/components/ui/progress";
import { useToast } from "@/hooks/use-toast";
import { PrintFormatDialog, PrintFormat, getCupomBaseStyles, printContent as printHtml } from "@/components/print-format-dialog";

const brl=(n:number)=>new Intl.NumberFormat("pt-BR",{style:"currency",currency:"BRL"}).format(Number(n||0));

interface VariationAllocation {
  variantId: string;
  size: string;
  color: string;
  availableQty: number;
  allocatedQty: number;
  maxQty: number; // Máximo permitido: disponível + alocação atual
}

const BatchDeliveriesSection = ({ batchId, totalQuantity, pricePerUnit }: { batchId: string; totalQuantity: number; pricePerUnit: number }) => {
  const { data: deliveries = [], isLoading } = useQuery<any[]>({
    queryKey: ["/api/batch-deliveries", batchId],
  });

  const totalDelivered = (deliveries as any[]).reduce((sum, d) => sum + (d.deliveredQuantity || 0), 0);
  const remaining = totalQuantity - totalDelivered;
  const progressPercent = totalQuantity > 0 ? (totalDelivered / totalQuantity) * 100 : 0;
  const deliveredValue = totalDelivered * pricePerUnit;

  if (isLoading) {
    return <p className="text-xs text-muted-foreground">Carregando...</p>;
  }

  return (
    <div className="space-y-2">
      <div className="flex items-center gap-2">
        <Progress value={progressPercent} className="flex-1 h-2" />
        <span className="text-xs font-semibold whitespace-nowrap">{totalDelivered}/{totalQuantity}</span>
      </div>
      <div className="flex justify-between text-xs">
        <span className="text-muted-foreground">Entregue: <span className="font-semibold text-foreground">{totalDelivered} un.</span></span>
        <span className="text-muted-foreground">Pendente: <span className="font-semibold text-orange-600">{remaining} un.</span></span>
      </div>
      <p className="text-xs text-muted-foreground">
        Valor entregue: <span className="font-semibold text-green-600">R$ {deliveredValue.toFixed(2)}</span>
      </p>
      {deliveries.length > 0 && (
        <div className="text-xs border rounded p-2 bg-muted/30 space-y-1 max-h-24 overflow-y-auto">
          {(deliveries as any[]).map((d, idx) => (
            <div key={d.id || idx} className="flex justify-between">
              <span>{new Date(d.deliveredAt).toLocaleDateString('pt-BR')}</span>
              <span className="font-semibold">{d.deliveredQuantity} un.</span>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

const Batches = () => {
  const { toast } = useToast();
  const [isOpen, setIsOpen] = useState(false);
  const [editingBatchId, setEditingBatchId] = useState<string | null>(null);
  const [selectedProductionId, setSelectedProductionId] = useState("");
  const [variantAllocations, setVariantAllocations] = useState<VariationAllocation[]>([]);
  const [expandedBatches, setExpandedBatches] = useState<Set<string>>(new Set());
  const [expandedAvailableProductions, setExpandedAvailableProductions] = useState<Set<string>>(new Set());
  const [deliveryDialogBatchId, setDeliveryDialogBatchId] = useState<string | null>(null);
  const [deliveryQuantity, setDeliveryQuantity] = useState("");
  const [deliveryNotes, setDeliveryNotes] = useState("");
  const [formData, setFormData] = useState({
    productionId: "",
    seamstressId: "",
    assignmentType: "external",
    sendDate: new Date().toISOString().split("T")[0],
    expectedReturnDate: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString().split("T")[0],
    pricePerUnit: 0,
  });
  
  // Print format dialog states
  const [printFormatDialogOpen, setPrintFormatDialogOpen] = useState(false);
  const [pendingPrintAction, setPendingPrintAction] = useState<{ type: 'column' | 'batch', data: any } | null>(null);

  useEffect(() => {
    const scrollToBatchId = localStorage.getItem("scrollToBatchId");
    if (scrollToBatchId) {
      setExpandedBatches(new Set([scrollToBatchId]));
      localStorage.removeItem("scrollToBatchId");
      setTimeout(() => {
        const element = document.querySelector(`[data-testid="card-batch-${scrollToBatchId}"]`);
        if (element) {
          element.scrollIntoView({ behavior: "smooth", block: "center" });
        }
      }, 100);
    }
  }, []);

  const { data: batches = [] } = useQuery({
    queryKey: ["/api/tenant/batches"],
  });

  const { data: productions = [] } = useQuery({
    queryKey: ["/api/tenant/productions"],
  });

  const { data: seamstresses = [] } = useQuery({
    queryKey: ["/api/tenant/seamstresses"],
  });

  const { data: internalCostData } = useQuery<any>({
    queryKey: ["/api/internal-costs/dashboard"],
  });
  const internalDailyCost = Number(internalCostData?.summary?.daily || 0);

  // Fetch open productions with available quantities
  const { data: openProductions = [] } = useQuery<any[]>({
    queryKey: ["/api/tenant/productions/available"],
  });

  // Fetch ALL variants for all productions using the global endpoint
  const { data: allVariants = [], isLoading: variantsLoading } = useQuery<any[]>({
    queryKey: ["/api/tenant/variants"],
    staleTime: 60000,
    gcTime: 300000,
  });


  const { data: variants = [] } = useQuery<any[]>({
    queryKey: ["/api/tenant/productions", selectedProductionId, "variants"],
    enabled: !!selectedProductionId,
  });

  const { data: existingAllocations = [] } = useQuery<any[]>({
    queryKey: ["/api/tenant/batches", editingBatchId, "allocations"],
    enabled: !!editingBatchId,
  });

  const openPrintColumnDialog = (status: string, columnBatches: any[]) => {
    setPendingPrintAction({ type: 'column', data: { status, columnBatches } });
    setPrintFormatDialogOpen(true);
  };

  const openPrintBatchDialog = (batch: any) => {
    setPendingPrintAction({ type: 'batch', data: batch });
    setPrintFormatDialogOpen(true);
  };

  const handlePrintFormatSelect = async (format: PrintFormat) => {
    if (!pendingPrintAction) return;
    
    if (pendingPrintAction.type === 'column') {
      await handlePrintColumn(pendingPrintAction.data.status, pendingPrintAction.data.columnBatches, format);
    } else if (pendingPrintAction.type === 'batch') {
      await handlePrintBatch(pendingPrintAction.data, format);
    }
    
    setPendingPrintAction(null);
  };

  const handlePrintColumn = async (status: string, columnBatches: any[], format: PrintFormat = 'a4') => {
    const statusLabel = statusLabels[status] || status;
    
    const batchesWithAllocations = await Promise.all(
      columnBatches.map(async (batch) => {
        try {
          const allocationsRes = await fetch(`/api/tenant/batches/${batch.id}/allocations`, { headers: getAuthHeader() });
          const allocations = await allocationsRes.json();
          
          const variantsRes = await fetch(`/api/tenant/productions/${batch.productionId}/variants`, { headers: getAuthHeader() });
          const productionVariants = await variantsRes.json();
          
          const variantDetails = allocations.map((alloc: any) => {
            const variant = productionVariants.find((v: any) => v.id === alloc.variantId);
            return {
              size: variant?.size || 'N/A',
              color: variant?.color || 'N/A',
              quantity: alloc.quantity,
            };
          });
          
          const production = (productions as any[]).find((p: any) => p.id === batch.productionId);
          const seamstress = (seamstresses as any[]).find((s: any) => s.id === batch.seamstressId);
          
          return { ...batch, variantDetails, production, seamstress };
        } catch (error) {
          return null;
        }
      })
    );
    
    const validBatches = batchesWithAllocations.filter(b => b !== null);
    const batchesPerPage = 3;
    const pages = Math.ceil(validBatches.length / batchesPerPage);
    
    const formatDate = (dateString: string) => {
      if (!dateString) return 'N/A';
      if (dateString.length === 10) {
        const [year, month, day] = dateString.split('-');
        return `${day}/${month}/${year}`;
      }
      const [datePart] = dateString.split('T');
      const [year, month, day] = datePart.split('-');
      return `${day}/${month}/${year}`;
    };

    // Cupom fiscal format
    if (format === 'cupom') {
      let cupomContent = `<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8">
  <title>Cupom - ${statusLabel}</title>
  <style>${getCupomBaseStyles()}</style>
</head>
<body>`;
      
      validBatches.forEach((batch) => {
        const totalValue = batch.quantity * parseFloat(batch.pricePerUnit);
        const sendDate = formatDate(batch.sendDate);
        const expDate = formatDate(batch.expectedReturnDate);
        
        cupomContent += `
  <div class="container" style="page-break-after: always;">
    <div class="header">
      <h1>GOFAST</h1>
      <p>${statusLabel}</p>
    </div>
    <div class="divider"></div>
    <div class="section">
      <div class="section-title">Lote</div>
      <div class="row"><span class="row-label">Código:</span><span class="row-value">${batch.batchCode}</span></div>
      <div class="row"><span class="row-label">Produto:</span><span class="row-value">${batch.production?.productName || 'N/A'}</span></div>
    </div>
    <div class="divider"></div>
    <div class="section">
      <div class="section-title">Costureira</div>
      <div class="row"><span class="row-label">Nome:</span><span class="row-value">${batch.seamstress?.name || 'N/A'}</span></div>
      <div class="row"><span class="row-label">Tel:</span><span class="row-value">${batch.seamstress?.phone || 'N/A'}</span></div>
      ${batch.seamstress?.neighborhood ? `<div class="row"><span class="row-label">Bairro:</span><span class="row-value">${batch.seamstress.neighborhood}</span></div>` : ''}
    </div>
    <div class="divider"></div>
    <div class="section">
      <div class="section-title">Datas</div>
      <div class="row"><span class="row-label">Envio:</span><span class="row-value">${sendDate}</span></div>
      <div class="row"><span class="row-label">Previsão:</span><span class="row-value">${expDate}</span></div>
    </div>
    <div class="divider"></div>
    <div class="section">
      <div class="section-title">Itens</div>
      ${batch.variantDetails.map((v: any) => `
      <div class="row"><span>${v.size} / ${v.color}</span><span class="row-value">${v.quantity} un</span></div>
      `).join('')}
    </div>
    <div class="total-row">
      <span>TOTAL</span>
      <span>${batch.quantity} un</span>
    </div>
    <div class="total-row">
      <span>VALOR</span>
      <span>R$ ${totalValue.toFixed(2)}</span>
    </div>
    <div class="footer">
      <p>${new Date().toLocaleString('pt-BR')}</p>
    </div>
  </div>`;
      });
      
      cupomContent += `</body></html>`;
      printHtml(cupomContent);
      return;
    }
    
    let printContent = `<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Impressão - ${statusLabel}</title>
  <style>
    * { margin: 0; padding: 0; box-sizing: border-box; }
    body { 
      font-family: 'Segoe UI', Arial, sans-serif; 
      background: #fff; 
      color: #000; 
      line-height: 1.3;
      -webkit-print-color-adjust: exact;
      print-color-adjust: exact;
    }
    @page { 
      margin: 8mm; 
      size: A4 portrait;
    }
    .page {
      width: 100%;
      min-height: 100vh;
      padding: 5mm;
      display: flex;
      flex-direction: column;
      page-break-after: always;
    }
    .page:last-child { page-break-after: avoid; }
    .page-header {
      text-align: center;
      margin-bottom: 8mm;
      padding-bottom: 4mm;
      border-bottom: 3px solid #8B5CF6;
    }
    .page-header h1 {
      font-size: 24px;
      font-weight: 700;
      color: #1F2937;
      text-transform: uppercase;
      letter-spacing: 1px;
    }
    .page-header .subtitle {
      font-size: 14px;
      color: #6B7280;
      margin-top: 4px;
    }
    .card {
      border: 2px solid #E5E7EB;
      border-radius: 8px;
      margin-bottom: 6mm;
      page-break-inside: avoid;
      overflow: hidden;
      box-shadow: 0 1px 3px rgba(0,0,0,0.1);
    }
    .card-header {
      background: linear-gradient(135deg, #8B5CF6 0%, #6366F1 100%);
      color: white;
      padding: 10px 15px;
      display: flex;
      justify-content: space-between;
      align-items: center;
    }
    .prod-name {
      font-size: 18px;
      font-weight: 700;
      text-transform: uppercase;
      letter-spacing: 0.5px;
    }
    .batch-code {
      font-size: 14px;
      font-weight: 600;
      background: rgba(255,255,255,0.2);
      padding: 4px 10px;
      border-radius: 4px;
    }
    .seamstress-row {
      background: #F3F4F6;
      padding: 10px 15px;
      border-bottom: 1px solid #E5E7EB;
      display: flex;
      justify-content: space-between;
      align-items: center;
    }
    .seamstress-info {
      display: flex;
      flex-direction: column;
    }
    .seamstress-label {
      font-size: 11px;
      font-weight: 600;
      color: #6B7280;
      text-transform: uppercase;
      letter-spacing: 0.5px;
    }
    .seamstress-name {
      font-size: 16px;
      font-weight: 700;
      color: #1F2937;
    }
    .seamstress-phone {
      font-size: 14px;
      color: #4B5563;
      font-weight: 500;
    }
    .card-body {
      padding: 12px 15px;
    }
    .info-grid {
      display: grid;
      grid-template-columns: repeat(4, 1fr);
      gap: 12px;
      margin-bottom: 12px;
    }
    .info-box {
      background: #F9FAFB;
      border: 1px solid #E5E7EB;
      border-radius: 6px;
      padding: 8px 10px;
    }
    .info-box.highlight {
      background: linear-gradient(135deg, #8B5CF6 0%, #6366F1 100%);
      border: none;
      color: white;
    }
    .info-box .label {
      font-size: 10px;
      font-weight: 600;
      color: #6B7280;
      text-transform: uppercase;
      letter-spacing: 0.3px;
    }
    .info-box.highlight .label {
      color: rgba(255,255,255,0.8);
    }
    .info-box .value {
      font-size: 14px;
      font-weight: 700;
      color: #1F2937;
      margin-top: 2px;
    }
    .info-box.highlight .value {
      color: white;
    }
    .section-title {
      font-size: 12px;
      font-weight: 700;
      color: #374151;
      text-transform: uppercase;
      letter-spacing: 0.5px;
      margin-bottom: 8px;
      padding-bottom: 4px;
      border-bottom: 2px solid #E5E7EB;
    }
    .address-box {
      background: #FEF3C7;
      border: 1px solid #F59E0B;
      border-radius: 6px;
      padding: 10px 12px;
      margin-bottom: 12px;
    }
    .address-box .neighborhood {
      font-size: 14px;
      font-weight: 700;
      color: #92400E;
      text-transform: uppercase;
      margin-bottom: 4px;
    }
    .address-box .address {
      font-size: 13px;
      color: #78350F;
    }
    .variants-table {
      width: 100%;
      border-collapse: collapse;
      font-size: 13px;
    }
    .variants-table thead {
      background: #8B5CF6;
      color: white;
    }
    .variants-table th {
      padding: 8px 10px;
      text-align: left;
      font-weight: 600;
      font-size: 12px;
      text-transform: uppercase;
      letter-spacing: 0.3px;
    }
    .variants-table th:last-child {
      text-align: right;
    }
    .variants-table td {
      padding: 8px 10px;
      border-bottom: 1px solid #E5E7EB;
    }
    .variants-table td:last-child {
      text-align: right;
      font-weight: 700;
    }
    .variants-table tbody tr:nth-child(even) {
      background: #F9FAFB;
    }
    .page-footer {
      margin-top: auto;
      padding-top: 4mm;
      border-top: 1px solid #E5E7EB;
      text-align: center;
      font-size: 11px;
      color: #9CA3AF;
    }
    @media print {
      body { margin: 0; padding: 0; }
      .page { padding: 0; min-height: auto; }
      .card { box-shadow: none; }
    }
  </style>
</head>
<body>`;
    
    for (let pageNum = 0; pageNum < pages; pageNum++) {
      const start = pageNum * batchesPerPage;
      const end = Math.min(start + batchesPerPage, validBatches.length);
      const pageBatches = validBatches.slice(start, end);
      
      printContent += `
  <div class="page">
    <div class="page-header">
      <h1>GoFast Produções</h1>
      <div class="subtitle">${statusLabel} - ${validBatches.length} lotes</div>
    </div>`;
      
      pageBatches.forEach((batch) => {
        const totalValue = batch.quantity * parseFloat(batch.pricePerUnit);
        const address = batch.seamstress?.address || 'Não informado';
        const neighborhood = batch.seamstress?.neighborhood || '';
        const phone = batch.seamstress?.phone || 'N/A';
        const sendDate = formatDate(batch.sendDate);
        const expDate = formatDate(batch.expectedReturnDate);
        
        printContent += `
    <div class="card">
      <div class="card-header">
        <span class="prod-name">${batch.production?.productName || 'SEM NOME'}</span>
        <span class="batch-code">${batch.batchCode}</span>
      </div>
      <div class="seamstress-row">
        <div class="seamstress-info">
          <span class="seamstress-label">Costureira</span>
          <span class="seamstress-name">${batch.seamstress?.name || 'N/A'}</span>
        </div>
        <span class="seamstress-phone">${phone}</span>
      </div>
      <div class="card-body">
        <div class="info-grid">
          <div class="info-box highlight">
            <div class="label">Envio</div>
            <div class="value">${sendDate}</div>
          </div>
          <div class="info-box highlight">
            <div class="label">Previsão</div>
            <div class="value">${expDate}</div>
          </div>
          <div class="info-box">
            <div class="label">Quantidade</div>
            <div class="value">${batch.quantity} peças</div>
          </div>
          <div class="info-box">
            <div class="label">Valor Total</div>
            <div class="value">R$ ${totalValue.toFixed(2)}</div>
          </div>
        </div>
        
        ${neighborhood || address !== 'Não informado' ? `
        <div class="address-box">
          ${neighborhood ? `<div class="neighborhood">${neighborhood}</div>` : ''}
          <div class="address">${address}</div>
        </div>
        ` : ''}
        
        <div class="section-title">Variações do Lote</div>
        <table class="variants-table">
          <thead>
            <tr>
              <th>Tamanho</th>
              <th>Cor</th>
              <th>Qtd</th>
            </tr>
          </thead>
          <tbody>
            ${batch.variantDetails.map((v: any) => `
            <tr>
              <td>${v.size}</td>
              <td>${v.color}</td>
              <td>${v.quantity}</td>
            </tr>
            `).join('')}
          </tbody>
        </table>
      </div>
    </div>`;
      });
      
      printContent += `
    <div class="page-footer">
      ${statusLabel} - Página ${pageNum + 1} de ${pages} • Impresso em ${new Date().toLocaleString('pt-BR')}
    </div>
  </div>`;
    }
    
    printContent += `
</body>
</html>`;
    
    printHtml(printContent);
  };

  const handlePrintBatch = async (batch: any, format: PrintFormat = 'a4') => {
    const productionData = Array.isArray(productions) ? (productions as any[]).find((p: any) => p.id === batch.productionId) : undefined;
    const seamstressData = Array.isArray(seamstresses) ? (seamstresses as any[]).find((s: any) => s.id === batch.seamstressId) : undefined;
    const batchIsInternal = batch.assignmentType === 'internal';
    
    const allocationsRes = await fetch(`/api/tenant/batches/${batch.id}/allocations`, { headers: getAuthHeader() });
    const allocations = await allocationsRes.json();
    
    const variantsRes = await fetch(`/api/tenant/productions/${batch.productionId}/variants`, { headers: getAuthHeader() });
    const productionVariants = await variantsRes.json();
    
    let variantDetails: any[] = [];
    
    if (allocations && allocations.length > 0) {
      variantDetails = allocations.map((alloc: any) => {
        const variant = productionVariants.find((v: any) => v.id === alloc.variantId);
        return {
          size: variant?.size || 'N/A',
          color: variant?.color || 'N/A',
          quantity: alloc.quantity,
          value: parseFloat(batch.pricePerUnit) * alloc.quantity,
        };
      });
    } else if (productionVariants && productionVariants.length > 0) {
      variantDetails = productionVariants.map((v: any) => ({
        size: v.size || 'N/A',
        color: v.color || 'N/A',
        quantity: v.quantity || 0,
        value: parseFloat(batch.pricePerUnit) * (v.quantity || 0),
      }));
    }

    const totalValue = batch.quantity * parseFloat(batch.pricePerUnit);
    const formatDate = (dateString: string) => {
      if (!dateString) return 'N/A';
      if (dateString.length === 10) {
        const [year, month, day] = dateString.split('-');
        return `${day}/${month}/${year}`;
      }
      const [datePart] = dateString.split('T');
      const [year, month, day] = datePart.split('-');
      return `${day}/${month}/${year}`;
    };
    const sendDate = formatDate(batch.sendDate);
    const expectedReturnDate = formatDate(batch.expectedReturnDate);

    // Cupom fiscal format for single batch
    if (format === 'cupom') {
      const cupomContent = `<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8">
  <title>Cupom - ${batch.batchCode}</title>
  <style>${getCupomBaseStyles()}</style>
</head>
<body>
  <div class="container">
    <div class="header">
      <h1>GOFAST</h1>
      <p>Etiqueta de Lote</p>
    </div>
    <div class="divider"></div>
    <div class="section">
      <div class="section-title">Lote</div>
      <div class="row"><span class="row-label">Código:</span><span class="row-value">${batch.batchCode}</span></div>
      <div class="row"><span class="row-label">Produto:</span><span class="row-value">${productionData?.productName || 'N/A'}</span></div>
    </div>
    <div class="divider"></div>
    <div class="section">
      <div class="section-title">Costureira</div>
      <div class="row"><span class="row-label">Nome:</span><span class="row-value">${seamstressData?.name || 'N/A'}</span></div>
      <div class="row"><span class="row-label">Tel:</span><span class="row-value">${seamstressData?.phone || 'N/A'}</span></div>
      ${seamstressData?.neighborhood ? `<div class="row"><span class="row-label">Bairro:</span><span class="row-value">${seamstressData.neighborhood}</span></div>` : ''}
      ${seamstressData?.address ? `<div class="row"><span class="row-label">End:</span><span class="row-value">${seamstressData.address}</span></div>` : ''}
    </div>
    <div class="divider"></div>
    <div class="section">
      <div class="section-title">Datas</div>
      <div class="row"><span class="row-label">Envio:</span><span class="row-value">${sendDate}</span></div>
      <div class="row"><span class="row-label">Previsão:</span><span class="row-value">${expectedReturnDate}</span></div>
    </div>
    <div class="divider"></div>
    <div class="section">
      <div class="section-title">VARIANTES</div>
      ${variantDetails.length > 0 ? `
      <table style="width:100%; border-collapse:collapse; margin-top:2mm;">
        <thead>
          <tr style="border-bottom:2px solid #000;">
            <th style="text-align:left; padding:2mm 1mm; font-size:14px; font-weight:bold;">COR</th>
            <th style="text-align:center; padding:2mm 1mm; font-size:14px; font-weight:bold;">TAM</th>
            <th style="text-align:right; padding:2mm 1mm; font-size:14px; font-weight:bold;">QTD</th>
          </tr>
        </thead>
        <tbody>
          ${variantDetails.map((v: any) => `
          <tr style="border-bottom:1px dotted #666;">
            <td style="text-align:left; padding:2mm 1mm; font-size:13px; font-weight:bold;">${v.color}</td>
            <td style="text-align:center; padding:2mm 1mm; font-size:13px; font-weight:bold;">${v.size}</td>
            <td style="text-align:right; padding:2mm 1mm; font-size:14px; font-weight:bold;">${v.quantity}</td>
          </tr>`).join('')}
        </tbody>
      </table>
      ` : '<div class="row"><span>Sem variantes cadastradas</span></div>'}
    </div>
    <div class="divider"></div>
    <div class="total-row" style="font-size:18px;">
      <span>TOTAL PEÇAS</span>
      <span>${batch.quantity}</span>
    </div>
    <div class="total-row">
      <span>VALOR UNIT.</span>
      <span>R$ ${parseFloat(batch.pricePerUnit).toFixed(2)}</span>
    </div>
    <div class="total-row">
      <span>VALOR TOTAL</span>
      <span>R$ ${totalValue.toFixed(2)}</span>
    </div>
    <div class="footer">
      <p>${new Date().toLocaleString('pt-BR')}</p>
    </div>
  </div>
</body>
</html>`;
      printHtml(cupomContent);
      return;
    }

    const printContent = `<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Etiqueta de Lote - ${batch.batchCode}</title>
  <style>
    * { margin: 0; padding: 0; box-sizing: border-box; }
    body {
      font-family: 'Segoe UI', Arial, sans-serif;
      background: #fff;
      color: #000;
      line-height: 1.4;
      -webkit-print-color-adjust: exact;
      print-color-adjust: exact;
    }
    @page { 
      margin: 10mm; 
      size: A4 portrait;
    }
    .container {
      max-width: 210mm;
      min-height: 297mm;
      margin: 0 auto;
      padding: 15mm;
      display: flex;
      flex-direction: column;
    }
    .header {
      text-align: center;
      margin-bottom: 20px;
      padding-bottom: 15px;
      border-bottom: 4px solid #8B5CF6;
    }
    .header .company {
      font-size: 14px;
      font-weight: 600;
      color: #6B7280;
      text-transform: uppercase;
      letter-spacing: 2px;
      margin-bottom: 8px;
    }
    .header h1 {
      font-size: 28px;
      font-weight: 800;
      color: #1F2937;
      text-transform: uppercase;
      letter-spacing: 1px;
    }
    .header .batch-code {
      display: inline-block;
      margin-top: 10px;
      background: linear-gradient(135deg, #8B5CF6 0%, #6366F1 100%);
      color: white;
      padding: 8px 20px;
      border-radius: 6px;
      font-size: 18px;
      font-weight: 700;
      letter-spacing: 1px;
    }
    .main-info {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 15px;
      margin-bottom: 20px;
    }
    .info-card {
      background: #F9FAFB;
      border: 2px solid #E5E7EB;
      border-radius: 10px;
      padding: 15px;
    }
    .info-card.large {
      grid-column: 1 / -1;
    }
    .info-card .label {
      font-size: 12px;
      font-weight: 700;
      color: #6B7280;
      text-transform: uppercase;
      letter-spacing: 0.5px;
      margin-bottom: 6px;
    }
    .info-card .value {
      font-size: 18px;
      font-weight: 700;
      color: #1F2937;
    }
    .info-card .value.large {
      font-size: 22px;
    }
    .dates-row {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 15px;
      margin-bottom: 20px;
    }
    .date-card {
      background: linear-gradient(135deg, #8B5CF6 0%, #6366F1 100%);
      border-radius: 10px;
      padding: 15px;
      color: white;
      text-align: center;
    }
    .date-card .label {
      font-size: 12px;
      font-weight: 600;
      color: rgba(255,255,255,0.85);
      text-transform: uppercase;
      letter-spacing: 0.5px;
      margin-bottom: 6px;
    }
    .date-card .value {
      font-size: 22px;
      font-weight: 800;
    }
    .section-title {
      font-size: 14px;
      font-weight: 700;
      color: #374151;
      text-transform: uppercase;
      letter-spacing: 1px;
      margin-bottom: 12px;
      padding-bottom: 8px;
      border-bottom: 3px solid #E5E7EB;
    }
    .variants-table {
      width: 100%;
      border-collapse: collapse;
      margin-bottom: 20px;
      font-size: 14px;
    }
    .variants-table thead {
      background: linear-gradient(135deg, #8B5CF6 0%, #6366F1 100%);
      color: white;
    }
    .variants-table th {
      padding: 12px 15px;
      text-align: left;
      font-weight: 700;
      font-size: 13px;
      text-transform: uppercase;
      letter-spacing: 0.5px;
    }
    .variants-table th:last-child {
      text-align: right;
    }
    .variants-table td {
      padding: 12px 15px;
      border-bottom: 1px solid #E5E7EB;
      font-size: 15px;
    }
    .variants-table td:last-child {
      text-align: right;
      font-weight: 700;
    }
    .variants-table tbody tr:nth-child(even) {
      background: #F9FAFB;
    }
    .totals-row {
      display: grid;
      grid-template-columns: repeat(3, 1fr);
      gap: 15px;
      margin-bottom: 20px;
    }
    .total-card {
      background: #F9FAFB;
      border: 2px solid #E5E7EB;
      border-radius: 10px;
      padding: 15px;
      text-align: center;
    }
    .total-card.highlight {
      background: linear-gradient(135deg, #10B981 0%, #059669 100%);
      border: none;
      color: white;
    }
    .total-card .label {
      font-size: 11px;
      font-weight: 700;
      color: #6B7280;
      text-transform: uppercase;
      letter-spacing: 0.5px;
      margin-bottom: 6px;
    }
    .total-card.highlight .label {
      color: rgba(255,255,255,0.85);
    }
    .total-card .value {
      font-size: 20px;
      font-weight: 800;
      color: #1F2937;
    }
    .total-card.highlight .value {
      color: white;
      font-size: 24px;
    }
    .address-box {
      background: #FEF3C7;
      border: 2px solid #F59E0B;
      border-radius: 10px;
      padding: 15px;
      margin-bottom: 20px;
    }
    .address-box .label {
      font-size: 12px;
      font-weight: 700;
      color: #92400E;
      text-transform: uppercase;
      letter-spacing: 0.5px;
      margin-bottom: 6px;
    }
    .address-box .neighborhood {
      font-size: 18px;
      font-weight: 800;
      color: #78350F;
      text-transform: uppercase;
      margin-bottom: 4px;
    }
    .address-box .address {
      font-size: 16px;
      color: #92400E;
      font-weight: 500;
    }
    .phone-box {
      background: #DBEAFE;
      border: 2px solid #3B82F6;
      border-radius: 10px;
      padding: 15px;
      margin-bottom: 20px;
      display: flex;
      align-items: center;
      justify-content: center;
      gap: 10px;
    }
    .phone-box .label {
      font-size: 14px;
      font-weight: 600;
      color: #1E40AF;
    }
    .phone-box .value {
      font-size: 20px;
      font-weight: 800;
      color: #1E3A8A;
    }
    .footer {
      margin-top: auto;
      text-align: center;
      padding-top: 15px;
      border-top: 2px solid #E5E7EB;
      font-size: 12px;
      color: #9CA3AF;
    }
    @media print {
      body { margin: 0; padding: 0; }
      .container { max-width: 100%; min-height: auto; padding: 0; }
    }
  </style>
</head>
<body>
  <div class="container">
    <div class="header">
      <div class="company">GoFast Produções</div>
      <h1>Etiqueta de Lote</h1>
      <div class="batch-code">${batch.batchCode}</div>
    </div>

    <div class="main-info">
      <div class="info-card">
        <div class="label">Produção</div>
        <div class="value large">${productionData?.productName || 'N/A'}</div>
      </div>
      <div class="info-card">
        <div class="label">Costureira</div>
        <div class="value large">${seamstressData?.name || 'N/A'}</div>
      </div>
    </div>

    <div class="dates-row">
      <div class="date-card">
        <div class="label">Data de Envio</div>
        <div class="value">${sendDate}</div>
      </div>
      <div class="date-card">
        <div class="label">Previsão de Entrega</div>
        <div class="value">${expectedReturnDate}</div>
      </div>
    </div>

    <div class="phone-box">
      <span class="label">Telefone:</span>
      <span class="value">${seamstressData?.phone || 'N/A'}</span>
    </div>

    <div class="section-title">Detalhes do Lote</div>
    <table class="variants-table">
      <thead>
        <tr>
          <th>Tamanho</th>
          <th>Cor</th>
          <th>Quantidade</th>
          <th>Valor Unit.</th>
        </tr>
      </thead>
      <tbody>
        ${variantDetails.map((detail: any) => `
        <tr>
          <td>${detail.size}</td>
          <td>${detail.color}</td>
          <td>${detail.quantity} peças</td>
          <td>R$ ${parseFloat(batch.pricePerUnit).toFixed(2)}</td>
        </tr>
        `).join('')}
      </tbody>
    </table>

    <div class="totals-row">
      <div class="total-card">
        <div class="label">Total de Peças</div>
        <div class="value">${batch.quantity}</div>
      </div>
      <div class="total-card">
        <div class="label">Valor Unitário</div>
        <div class="value">R$ ${parseFloat(batch.pricePerUnit).toFixed(2)}</div>
      </div>
      <div class="total-card highlight">
        <div class="label">Valor Total</div>
        <div class="value">R$ ${totalValue.toFixed(2)}</div>
      </div>
    </div>

    ${seamstressData?.address || seamstressData?.neighborhood ? `
    <div class="address-box">
      <div class="label">Endereço para Entrega</div>
      ${seamstressData?.neighborhood ? `<div class="neighborhood">${seamstressData.neighborhood}</div>` : ''}
      <div class="address">${seamstressData?.address || 'Endereço não informado'}</div>
    </div>
    ` : ''}

    <div class="footer">
      Impresso em: ${new Date().toLocaleString('pt-BR')} • GoFast Produções
    </div>
  </div>
</body>
</html>`;

    printHtml(printContent);
  };

  const totalAllocatedQuantity = useMemo(() => {
    return variantAllocations.reduce((sum, v) => sum + v.allocatedQty, 0);
  }, [variantAllocations]);

  const handleProductionChange = (productionId: string) => {
    const production = (productions as any[]).find((p: any) => p.id === productionId);
    setSelectedProductionId(productionId);
    const today = new Date();
    const deliveryDate = production ? new Date(production.deliveryDate) : null;
    const defaultReturnDate = deliveryDate && deliveryDate > today
      ? deliveryDate.toISOString().split("T")[0]
      : new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString().split("T")[0];
    setFormData({ ...formData, productionId, expectedReturnDate: defaultReturnDate, pricePerUnit: production ? parseFloat(production.pricePerUnit) : 0 });
    setVariantAllocations([]);
  };

  const internalDeadline = useMemo(() => {
    const production = (productions as any[]).find((p: any) => p.id === formData.productionId);
    if (formData.assignmentType !== "internal" || !production || internalDailyCost <= 0) return null;
    const plannedQuantity = totalAllocatedQuantity > 0 ? totalAllocatedQuantity : Number(production.quantity || 0);
    const revenue = plannedQuantity * Number(production.pricePerUnit || 0);
    const maxCost = revenue * 0.65;
    const days = maxCost / internalDailyCost;
    const deadline = new Date(formData.sendDate || new Date().toISOString().split("T")[0] + "T00:00:00");
    let remaining = Math.max(0, Math.floor(days));
    while (remaining > 0) {
      deadline.setDate(deadline.getDate() + 1);
      const day = deadline.getDay();
      if (day !== 0 && day !== 6) remaining--;
    }
    return { revenue, maxCost, days, maxFullDays: Math.floor(days), deadline };
  }, [formData.assignmentType, formData.productionId, formData.sendDate, productions, internalDailyCost, totalAllocatedQuantity]);

  const handleVariantAllocationChange = (variantId: string, quantity: number) => {
    setVariantAllocations(prev => 
      prev.map(v => {
        if (v.variantId === variantId) {
          // Limitar ao máximo permitido
          const clampedQty = Math.max(0, Math.min(quantity, v.maxQty));
          return { ...v, allocatedQty: clampedQty };
        }
        return v;
      })
    );
  };

  const createMutation = useMutation({
    mutationFn: async (data: any) => {
      const res = await apiRequest("POST", "/api/tenant/batches", {
        productionId: data.productionId,
        seamstressId: data.assignmentType === "internal" ? null : data.seamstressId,
        assignmentType: data.assignmentType,
        quantity: totalAllocatedQuantity,
        sendDate: new Date(data.sendDate),
        expectedReturnDate: new Date(data.expectedReturnDate),
        pricePerUnit: data.pricePerUnit.toString(),
        variantAllocations: variantAllocations.filter(v => v.allocatedQty > 0),
      });
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/tenant/batches"] });
      queryClient.invalidateQueries({ queryKey: ["/api/tenant/variants"] });
      queryClient.invalidateQueries({ queryKey: ["/api/tenant/productions"] });
      queryClient.invalidateQueries({ queryKey: ["/api/tenant/productions/available"] });
      queryClient.invalidateQueries({ queryKey: ["/api/tenant/dashboard"] });
      setIsOpen(false);
      resetForm();
      toast({ title: "Lote criado com sucesso!" });
    },
    onError: (error: any) => {
      toast({ title: "Erro ao criar lote", description: error.message, variant: "destructive" });
    },
  });

  const updateMutation = useMutation({
    mutationFn: async (batchId: string) => {
      const res = await apiRequest("PATCH", `/api/tenant/batches/${batchId}`, {
        seamstressId: formData.assignmentType === "internal" ? null : formData.seamstressId,
        assignmentType: formData.assignmentType,
        pricePerUnit: formData.pricePerUnit.toString(),
        variantAllocations: variantAllocations.filter(v => v.allocatedQty > 0),
      });
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/tenant/batches"] });
      queryClient.invalidateQueries({ queryKey: ["/api/tenant/batches", editingBatchId, "allocations"] });
      queryClient.invalidateQueries({ queryKey: ["/api/tenant/productions"] });
      queryClient.invalidateQueries({ queryKey: ["/api/tenant/productions", formData.productionId, "variants"] });
      queryClient.invalidateQueries({ queryKey: ["/api/tenant/dashboard"] });
      setIsOpen(false);
      setEditingBatchId(null);
      resetForm();
      toast({ title: "Lote atualizado com sucesso!" });
    },
    onError: (error: any) => {
      toast({ title: "Erro ao atualizar lote", description: error.message, variant: "destructive" });
    },
  });

  const deleteMutation = useMutation({
    mutationFn: async (batchId: string) => {
      await apiRequest("DELETE", `/api/tenant/batches/${batchId}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/tenant/batches"] });
      queryClient.invalidateQueries({ queryKey: ["/api/tenant/productions"] });
      queryClient.invalidateQueries({ queryKey: ["/api/tenant/variants"] });
      queryClient.invalidateQueries({ queryKey: ["/api/tenant/productions", selectedProductionId, "variants"] });
      queryClient.invalidateQueries({ queryKey: ["/api/tenant/productions/available"] });
      queryClient.invalidateQueries({ queryKey: ["/api/tenant/dashboard"] });
      toast({ title: "Lote excluído com sucesso!" });
    },
    onError: (error: any) => {
      toast({ title: "Erro ao excluir lote", description: error.message, variant: "destructive" });
    },
  });

  const updateStatusMutation = useMutation({
    mutationFn: async ({ batchId, status }: { batchId: string; status: string }) => {
      // Get the batch details before updating
      const batchRes = await apiRequest("GET", `/api/tenant/batches/${batchId}`);
      const oldBatch = await batchRes.json();

      // Update the batch status
      const res = await apiRequest("PATCH", `/api/tenant/batches/${batchId}`, { status });
      
      // If moving away from 'concluido' to something else, we should handle the payment
      if (oldBatch.status === "concluido" && status !== "concluido") {
        try {
          // Get payments associated with this batch
          const paymentsRes = await apiRequest("GET", "/api/tenant/payments");
          const allPayments = await paymentsRes.json();
          const batchPayments = allPayments.filter((p: any) => p.batchId === batchId && p.status === "pending");

          // Delete pending payments for this batch
          for (const payment of batchPayments) {
            await apiRequest("PATCH", `/api/tenant/payments/${payment.id}`, { 
              amount: "0.00",
              notes: "Pagamento cancelado: Lote retornado para produção."
            });
          }
        } catch (error) {
          console.error("Erro ao remover pagamentos pendentes:", error);
        }
      }

      // When completing, calculate payment based on deliveries
      if (status === "concluido") {
        await new Promise(r => setTimeout(r, 200));
        
        // Get the updated batch
        const freshBatchRes = await apiRequest("GET", `/api/tenant/batches/${batchId}`);
        const freshBatch = await freshBatchRes.json();
        
        // Get total delivered quantity
        const deliveriesRes = await fetch(`/api/tenant/batch-deliveries/${batchId}`, { headers: getAuthHeader() });
        const deliveries = await deliveriesRes.json();
        const totalDelivered = Array.isArray(deliveries) 
          ? deliveries.reduce((sum: number, d: any) => sum + (d.deliveredQuantity || 0), 0)
          : 0;
        
        // Use delivered quantity if available, otherwise use batch quantity
        const quantityForPayment = totalDelivered > 0 ? totalDelivered : (freshBatch.quantity || 0);
        const paymentAmount = quantityForPayment * parseFloat(freshBatch.pricePerUnit || 0);
        
        if (paymentAmount > 0 && freshBatch.assignmentType !== "internal" && freshBatch.seamstressId) {
          try {
            await apiRequest("POST", "/api/tenant/payments", {
              batchId: batchId,
              seamstressId: freshBatch.seamstressId,
              amount: paymentAmount.toString(),
              status: "pending",
            });
          } catch (error) {
            console.error("Erro ao criar pagamento:", error);
          }
        }
        return freshBatch;
      }
      
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/tenant/batches"] });
      queryClient.invalidateQueries({ queryKey: ["/api/tenant/dashboard"] });
      queryClient.invalidateQueries({ queryKey: ["/api/tenant/payments"] });
      queryClient.invalidateQueries({ queryKey: ["/api/tenant/productions"] });
      toast({ title: "Status do lote atualizado!" });
    },
    onError: (error: any) => {
      toast({ title: "Erro ao atualizar status do lote", description: error.message, variant: "destructive" });
    },
  });

  const handleDeleteBatch = (batchId: string) => {
    if (confirm("Tem certeza que deseja excluir este lote? As quantidades serão devolvidas à produção.")) {
      deleteMutation.mutate(batchId);
    }
  };

  const markAsDeliveredMutation = useMutation({
    mutationFn: async (batchId: string) => {
      // Get the batch details
      const batch = (Array.isArray(batches) ? batches : []).find((b: any) => b.id === batchId);
      if (!batch) throw new Error("Lote não encontrado");
      
      // Update batch status
      const res = await apiRequest("PATCH", `/api/tenant/batches/${batchId}`, {
        status: "concluido",
        returnedDate: new Date(),
      });
      
      // Get total delivered quantity
      const deliveriesRes = await fetch(`/api/tenant/batch-deliveries/${batchId}`, { headers: getAuthHeader() });
      const deliveries = await deliveriesRes.json();
      const totalDelivered = Array.isArray(deliveries) 
        ? deliveries.reduce((sum: number, d: any) => sum + (d.deliveredQuantity || 0), 0)
        : 0;
      
      // Use delivered quantity if available, otherwise use batch quantity
      const quantityForPayment = totalDelivered > 0 ? totalDelivered : batch.quantity;
      const paymentAmount = quantityForPayment * parseFloat(batch.pricePerUnit);
      
      if (batch.assignmentType !== "internal" && batch.seamstressId && paymentAmount > 0) {
        await apiRequest("POST", "/api/tenant/payments", {
          batchId: batchId,
          seamstressId: batch.seamstressId,
          amount: paymentAmount.toString(),
          status: "pending",
        });
      }
      
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/tenant/batches"] });
      queryClient.invalidateQueries({ queryKey: ["/api/tenant/productions"] });
      queryClient.invalidateQueries({ queryKey: ["/api/tenant/dashboard"] });
      queryClient.invalidateQueries({ queryKey: ["/api/tenant/payments"] });
      toast({ title: "Lote marcado como entregue!" });
    },
    onError: (error: any) => {
      toast({ title: "Erro ao marcar lote como entregue", description: error.message, variant: "destructive" });
    },
  });

  const handleMarkAsDelivered = (batchId: string) => {
    if (confirm("Marcar este lote como entregue?")) {
      markAsDeliveredMutation.mutate(batchId);
    }
  };

  const createDeliveryMutation = useMutation({
    mutationFn: async ({ batchId, deliveredQuantity, notes }: { batchId: string; deliveredQuantity: number; notes?: string }) => {
      const res = await apiRequest("POST", "/api/tenant/batch-deliveries", {
        batchId,
        deliveredQuantity,
        deliveredAt: new Date(),
        notes: notes || null,
      });
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/tenant/batches"] });
      queryClient.invalidateQueries({ queryKey: ["/api/tenant/batch-deliveries"] });
      queryClient.invalidateQueries({ queryKey: ["/api/tenant/productions"] });
      queryClient.invalidateQueries({ queryKey: ["/api/tenant/variants"] });
      setDeliveryDialogBatchId(null);
      setDeliveryQuantity("");
      setDeliveryNotes("");
      toast({ title: "Entrega registrada com sucesso!" });
    },
    onError: (error: any) => {
      toast({ title: "Erro ao registrar entrega", description: error.message, variant: "destructive" });
    },
  });

  const handleCreateDelivery = (batchId: string) => {
    const qty = parseInt(deliveryQuantity, 10);
    if (isNaN(qty) || qty <= 0) {
      toast({ title: "Digite uma quantidade válida", variant: "destructive" });
      return;
    }
    createDeliveryMutation.mutate({ batchId, deliveredQuantity: qty, notes: deliveryNotes });
  };

  const resetForm = () => {
    setFormData({
      productionId: "",
      seamstressId: "",
      assignmentType: "external",
      sendDate: new Date().toISOString().split("T")[0],
      expectedReturnDate: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString().split("T")[0],
      pricePerUnit: 0,
    });
    setSelectedProductionId("");
    setVariantAllocations([]);
  };

  const handleEditBatch = (batch: any) => {
    setEditingBatchId(batch.id);
    setSelectedProductionId(batch.productionId);
    setFormData({
      productionId: batch.productionId,
      seamstressId: batch.seamstressId || "",
      assignmentType: batch.assignmentType || "external",
      sendDate: batch.sendDate.split("T")[0],
      expectedReturnDate: batch.expectedReturnDate.split("T")[0],
      pricePerUnit: parseFloat(batch.pricePerUnit),
    });
    setIsOpen(true);
  };

  // Track the last production ID to detect when it actually changes
  const lastProductionIdRef = useRef<string>("");

  // Load variant allocations based on mode (create or edit)
  useEffect(() => {
    if (!variants || variants.length === 0) return;

    if (editingBatchId) {
      // Mode: editing - load existing allocations
      const allocationsMap: Record<string, number> = {};
      (existingAllocations || []).forEach((alloc: any) => {
        allocationsMap[alloc.variantId] = alloc.quantity;
      });

      const newAllocations = variants.map((v: any) => {
        const currentAllocation = allocationsMap[v.id] || 0;
        const availableQty = v.availableQuantity ?? v.quantity;
        // maxQty = disponível na produção + o que já está alocado neste lote
        const maxQty = availableQty + currentAllocation;
        return {
          variantId: v.id,
          size: v.size,
          color: v.color,
          availableQty: availableQty,
          allocatedQty: currentAllocation,
          maxQty: maxQty,
        };
      });
      setVariantAllocations(newAllocations);
    } else if (!editingBatchId && selectedProductionId !== lastProductionIdRef.current) {
      // Mode: creating - only reset when production actually changes
      lastProductionIdRef.current = selectedProductionId;
      const newAllocations = variants.map((v: any) => {
        const availableQty = v.availableQuantity ?? v.quantity;
        return {
          variantId: v.id,
          size: v.size,
          color: v.color,
          availableQty: availableQty,
          allocatedQty: 0,
          maxQty: availableQty, // Ao criar, máximo é o disponível
        };
      });
      setVariantAllocations(newAllocations);
    }
  }, [variants, editingBatchId, existingAllocations, selectedProductionId]);

  useEffect(() => {
    if (formData.assignmentType !== "internal" || !internalDeadline) return;
    const iso = internalDeadline.deadline.toISOString().split("T")[0];
    if (iso !== formData.expectedReturnDate) setFormData((prev) => ({ ...prev, expectedReturnDate: iso, pricePerUnit: 0 }));
  }, [formData.assignmentType, formData.productionId, formData.sendDate, internalDeadline?.days]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (editingBatchId) {
      updateMutation.mutate(editingBatchId);
    } else {
      if (totalAllocatedQuantity === 0) {
        alert("Por favor, aloque pelo menos uma variação");
        return;
      }
      if (formData.assignmentType === "external" && !formData.seamstressId) {
        alert("Por favor, selecione uma costureira externa");
        return;
      }
      if (!formData.sendDate) {
        alert("Por favor, preencha a Data de Envio");
        return;
      }
      if (!formData.expectedReturnDate) {
        alert("Por favor, preencha a Data de Retorno Esperado");
        return;
      }
      if (formData.assignmentType === "external" && formData.pricePerUnit <= 0) {
        alert("Por favor, preencha o Preço por Unidade da costureira");
        return;
      }
      
      createMutation.mutate(formData);
    }
  };

  const statusLabels: Record<string, string> = {
    em_separacao: "Em Separação",
    para_entrega: "Para Entrega",
    em_producao: "Em Produção",
    para_recolha: "Para Recolha",
    concluido: "Concluído",
  };

  // Get productions with status "aberto" for "Em Separação" column - use the dedicated endpoint
  const productionsWithAvailable = useMemo(() => {
    return openProductions || [];
  }, [openProductions]);

  // Kanban view
  const statuses = ["em_separacao", "para_entrega", "em_producao", "para_recolha", "concluido"];
  const batchesByStatus = statuses.map(status => {
    if (status === "em_separacao") {
      // For "Em Separação", show batch cards AND production cards with available quantities
      const batchCards = ((batches as any[]) || []).filter((b: any) => b.status === status);
      return {
        status,
        batches: batchCards,
        productions: productionsWithAvailable,
      };
    }
    return {
      status,
      batches: ((batches as any[]) || []).filter((b: any) => b.status === status),
      productions: [],
    };
  });

  return (
    <div className="p-8 space-y-8">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-semibold">Lotes</h1>
        <Dialog open={isOpen} onOpenChange={(open) => {
          setIsOpen(open);
          if (!open) {
            setEditingBatchId(null);
            resetForm();
          }
        }}>
          <DialogTrigger asChild>
            <Button className="gap-2" data-testid="button-create-batch">
              <Plus className="w-4 h-4" />
              Criar Lote
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>{editingBatchId ? "Editar Lote" : "Criar Novo Lote"}</DialogTitle>
            </DialogHeader>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label className="text-sm font-medium">Tipo de direcionamento</Label>
                  <Select value={formData.assignmentType} onValueChange={(value) => setFormData({ ...formData, assignmentType: value, seamstressId: value === "internal" ? "" : formData.seamstressId })}>
                    <SelectTrigger data-testid="select-batch-assignment-type"><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="external">Costureira externa</SelectItem>
                      <SelectItem value="internal">Equipe interna</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                {!editingBatchId ? <div>
                  <Label className="text-sm font-medium">Produção</Label>
                  <Select value={formData.productionId} onValueChange={handleProductionChange}>
                    <SelectTrigger data-testid="select-batch-production"><SelectValue placeholder="Selecionar produção" /></SelectTrigger>
                    <SelectContent>{((productions || []) as any[]).map((p) => <SelectItem key={p.id} value={p.id}>{p.productName}</SelectItem>)}</SelectContent>
                  </Select>
                </div> : <div>
                  <Label className="text-sm font-medium">Produção</Label>
                  <Input value={((productions || []) as any[]).find((p:any)=>p.id===formData.productionId)?.productName || ""} disabled />
                </div>}
              </div>

              {formData.assignmentType === "external" && (
                <div>
                  <Label className="text-sm font-medium">Costureira externa</Label>
                  <Select value={formData.seamstressId} onValueChange={(value) => setFormData({ ...formData, seamstressId: value })}>
                    <SelectTrigger data-testid="select-batch-seamstress"><SelectValue placeholder="Selecionar costureira" /></SelectTrigger>
                    <SelectContent>{((seamstresses || []) as any[]).map((s) => <SelectItem key={s.id} value={s.id}>{s.name}</SelectItem>)}</SelectContent>
                  </Select>
                </div>
              )}

              {formData.assignmentType === "internal" && internalDeadline && (
                <div className="rounded-2xl border border-blue-200 bg-blue-50 dark:bg-blue-950/30 dark:border-blue-900 p-4 space-y-2">
                  <div className="flex items-center justify-between"><div><p className="text-sm font-semibold text-blue-900 dark:text-blue-100">Prazo máximo para manter 35% de margem</p><p className="text-xs text-blue-700 dark:text-blue-300">Custo diário atual: {new Intl.NumberFormat("pt-BR",{style:"currency",currency:"BRL"}).format(internalDailyCost)}</p></div><span className="text-2xl font-bold text-blue-700 dark:text-blue-200">{internalDeadline.days.toFixed(1)} dias</span></div>
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-3 text-xs"><div><span className="text-muted-foreground">Receita do lote</span><p className="font-semibold">{brl(internalDeadline.revenue)}</p></div><div><span className="text-muted-foreground">Custo máximo</span><p className="font-semibold">{brl(internalDeadline.maxCost)}</p></div><div><span className="text-muted-foreground">Dias completos seguros</span><p className="font-semibold">{internalDeadline.maxFullDays} dias</p></div><div><span className="text-muted-foreground">Conclusão limite</span><p className="font-semibold">{internalDeadline.deadline.toLocaleDateString("pt-BR")}</p></div></div>
                  <p className="text-[11px] text-muted-foreground">Cálculo: receita × 65% ÷ custo diário. Para 100 peças a R$ 1,00 e custo diário de R$ 10, o limite correto é 6,5 dias para preservar 35% de margem.</p>
                </div>
              )}

              {formData.assignmentType === "external" ? (
                <div className="grid grid-cols-2 gap-4">
                  <div><Label className="text-sm font-medium">Data de Envio</Label><Input type="date" value={formData.sendDate} onChange={(e)=>setFormData({...formData,sendDate:e.target.value})} required /></div>
                  <div><Label className="text-sm font-medium">Retorno Esperado</Label><Input type="date" value={formData.expectedReturnDate} onChange={(e)=>setFormData({...formData,expectedReturnDate:e.target.value})} required /></div>
                </div>
              ) : (
                <div className="rounded-xl bg-muted p-3 text-sm"><span className="text-muted-foreground">Cronograma interno:</span> <strong>{formData.sendDate} → {formData.expectedReturnDate}</strong></div>
              )}

              {formData.assignmentType === "external" && (
                <div><Label className="text-sm font-medium">Preço por Unidade para Costureira (R$)</Label><Input type="number" step="0.01" value={formData.pricePerUnit} onChange={(e)=>setFormData({...formData,pricePerUnit:parseFloat(e.target.value)||0})} required data-testid="input-batch-price" /></div>
              )}


              {!editingBatchId && variantAllocations.length > 0 && (
                <div className="bg-muted/50 p-4 rounded-lg">
                  <div className="flex items-center justify-between mb-3">
                    <h3 className="font-semibold text-sm">Variações da Produção</h3>
                    <span className="text-sm font-medium text-primary">Total: {totalAllocatedQuantity} unidades</span>
                  </div>

                  <div className="space-y-2">
                    {variantAllocations.map((variant) => (
                      <div key={variant.variantId} className="grid grid-cols-4 gap-3 items-center bg-white dark:bg-muted p-3 rounded border text-sm">
                        <div>
                          <span className="font-medium">{variant.size}</span>
                          <span className="text-muted-foreground ml-2">{variant.color}</span>
                        </div>
                        <div className="text-muted-foreground">
                          Disponível: {variant.availableQty}
                        </div>
                        <Input
                          type="number"
                          min="0"
                          max={variant.maxQty}
                          value={variant.allocatedQty}
                          onChange={(e) => handleVariantAllocationChange(variant.variantId, parseInt(e.target.value) || 0)}
                          placeholder="0"
                          data-testid={`input-allocate-${variant.variantId}`}
                        />
                        <span className="text-right font-medium">
                          {variant.allocatedQty} alocadas
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {editingBatchId && variantAllocations.length > 0 && (
                <div className="bg-blue-900/20 border border-blue-600/30 p-4 rounded-lg">
                  <div className="flex items-center justify-between mb-3">
                    <h3 className="font-semibold text-sm text-blue-400">Peças Alocadas neste Lote</h3>
                    <span className="text-sm font-medium text-blue-400">Total: {totalAllocatedQuantity} unidades</span>
                  </div>

                  <div className="space-y-2">
                    {variantAllocations.map((variant) => (
                      <div key={variant.variantId} className="grid grid-cols-4 gap-3 items-center bg-blue-900/30 p-3 rounded border border-blue-600/20 text-sm">
                        <div>
                          <span className="font-medium">{variant.size}</span>
                          <span className="text-muted-foreground ml-2">{variant.color}</span>
                        </div>
                        <div className="text-muted-foreground">
                          Máx: {variant.maxQty}
                        </div>
                        <Input
                          type="number"
                          min="0"
                          max={variant.maxQty}
                          value={variant.allocatedQty}
                          onChange={(e) => handleVariantAllocationChange(variant.variantId, parseInt(e.target.value) || 0)}
                          placeholder="0"
                          data-testid={`input-edit-allocate-${variant.variantId}`}
                        />
                        <span className="text-right font-medium">
                          {variant.allocatedQty} / {variant.maxQty}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              <Button 
                type="submit" 
                className="w-full" 
                disabled={!editingBatchId && totalAllocatedQuantity === 0} 
                data-testid={editingBatchId ? "button-update-batch" : "button-submit-batch"}
              >
                {editingBatchId ? "Atualizar Lote" : `Criar Lote (${totalAllocatedQuantity} unidades)`}
              </Button>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      {/* Kanban Board */}
      <div className="w-full">
        <div className="grid grid-cols-5 gap-3">
          {((batchesByStatus || []) as any[]).map((column) => (
            <div key={column.status} className="min-w-0">
              <div className="bg-muted/50 rounded-lg p-4">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="font-semibold text-sm uppercase">{statusLabels[column.status]} ({column.batches.length + column.productions.length})</h3>
                  {column.batches.length > 0 && (
                    <Button
                      size="icon"
                      variant="ghost"
                      onClick={() => openPrintColumnDialog(column.status, column.batches)}
                      data-testid={`button-print-column-${column.status}`}
                      className="h-8 w-8"
                      title="Imprimir coluna"
                    >
                      <Printer className="w-4 h-4" />
                    </Button>
                  )}
                </div>
                <div className="space-y-3">
                  {column.productions && column.productions.length > 0 ? column.productions.map((production: any) => {
                    const availableQuantity = typeof production.availableQuantity === 'number' ? production.availableQuantity : 0;
                    
                    const handleCreateBatchFromProduction = () => {
                      handleProductionChange(production.id);
                      setIsOpen(true);
                    };
                    
                    return (
                      <Card 
                        key={`prod-${production.id}`} 
                        className="p-4 cursor-pointer transition-all border-amber-200 bg-amber-50 dark:bg-amber-950 dark:border-amber-800 hover:shadow-md" 
                        data-testid={`card-production-${production.id}`}
                        onClick={handleCreateBatchFromProduction}
                      >
                        <div className="flex items-start justify-between gap-2">
                          <div className="flex-1 min-w-0">
                            <p className="text-sm font-bold text-primary truncate">{production.productName || "Sem nome"}</p>
                            <p className="text-xs text-muted-foreground truncate">{production.supplier}</p>
                            <div className="mt-2 p-2 bg-amber-100 dark:bg-amber-900 rounded">
                              <p className="text-sm font-bold text-amber-900 dark:text-amber-100">Disponível: {availableQuantity} un.</p>
                            </div>
                          </div>
                          <Plus className="w-5 h-5 flex-shrink-0 text-amber-600 mt-1" />
                        </div>
                      </Card>
                    );
                  }) : null}
                  {column.batches.map((batch: any) => {
                    const production = ((productions || []) as any[]).find((p: any) => p.id === batch.productionId);
                    const seamstress = ((seamstresses || []) as any[]).find((s: any) => s.id === batch.seamstressId);
                    const isInternalBatch = batch.assignmentType === "internal";
                    const totalPayment = batch.quantity * parseFloat(batch.pricePerUnit);
                    const isExpanded = expandedBatches.has(batch.id);
                    
                    const toggleExpanded = (id: string) => {
                      const newExpanded = new Set(expandedBatches);
                      if (newExpanded.has(id)) {
                        newExpanded.delete(id);
                      } else {
                        newExpanded.add(id);
                      }
                      setExpandedBatches(newExpanded);
                    };

                    return (
                      <Card key={batch.id} className="p-3 cursor-pointer transition-all" data-testid={`card-batch-${batch.id}`}>
                        {!isExpanded ? (
                          <div className="flex items-center justify-between" onClick={() => toggleExpanded(batch.id)}>
                            <p className="text-sm font-bold text-primary truncate">{production?.productName || "Sem nome definido"}</p>
                            <ChevronDown className="w-4 h-4 flex-shrink-0" />
                          </div>
                        ) : (
                          <div className="space-y-2">
                            <div className="flex items-center justify-between cursor-pointer" onClick={() => toggleExpanded(batch.id)}>
                              <div>
                                <p className="text-sm font-bold text-primary">{production?.productName || "Sem nome definido"}</p>
                                <p className="font-mono text-xs font-semibold text-muted-foreground">{batch.batchCode}</p>
                              </div>
                              <ChevronUp className="w-4 h-4 flex-shrink-0" />
                            </div>
                            
                            <div className="flex gap-1">
                              <Button
                                size="icon"
                                variant="ghost"
                                onClick={() => openPrintBatchDialog(batch)}
                                data-testid={`button-print-batch-${batch.id}`}
                                className="h-7 w-7"
                              >
                                <Printer className="w-3 h-3" />
                              </Button>
                              <Button
                                size="icon"
                                variant="ghost"
                                onClick={() => handleEditBatch(batch)}
                                data-testid={`button-edit-batch-${batch.id}`}
                                className="h-7 w-7"
                              >
                                <Edit2 className="w-3 h-3" />
                              </Button>
                              <Button
                                size="icon"
                                variant="ghost"
                                onClick={() => handleDeleteBatch(batch.id)}
                                data-testid={`button-delete-batch-${batch.id}`}
                                className="h-7 w-7 text-destructive"
                              >
                                <Trash2 className="w-3 h-3" />
                              </Button>
                            </div>
                            
                            <div className="border-t pt-2">
                              <label className="text-xs font-semibold mb-1 block">Status</label>
                              <Select value={batch.status} onValueChange={(newStatus) => updateStatusMutation.mutate({ batchId: batch.id, status: newStatus })}>
                                <SelectTrigger data-testid={`select-batch-status-${batch.id}`} className="h-7 text-xs">
                                  <SelectValue>{statusLabels[batch.status]}</SelectValue>
                                </SelectTrigger>
                                <SelectContent>
                                  <SelectItem value="em_separacao">{statusLabels.em_separacao}</SelectItem>
                                  <SelectItem value="para_entrega">{statusLabels.para_entrega}</SelectItem>
                                  <SelectItem value="em_producao">{statusLabels.em_producao}</SelectItem>
                                  <SelectItem value="para_recolha">{statusLabels.para_recolha}</SelectItem>
                                  <SelectItem value="concluido">{statusLabels.concluido}</SelectItem>
                                </SelectContent>
                              </Select>
                            </div>
                            
                            <div className="text-xs text-muted-foreground space-y-1">
                              <p>Produção: <span className="font-semibold text-foreground">{production?.supplier || 'N/A'}</span></p>
                              <p>Destino: <span className="font-semibold text-foreground">{isInternalBatch ? "Equipe interna" : (seamstress?.name || 'N/A')}</span></p>
                              <p>Qtd: {batch.quantity} unidades</p>
                              {!isInternalBatch && <><p>Valor/un: R$ {parseFloat(batch.pricePerUnit).toFixed(2)}</p><p className="border-t pt-1 mt-1">Pagamento Pendente: <span className="font-semibold text-green-600">R$ {totalPayment.toFixed(2)}</span></p></>}
                              {isInternalBatch && <p className="border-t pt-1 mt-1 text-blue-600 font-medium">Lote interno · sem pagamento de costureira</p>}
                            </div>
                            
                            {/* Seção de Entregas Parciais */}
                            {batch.status !== 'concluido' && (
                              <div className="border-t pt-2 mt-2">
                                <div className="flex items-center justify-between mb-1">
                                  <label className="text-xs font-semibold">Entregas Parciais</label>
                                  <Button
                                    size="sm"
                                    variant="outline"
                                    className="h-6 text-xs px-2"
                                    onClick={() => setDeliveryDialogBatchId(batch.id)}
                                    data-testid={`button-add-delivery-${batch.id}`}
                                  >
                                    <Package className="w-3 h-3 mr-1" />
                                    Registrar Entrega
                                  </Button>
                                </div>
                                <BatchDeliveriesSection batchId={batch.id} totalQuantity={batch.quantity} pricePerUnit={parseFloat(batch.pricePerUnit)} />
                              </div>
                            )}
                          </div>
                        )}
                      </Card>
                    );
                  })}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Modal de Entrega Parcial */}
      <Dialog open={!!deliveryDialogBatchId} onOpenChange={(open) => { if (!open) { setDeliveryDialogBatchId(null); setDeliveryQuantity(""); setDeliveryNotes(""); } }}>
        <DialogContent className="max-w-sm">
          <DialogHeader>
            <DialogTitle>Registrar Entrega Parcial</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label>Quantidade Entregue</Label>
              <Input
                type="number"
                min="1"
                value={deliveryQuantity}
                onChange={(e) => setDeliveryQuantity(e.target.value)}
                placeholder="Ex: 50"
                data-testid="input-delivery-quantity"
              />
            </div>
            <div>
              <Label>Observações (opcional)</Label>
              <Input
                value={deliveryNotes}
                onChange={(e) => setDeliveryNotes(e.target.value)}
                placeholder="Ex: Entrega parcial"
                data-testid="input-delivery-notes"
              />
            </div>
            <Button
              onClick={() => deliveryDialogBatchId && handleCreateDelivery(deliveryDialogBatchId)}
              disabled={createDeliveryMutation.isPending}
              className="w-full"
              data-testid="button-confirm-delivery"
            >
              {createDeliveryMutation.isPending ? "Salvando..." : "Confirmar Entrega"}
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* Print Format Dialog */}
      <PrintFormatDialog
        open={printFormatDialogOpen}
        onOpenChange={setPrintFormatDialogOpen}
        onSelectFormat={handlePrintFormatSelect}
      />
    </div>
  );
};

export default Batches;
