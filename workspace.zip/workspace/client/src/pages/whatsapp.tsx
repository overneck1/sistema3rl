import { useState, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { MessageCircle, CheckCircle, AlertCircle, Loader, MessageSquare, RefreshCw } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { queryClient } from "@/lib/queryClient";
import { Link } from "wouter";
import { useToast } from "@/hooks/use-toast";

interface WhatsAppStatusResponse {
  status: "disconnected" | "connecting" | "scanning" | "connected";
  qrCode: string | null;
  phoneNumber: string | null;
  lastSync: string | null;
}

const WhatsAppCentral = () => {
  const { toast } = useToast();
  const [pollingInterval, setPollingInterval] = useState<number | null>(2000);

  // Fetch WhatsApp status
  const { data: statusData, isLoading, error: statusError, refetch: refetchStatus } = useQuery<WhatsAppStatusResponse>({
    queryKey: ["/api/whatsapp/status"],
    refetchInterval: pollingInterval || undefined,
    refetchOnWindowFocus: false,
  });

  // Connect mutation
  const connectMutation = useMutation({
    mutationFn: async () => {
      const res = await apiRequest("POST", "/api/whatsapp/connect", {});
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/whatsapp/status"] });
      setPollingInterval(2000);
      toast({ title: "Conectando WhatsApp", description: "A sessão foi iniciada. Aguarde o QR Code." });
    },
    onError: (error: any) => {
      toast({ title: "Erro ao conectar WhatsApp", description: error.message, variant: "destructive" });
    },
  });

  // Disconnect mutation
  const disconnectMutation = useMutation({
    mutationFn: async () => {
      const res = await apiRequest("POST", "/api/whatsapp/disconnect", {});
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/whatsapp/status"] });
      setPollingInterval(null);
      toast({ title: "WhatsApp desconectado" });
    },
    onError: (error: any) => {
      toast({ title: "Erro ao desconectar WhatsApp", description: error.message, variant: "destructive" });
    },
  });

  // Stop polling when connected, keep polling when scanning
  useEffect(() => {
    if (statusData?.status === "connected") {
      setPollingInterval(null);
    } else if (statusData?.status === "scanning" || statusData?.status === "connecting") {
      setPollingInterval(1000); // Poll faster during scanning
    }
  }, [statusData?.status]);

  const status: "disconnected" | "connecting" | "scanning" | "connected" = (statusData?.status as any) || "disconnected";
  const qrCode: string | null = statusData?.qrCode || null;
  const phoneNumber: string | null = statusData?.phoneNumber || null;
  const lastSync: string | null = statusData?.lastSync ? new Date(statusData.lastSync).toLocaleString("pt-BR") : null;

  const connectionMessage = statusError ? "Não foi possível consultar o WhatsApp. Verifique o login e o servidor." :
    status === "connected" ? "WhatsApp conectado e pronto para envio." :
    status === "scanning" ? "Escaneie o QR Code pelo WhatsApp do celular." :
    status === "connecting" ? "Iniciando a sessão do WhatsApp..." : "WhatsApp desconectado.";

  const handleConnectClick = () => {
    connectMutation.mutate();
  };

  const handleDisconnectClick = () => {
    if (confirm("Tem certeza que deseja desconectar o WhatsApp?")) {
      disconnectMutation.mutate();
    }
  };

  return (
    <div className="p-8 space-y-6">
      <div>
        <h1 className="text-3xl font-bold text-foreground">Central WhatsApp</h1>
        <p className="text-muted-foreground mt-2">Conecte o número da sua empresa ao WhatsApp Web</p>
        {statusError && <div className="mt-3 inline-flex items-center gap-2 rounded-lg border border-destructive/30 bg-destructive/5 px-3 py-2 text-sm text-destructive"><AlertCircle className="h-4 w-4" />{String(statusError.message || statusError)}</div>}
      </div>

      <Card className="max-w-md mx-auto p-8 space-y-6 bg-card border-card-border card-tech">
        {/* Status Card */}
        <div className="text-center space-y-4">
          <div className="flex justify-center">
            {status === "disconnected" && (
              <AlertCircle className="w-16 h-16 text-destructive/70" />
            )}
            {(status === "connecting" || status === "scanning") && (
              <Loader className="w-16 h-16 text-warning animate-spin" />
            )}
            {status === "connected" && (
              <CheckCircle className="w-16 h-16 text-success" />
            )}
          </div>

          <div>
            <h2 className="text-2xl font-bold text-foreground">
              {status === "disconnected" && "Desconectado"}
              {status === "connecting" && "Gerando QR Code..."}
              {status === "scanning" && "Escaneie o QR Code"}
              {status === "connected" && "Conectado"}
            </h2>
            <p className="text-sm text-muted-foreground mt-1">
              {status === "disconnected" && "Clique em 'Conectar WhatsApp' para gerar o QR Code"}
              {status === "connecting" && "Inicializando cliente WhatsApp Web..."}
              {status === "scanning" && "Seu QR Code está pronto! Abra o WhatsApp e escaneie"}
              {status === "connected" && "Sistema sincronizado com WhatsApp"}
            </p>
          </div>
        </div>

        {/* QR Code Display */}
        {status === "scanning" && qrCode && (
          <div className="bg-muted/30 border-2 border-primary rounded-lg p-8 flex items-center justify-center">
            <div className="text-center space-y-4">
              <img src={qrCode} alt="QR Code WhatsApp" className="w-64 h-64 mx-auto border-4 border-primary p-3 bg-white rounded-lg shadow-lg" data-testid="img-whatsapp-qr" />
              <div className="space-y-2 bg-success/10 p-4 rounded-lg border border-success/30">
                <p className="text-sm font-semibold text-foreground">
                  QR Code do WhatsApp Web
                </p>
                <p className="text-sm text-muted-foreground">
                  Abra o <strong>WhatsApp</strong> no seu celular
                </p>
                <p className="text-sm text-muted-foreground">
                  Vá para <strong>Configurações → Dispositivos Conectados</strong>
                </p>
                <p className="text-sm text-foreground font-semibold text-primary">
                  Aponte a câmera para escanear este código
                </p>
              </div>
            </div>
          </div>
        )}

        {/* Connecting State */}
        {status === "connecting" && !qrCode && (
          <div className="bg-muted/30 border border-border rounded-lg p-8 flex items-center justify-center">
            <div className="text-center space-y-4">
              <Loader className="w-16 h-16 text-warning animate-spin mx-auto" />
              <p className="text-sm text-muted-foreground">
                Gerando QR Code...
              </p>
              <p className="text-xs text-muted-foreground">
                Aguarde alguns segundos
              </p>
            </div>
          </div>
        )}

        {/* Connected Info */}
        {status === "connected" && phoneNumber && (
          <div className="bg-success/10 border border-success/30 rounded-lg p-4 space-y-2">
            <p className="text-sm font-semibold text-foreground">Número Conectado</p>
            <p className="text-lg font-bold text-success">{phoneNumber}</p>
            {lastSync && (
              <>
                <p className="text-xs text-muted-foreground mt-2">Última sincronização</p>
                <p className="text-xs text-foreground">{lastSync}</p>
              </>
            )}
          </div>
        )}

        {/* Action Buttons */}
        <div className="space-y-2">
          {status === "disconnected" && (
            <Button
              onClick={handleConnectClick}
              disabled={connectMutation.isPending || isLoading}
              className="w-full bg-[#25D366] hover:bg-[#1fa754] text-white font-semibold gap-2"
              data-testid="button-connect-whatsapp"
            >
              {connectMutation.isPending ? (
                <>
                  <Loader className="w-4 h-4 animate-spin" />
                  Conectando...
                </>
              ) : (
                <>
                  <MessageCircle className="w-4 h-4" />
                  Conectar WhatsApp
                </>
              )}
            </Button>
          )}

          {(status === "connecting" || status === "scanning") && (
            <Button
              disabled
              className="w-full bg-[#25D366]/50 text-white font-semibold gap-2 cursor-not-allowed"
            >
              <Loader className="w-4 h-4 animate-spin" />
              {status === "connecting" ? "Gerando código..." : "Aguarde escanear"}
            </Button>
          )}

          {status === "connected" && (
            <>
              <Link href="/whatsapp-chat">
                <Button
                  className="w-full bg-[#25D366] hover:bg-[#1fa754] text-white font-semibold gap-2"
                  data-testid="button-open-chat"
                >
                  <MessageSquare className="w-4 h-4" />
                  Abrir Conversa
                </Button>
              </Link>
              <Button
                onClick={handleConnectClick}
                disabled={connectMutation.isPending}
                className="w-full bg-primary hover:bg-primary/90 text-primary-foreground font-semibold gap-2"
                data-testid="button-reconnect-whatsapp"
              >
                {connectMutation.isPending ? (
                  <>
                    <Loader className="w-4 h-4 animate-spin" />
                    Reconectando...
                  </>
                ) : (
                  <>
                    <MessageCircle className="w-4 h-4" />
                    Reconectar
                  </>
                )}
              </Button>
              <Button
                onClick={handleDisconnectClick}
                disabled={disconnectMutation.isPending}
                variant="outline"
                className="w-full text-destructive hover:text-destructive"
                data-testid="button-disconnect-whatsapp"
              >
                {disconnectMutation.isPending ? (
                  <>
                    <Loader className="w-4 h-4 animate-spin mr-1" />
                    Desconectando...
                  </>
                ) : (
                  "Desconectar"
                )}
              </Button>
            </>
          )}
        </div>
      </Card>

      {/* Info Section */}
      <Card className="max-w-2xl mx-auto p-6 bg-card border-card-border card-tech space-y-4">
        <h3 className="text-lg font-semibold text-foreground">Como funciona</h3>
        <ol className="space-y-3 text-sm text-foreground">
          <li className="flex gap-3">
            <span className="font-bold text-primary">1.</span>
            <span>Clique em "Conectar WhatsApp" para exibir o QR Code</span>
          </li>
          <li className="flex gap-3">
            <span className="font-bold text-primary">2.</span>
            <span>Abra o WhatsApp no seu telefone e escaneie o código</span>
          </li>
          <li className="flex gap-3">
            <span className="font-bold text-primary">3.</span>
            <span>A conexão será estabelecida automaticamente</span>
          </li>
          <li className="flex gap-3">
            <span className="font-bold text-primary">4.</span>
            <span>Agora você pode enviar mensagens diretamente para as costureiras</span>
          </li>
        </ol>
      </Card>

      {/* Error/Status Message */}
      {connectMutation.isError && (
        <Card className="max-w-2xl mx-auto p-4 bg-destructive/10 border border-destructive/30">
          <p className="text-sm text-destructive">
            Erro ao conectar: {String(connectMutation.error)}
          </p>
        </Card>
      )}

      {disconnectMutation.isError && (
        <Card className="max-w-2xl mx-auto p-4 bg-destructive/10 border border-destructive/30">
          <p className="text-sm text-destructive">
            Erro ao desconectar: {String(disconnectMutation.error)}
          </p>
        </Card>
      )}
    </div>
  );
};

export default WhatsAppCentral;
