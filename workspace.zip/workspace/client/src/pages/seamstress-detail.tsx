import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { useRoute, useLocation } from "wouter";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ArrowLeft, Printer, Phone, MapPin } from "lucide-react";
import { format } from "date-fns";
import { ptBR } from "date-fns/locale";
import { isPast, isToday } from "date-fns";
import { PrintFormatDialog, PrintFormat, getCupomBaseStyles, printContent as printHtml } from "@/components/print-format-dialog";

interface Seamstress {
  id: string;
  name: string;
  phone: string;
  address: string;
  neighborhood: string;
  rating: number;
  status: "active" | "paused" | "blocked";
}

interface Payment {
  id: string;
  seamstressId: string;
  batchId: string;
  amount: string;
  status: "pending" | "paid" | "overdue";
  dueDate?: string;
  paidDate?: string;
  createdAt: string;
}

interface Batch {
  id: string;
  batchCode: string;
  status: string;
}

interface PaymentDetails {
  seamstress: Seamstress;
  payments: Payment[];
  batches: Batch[];
  totalToPay: number;
  totalPaid: number;
}

const SeamstressDetail = () => {
  const [, params] = useRoute("/seamstresses/:id");
  const [, navigate] = useLocation();
  const seamstressId = params?.id;
  
  // Print format dialog state
  const [printFormatDialogOpen, setPrintFormatDialogOpen] = useState(false);

  const { data: seamstressData, isLoading: seamstressLoading } = useQuery({
    queryKey: ["/api/tenant/seamstresses", seamstressId],
    enabled: !!seamstressId,
  }) as { data: Seamstress | undefined; isLoading: boolean };

  const { data: paymentDetails } = useQuery({
    queryKey: ["/api/tenant/seamstresses", seamstressId, "payments"],
    enabled: !!seamstressId,
  }) as { data: PaymentDetails | undefined };

  const seamstress = seamstressData;
  const payments = paymentDetails?.payments || [];
  const batches = paymentDetails?.batches || [];

  if (seamstressLoading) {
    return <div className="p-8">Carregando...</div>;
  }

  if (!seamstress) {
    return <div className="p-8">Costureira não encontrada</div>;
  }

  const isPaymentOverdue = (payment: Payment) => {
    if (!payment.dueDate) return false;
    return new Date(payment.dueDate) < new Date() && payment.status !== "paid";
  };

  const getPaymentStatus = (payment: Payment) => {
    if (payment.status === "paid") return "paid";
    if (!payment.dueDate) return payment.status || "pending";
    const dueDate = new Date(payment.dueDate);
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    if (isPast(dueDate) && !isToday(dueDate)) {
      return "overdue";
    }
    return payment.status || "pending";
  };

  const totalPaid = payments
    .filter((p) => p.status === "paid")
    .reduce((sum, p) => sum + parseFloat(p.amount), 0);

  const totalPending = payments
    .filter((p) => p.status === "pending" && !isPaymentOverdue(p))
    .reduce((sum, p) => sum + parseFloat(p.amount), 0);

  const totalOverdue = payments
    .filter((p) => isPaymentOverdue(p))
    .reduce((sum, p) => sum + parseFloat(p.amount), 0);

  const openPrintDialog = () => {
    setPrintFormatDialogOpen(true);
  };

  const handlePrintFormatSelect = (format: PrintFormat) => {
    setPrintFormatDialogOpen(false);
    handlePrintDetails(format);
  };

  const handlePrintDetails = (format: PrintFormat = 'a4') => {
    let paymentRows = "";
    payments.forEach((payment) => {
      const batch = batches.find((b) => b.id === payment.batchId);
      const dueDate = payment.dueDate
        ? new Date(payment.dueDate).toLocaleDateString("pt-BR")
        : "N/A";
      const status = getPaymentStatus(payment);
      const statusLabel =
        status === "paid" ? "Pago" : status === "overdue" ? "Atrasado" : "Pendente";

      paymentRows += `
        <tr>
          <td>${batch?.batchCode || payment.batchId.slice(0, 8)}</td>
          <td>R$ ${parseFloat(payment.amount).toFixed(2)}</td>
          <td>${statusLabel}</td>
          <td>${dueDate}</td>
        </tr>
      `;
    });

    const printContent = `
      <!DOCTYPE html>
      <html lang="pt-BR">
      <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Detalhes de ${seamstress.name}</title>
        <style>
          * { margin: 0; padding: 0; box-sizing: border-box; }
          body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background-color: #fff; padding: 20px; }
          .container { max-width: 210mm; margin: 0 auto; }
          .header { text-align: center; margin-bottom: 30px; border-bottom: 3px solid #8B5CF6; padding-bottom: 15px; }
          .header h1 { font-size: 24px; color: #1F2937; margin-bottom: 5px; }
          .header p { font-size: 12px; color: #6B7280; margin-bottom: 5px; }
          .info-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 15px; margin-bottom: 20px; }
          .info-box { background: #F3F4F6; border-left: 4px solid #8B5CF6; padding: 12px; border-radius: 4px; }
          .info-label { font-size: 12px; color: #6B7280; font-weight: 600; text-transform: uppercase; }
          .info-value { font-size: 14px; color: #1F2937; margin-top: 5px; font-weight: 500; }
          .summary { display: grid; grid-template-columns: repeat(3, 1fr); gap: 15px; margin-bottom: 30px; }
          .summary-box { background: #F3F4F6; border-left: 4px solid #8B5CF6; padding: 15px; border-radius: 4px; text-align: center; }
          .summary-label { font-size: 12px; color: #6B7280; font-weight: 600; }
          .summary-value { font-size: 20px; font-weight: 700; color: #1F2937; margin-top: 8px; }
          table { width: 100%; border-collapse: collapse; margin-top: 20px; }
          table thead { background-color: #8B5CF6; color: white; }
          table th { padding: 10px; text-align: left; font-size: 12px; font-weight: 600; }
          table td { padding: 10px; border-bottom: 1px solid #E5E7EB; font-size: 12px; }
          .footer { text-align: center; margin-top: 30px; padding-top: 20px; border-top: 1px solid #E5E7EB; font-size: 11px; color: #6B7280; }
        </style>
      </head>
      <body>
        <div class="container">
          <div class="header">
            <h1>Detalhes da Costureira</h1>
            <p>GoFast Produções</p>
            <p>Gerado em: ${new Date().toLocaleDateString("pt-BR")} às ${new Date().toLocaleTimeString("pt-BR")}</p>
          </div>

          <div class="info-grid">
            <div class="info-box">
              <div class="info-label">Nome</div>
              <div class="info-value">${seamstress.name}</div>
            </div>
            <div class="info-box">
              <div class="info-label">Telefone</div>
              <div class="info-value">${seamstress.phone}</div>
            </div>
            <div class="info-box">
              <div class="info-label">Endereço</div>
              <div class="info-value">${seamstress.address}</div>
            </div>
            <div class="info-box">
              <div class="info-label">Bairro</div>
              <div class="info-value">${seamstress.neighborhood}</div>
            </div>
          </div>

          <div class="summary">
            <div class="summary-box">
              <div class="summary-label">Total Pago</div>
              <div class="summary-value">R$ ${totalPaid.toFixed(2)}</div>
            </div>
            <div class="summary-box">
              <div class="summary-label">Total Pendente</div>
              <div class="summary-value">R$ ${totalPending.toFixed(2)}</div>
            </div>
            <div class="summary-box">
              <div class="summary-label">Total Atrasado</div>
              <div class="summary-value">R$ ${totalOverdue.toFixed(2)}</div>
            </div>
          </div>

          <h2 style="margin-top: 30px; font-size: 14px; font-weight: 700; color: #1F2937;">Histórico de Pagamentos</h2>
          <table>
            <thead>
              <tr>
                <th>Código Lote</th>
                <th>Valor</th>
                <th>Status</th>
                <th>Vencimento</th>
              </tr>
            </thead>
            <tbody>
              ${paymentRows}
            </tbody>
          </table>

          <div class="footer">
            <p>Este é um documento gerado automaticamente por GoFast Produções</p>
          </div>
        </div>
      </body>
      </html>
    `;

    let content = '';

    if (format === 'cupom') {
      let paymentLines = '';
      payments.forEach((payment) => {
        const batch = batches.find((b) => b.id === payment.batchId);
        const dueDate = payment.dueDate ? new Date(payment.dueDate).toLocaleDateString("pt-BR") : "N/A";
        const status = getPaymentStatus(payment);
        const statusLabel = status === "paid" ? "Pago" : status === "overdue" ? "Atraso" : "Pend";
        paymentLines += `
          <div class="item">
            <div class="item-row"><span>${batch?.batchCode || payment.batchId.slice(0, 8)}</span><span>${statusLabel}</span></div>
            <div class="item-row"><span>Valor:</span><span>R$ ${parseFloat(payment.amount).toFixed(2)}</span></div>
            <div class="item-row"><span>Venc:</span><span>${dueDate}</span></div>
          </div>
        `;
      });

      content = `<!DOCTYPE html><html lang="pt-BR"><head><meta charset="UTF-8">
        <title>Detalhes - ${seamstress.name}</title>
        <style>${getCupomBaseStyles()}</style>
      </head><body>
        <div class="cupom">
          <div class="header">GOFAST PRODUCOES</div>
          <div class="title">COSTUREIRA</div>
          <div class="divider"></div>
          <div class="info">${seamstress.name}</div>
          <div class="info">Tel: ${seamstress.phone}</div>
          <div class="info">${seamstress.address}</div>
          <div class="info">${seamstress.neighborhood}</div>
          <div class="divider"></div>
          <div class="total">PAGO: R$ ${totalPaid.toFixed(2)}</div>
          <div class="total">PEND: R$ ${totalPending.toFixed(2)}</div>
          <div class="total">ATRASO: R$ ${totalOverdue.toFixed(2)}</div>
          <div class="divider"></div>
          ${paymentLines}
          <div class="divider"></div>
          <div class="footer">${new Date().toLocaleString('pt-BR')}</div>
        </div>
      </body></html>`;
    } else {
      content = printContent;
    }

    printHtml(content);
  };

  return (
    <div className="p-8 space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <Button
            variant="ghost"
            size="icon"
            onClick={() => navigate("/payments")}
            data-testid="button-back"
          >
            <ArrowLeft className="w-5 h-5" />
          </Button>
          <div>
            <h1 className="text-3xl font-bold">{seamstress.name}</h1>
            <p className="text-muted-foreground">
              <Badge
                variant={
                  seamstress.status === "active"
                    ? "default"
                    : seamstress.status === "paused"
                      ? "secondary"
                      : "destructive"
                }
              >
                {seamstress.status === "active"
                  ? "Ativa"
                  : seamstress.status === "paused"
                    ? "Pausada"
                    : "Bloqueada"}
              </Badge>
            </p>
          </div>
        </div>
        <Button onClick={openPrintDialog} className="gap-2" data-testid="button-print-details">
          <Printer className="w-4 h-4" />
          Imprimir
        </Button>
      </div>

      {/* Info Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <Card className="p-4">
          <div className="flex items-start gap-3">
            <Phone className="w-5 h-5 text-blue-400 mt-1" />
            <div>
              <p className="text-sm text-muted-foreground">Telefone</p>
              <p className="font-semibold">{seamstress.phone}</p>
            </div>
          </div>
        </Card>
        <Card className="p-4">
          <div className="flex items-start gap-3">
            <MapPin className="w-5 h-5 text-purple-400 mt-1" />
            <div>
              <p className="text-sm text-muted-foreground">Endereço</p>
              <p className="font-semibold">
                {seamstress.address}, {seamstress.neighborhood}
              </p>
            </div>
          </div>
        </Card>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card className="p-6 bg-gradient-to-br from-green-900/20 to-green-800/10 border-green-600/30">
          <div>
            <p className="text-sm font-medium text-green-400">Total Pago</p>
            <p className="text-3xl font-bold mt-2">R$ {totalPaid.toFixed(2)}</p>
          </div>
        </Card>
        <Card className="p-6 bg-gradient-to-br from-orange-900/20 to-orange-800/10 border-orange-600/30">
          <div>
            <p className="text-sm font-medium text-orange-400">Total Pendente</p>
            <p className="text-3xl font-bold mt-2">R$ {totalPending.toFixed(2)}</p>
          </div>
        </Card>
        <Card className="p-6 bg-gradient-to-br from-red-900/20 to-red-800/10 border-red-600/30">
          <div>
            <p className="text-sm font-medium text-red-400">Total Atrasado</p>
            <p className="text-3xl font-bold mt-2">R$ {totalOverdue.toFixed(2)}</p>
          </div>
        </Card>
      </div>

      {/* Payments Table */}
      <Card className="p-6">
        <h3 className="text-lg font-semibold mb-4">Histórico de Pagamentos</h3>
        {payments.length === 0 ? (
          <p className="text-muted-foreground text-center py-8">
            Nenhum pagamento encontrado
          </p>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="border-b">
                <tr>
                  <th className="text-left py-2 px-3">Código Lote</th>
                  <th className="text-left py-2 px-3">Valor</th>
                  <th className="text-left py-2 px-3">Status</th>
                  <th className="text-left py-2 px-3">Data de Vencimento</th>
                  <th className="text-left py-2 px-3">Data de Pagamento</th>
                </tr>
              </thead>
              <tbody>
                {payments.map((payment) => {
                  const batch = batches.find((b) => b.id === payment.batchId);
                  const status = getPaymentStatus(payment);
                  const dueDate = payment.dueDate
                    ? new Date(payment.dueDate)
                    : null;
                  const paidDate = payment.paidDate
                    ? new Date(payment.paidDate)
                    : null;

                  return (
                    <tr
                      key={payment.id}
                      className={`border-b hover:bg-muted/50 ${status === "overdue" ? "bg-red-900/10" : ""}`}
                      data-testid={`row-payment-${payment.id}`}
                    >
                      <td className="py-2 px-3 font-mono text-xs">
                        {batch?.batchCode || payment.batchId.slice(0, 8)}
                      </td>
                      <td className="py-2 px-3">
                        R$ {parseFloat(payment.amount).toFixed(2)}
                      </td>
                      <td className="py-2 px-3">
                        <span
                          className={`px-2 py-1 text-xs rounded-full ${
                            status === "paid"
                              ? "bg-green-900/50 text-green-400 border border-green-600/50"
                              : status === "overdue"
                                ? "bg-red-900/50 text-red-400 border border-red-600/50"
                                : "bg-orange-900/50 text-orange-400 border border-orange-600/50"
                          }`}
                        >
                          {status === "paid"
                            ? "Pago"
                            : status === "overdue"
                              ? "Atrasado"
                              : "Pendente"}
                        </span>
                      </td>
                      <td className="py-2 px-3">
                        {dueDate ? format(dueDate, "dd/MM/yyyy") : "N/A"}
                      </td>
                      <td className="py-2 px-3">
                        {paidDate ? format(paidDate, "dd/MM/yyyy") : "—"}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </Card>

      <PrintFormatDialog
        open={printFormatDialogOpen}
        onOpenChange={setPrintFormatDialogOpen}
        onSelectFormat={handlePrintFormatSelect}
      />
    </div>
  );
};

export default SeamstressDetail;
