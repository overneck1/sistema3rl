import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Printer } from "lucide-react";
import { format } from "date-fns";
import { ptBR } from "date-fns/locale";
import { PrintFormatDialog, PrintFormat, getCupomBaseStyles, printContent as printHtml } from "@/components/print-format-dialog";

interface Production {
  id: string;
  code: string;
  productName: string;
  supplier: string;
  quantity: number;
  status: "open" | "partial" | "completed";
  pricePerUnit: number;
  date: string;
  variants?: Array<{
    id: string;
    size: string;
    color: string;
    quantity: number;
  }>;
}

interface Batch {
  id: string;
  productionId: string;
  seamstressId: string;
}

interface Seamstress {
  id: string;
  name: string;
  phone?: string;
  neighborhood?: string;
}

type BatchStatus = "em_separacao" | "para_entrega" | "em_producao" | "para_recolha" | "concluido";

const MonthlyKanban = () => {
  const [selectedMonth, setSelectedMonth] = useState<string | null>(null);
  const [batchStatusFilter, setBatchStatusFilter] = useState<Set<BatchStatus>>(
    new Set(["em_separacao", "para_entrega", "em_producao", "para_recolha", "concluido"] as BatchStatus[])
  );
  
  // Print format dialog state
  const [printFormatDialogOpen, setPrintFormatDialogOpen] = useState(false);
  const [pendingPrintAction, setPendingPrintAction] = useState<{
    monthLabel: string;
    monthProductions: Production[];
  } | null>(null);
  
  const { data: productions = [], isLoading } = useQuery<Production[]>({
    queryKey: ["/api/productions"],
  });

  const { data: batches = [] } = useQuery<any[]>({
    queryKey: ["/api/batches"],
  });

  const { data: seamstresses = [] } = useQuery<Seamstress[]>({
    queryKey: ["/api/seamstresses"],
  });

  if (isLoading) {
    return <div className="p-8">Carregando produções...</div>;
  }

  // Helper to get seamstresses for a production
  const getSeamstressesForProduction = (productionId: string) => {
    const productionBatches = batches.filter((b: Batch) => b.productionId === productionId);
    const seamstressIds = Array.from(new Set(productionBatches.map((b: Batch) => b.seamstressId)));
    return seamstresses.filter((s: Seamstress) => seamstressIds.includes(s.id));
  };

  // Print format dialog functions
  const openPrintMonthDialog = (monthLabel: string, monthProductions: Production[]) => {
    setPendingPrintAction({ monthLabel, monthProductions });
    setPrintFormatDialogOpen(true);
  };

  const handlePrintFormatSelect = (format: PrintFormat) => {
    setPrintFormatDialogOpen(false);
    if (!pendingPrintAction) return;
    handlePrintMonth(pendingPrintAction.monthLabel, pendingPrintAction.monthProductions, format);
    setPendingPrintAction(null);
  };

  const handlePrintMonth = (monthLabel: string, monthProductions: Production[], format: PrintFormat = 'a4') => {
    const totalQuantity = monthProductions.reduce((sum, p) => sum + p.quantity, 0);

    const totalRevenue = monthProductions.reduce((sum, p) => {
      return sum + (p.quantity * parseFloat(p.pricePerUnit.toString()));
    }, 0);

    const printContent = `
      <!DOCTYPE html>
      <html lang="pt-BR">
      <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Kanban Mensal - ${monthLabel}</title>
        <style>
          * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
          }
          body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #fff;
            padding: 20px;
            line-height: 1.6;
          }
          .container {
            max-width: 1000px;
            margin: 0 auto;
          }
          .header {
            text-align: center;
            margin-bottom: 30px;
            border-bottom: 3px solid #8B5CF6;
            padding-bottom: 20px;
          }
          .header h1 {
            font-size: 28px;
            color: #1F2937;
            margin-bottom: 5px;
          }
          .header p {
            font-size: 14px;
            color: #6B7280;
          }
          .summary {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 20px;
            margin-bottom: 30px;
          }
          .summary-box {
            background: #F3F4F6;
            border-left: 4px solid #8B5CF6;
            padding: 15px;
            border-radius: 4px;
          }
          .summary-box label {
            font-size: 12px;
            color: #6B7280;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.5px;
          }
          .summary-box .value {
            font-size: 24px;
            font-weight: 700;
            color: #1F2937;
            margin-top: 5px;
          }
          .productions {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 15px;
          }
          .production-card {
            border: 1px solid #E5E7EB;
            border-radius: 6px;
            padding: 15px;
            background: #FAFAFA;
            page-break-inside: avoid;
          }
          .prod-header {
            display: flex;
            justify-content: space-between;
            align-items: start;
            margin-bottom: 10px;
          }
          .prod-code {
            font-size: 11px;
            color: #9CA3AF;
            font-weight: 600;
          }
          .prod-name {
            font-size: 14px;
            font-weight: 700;
            color: #1F2937;
            margin: 5px 0;
          }
          .prod-status {
            display: inline-block;
            font-size: 11px;
            font-weight: 600;
            padding: 4px 8px;
            border-radius: 3px;
          }
          .status-open { background: #DBEAFE; color: #1E40AF; }
          .status-partial { background: #FEF3C7; color: #92400E; }
          .status-completed { background: #D1FAE5; color: #065F46; }
          .prod-supplier {
            font-size: 12px;
            color: #6B7280;
            margin: 8px 0;
            border-bottom: 1px solid #E5E7EB;
            padding-bottom: 8px;
          }
          .prod-variants {
            font-size: 12px;
            margin: 8px 0;
          }
          .variant-row {
            display: flex;
            justify-content: space-between;
            padding: 4px 0;
            color: #374151;
          }
          .prod-total {
            font-size: 12px;
            font-weight: 600;
            padding: 8px 0;
            border-top: 1px solid #E5E7EB;
            margin-top: 8px;
            display: flex;
            justify-content: space-between;
          }
          .prod-price {
            font-size: 12px;
            margin-top: 8px;
            padding-top: 8px;
            border-top: 1px solid #E5E7EB;
            display: flex;
            justify-content: space-between;
            color: #059669;
            font-weight: 600;
          }
          .prod-date {
            font-size: 11px;
            color: #9CA3AF;
            margin-top: 8px;
            padding-top: 8px;
            border-top: 1px solid #E5E7EB;
          }
          .prod-seamstresses {
            font-size: 12px;
            margin-top: 8px;
            padding-top: 8px;
            border-top: 1px solid #E5E7EB;
          }
          .prod-seamstresses strong {
            display: block;
            margin-bottom: 5px;
            color: #1F2937;
          }
          .seamstress-item {
            padding: 6px;
            margin: 4px 0;
            background: #EDE9FE;
            border-left: 3px solid #8B5CF6;
            border-radius: 2px;
            font-size: 11px;
          }
          .seamstress-name {
            font-weight: 600;
            color: #4C1D95;
          }
          .seamstress-contact {
            color: #6B7280;
            font-size: 10px;
          }
          .footer {
            margin-top: 30px;
            padding-top: 20px;
            border-top: 1px solid #E5E7EB;
            text-align: center;
            font-size: 12px;
            color: #9CA3AF;
          }
          @media print {
            body {
              padding: 0;
              margin: 0;
            }
            .container {
              max-width: 100%;
            }
            .production-card {
              page-break-inside: avoid;
            }
          }
        </style>
      </head>
      <body>
        <div class="container">
          <div class="header">
            <h1>KANBAN MENSAL</h1>
            <p>${monthLabel}</p>
          </div>

          <div class="summary">
            <div class="summary-box">
              <label>Total de Produções</label>
              <div class="value">${monthProductions.length}</div>
            </div>
            <div class="summary-box">
              <label>Total de Peças</label>
              <div class="value">${totalQuantity}</div>
            </div>
            <div class="summary-box">
              <label>Receita Total</label>
              <div class="value">R$ ${totalRevenue.toFixed(2)}</div>
            </div>
          </div>

          <div class="productions">
            ${monthProductions.map(prod => {
              const qty = prod.quantity;
              const revenue = qty * parseFloat(prod.pricePerUnit.toString());
              const statusClass = `status-${prod.status}`;
              
              // Get seamstresses for this production
              const productionBatches = batches.filter((b) => b.productionId === prod.id);
              const seamstressIds = Array.from(new Set(productionBatches.map((b) => b.seamstressId)));
              const productSeamstresses = seamstresses.filter((s) => seamstressIds.includes(s.id));
              
              return `
                <div class="production-card">
                  <div class="prod-header">
                    <div class="prod-code">${prod.code || 'N/A'}</div>
                    <span class="prod-status ${statusClass}">${prod.status === 'open' ? 'Aberta' : prod.status === 'partial' ? 'Parcial' : 'Concluída'}</span>
                  </div>
                  <div class="prod-name">${prod.productName}</div>
                  <div class="prod-supplier"><strong>Fornecedor:</strong> ${prod.supplier}</div>
                  
                  <div class="prod-variants">
                    ${prod.variants && prod.variants.length > 0 ? `
                      <div><strong>Variantes:</strong></div>
                      ${prod.variants.map(v => `<div class="variant-row"><span>${v.size} - ${v.color}</span><span>${v.quantity} un.</span></div>`).join('')}
                      <div class="prod-total"><span>Total:</span><span>${qty} un.</span></div>
                    ` : `
                      <div class="prod-total"><span>Quantidade:</span><span>${qty} un.</span></div>
                    `}
                  </div>

                  <div class="prod-price">
                    <span>Receita Total:</span>
                    <span>R$ ${revenue.toFixed(2)}</span>
                  </div>

                  <div class="prod-date">
                    ${format(new Date(prod.date), "dd 'de' MMMM 'de' yyyy", { locale: ptBR })}
                  </div>

                  ${productSeamstresses.length > 0 ? `
                    <div class="prod-seamstresses">
                      <strong>Costureiras:</strong>
                      ${productSeamstresses.map(s => `
                        <div class="seamstress-item">
                          <div class="seamstress-name">${s.name}</div>
                          <div class="seamstress-contact">📞 ${s.phone || 'N/A'} | 🏘️ ${s.neighborhood || 'N/A'}</div>
                        </div>
                      `).join('')}
                    </div>
                  ` : ''}
                </div>
              `;
            }).join('')}
          </div>

          <div class="footer">
            Impresso em: ${new Date().toLocaleString('pt-BR')}
          </div>
        </div>
      </body>
      </html>
    `;

    let content = '';
    if (format === 'cupom') {
      let productionLines = '';
      monthProductions.forEach(prod => {
        const productSeamstresses = getSeamstressesForProduction(prod.id);
        productionLines += `
          <div class="item">
            <div class="item-header">${prod.productName?.substring(0, 18) || 'N/A'}</div>
            <div class="item-row"><span>${prod.code}</span><span>${prod.quantity}un</span></div>
            <div class="item-row"><span>${prod.supplier?.substring(0, 12) || 'N/A'}</span><span>R$${(prod.quantity * parseFloat(prod.pricePerUnit.toString())).toFixed(0)}</span></div>
            ${productSeamstresses.length > 0 ? `<div class="info">Cost: ${productSeamstresses.map(s => s.name.substring(0, 10)).join(', ')}</div>` : ''}
          </div>
        `;
      });

      content = `<!DOCTYPE html><html lang="pt-BR"><head><meta charset="UTF-8">
        <title>Kanban - ${monthLabel}</title>
        <style>${getCupomBaseStyles()}</style>
      </head><body>
        <div class="cupom">
          <div class="header">GOFAST PRODUCOES</div>
          <div class="title">KANBAN MENSAL</div>
          <div class="info">${monthLabel}</div>
          <div class="divider"></div>
          <div class="total">Prods: ${monthProductions.length}</div>
          <div class="total">Pecas: ${totalQuantity}</div>
          <div class="total">Total: R$ ${totalRevenue.toFixed(2)}</div>
          <div class="divider"></div>
          ${productionLines}
          <div class="divider"></div>
          <div class="footer">${new Date().toLocaleString('pt-BR')}</div>
        </div>
      </body></html>`;
    } else {
      content = printContent;
    }
    
    printHtml(content);
  };

  // Agrupar produções por mês/ano
  const productionsByMonth = productions.reduce((acc, prod) => {
    const date = new Date(prod.date);
    const monthKey = format(date, "yyyy-MM");
    const monthLabel = format(date, "MMMM yyyy", { locale: ptBR });

    if (!acc[monthKey]) {
      acc[monthKey] = {
        label: monthLabel,
        productions: [],
      };
    }
    acc[monthKey].productions.push(prod);
    return acc;
  }, {} as Record<string, { label: string; productions: Production[] }>);

  // Ordenar meses cronologicamente
  const sortedMonths = Object.entries(productionsByMonth)
    .sort(([keyA], [keyB]) => keyA.localeCompare(keyB))
    .reverse(); // Mais recentes primeiro

  // Se não houver meses, mostrar mensagem
  if (sortedMonths.length === 0) {
    return (
      <div className="p-8">
        <h1 className="text-3xl font-semibold mb-6">Kanban Mensal</h1>
        <p className="text-muted-foreground">Nenhuma produção encontrada</p>
      </div>
    );
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case "open":
        return "bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200";
      case "partial":
        return "bg-amber-100 text-amber-800 dark:bg-amber-900 dark:text-amber-200";
      case "completed":
        return "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200";
      default:
        return "bg-gray-100 text-gray-800 dark:bg-gray-900 dark:text-gray-200";
    }
  };

  const getStatusLabel = (status: string) => {
    switch (status) {
      case "open":
        return "Aberta";
      case "partial":
        return "Parcial";
      case "completed":
        return "Concluída";
      default:
        return status;
    }
  };

  const getBatchStatusLabel = (status: string) => {
    const labels: Record<string, string> = {
      em_separacao: "Em Separação",
      para_entrega: "Para Entrega",
      em_producao: "Em Produção",
      para_recolha: "Para Recolha",
      concluido: "Concluído",
    };
    return labels[status] || status;
  };

  const toggleBatchStatusFilter = (status: BatchStatus) => {
    const newFilter = new Set(batchStatusFilter);
    if (newFilter.has(status)) {
      newFilter.delete(status);
    } else {
      newFilter.add(status);
    }
    setBatchStatusFilter(newFilter);
  };

  // Get count of batches with filters
  const getBatchCountByStatus = (status: BatchStatus) => {
    return (batches as any[]).filter((b: any) => b.status === status).length;
  };

  return (
    <div className="p-4 md:p-8 space-y-6">
      <div>
        <h1 className="text-2xl md:text-3xl font-bold">Kanban Mensal</h1>
        <p className="text-sm md:text-base text-muted-foreground mt-2">
          Visualize as produções organizadas por mês
        </p>
      </div>

      {/* Batch Status Filter */}
      <Card className="p-4 bg-muted/50 space-y-3">
        <p className="text-sm font-medium">Filtrar Lotes por Status:</p>
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3">
          {(["em_separacao", "para_entrega", "em_producao", "para_recolha", "concluido"] as BatchStatus[]).map((status) => (
            <Label key={status} className="flex items-center gap-2 cursor-pointer">
              <Input
                type="checkbox"
                checked={batchStatusFilter.has(status)}
                onChange={() => toggleBatchStatusFilter(status)}
                className="w-4 h-4 cursor-pointer"
                data-testid={`checkbox-batch-status-${status}`}
              />
              <span className="text-xs font-medium">{getBatchStatusLabel(status)}</span>
              <span className="text-xs text-muted-foreground">({getBatchCountByStatus(status)})</span>
            </Label>
          ))}
        </div>
      </Card>

      <Tabs defaultValue={sortedMonths[0]?.[0]} className="w-full" onValueChange={setSelectedMonth}>
        <TabsList className="flex flex-wrap gap-1 h-auto p-2 bg-muted rounded-lg mb-6 w-full">
          {sortedMonths.map(([monthKey, { label }]) => (
            <TabsTrigger
              key={monthKey}
              value={monthKey}
              className="text-xs px-2 py-1"
              data-testid={`tab-month-${monthKey}`}
            >
              {label}
            </TabsTrigger>
          ))}
        </TabsList>

        {sortedMonths.map(([monthKey, { label, productions: monthProductions }]) => {
          // Filter productions based on batch status
          const filteredProductions = monthProductions.filter((production: Production) => {
            const productionBatches = (batches as any[]).filter((b: any) => b.productionId === production.id);
            return productionBatches.some((b: any) => batchStatusFilter.has(b.status as BatchStatus));
          });

          return (
          <TabsContent key={monthKey} value={monthKey} className="space-y-4">
            <div className="flex items-center justify-between gap-2 flex-wrap">
              <h2 className="text-xl md:text-2xl font-semibold">{label}</h2>
              <div className="flex items-center gap-2">
                <span className="text-sm text-muted-foreground">
                  {filteredProductions.length} produção{filteredProductions.length !== 1 ? "s" : ""}
                </span>
                {filteredProductions.length > 0 && (
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => openPrintMonthDialog(label, filteredProductions)}
                    data-testid={`button-print-month-${monthKey}`}
                    className="gap-2"
                  >
                    <Printer className="w-4 h-4" />
                    Imprimir
                  </Button>
                )}
              </div>
            </div>

            {filteredProductions.length === 0 ? (
              <div className="text-center py-8 text-muted-foreground">
                Nenhuma produção neste mês com os filtros selecionados
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 md:gap-6">
                {filteredProductions.map((production) => {
                  const totalRevenue = production.quantity * parseFloat(production.pricePerUnit.toString());

                  return (
                    <Card
                      key={production.id}
                      className="p-4 md:p-6 hover-elevate cursor-pointer border border-border"
                      data-testid={`card-production-${production.id}`}
                    >
                      <div className="space-y-4">
                        {/* Header */}
                        <div className="flex flex-col sm:flex-row sm:items-start sm:justify-between gap-2">
                          <div className="flex-1 min-w-0">
                            <p className="text-xs md:text-sm text-muted-foreground truncate">
                              {production.code}
                            </p>
                            <h3 className="text-base md:text-lg font-bold truncate mt-1">
                              {production.productName}
                            </h3>
                          </div>
                          <Badge
                            className={`flex-shrink-0 text-xs ${getStatusColor(production.status)}`}
                            data-testid={`badge-status-${production.id}`}
                          >
                            {getStatusLabel(production.status)}
                          </Badge>
                        </div>

                        {/* Supplier */}
                        <div className="border-t border-border pt-3">
                          <p className="text-xs md:text-sm text-muted-foreground">
                            <span className="font-semibold">Fornecedor:</span> {production.supplier}
                          </p>
                        </div>

                        {/* Seamstresses */}
                        {(() => {
                          const productSeamstresses = getSeamstressesForProduction(production.id);
                          if (productSeamstresses.length > 0) {
                            return (
                              <div className="border-t border-border pt-3">
                                <p className="text-xs md:text-sm font-semibold text-muted-foreground mb-2">
                                  Costureiras:
                                </p>
                                <div className="space-y-2">
                                  {productSeamstresses.map((seamstress) => (
                                    <div key={seamstress.id} className="text-xs md:text-sm p-2 bg-purple-900/20 border border-purple-600/30 rounded">
                                      <div className="font-semibold text-purple-400">{seamstress.name}</div>
                                      {seamstress.phone && (
                                        <div className="text-purple-300/80 text-xs">📞 {seamstress.phone}</div>
                                      )}
                                      {seamstress.neighborhood && (
                                        <div className="text-purple-300/80 text-xs">🏘️ {seamstress.neighborhood}</div>
                                      )}
                                    </div>
                                  ))}
                                </div>
                              </div>
                            );
                          }
                          return null;
                        })()}

                        {/* Variants or Quantity */}
                        <div className="space-y-2">
                          {production.variants && production.variants.length > 0 ? (
                            <div>
                              <p className="text-xs md:text-sm font-semibold text-muted-foreground mb-2">
                                Variantes:
                              </p>
                              <div className="space-y-1">
                                {production.variants.map((variant, idx) => (
                                  <div
                                    key={idx}
                                    className="flex justify-between text-xs md:text-sm"
                                  >
                                    <span>
                                      {variant.size} - {variant.color}
                                    </span>
                                    <span className="font-semibold">{variant.quantity} un.</span>
                                  </div>
                                ))}
                              </div>
                              <div className="flex justify-between border-t border-gray-200 dark:border-gray-700 pt-2 mt-2 font-bold">
                                <span className="text-xs md:text-sm">Total:</span>
                                <span className="text-xs md:text-sm">
                                  {production.quantity} un.
                                </span>
                              </div>
                            </div>
                          ) : (
                            <div className="flex justify-between text-xs md:text-sm">
                              <span className="font-semibold">Quantidade:</span>
                              <span>{production.quantity} un.</span>
                            </div>
                          )}
                        </div>

                        {/* Financial Info */}
                        <div className="border-t border-border pt-3 space-y-2">
                          <div className="flex justify-between text-xs md:text-sm">
                            <span className="text-muted-foreground">Preço Unitário:</span>
                            <span className="font-semibold">
                              R$ {parseFloat(production.pricePerUnit.toString()).toFixed(2)}
                            </span>
                          </div>
                          <div className="flex justify-between text-xs md:text-sm">
                            <span className="text-muted-foreground">Receita Total:</span>
                            <span className="font-bold text-green-600 dark:text-green-400">
                              R$ {totalRevenue.toFixed(2)}
                            </span>
                          </div>
                        </div>

                        {/* Date */}
                        <div className="border-t border-border pt-3">
                          <p className="text-xs text-muted-foreground">
                            {format(new Date(production.date), "dd 'de' MMMM 'de' yyyy", {
                              locale: ptBR,
                            })}
                          </p>
                        </div>
                      </div>
                    </Card>
                  );
                })}
              </div>
            )}
          </TabsContent>
          );
        })}
      </Tabs>

      <PrintFormatDialog
        open={printFormatDialogOpen}
        onOpenChange={setPrintFormatDialogOpen}
        onSelectFormat={handlePrintFormatSelect}
      />
    </div>
  );
};

export default MonthlyKanban;
