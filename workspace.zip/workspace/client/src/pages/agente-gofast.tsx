import { getAuthHeader } from "../lib/auth";
import { useState, useRef, useEffect } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useQuery, useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { Send, Bot, User, RefreshCw, AlertTriangle, TrendingUp, Users, Package, Loader2, Code, BarChart3, FileCode, CheckCircle, XCircle, Eye } from "lucide-react";

interface Message {
  role: "user" | "assistant";
  content: string;
  timestamp: string;
  actions?: any[];
}

interface AgentContext {
  resumoGeral: {
    totalProducoes: number;
    producoesAtivas: number;
    producoesConcluidas: number;
    totalLotes: number;
    lotesPendentes: number;
    lotesAtrasados: number;
    totalCostureiras: number;
    costureirasAtivas: number;
    pagamentosPendentes: number;
  };
  financeiro: {
    receitaTotal: number;
    custoProducao: number;
    lucroEstimado: number;
    margemLucro: string | number;
  };
  alertas: {
    lotesAtrasados: any[];
    producoesComProblemas: any[];
    lotesComProblemas: any[];
    pagamentosPendentes: any[];
  };
}

interface FileInfo {
  name: string;
  path: string;
  isDirectory: boolean;
  size?: number;
}

const AgenteGoFast = () => {
  const [mode, setMode] = useState<"monitor" | "code">("monitor");
  const [messages, setMessages] = useState<Message[]>([]);
  const [codeMessages, setCodeMessages] = useState<Message[]>([]);
  const [input, setInput] = useState("");
  const [selectedFile, setSelectedFile] = useState<string | null>(null);
  const [fileContent, setFileContent] = useState<string>("");
  const chatEndRef = useRef<HTMLDivElement>(null);
  const codeEndRef = useRef<HTMLDivElement>(null);

  const { data: context, isLoading: loadingContext, refetch: refetchContext } = useQuery<AgentContext>({
    queryKey: ["/api/agent/context"],
    refetchInterval: 60000,
  });

  const { data: filesData, refetch: refetchFiles } = useQuery<{ files: FileInfo[] }>({
    queryKey: ["/api/agent/fs/list"],
    enabled: mode === "code",
    queryFn: async () => {
      const res = await fetch("/api/agent/fs/list", { headers: getAuthHeader() });
      return res.json();
    },
  });

  const chatMutation = useMutation({
    mutationFn: async (message: string) => {
      const response = await apiRequest("POST", "/api/agent/chat", {
        message,
        history: messages.slice(-10),
      });
      return response.json();
    },
    onSuccess: (data) => {
      setMessages((prev) => [
        ...prev,
        {
          role: "assistant",
          content: data.response,
          timestamp: data.timestamp,
        },
      ]);
    },
    onError: (error: any) => {
      setMessages((prev) => [...prev, { role: "assistant", content: `Não consegui consultar a IA nesta tentativa. ${error?.message || "Erro desconhecido"}`, timestamp: new Date().toISOString() }]);
    },
  });

  const codeChatMutation = useMutation({
    mutationFn: async (message: string) => {
      const response = await apiRequest("POST", "/api/agent/code-chat", {
        message,
        history: codeMessages.slice(-10),
      });
      return response.json();
    },
    onSuccess: (data) => {
      setCodeMessages((prev) => [
        ...prev,
        {
          role: "assistant",
          content: data.response,
          timestamp: data.timestamp,
          actions: data.actions,
        },
      ]);
      if (data.actions && data.actions.length > 0) {
        refetchFiles();
      }
    },
    onError: (error: any) => {
      setCodeMessages((prev) => [...prev, { role: "assistant", content: `Erro no agente de código: ${error?.message || "erro desconhecido"}`, timestamp: new Date().toISOString() }]);
    },
  });

  const readFileMutation = useMutation({
    mutationFn: async (filePath: string) => {
      const response = await fetch(`/api/agent/fs/read?path=${encodeURIComponent(filePath)}`, { headers: getAuthHeader() });
      return response.json();
    },
    onSuccess: (data) => {
      if (data.success) {
        setFileContent(data.content);
      }
    },
  });

  const handleSend = () => {
    if (!input.trim()) return;

    const userMessage: Message = {
      role: "user",
      content: input.trim(),
      timestamp: new Date().toISOString(),
    };

    if (mode === "monitor") {
      if (chatMutation.isPending) return;
      setMessages((prev) => [...prev, userMessage]);
      chatMutation.mutate(input.trim());
    } else {
      if (codeChatMutation.isPending) return;
      setCodeMessages((prev) => [...prev, userMessage]);
      codeChatMutation.mutate(input.trim());
    }
    setInput("");
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  const handleFileClick = (file: FileInfo) => {
    if (!file.isDirectory) {
      setSelectedFile(file.path);
      readFileMutation.mutate(file.path);
    }
  };

  useEffect(() => {
    if (mode === "monitor") {
      chatEndRef.current?.scrollIntoView({ behavior: "smooth" });
    } else {
      codeEndRef.current?.scrollIntoView({ behavior: "smooth" });
    }
  }, [messages, codeMessages, mode]);

  const quickCommands = [
    { label: "Resumo do dia", command: "Me dê um resumo completo da operação hoje" },
    { label: "Lotes atrasados", command: "Quais lotes estão atrasados e quem são as costureiras responsáveis?" },
    { label: "Sugestões de melhoria", command: "O que precisa melhorar no meu sistema hoje?" },
    { label: "Análise financeira", command: "Faça uma análise financeira detalhada da operação" },
  ];

  const codeCommands = [
    { label: "Ver arquitetura", command: "Mostre a estrutura do sistema e os principais arquivos" },
    { label: "Listar arquivos", command: "Liste todos os arquivos disponíveis para edição" },
    { label: "Documentação", command: "Mostre a documentação completa do sistema" },
  ];

  const totalAlertas = context ? 
    (context.alertas?.lotesAtrasados?.length || 0) + 
    (context.alertas?.producoesComProblemas?.length || 0) + 
    (context.alertas?.pagamentosPendentes?.length || 0) : 0;

  const currentMessages = mode === "monitor" ? messages : codeMessages;
  const isPending = mode === "monitor" ? chatMutation.isPending : codeChatMutation.isPending;
  const endRef = mode === "monitor" ? chatEndRef : codeEndRef;

  return (
    <div className="h-[calc(100vh-80px)] flex flex-col p-4 gap-4">
      <div className="flex items-center justify-between flex-wrap gap-2">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-full bg-gradient-to-r from-purple-600 to-cyan-500 flex items-center justify-center">
            <Bot className="w-7 h-7 text-white" />
          </div>
          <div>
            <h1 className="text-xl md:text-2xl font-bold">Agente GoFast</h1>
            <p className="text-xs md:text-sm text-muted-foreground">
              {mode === "monitor" ? "Monitoramento & Inteligência" : "Acesso Total ao Código"}
            </p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <Tabs value={mode} onValueChange={(v) => setMode(v as "monitor" | "code")} className="w-auto">
            <TabsList>
              <TabsTrigger value="monitor" className="gap-1" data-testid="tab-monitor">
                <BarChart3 className="w-4 h-4" />
                <span className="hidden sm:inline">Monitorar</span>
              </TabsTrigger>
              <TabsTrigger value="code" className="gap-1" data-testid="tab-code">
                <Code className="w-4 h-4" />
                <span className="hidden sm:inline">Código</span>
              </TabsTrigger>
            </TabsList>
          </Tabs>
          <Button
            variant="outline"
            size="sm"
            onClick={() => mode === "monitor" ? refetchContext() : refetchFiles()}
            className="gap-1"
            data-testid="button-refresh-context"
          >
            <RefreshCw className="w-4 h-4" />
            <span className="hidden sm:inline">Atualizar</span>
          </Button>
        </div>
      </div>

      {mode === "monitor" && (
        <div className="grid grid-cols-2 md:grid-cols-4 gap-2 md:gap-4">
          <Card className="p-3 md:p-4">
            <div className="flex items-center gap-2 md:gap-3">
              <Package className="w-6 h-6 md:w-8 md:h-8 text-blue-500" />
              <div>
                <p className="text-xs text-muted-foreground">Produções Ativas</p>
                <p className="text-lg md:text-2xl font-bold">{context?.resumoGeral?.producoesAtivas || 0}</p>
              </div>
            </div>
          </Card>
          <Card className="p-3 md:p-4">
            <div className="flex items-center gap-2 md:gap-3">
              <Users className="w-6 h-6 md:w-8 md:h-8 text-green-500" />
              <div>
                <p className="text-xs text-muted-foreground">Costureiras</p>
                <p className="text-lg md:text-2xl font-bold">{context?.resumoGeral?.costureirasAtivas || 0}</p>
              </div>
            </div>
          </Card>
          <Card className="p-3 md:p-4">
            <div className="flex items-center gap-2 md:gap-3">
              <TrendingUp className="w-6 h-6 md:w-8 md:h-8 text-emerald-500" />
              <div>
                <p className="text-xs text-muted-foreground">Margem</p>
                <p className="text-lg md:text-2xl font-bold">{context?.financeiro?.margemLucro || 0}%</p>
              </div>
            </div>
          </Card>
          <Card className={`p-3 md:p-4 ${totalAlertas > 0 ? 'border-orange-500/50' : ''}`}>
            <div className="flex items-center gap-2 md:gap-3">
              <AlertTriangle className={`w-6 h-6 md:w-8 md:h-8 ${totalAlertas > 0 ? 'text-orange-500' : 'text-muted-foreground'}`} />
              <div>
                <p className="text-xs text-muted-foreground">Alertas</p>
                <p className={`text-lg md:text-2xl font-bold ${totalAlertas > 0 ? 'text-orange-500' : ''}`}>{totalAlertas}</p>
              </div>
            </div>
          </Card>
        </div>
      )}

      {mode === "code" && (
        <Card className="p-3 bg-gradient-to-r from-purple-900/20 to-cyan-900/20 border-purple-500/30">
          <div className="flex items-center gap-2 text-sm">
            <Code className="w-5 h-5 text-purple-400" />
            <span className="font-medium text-purple-200">Modo Desenvolvedor Ativo</span>
            <span className="text-muted-foreground">- O Agente pode ler, editar e criar arquivos do sistema</span>
          </div>
        </Card>
      )}

      <div className="flex flex-wrap gap-2">
        {(mode === "monitor" ? quickCommands : codeCommands).map((cmd) => (
          <Button
            key={cmd.label}
            variant="outline"
            size="sm"
            onClick={() => setInput(cmd.command)}
            data-testid={`button-quick-${cmd.label.toLowerCase().replace(/\s/g, '-')}`}
          >
            {cmd.label}
          </Button>
        ))}
      </div>

      <div className="flex-1 flex gap-4 overflow-hidden">
        <Card className="flex-1 flex flex-col overflow-hidden">
          <div className="flex-1 overflow-y-auto p-4 space-y-4">
            {currentMessages.length === 0 ? (
              <div className="h-full flex flex-col items-center justify-center text-center text-muted-foreground">
                <Bot className="w-16 h-16 mb-4 opacity-50" />
                <h3 className="text-lg font-medium mb-2">
                  {mode === "monitor" ? "Olá! Sou o Agente GoFast" : "Modo Desenvolvedor"}
                </h3>
                <p className="max-w-md text-sm">
                  {mode === "monitor" 
                    ? "Pergunte sobre lotes, produções, costureiras, finanças ou peça sugestões de melhoria."
                    : "Tenho acesso total ao código. Peça para modificar qualquer lógica, cálculo ou interface do sistema."
                  }
                </p>
              </div>
            ) : (
              currentMessages.map((msg, idx) => (
                <div
                  key={idx}
                  className={`flex gap-3 ${msg.role === "user" ? "justify-end" : "justify-start"}`}
                >
                  {msg.role === "assistant" && (
                    <div className={`w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 ${
                      mode === "code" 
                        ? "bg-gradient-to-r from-purple-600 to-pink-500"
                        : "bg-gradient-to-r from-purple-600 to-cyan-500"
                    }`}>
                      {mode === "code" ? <FileCode className="w-5 h-5 text-white" /> : <Bot className="w-5 h-5 text-white" />}
                    </div>
                  )}
                  <div
                    className={`max-w-[85%] rounded-lg p-4 ${
                      msg.role === "user"
                        ? "bg-primary text-primary-foreground"
                        : "bg-muted"
                    }`}
                  >
                    <div className="whitespace-pre-wrap text-sm">{msg.content}</div>
                    {msg.actions && msg.actions.length > 0 && (
                      <div className="mt-3 pt-3 border-t border-border/50 space-y-2">
                        {msg.actions.map((action: any, i: number) => (
                          <div key={i} className="flex items-center gap-2 text-xs">
                            {action.result?.success ? (
                              <CheckCircle className="w-4 h-4 text-green-500" />
                            ) : (
                              <XCircle className="w-4 h-4 text-red-500" />
                            )}
                            <span className="font-mono">{action.filePath}</span>
                            <span className="text-muted-foreground">({action.action})</span>
                          </div>
                        ))}
                      </div>
                    )}
                    <p className="text-xs opacity-70 mt-2">
                      {new Date(msg.timestamp).toLocaleTimeString("pt-BR")}
                    </p>
                  </div>
                  {msg.role === "user" && (
                    <div className="w-8 h-8 rounded-full bg-primary flex items-center justify-center flex-shrink-0">
                      <User className="w-5 h-5 text-primary-foreground" />
                    </div>
                  )}
                </div>
              ))
            )}
            {isPending && (
              <div className="flex gap-3 justify-start">
                <div className={`w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 ${
                  mode === "code" 
                    ? "bg-gradient-to-r from-purple-600 to-pink-500"
                    : "bg-gradient-to-r from-purple-600 to-cyan-500"
                }`}>
                  {mode === "code" ? <FileCode className="w-5 h-5 text-white" /> : <Bot className="w-5 h-5 text-white" />}
                </div>
                <div className="bg-muted rounded-lg p-4 flex items-center gap-2">
                  <Loader2 className="w-4 h-4 animate-spin" />
                  <span className="text-sm">{mode === "code" ? "Analisando código..." : "Analisando dados..."}</span>
                </div>
              </div>
            )}
            <div ref={endRef} />
          </div>

          <div className="border-t p-4">
            <div className="flex gap-2">
              <Textarea
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={handleKeyDown}
                placeholder={mode === "monitor" 
                  ? "Pergunte sobre sua operação..." 
                  : "Peça uma alteração no código (ex: 'mude a cor do botão para verde')"
                }
                className="resize-none min-h-[50px] max-h-[150px]"
                data-testid="input-agent-message"
              />
              <Button
                onClick={handleSend}
                disabled={!input.trim() || isPending}
                size="icon"
                className="h-auto"
                data-testid="button-send-message"
              >
                <Send className="w-5 h-5" />
              </Button>
            </div>
          </div>
        </Card>

        {mode === "code" && selectedFile && (
          <Card className="w-96 hidden lg:flex flex-col overflow-hidden">
            <div className="p-3 border-b flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Eye className="w-4 h-4" />
                <span className="text-sm font-mono truncate">{selectedFile}</span>
              </div>
              <Button variant="ghost" size="sm" onClick={() => setSelectedFile(null)}>
                ×
              </Button>
            </div>
            <div className="flex-1 overflow-auto p-3">
              <pre className="text-xs font-mono whitespace-pre-wrap">{fileContent}</pre>
            </div>
          </Card>
        )}
      </div>
    </div>
  );
};

export default AgenteGoFast;
