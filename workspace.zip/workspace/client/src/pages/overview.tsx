import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { ChevronDown, ChevronUp, Printer } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { PrintFormatDialog, PrintFormat, getCupomBaseStyles, printContent as printHtml } from "@/components/print-format-dialog";

type BatchStatus = "em_separacao" | "para_entrega" | "em_producao" | "para_recolha" | "concluido";

const Overview = () => {
  const [expandedSeamstresses, setExpandedSeamstresses] = useState<Set<string>>(new Set());
  const [showOnlyActive, setShowOnlyActive] = useState(true);
  const [statusFilter, setStatusFilter] = useState<Set<BatchStatus>>(
    new Set(["em_separacao", "para_entrega", "em_producao", "para_recolha", "concluido"] as BatchStatus[])
  );
  
  // Print format dialog state
  const [printFormatDialogOpen, setPrintFormatDialogOpen] = useState(false);
  const [pendingPrintAction, setPendingPrintAction] = useState<{
    type: 'single' | 'all';
    data?: any;
  } | null>(null);

  const { data: seamstresses = [] } = useQuery<any[]>({
    queryKey: ["/api/seamstresses"],
  });

  const { data: batches = [] } = useQuery<any[]>({
    queryKey: ["/api/batches"],
  });

  const { data: productions = [] } = useQuery<any[]>({
    queryKey: ["/api/productions"],
  });

  // Agrupar dados por costureira
  const seamstressOverview = seamstresses.map((seamstress: any) => {
    const seamstressBatches = batches.filter((b: any) => b.seamstressId === seamstress.id);
    const seamstressProductions = new Map<string, any>();

    seamstressBatches.forEach((batch: any) => {
      const production = productions.find((p: any) => p.id === batch.productionId);
      if (production && !seamstressProductions.has(production.id)) {
        seamstressProductions.set(production.id, production);
      }
    });

    return {
      ...seamstress,
      batches: seamstressBatches,
      productions: Array.from(seamstressProductions.values()),
    };
  });

  const toggleExpanded = (id: string) => {
    const newExpanded = new Set(expandedSeamstresses);
    if (newExpanded.has(id)) {
      newExpanded.delete(id);
    } else {
      newExpanded.add(id);
    }
    setExpandedSeamstresses(newExpanded);
  };

  // Print format dialog functions
  const openPrintSeamstressDialog = (seamstress: any) => {
    setPendingPrintAction({ type: 'single', data: seamstress });
    setPrintFormatDialogOpen(true);
  };

  const openPrintAllDialog = () => {
    setPendingPrintAction({ type: 'all' });
    setPrintFormatDialogOpen(true);
  };

  const handlePrintFormatSelect = (format: PrintFormat) => {
    setPrintFormatDialogOpen(false);
    if (!pendingPrintAction) return;

    if (pendingPrintAction.type === 'single') {
      handlePrintSeamstress(pendingPrintAction.data, format);
    } else {
      handlePrintAll(format);
    }
    setPendingPrintAction(null);
  };

  const handlePrintSeamstress = (seamstress: any, format: PrintFormat = 'a4') => {
    let content = '';
    
    if (format === 'cupom') {
      let batchLines = '';
      seamstress.batches.forEach((batch: any) => {
        const production = productions.find((p: any) => p.id === batch.productionId);
        batchLines += `
          <div class="item">
            <div class="item-header">${batch.batchCode}</div>
            <div class="item-row"><span>Prod:</span><span>${production?.productName?.substring(0, 10) || 'N/A'}</span></div>
            <div class="item-row"><span>Qtd:</span><span>${batch.quantity}</span></div>
            <div class="item-row"><span>Status:</span><span>${getStatusLabel(batch.status).substring(0, 12)}</span></div>
          </div>
        `;
      });

      content = `<!DOCTYPE html><html lang="pt-BR"><head><meta charset="UTF-8">
        <title>Visao Geral - ${seamstress.name}</title>
        <style>${getCupomBaseStyles()}</style>
      </head><body>
        <div class="cupom">
          <div class="header">GOFAST PRODUCOES</div>
          <div class="title">VISAO GERAL</div>
          <div class="divider"></div>
          <div class="info">${seamstress.name}</div>
          <div class="info">Tel: ${seamstress.phone || 'N/A'}</div>
          <div class="info">${seamstress.address || ''}</div>
          <div class="total">Lotes: ${seamstress.batches.length}</div>
          <div class="divider"></div>
          ${batchLines}
          <div class="divider"></div>
          <div class="footer">${new Date().toLocaleString('pt-BR')}</div>
        </div>
      </body></html>`;
    } else {
      content = generateSeamstressPrintContent(seamstress);
    }
    
    printHtml(content);
  };

  const handlePrintAll = (format: PrintFormat = 'a4') => {
    const activeSemstresses = filteredSeamstresses.filter((s: any) => s.batches.length > 0);
    let content = '';
    
    if (format === 'cupom') {
      let seamstressLines = '';
      activeSemstresses.forEach((seamstress: any) => {
        seamstressLines += `
          <div class="item">
            <div class="item-header">${seamstress.name.substring(0, 20)}</div>
            <div class="item-row"><span>Lotes:</span><span>${seamstress.batches.length}</span></div>
            <div class="item-row"><span>Prods:</span><span>${seamstress.productions.length}</span></div>
          </div>
        `;
      });

      content = `<!DOCTYPE html><html lang="pt-BR"><head><meta charset="UTF-8">
        <title>Visao Geral Completa</title>
        <style>${getCupomBaseStyles()}</style>
      </head><body>
        <div class="cupom">
          <div class="header">GOFAST PRODUCOES</div>
          <div class="title">VISAO GERAL</div>
          <div class="divider"></div>
          <div class="total">${activeSemstresses.length} costureiras</div>
          <div class="divider"></div>
          ${seamstressLines}
          <div class="divider"></div>
          <div class="footer">${new Date().toLocaleString('pt-BR')}</div>
        </div>
      </body></html>`;
    } else {
      content = generateAllPrintContent(activeSemstresses);
    }
    
    printHtml(content);
  };

  const generateSeamstressPrintContent = (seamstress: any) => {
    const batchesHtml = seamstress.batches.map((batch: any) => {
      const production = productions.find((p: any) => p.id === batch.productionId);
      const statusColor = batch.status === "concluido" ? "#10b981" : 
                         batch.status === "para_recolha" ? "#f59e0b" : "#eab308";
      
      return `
        <tr>
          <td style="padding: 8px; border-bottom: 1px solid #ddd;">${production?.productName || "N/A"}</td>
          <td style="padding: 8px; border-bottom: 1px solid #ddd;">${batch.batchCode}</td>
          <td style="padding: 8px; border-bottom: 1px solid #ddd;">${batch.quantity}</td>
          <td style="padding: 8px; border-bottom: 1px solid #ddd; color: ${statusColor}; font-weight: bold;">
            ${getStatusLabel(batch.status)}
          </td>
          <td style="padding: 8px; border-bottom: 1px solid #ddd;">${new Date(batch.expectedReturnDate).toLocaleDateString("pt-BR")}</td>
        </tr>
      `;
    }).join("");

    return `
      <!DOCTYPE html>
      <html lang="pt-BR">
      <head>
        <meta charset="UTF-8">
        <title>Visão Geral - ${seamstress.name}</title>
        <style>
          body { font-family: Arial, sans-serif; margin: 20px; }
          .header { border-bottom: 3px solid #8B5CF6; padding-bottom: 10px; margin-bottom: 20px; }
          .header h1 { margin: 0; color: #333; }
          .info { margin-bottom: 10px; font-size: 14px; }
          table { width: 100%; border-collapse: collapse; margin-top: 20px; }
          th { background-color: #f3f4f6; padding: 10px; text-align: left; font-weight: bold; border-bottom: 2px solid #333; }
          td { padding: 8px; border-bottom: 1px solid #ddd; }
          .footer { margin-top: 30px; font-size: 12px; color: #666; }
        </style>
      </head>
      <body>
        <div class="header">
          <h1>Visão Geral - ${seamstress.name}</h1>
          <p style="margin: 5px 0; color: #666;">${new Date().toLocaleDateString("pt-BR")}</p>
        </div>
        <div class="info">
          <p><strong>Telefone:</strong> ${seamstress.phone}</p>
          <p><strong>Endereço:</strong> ${seamstress.address}, ${seamstress.neighborhood}</p>
          <p><strong>Total de Lotes:</strong> ${seamstress.batches.length}</p>
        </div>
        <table>
          <thead>
            <tr>
              <th>Produção</th>
              <th>Código do Lote</th>
              <th>Quantidade</th>
              <th>Status</th>
              <th>Data de Retorno</th>
            </tr>
          </thead>
          <tbody>
            ${batchesHtml}
          </tbody>
        </table>
        <div class="footer">
          <p>Impresso em ${new Date().toLocaleString("pt-BR")}</p>
        </div>
      </body>
      </html>
    `;
  };

  const generateAllPrintContent = (seamstressOverview: any[]) => {
    // Expandir todos para impressão
    const allSeamstressesHtml = seamstressOverview.map((seamstress: any) => {
      const batchesHtml = seamstress.batches.map((batch: any) => {
        const production = productions.find((p: any) => p.id === batch.productionId);
        const statusColor = batch.status === "concluido" ? "#10b981" : 
                           batch.status === "para_recolha" ? "#f59e0b" : "#eab308";
        
        return `
          <tr>
            <td style="padding: 6px; border-bottom: 1px solid #ddd; font-size: 12px;">${production?.productName || "N/A"}</td>
            <td style="padding: 6px; border-bottom: 1px solid #ddd; font-size: 12px;">${batch.batchCode}</td>
            <td style="padding: 6px; border-bottom: 1px solid #ddd; font-size: 12px; text-align: center;">${batch.quantity}</td>
            <td style="padding: 6px; border-bottom: 1px solid #ddd; font-size: 12px; color: ${statusColor}; font-weight: bold; text-align: center;">
              ${getStatusLabel(batch.status)}
            </td>
            <td style="padding: 6px; border-bottom: 1px solid #ddd; font-size: 12px;">${new Date(batch.expectedReturnDate).toLocaleDateString("pt-BR")}</td>
          </tr>
        `;
      }).join("");

      return `
        <div style="margin-bottom: 20px; page-break-inside: avoid; border: 1px solid #e5e7eb; padding: 12px;">
          <h2 style="border-bottom: 2px solid #8B5CF6; padding-bottom: 6px; margin: 0 0 10px 0; font-size: 16px;">${seamstress.name}</h2>
          
          <div style="display: grid; grid-template-columns: 2fr 2fr 1.5fr 1fr 1fr; gap: 8px; margin-bottom: 10px; font-size: 11px;">
            <div><strong>Nome:</strong> ${seamstress.name}</div>
            <div style="grid-column: span 2;"><strong>Endereço:</strong> ${seamstress.address || 'N/A'}</div>
            <div><strong>Bairro:</strong> ${seamstress.neighborhood || 'N/A'}</div>
            <div><strong>Tel:</strong> ${seamstress.phone || 'N/A'}</div>
            <div><strong>Lotes:</strong> ${seamstress.batches.length}</div>
            <div style="grid-column: 2;"><strong>Produções:</strong> ${seamstress.productions.length}</div>
          </div>

          <table style="width: 100%; border-collapse: collapse; margin-top: 8px; font-size: 12px;">
            <thead>
              <tr style="background-color: #f3f4f6;">
                <th style="padding: 6px; text-align: left; font-weight: bold; border-bottom: 1px solid #333; font-size: 11px;">Produção</th>
                <th style="padding: 6px; text-align: left; font-weight: bold; border-bottom: 1px solid #333; font-size: 11px;">Lote</th>
                <th style="padding: 6px; text-align: center; font-weight: bold; border-bottom: 1px solid #333; font-size: 11px;">Qtd</th>
                <th style="padding: 6px; text-align: center; font-weight: bold; border-bottom: 1px solid #333; font-size: 11px;">Status</th>
                <th style="padding: 6px; text-align: left; font-weight: bold; border-bottom: 1px solid #333; font-size: 11px;">Retorno</th>
              </tr>
            </thead>
            <tbody>
              ${batchesHtml}
            </tbody>
          </table>
        </div>
      `;
    }).join("");

    return `
      <!DOCTYPE html>
      <html lang="pt-BR">
      <head>
        <meta charset="UTF-8">
        <title>Visão Geral Completa</title>
        <style>
          body { font-family: Arial, sans-serif; margin: 10px; padding: 0; }
          .header { border-bottom: 3px solid #8B5CF6; padding-bottom: 8px; margin-bottom: 15px; }
          .header h1 { margin: 0; color: #333; font-size: 20px; }
          .header p { margin: 3px 0; color: #666; font-size: 12px; }
          .footer { margin-top: 20px; font-size: 10px; color: #666; border-top: 1px solid #ddd; padding-top: 8px; }
          @media print {
            body { margin: 5px; }
            .page-break { page-break-before: always; }
          }
        </style>
      </head>
      <body>
        <div class="header">
          <h1>Visão Geral - GoFast Produções</h1>
          <p>${new Date().toLocaleDateString("pt-BR")} - Total: ${seamstressOverview.length} costureira(s)</p>
        </div>
        ${allSeamstressesHtml}
        <div class="footer">
          <p>Impresso em ${new Date().toLocaleString("pt-BR")}</p>
        </div>
      </body>
      </html>
    `;
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case "concluido":
        return "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200";
      case "em_producao":
        return "bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200";
      case "para_recolha":
        return "bg-amber-100 text-amber-800 dark:bg-amber-900 dark:text-amber-200";
      case "para_entrega":
        return "bg-purple-100 text-purple-800 dark:bg-purple-900 dark:text-purple-200";
      case "em_separacao":
        return "bg-gray-100 text-gray-800 dark:bg-gray-900 dark:text-gray-200";
      default:
        return "bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200";
    }
  };

  // Filtrar costureiras com lotes ativos se o filtro estiver ativo E com status selecionados
  const filteredSeamstresses = seamstressOverview
    .map((s: any) => ({
      ...s,
      batches: s.batches.filter((b: any) => statusFilter.has(b.status as BatchStatus)),
    }))
    .filter((s: any) => showOnlyActive ? s.batches.length > 0 : true);

  const toggleStatusFilter = (status: BatchStatus) => {
    const newFilter = new Set(statusFilter);
    if (newFilter.has(status)) {
      newFilter.delete(status);
    } else {
      newFilter.add(status);
    }
    setStatusFilter(newFilter);
  };

  const getStatusLabel = (status: string) => {
    const labels: Record<string, string> = {
      em_separacao: "Em Separação",
      para_entrega: "Para Entrega",
      em_producao: "Em Produção",
      para_recolha: "Para Recolha",
      concluido: "Concluído",
    };
    return labels[status] || status;
  };

  const getStatusBadgeColor = (status: string) => {
    const colors: Record<string, string> = {
      em_separacao: "bg-gray-100 text-gray-800",
      para_entrega: "bg-purple-100 text-purple-800",
      em_producao: "bg-blue-100 text-blue-800",
      para_recolha: "bg-amber-100 text-amber-800",
      concluido: "bg-green-100 text-green-800",
    };
    return colors[status] || "";
  };

  return (
    <div className="p-8 space-y-6">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <h1 className="text-3xl font-semibold">Visão Geral</h1>
        <Button onClick={openPrintAllDialog} className="gap-2" data-testid="button-print-all">
          <Printer className="w-4 h-4" />
          Imprimir Tudo
        </Button>
      </div>

      <Card className="p-4 bg-muted/50 space-y-4">
        <Label className="flex items-center gap-2 cursor-pointer">
          <Input
            type="checkbox"
            checked={showOnlyActive}
            onChange={(e) => setShowOnlyActive(e.target.checked)}
            className="w-4 h-4 cursor-pointer"
            data-testid="checkbox-filter-active"
          />
          <span className="text-sm font-medium">Mostrar apenas costureiras com lotes/produção ativas</span>
        </Label>

        <div className="space-y-2">
          <p className="text-sm font-medium">Filtrar por Status:</p>
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-2">
            {(["em_separacao", "para_entrega", "em_producao", "para_recolha", "concluido"] as BatchStatus[]).map((status) => (
              <Label key={status} className="flex items-center gap-2 cursor-pointer">
                <Input
                  type="checkbox"
                  checked={statusFilter.has(status)}
                  onChange={() => toggleStatusFilter(status)}
                  className="w-4 h-4 cursor-pointer"
                  data-testid={`checkbox-filter-status-${status}`}
                />
                <span className="text-xs font-medium">{getStatusLabel(status)}</span>
              </Label>
            ))}
          </div>
        </div>
      </Card>

      {/* Simplified Print-Friendly Layout */}
      <div className="space-y-4">
        {filteredSeamstresses.length === 0 ? (
          <Card className="p-8 text-center">
            <p className="text-muted-foreground">
              {showOnlyActive ? "Nenhuma costureira com lotes/produção ativas no momento." : "Nenhuma costureira cadastrada."}
            </p>
          </Card>
        ) : (
          <>
            {/* Summary Header */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 print:gap-2">
              <Card className="p-4 print:p-3">
                <p className="text-xs text-muted-foreground print:text-xs">Total de Costureiras</p>
                <p className="text-2xl font-bold print:text-xl">{filteredSeamstresses.length}</p>
              </Card>
              <Card className="p-4 print:p-3">
                <p className="text-xs text-muted-foreground print:text-xs">Total de Lotes</p>
                <p className="text-2xl font-bold print:text-xl">
                  {filteredSeamstresses.reduce((sum, s) => sum + s.batches.length, 0)}
                </p>
              </Card>
              <Card className="p-4 print:p-3">
                <p className="text-xs text-muted-foreground print:text-xs">Lotes Concluídos</p>
                <p className="text-2xl font-bold print:text-xl">
                  {filteredSeamstresses.reduce((sum, s) => sum + s.batches.filter((b: any) => b.status === "concluido").length, 0)}
                </p>
              </Card>
              <Card className="p-4 print:p-3">
                <p className="text-xs text-muted-foreground print:text-xs">Para Recolha</p>
                <p className="text-2xl font-bold print:text-xl">
                  {filteredSeamstresses.reduce((sum, s) => sum + s.batches.filter((b: any) => b.status === "para_recolha").length, 0)}
                </p>
              </Card>
            </div>

            {/* Table View - Optimized for Print */}
            <Card className="overflow-x-auto print:overflow-visible">
              <div className="p-4 print:p-2">
                <div className="min-w-full">
                  {/* Table Header */}
                  <div className="grid gap-1 print:gap-0 text-xs font-bold bg-muted p-3 print:p-2 rounded-t border-b-2 mb-2 print:mb-1 print:text-xs"
                       style={{ gridTemplateColumns: "2fr 2fr 1fr 1fr 1.2fr 1fr 1fr" }}>
                    <div>Costureira</div>
                    <div>Produção</div>
                    <div>Código</div>
                    <div className="text-right">Qtd</div>
                    <div>Status</div>
                    <div>Envio</div>
                    <div>Retorno</div>
                  </div>

                  {/* Table Body */}
                  {filteredSeamstresses.flatMap((seamstress: any) =>
                    seamstress.batches.map((batch: any, batchIdx: number) => {
                      const production = productions.find((p: any) => p.id === batch.production_id);
                      const isFirstBatch = batchIdx === 0;
                      return (
                        <div
                          key={batch.id}
                          className="grid gap-1 print:gap-0 text-xs p-3 print:p-2 border-b hover:bg-muted/30 print:hover:bg-transparent transition-colors"
                          style={{ gridTemplateColumns: "2fr 2fr 1fr 1fr 1.2fr 1fr 1fr" }}
                          data-testid={`row-batch-${batch.id}`}
                        >
                          {isFirstBatch && (
                            <div className="font-semibold text-sm print:text-xs row-span-{seamstress.batches.length}">
                              {seamstress.name}
                            </div>
                          )}
                          {!isFirstBatch && <div />}

                          <div>{production?.productName || "N/A"}</div>
                          <div className="font-mono text-xs">{batch.batchCode}</div>
                          <div className="text-right font-semibold">{batch.quantity}</div>
                          
                          <div>
                            <span className={`inline-block px-2 py-1 rounded text-xs font-bold whitespace-nowrap ${getStatusBadgeColor(batch.status)}`}>
                              {getStatusLabel(batch.status)}
                            </span>
                          </div>

                          <div className="text-xs">
                            {new Date(batch.sendDate).toLocaleDateString("pt-BR")}
                          </div>
                          <div className="text-xs">
                            {new Date(batch.expectedReturnDate).toLocaleDateString("pt-BR")}
                          </div>
                        </div>
                      );
                    })
                  )}
                </div>
              </div>
            </Card>

            {/* Print Button */}
            <div className="flex gap-2 print:hidden">
              <Button onClick={openPrintAllDialog} className="gap-2 flex-1" data-testid="button-print-overview">
                <Printer className="w-4 h-4" />
                Imprimir Visão Geral
              </Button>
            </div>
          </>
        )}
      </div>

      <PrintFormatDialog
        open={printFormatDialogOpen}
        onOpenChange={setPrintFormatDialogOpen}
        onSelectFormat={handlePrintFormatSelect}
      />
    </div>
  );
};

export default Overview;
