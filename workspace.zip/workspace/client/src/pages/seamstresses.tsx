import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Drawer, DrawerContent, DrawerHeader, DrawerTitle, DrawerClose } from "@/components/ui/drawer";
import { apiRequest } from "@/lib/queryClient";
import { queryClient } from "@/lib/queryClient";
import { Plus, Trash2, Edit2, ChevronDown, ChevronUp, Download, Upload, MessageCircle, Search, X, Star, Copy, Check, Users } from "lucide-react";
import * as XLSX from "xlsx";
import { useToast } from "@/hooks/use-toast";

// Validation functions
const formatPhone = (value: string): string => {
  const digits = value.replace(/\D/g, "");
  if (digits.length <= 2) return digits;
  if (digits.length <= 7) return `(${digits.slice(0, 2)}) ${digits.slice(2)}`;
  if (digits.length <= 11) return `(${digits.slice(0, 2)}) ${digits.slice(2, 7)}-${digits.slice(7)}`;
  return `(${digits.slice(0, 2)}) ${digits.slice(2, 7)}-${digits.slice(7, 11)}`;
};

const validatePhone = (phone: string): boolean => {
  const digits = phone.replace(/\D/g, "");
  return digits.length === 10 || digits.length === 11;
};

const formatCPF = (value: string): string => {
  const digits = value.replace(/\D/g, "");
  if (digits.length <= 3) return digits;
  if (digits.length <= 6) return `${digits.slice(0, 3)}.${digits.slice(3)}`;
  if (digits.length <= 9) return `${digits.slice(0, 3)}.${digits.slice(3, 6)}.${digits.slice(6)}`;
  return `${digits.slice(0, 3)}.${digits.slice(3, 6)}.${digits.slice(6, 9)}-${digits.slice(9, 11)}`;
};

const validateCPF = (cpf: string): boolean => {
  const digits = cpf.replace(/\D/g, "");
  if (digits.length !== 11) return false;
  if (/^(\d)\1{10}$/.test(digits)) return false;
  
  let sum = 0;
  for (let i = 0; i < 9; i++) {
    sum += parseInt(digits[i]) * (10 - i);
  }
  let remainder = (sum * 10) % 11;
  if (remainder === 10 || remainder === 11) remainder = 0;
  if (remainder !== parseInt(digits[9])) return false;
  
  sum = 0;
  for (let i = 0; i < 10; i++) {
    sum += parseInt(digits[i]) * (11 - i);
  }
  remainder = (sum * 10) % 11;
  if (remainder === 10 || remainder === 11) remainder = 0;
  if (remainder !== parseInt(digits[10])) return false;
  
  return true;
};

const validateEmail = (email: string): boolean => {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
};

const validateRandomKey = (key: string): boolean => {
  const uuidRegex = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
  return uuidRegex.test(key);
};

const validatePix = (pix: string): { valid: boolean; type: string } => {
  if (!pix || pix.trim() === "") return { valid: true, type: "empty" };
  
  const cleanPix = pix.trim();
  
  // Check if it's a CPF
  const cpfDigits = cleanPix.replace(/\D/g, "");
  if (cpfDigits.length === 11 && validateCPF(cleanPix)) {
    return { valid: true, type: "cpf" };
  }
  
  // Check if it's a phone number
  if ((cpfDigits.length === 10 || cpfDigits.length === 11) && validatePhone(cleanPix)) {
    return { valid: true, type: "phone" };
  }
  
  // Check if it's an email
  if (validateEmail(cleanPix)) {
    return { valid: true, type: "email" };
  }
  
  // Check if it's a random key (UUID format)
  if (validateRandomKey(cleanPix)) {
    return { valid: true, type: "random" };
  }
  
  return { valid: false, type: "invalid" };
};

const Seamstresses = () => {
  const { toast } = useToast();
  const [isOpen, setIsOpen] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [expandedSeamstresses, setExpandedSeamstresses] = useState<Set<string>>(new Set());
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedSeamstress, setSelectedSeamstress] = useState<any | null>(null);
  const [drawerOpen, setDrawerOpen] = useState(false);
  const [ratingDeadline, setRatingDeadline] = useState(5);
  const [ratingFinish, setRatingFinish] = useState(5);
  const [copiedField, setCopiedField] = useState<string | null>(null);
  const [formErrors, setFormErrors] = useState<Record<string, string>>({});
  const [duplicatesDialogOpen, setDuplicatesDialogOpen] = useState(false);
  const [duplicateGroups, setDuplicateGroups] = useState<any[][]>([]);
  const [selectedDuplicates, setSelectedDuplicates] = useState<Set<string>>(new Set());
  const [formData, setFormData] = useState({
    name: "",
    phone: "",
    pix: "",
    address: "",
    neighborhood: "",
    numberOfWorkers: 1,
    skills: [] as string[],
    machines: [] as string[],
    status: "active",
  });

  const { data: seamstresses = [], isLoading } = useQuery<any[]>({
    queryKey: ["/api/seamstresses"],
  });

  const { data: productions = [] } = useQuery<any[]>({
    queryKey: ["/api/productions"],
  });

  const { data: batches = [] } = useQuery<any[]>({
    queryKey: ["/api/batches"],
  });

  const createMutation = useMutation({
    mutationFn: async (data: any) => {
      const res = await apiRequest("POST", "/api/seamstresses", data);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/seamstresses"] });
      setIsOpen(false);
      resetForm();
      toast({ title: "Sucesso", description: "Costureira cadastrada!" });
    },
    onError: (error: any) => {
      toast({ title: "Erro ao cadastrar costureira", description: error.message, variant: "destructive" });
    },
  });

  const updateMutation = useMutation({
    mutationFn: async (data: any) => {
      const res = await apiRequest("PATCH", `/api/seamstresses/${editingId}`, data);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/seamstresses"] });
      setIsOpen(false);
      setEditingId(null);
      resetForm();
      toast({ title: "Sucesso", description: "Costureira atualizada!" });
    },
    onError: (error: any) => {
      toast({ title: "Erro ao atualizar costureira", description: error.message, variant: "destructive" });
    },
  });

  const deleteMutation = useMutation({
    mutationFn: async (id: string) => {
      await apiRequest("DELETE", `/api/seamstresses/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/seamstresses"] });
      toast({ title: "Sucesso", description: "Costureira excluída!" });
    },
    onError: (error: any) => {
      toast({ title: "Erro ao excluir costureira", description: error.message, variant: "destructive" });
    },
  });

  const resetForm = () => {
    setFormData({
      name: "",
      phone: "",
      pix: "",
      address: "",
      neighborhood: "",
      numberOfWorkers: 1,
      skills: [],
      machines: [],
      status: "active",
    });
    setFormErrors({});
    setEditingId(null);
  };

  const copyToClipboard = async (text: string, field: string) => {
    try {
      await navigator.clipboard.writeText(text);
      setCopiedField(field);
      toast({ title: "Copiado!", description: `${field} copiado para a área de transferência` });
      setTimeout(() => setCopiedField(null), 2000);
    } catch (err) {
      toast({ title: "Erro", description: "Não foi possível copiar", variant: "destructive" });
    }
  };

  const validateForm = (): boolean => {
    const errors: Record<string, string> = {};
    
    if (!formData.name.trim()) {
      errors.name = "Nome é obrigatório";
    }
    
    if (!formData.phone.trim()) {
      errors.phone = "Telefone é obrigatório";
    } else if (!validatePhone(formData.phone)) {
      errors.phone = "Telefone inválido. Use o formato (XX) XXXXX-XXXX";
    }
    
    if (formData.pix && formData.pix.trim()) {
      const pixValidation = validatePix(formData.pix);
      if (!pixValidation.valid) {
        errors.pix = "PIX inválido. Use CPF, telefone, e-mail ou chave aleatória";
      }
    }
    
    if (!formData.address.trim()) {
      errors.address = "Endereço é obrigatório";
    }
    
    if (!formData.neighborhood.trim()) {
      errors.neighborhood = "Bairro é obrigatório";
    }
    
    if (formData.numberOfWorkers < 1) {
      errors.numberOfWorkers = "Número de costureiras deve ser pelo menos 1";
    }
    
    setFormErrors(errors);
    return Object.keys(errors).length === 0;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!validateForm()) {
      toast({ title: "Erro de validação", description: "Por favor, corrija os campos em vermelho", variant: "destructive" });
      return;
    }
    
    if (editingId) {
      updateMutation.mutate(formData);
    } else {
      createMutation.mutate(formData);
    }
  };

  const handleEditClick = (seamstress: any) => {
    setEditingId(seamstress.id);
    setFormData({
      name: seamstress.name,
      phone: seamstress.phone,
      pix: seamstress.pix || "",
      address: seamstress.address,
      neighborhood: seamstress.neighborhood,
      numberOfWorkers: seamstress.numberOfWorkers || 1,
      skills: seamstress.skills || [],
      machines: seamstress.machines || [],
      status: seamstress.status || "active",
    });
    setFormErrors({});
    setIsOpen(true);
  };

  const handleDeleteClick = (id: string) => {
    if (confirm("Tem certeza que deseja deletar esta costureira?")) {
      deleteMutation.mutate(id);
    }
  };

  const toggleExpanded = (id: string) => {
    const newExpanded = new Set(expandedSeamstresses);
    if (newExpanded.has(id)) {
      newExpanded.delete(id);
    } else {
      newExpanded.add(id);
    }
    setExpandedSeamstresses(newExpanded);
  };

  const handleOpenSeamstressDetails = (seamstress: any) => {
    setSelectedSeamstress(seamstress);
    setRatingDeadline(parseFloat(seamstress.ratingDeadline || 5));
    setRatingFinish(parseFloat(seamstress.ratingFinish || 5));
    setDrawerOpen(true);
  };

  const handleSaveRatings = async () => {
    if (!selectedSeamstress) return;
    try {
      await apiRequest("PATCH", `/api/seamstresses/${selectedSeamstress.id}`, {
        ratingDeadline: ratingDeadline.toString(),
        ratingFinish: ratingFinish.toString(),
      });
      queryClient.invalidateQueries({ queryKey: ["/api/seamstresses"] });
      setDrawerOpen(false);
    } catch (error) {
      console.error("Erro ao salvar avaliações:", error);
    }
  };

  const handleExportExcel = () => {
    const data = seamstresses.map((s: any) => ({
      Nome: s.name,
      Telefone: s.phone,
      PIX: s.pix || "",
      Endereço: s.address,
      Bairro: s.neighborhood,
      "Número de Pessoas": s.numberOfWorkers || 1,
      Habilidades: (s.skills || []).join(", "),
      Máquinas: (s.machines || []).join(", "),
      Status: s.status === "active" ? "Ativa" : s.status === "paused" ? "Pausada" : "Bloqueada",
    }));

    const ws = XLSX.utils.json_to_sheet(data);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, "Costureiras");
    XLSX.writeFile(wb, "costureiras.xlsx");
  };

  const handleImportExcel = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    try {
      const reader = new FileReader();
      reader.onload = async (event) => {
        const data = event.target?.result;
        const workbook = XLSX.read(data, { type: "binary" });
        const worksheet = workbook.Sheets[workbook.SheetNames[0]];
        const jsonData = XLSX.utils.sheet_to_json(worksheet);

        const statusMap: Record<string, string> = {
          Ativa: "active",
          Pausada: "paused",
          Bloqueada: "blocked",
        };

        for (const row of jsonData) {
          const seamstressData = {
            name: row.Nome || "",
            phone: row.Telefone || "",
            pix: row.PIX || "",
            address: row.Endereço || "",
            neighborhood: row.Bairro || "",
            numberOfWorkers: parseInt(row["Número de Pessoas"]) || 1,
            skills: row.Habilidades ? row.Habilidades.split(",").map((s: string) => s.trim()) : [],
            machines: row.Máquinas ? row.Máquinas.split(",").map((m: string) => m.trim()) : [],
            status: statusMap[row.Status] || "active",
          };

          await apiRequest("POST", "/api/seamstresses", seamstressData);
        }

        queryClient.invalidateQueries({ queryKey: ["/api/seamstresses"] });
        alert(`Importação concluída! ${jsonData.length} costureiras adicionadas.`);
      };
      reader.readAsBinaryString(file);
    } catch (error) {
      console.error("Erro ao importar arquivo:", error);
      alert("Erro ao importar arquivo. Verifique o formato e tente novamente.");
    }

    if (e.target) {
      e.target.value = "";
    }
  };

  const findDuplicates = () => {
    const nameGroups: Record<string, any[]> = {};
    const phoneGroups: Record<string, any[]> = {};
    
    seamstresses.forEach((s: any) => {
      const normalizedName = s.name.toLowerCase().trim();
      const normalizedPhone = s.phone.replace(/\D/g, "");
      
      if (!nameGroups[normalizedName]) {
        nameGroups[normalizedName] = [];
      }
      nameGroups[normalizedName].push(s);
      
      if (normalizedPhone && normalizedPhone.length >= 10) {
        if (!phoneGroups[normalizedPhone]) {
          phoneGroups[normalizedPhone] = [];
        }
        phoneGroups[normalizedPhone].push(s);
      }
    });
    
    const duplicates: any[][] = [];
    const addedIds = new Set<string>();
    
    Object.values(nameGroups).forEach((group) => {
      if (group.length > 1) {
        const newGroup = group.filter((s) => !addedIds.has(s.id));
        if (newGroup.length > 1) {
          duplicates.push(newGroup);
          newGroup.forEach((s) => addedIds.add(s.id));
        }
      }
    });
    
    Object.values(phoneGroups).forEach((group) => {
      if (group.length > 1) {
        const newGroup = group.filter((s) => !addedIds.has(s.id));
        if (newGroup.length > 1) {
          duplicates.push(newGroup);
          newGroup.forEach((s) => addedIds.add(s.id));
        }
      }
    });
    
    setDuplicateGroups(duplicates);
    setSelectedDuplicates(new Set());
    setDuplicatesDialogOpen(true);
  };

  const handleDeleteDuplicates = async () => {
    if (selectedDuplicates.size === 0) {
      toast({ title: "Atenção", description: "Selecione pelo menos uma costureira para excluir", variant: "destructive" });
      return;
    }
    
    if (!confirm(`Tem certeza que deseja excluir ${selectedDuplicates.size} costureira(s)?`)) {
      return;
    }
    
    let deleted = 0;
    for (const id of Array.from(selectedDuplicates)) {
      try {
        await apiRequest("DELETE", `/api/seamstresses/${id}`);
        deleted++;
      } catch (error) {
        console.error("Erro ao excluir costureira:", error);
      }
    }
    
    queryClient.invalidateQueries({ queryKey: ["/api/seamstresses"] });
    setDuplicatesDialogOpen(false);
    setSelectedDuplicates(new Set());
    toast({ title: "Sucesso", description: `${deleted} costureira(s) excluída(s)` });
  };

  const toggleDuplicateSelection = (id: string) => {
    const newSelected = new Set(selectedDuplicates);
    if (newSelected.has(id)) {
      newSelected.delete(id);
    } else {
      newSelected.add(id);
    }
    setSelectedDuplicates(newSelected);
  };

  if (isLoading) {
    return <div className="p-8">Carregando costureiras...</div>;
  }

  // Filtrar por busca
  const filtered = seamstresses.filter((s: any) => 
    s.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
    s.phone.includes(searchQuery) ||
    s.address.toLowerCase().includes(searchQuery.toLowerCase()) ||
    s.neighborhood.toLowerCase().includes(searchQuery.toLowerCase())
  );

  // Função para checar se uma costureira tem lotes ativos (em qualquer status exceto concluído/returned)
  const hasActiveBatches = (seamstress: any) => {
    if (!seamstress.batches || seamstress.batches.length === 0) return false;
    return seamstress.batches.some((b: any) => {
      const status = b.status?.toLowerCase() || "";
      // Mostrar em produção se NÃO for: concluido, concluída, completed, returned
      return status !== "concluido" && status !== "concluída" && status !== "completed" && status !== "returned";
    });
  };

  // Separar costureiras em 3 categorias
  const seamstressesWithProduction = filtered.filter((s: any) => hasActiveBatches(s))
    .sort((a: any, b: any) => {
      const workersA = a.numberOfWorkers || 1;
      const workersB = b.numberOfWorkers || 1;
      if (workersB !== workersA) {
        return workersB - workersA;
      }
      return a.name.localeCompare(b.name);
    });
  
  // Costureiras que já concluíram lotes e estão disponíveis
  const seamstressesWithCompletedBatches = filtered.filter((s: any) => {
    if (hasActiveBatches(s)) return false; // Não tem lotes ativos
    if (!s.batches || s.batches.length === 0) return false; // Nunca teve lote
    // Tem pelo menos um lote concluído
    return s.batches.some((b: any) => {
      const status = b.status?.toLowerCase() || "";
      return status === "concluido" || status === "concluída" || status === "completed" || status === "returned";
    });
  })
    .sort((a: any, b: any) => {
      const workersA = a.numberOfWorkers || 1;
      const workersB = b.numberOfWorkers || 1;
      if (workersB !== workersA) {
        return workersB - workersA;
      }
      return a.name.localeCompare(b.name);
    });
  
  // Costureiras que nunca tiveram lote alocado
  const seamstressesNeverUsed = filtered.filter((s: any) => {
    if (hasActiveBatches(s)) return false;
    return !s.batches || s.batches.length === 0;
  })
    .sort((a: any, b: any) => {
      const workersA = a.numberOfWorkers || 1;
      const workersB = b.numberOfWorkers || 1;
      if (workersB !== workersA) {
        return workersB - workersA;
      }
      return a.name.localeCompare(b.name);
    });

  return (
    <div className="p-8 space-y-8">
      {/* Header Section */}
      <div className="space-y-4">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div>
            <h1 className="text-3xl font-semibold mb-2">Costureiras</h1>
            <div className="flex flex-wrap gap-3">
              <div className="flex items-center gap-2 px-4 py-2 bg-blue-50 dark:bg-blue-950 rounded-lg border border-blue-200 dark:border-blue-800">
                <span className="text-2xl font-bold text-blue-600 dark:text-blue-400">{seamstresses.length}</span>
                <span className="text-sm font-semibold text-blue-700 dark:text-blue-300">Total</span>
              </div>
              <div className="flex items-center gap-2 px-4 py-2 bg-amber-50 dark:bg-amber-950 rounded-lg border border-amber-200 dark:border-amber-800">
                <span className="text-2xl font-bold text-amber-600 dark:text-amber-400">{seamstressesWithProduction.length}</span>
                <span className="text-sm font-semibold text-amber-700 dark:text-amber-300">Em Produção</span>
              </div>
              <div className="flex items-center gap-2 px-4 py-2 bg-blue-50 dark:bg-blue-950 rounded-lg border border-blue-200 dark:border-blue-800">
                <span className="text-2xl font-bold text-blue-600 dark:text-blue-400">{seamstressesWithCompletedBatches.length}</span>
                <span className="text-sm font-semibold text-blue-700 dark:text-blue-300">Experiência</span>
              </div>
              <div className="flex items-center gap-2 px-4 py-2 bg-green-50 dark:bg-green-950 rounded-lg border border-green-200 dark:border-green-800">
                <span className="text-2xl font-bold text-green-600 dark:text-green-400">{seamstressesNeverUsed.length}</span>
                <span className="text-sm font-semibold text-green-700 dark:text-green-300">Iniciante</span>
              </div>
            </div>
          </div>
          <div className="flex flex-wrap gap-2">
            <Button variant="outline" className="gap-2" onClick={findDuplicates} data-testid="button-find-duplicates">
              <Users className="w-4 h-4" />
              Duplicados
            </Button>
            <Dialog open={isOpen} onOpenChange={(open) => {
              setIsOpen(open);
              if (!open) resetForm();
            }}>
              <DialogTrigger asChild>
                <Button className="gap-2" data-testid="button-create-seamstress">
                  <Plus className="w-4 h-4" />
                  Adicionar Costureira
                </Button>
              </DialogTrigger>
              <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
                <DialogHeader>
                  <DialogTitle>{editingId ? "Editar Costureira" : "Registrar Nova Costureira"}</DialogTitle>
                </DialogHeader>
                <form onSubmit={handleSubmit} className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="name">Nome *</Label>
                      <Input
                        id="name"
                        value={formData.name}
                        onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                        className={formErrors.name ? "border-red-500" : ""}
                        data-testid="input-seamstress-name"
                      />
                      {formErrors.name && <p className="text-xs text-red-500 mt-1">{formErrors.name}</p>}
                    </div>
                    <div>
                      <Label htmlFor="phone">Telefone *</Label>
                      <div className="flex gap-2">
                        <Input
                          id="phone"
                          value={formData.phone}
                          onChange={(e) => setFormData({ ...formData, phone: formatPhone(e.target.value) })}
                          placeholder="(XX) XXXXX-XXXX"
                          className={`flex-1 ${formErrors.phone ? "border-red-500" : ""}`}
                          data-testid="input-seamstress-phone"
                        />
                        {formData.phone && (
                          <Button
                            type="button"
                            size="icon"
                            variant="outline"
                            onClick={() => copyToClipboard(formData.phone, "Telefone")}
                            data-testid="button-copy-phone"
                          >
                            {copiedField === "Telefone" ? <Check className="w-4 h-4 text-green-500" /> : <Copy className="w-4 h-4" />}
                          </Button>
                        )}
                      </div>
                      {formErrors.phone && <p className="text-xs text-red-500 mt-1">{formErrors.phone}</p>}
                    </div>
                  </div>

                  <div>
                    <Label htmlFor="pix">Chave PIX</Label>
                    <div className="flex gap-2">
                      <Input
                        id="pix"
                        value={formData.pix}
                        onChange={(e) => setFormData({ ...formData, pix: e.target.value })}
                        placeholder="CPF, telefone, e-mail ou chave aleatória"
                        className={`flex-1 ${formErrors.pix ? "border-red-500" : ""}`}
                        data-testid="input-seamstress-pix"
                      />
                      {formData.pix && (
                        <Button
                          type="button"
                          size="icon"
                          variant="outline"
                          onClick={() => copyToClipboard(formData.pix, "PIX")}
                          data-testid="button-copy-pix"
                        >
                          {copiedField === "PIX" ? <Check className="w-4 h-4 text-green-500" /> : <Copy className="w-4 h-4" />}
                        </Button>
                      )}
                    </div>
                    {formErrors.pix && <p className="text-xs text-red-500 mt-1">{formErrors.pix}</p>}
                    {formData.pix && !formErrors.pix && (
                      <p className="text-xs text-muted-foreground mt-1">
                        Tipo: {validatePix(formData.pix).type === "cpf" ? "CPF" : 
                               validatePix(formData.pix).type === "phone" ? "Telefone" :
                               validatePix(formData.pix).type === "email" ? "E-mail" :
                               validatePix(formData.pix).type === "random" ? "Chave Aleatória" : ""}
                      </p>
                    )}
                  </div>

                  <div>
                    <Label htmlFor="address">Endereço *</Label>
                    <Input
                      id="address"
                      value={formData.address}
                      onChange={(e) => setFormData({ ...formData, address: e.target.value })}
                      className={formErrors.address ? "border-red-500" : ""}
                      data-testid="input-seamstress-address"
                    />
                    {formErrors.address && <p className="text-xs text-red-500 mt-1">{formErrors.address}</p>}
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="neighborhood">Bairro *</Label>
                      <Input
                        id="neighborhood"
                        value={formData.neighborhood}
                        onChange={(e) => setFormData({ ...formData, neighborhood: e.target.value })}
                        className={formErrors.neighborhood ? "border-red-500" : ""}
                        data-testid="input-seamstress-neighborhood"
                      />
                      {formErrors.neighborhood && <p className="text-xs text-red-500 mt-1">{formErrors.neighborhood}</p>}
                    </div>
                    <div>
                      <Label htmlFor="workers">Número de Costureiras *</Label>
                      <Input
                        id="workers"
                        type="number"
                        min="1"
                        value={formData.numberOfWorkers}
                        onChange={(e) => setFormData({ ...formData, numberOfWorkers: parseInt(e.target.value) || 1 })}
                        className={formErrors.numberOfWorkers ? "border-red-500" : ""}
                        data-testid="input-seamstress-workers"
                      />
                      {formErrors.numberOfWorkers && <p className="text-xs text-red-500 mt-1">{formErrors.numberOfWorkers}</p>}
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="status">Status *</Label>
                      <Select value={formData.status} onValueChange={(value) => setFormData({ ...formData, status: value })}>
                        <SelectTrigger data-testid="select-seamstress-status">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="active">Ativa</SelectItem>
                          <SelectItem value="paused">Pausada</SelectItem>
                          <SelectItem value="blocked">Bloqueada</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>

                  <Button type="submit" className="w-full" data-testid="button-submit-seamstress">
                    {editingId ? "Salvar Alterações" : "Criar Costureira"}
                  </Button>
                </form>
              </DialogContent>
            </Dialog>
            <Button variant="outline" size="sm" onClick={handleExportExcel} className="gap-2" data-testid="button-export-seamstress">
              <Download className="w-4 h-4" />
            </Button>
            <label>
              <input
                type="file"
                accept=".xlsx"
                onChange={handleImportExcel}
                style={{ display: "none" }}
              />
              <Button variant="outline" size="sm" asChild className="gap-2 cursor-pointer" data-testid="button-import-seamstress">
                <span>
                  <Upload className="w-4 h-4" />
                </span>
              </Button>
            </label>
          </div>
        </div>

        {/* Search Filter */}
        <div className="relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input
            placeholder="Buscar por nome, telefone, endereço ou bairro..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-10"
            data-testid="input-search-seamstress"
          />
        </div>
      </div>

      {/* Seamstresses com Produção Ativa */}
      {seamstressesWithProduction.length > 0 && (
        <div className="space-y-4">
          <div className="flex items-center gap-3">
            <div className="h-1 w-8 bg-amber-500 rounded-full"></div>
            <h2 className="text-lg font-bold text-amber-700 dark:text-amber-300">👷 Em Produção - {seamstressesWithProduction.length} costureira{seamstressesWithProduction.length !== 1 ? 's' : ''}</h2>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-3 md:gap-4">
            {seamstressesWithProduction.map((seamstress: any) => {
              const hasBatches = seamstress.batches && seamstress.batches.length > 0;
              const activeBatches = seamstress.batches ? seamstress.batches.filter((b: any) => {
                const status = b.status?.toLowerCase() || "";
                return status !== "concluido" && status !== "concluída" && status !== "completed" && status !== "returned";
              }).length : 0;
              const isExpanded = expandedSeamstresses.has(seamstress.id);
              
              return (
                <Card 
                  key={seamstress.id} 
                  className={`p-3 md:p-4 transition-all ${hasBatches ? 'border-amber-600 bg-amber-100 dark:border-amber-600 dark:bg-amber-950 text-amber-900 dark:text-amber-50' : 'border-gray-200'}`}
                  data-testid={`card-seamstress-${seamstress.id}`}
                >
                  {!isExpanded ? (
                    <div className="space-y-2">
                      <div className="flex items-center justify-between cursor-pointer" onClick={() => toggleExpanded(seamstress.id)}>
                        <h3 className="text-sm md:text-base font-bold truncate text-amber-900 dark:text-amber-100" data-testid={`text-seamstress-name-${seamstress.id}`}>{seamstress.name}</h3>
                        <ChevronDown className="w-4 h-4 flex-shrink-0 text-amber-700 dark:text-amber-300" />
                      </div>
                      <div className="flex items-center justify-between gap-2">
                        <div className="flex items-center gap-1">
                          <span className="text-xs text-amber-700 dark:text-amber-200">{seamstress.phone}</span>
                          <Button size="icon" variant="ghost" className="h-5 w-5" onClick={(e) => { e.stopPropagation(); copyToClipboard(seamstress.phone, `Tel-${seamstress.id}`); }}>
                            {copiedField === `Tel-${seamstress.id}` ? <Check className="w-3 h-3 text-green-500" /> : <Copy className="w-3 h-3 text-amber-600" />}
                          </Button>
                        </div>
                        <span className="inline-flex items-center px-2 py-0.5 rounded-lg text-xs font-bold bg-amber-600 text-white dark:bg-amber-500 dark:text-white whitespace-nowrap shadow-md" data-testid={`workers-count-${seamstress.id}`}>
                          👥 {seamstress.numberOfWorkers || 1}
                        </span>
                      </div>
                      {seamstress.pix && (
                        <div className="flex items-center gap-1 border-t border-amber-200 dark:border-amber-800 pt-1">
                          <span className="text-xs font-semibold text-amber-700 dark:text-amber-200">PIX:</span>
                          <span className="text-xs break-all text-amber-900 dark:text-amber-100 flex-1 truncate">{seamstress.pix}</span>
                          <Button size="icon" variant="ghost" className="h-5 w-5 flex-shrink-0" onClick={(e) => { e.stopPropagation(); copyToClipboard(seamstress.pix, `PIX-${seamstress.id}`); }}>
                            {copiedField === `PIX-${seamstress.id}` ? <Check className="w-3 h-3 text-green-500" /> : <Copy className="w-3 h-3 text-amber-600" />}
                          </Button>
                        </div>
                      )}
                    </div>
                  ) : (
                    <div className="space-y-2">
                      <div 
                        className="flex items-center justify-between cursor-pointer"
                        onClick={() => toggleExpanded(seamstress.id)}
                      >
                        <h3 className="text-sm md:text-base font-bold truncate text-amber-900 dark:text-amber-100" data-testid={`text-seamstress-name-${seamstress.id}`}>{seamstress.name}</h3>
                        <ChevronUp className="w-4 h-4 flex-shrink-0 text-amber-700 dark:text-amber-300" />
                      </div>
                      <div className="flex items-center justify-between gap-2">
                        <p className="text-xs text-amber-700 dark:text-amber-200">{seamstress.phone}</p>
                        <span className="inline-flex items-center px-3 py-1 rounded-lg text-xs font-bold bg-amber-600 text-white dark:bg-amber-500 dark:text-white whitespace-nowrap shadow-md" data-testid={`workers-count-${seamstress.id}`}>👥 {seamstress.numberOfWorkers || 1}</span>
                      </div>

                      {/* Status Badge */}
                      <div className="flex items-center gap-2 flex-wrap">
                        {hasBatches ? (
                          <div className="flex flex-wrap gap-1">
                            {seamstress.batches && seamstress.batches.filter((b: any) => {
                              const status = b.status?.toLowerCase() || "";
                              return status !== "concluido" && status !== "concluída" && status !== "completed" && status !== "returned";
                            }).map((batch: any) => {
                              const prod = (productions as any[]).find((p: any) => p.id === batch.productionId);
                              return (
                                <span key={batch.id} className="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-bold bg-amber-300 text-amber-900 dark:bg-amber-700 dark:text-amber-100 whitespace-nowrap">
                                  {prod?.productName || 'Prod.'}
                                </span>
                              );
                            })}
                            {(!seamstress.batches || seamstress.batches.filter((b: any) => {
                              const status = b.status?.toLowerCase() || "";
                              return status !== "concluido" && status !== "concluída" && status !== "completed" && status !== "returned";
                            }).length === 0) && (
                              <span className="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-bold bg-gray-200 text-gray-800 dark:bg-gray-700 dark:text-gray-200">Livre</span>
                            )}
                          </div>
                        ) : (
                          <span className="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-bold bg-gray-200 text-gray-800 dark:bg-gray-700 dark:text-gray-200" data-testid={`production-status-${seamstress.id}`}>
                            Livre
                          </span>
                        )}
                        <span className={`inline-flex px-2 py-0.5 rounded text-xs font-semibold ${
                          seamstress.status === "active" ? "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200" :
                          seamstress.status === "paused" ? "bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200" :
                          "bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200"
                        }`} data-testid={`status-seamstress-${seamstress.id}`}>
                          {seamstress.status === "active" ? "Ativa" : seamstress.status === "paused" ? "Pausada" : "Bloqueada"}
                        </span>
                      </div>
                    
                      {/* Address Info */}
                      <div className="border-t border-amber-200 dark:border-amber-800 pt-2">
                        <div className="space-y-1">
                          <div className="flex flex-col gap-1">
                            <span className="text-xs font-semibold text-amber-700 dark:text-amber-200">Endereço:</span>
                            <span className="text-xs break-all text-amber-900 dark:text-amber-100">{seamstress.address || "N/A"}</span>
                          </div>
                          <div className="flex flex-col gap-1">
                            <span className="text-xs font-semibold text-amber-700 dark:text-amber-200">Bairro:</span>
                            <span className="text-xs break-all text-amber-900 dark:text-amber-100">{seamstress.neighborhood || "N/A"}</span>
                          </div>
                        </div>
                      </div>

                      {/* PIX Info */}
                      {seamstress.pix && (
                        <div className="border-t border-amber-200 dark:border-amber-800 pt-2">
                          <div className="flex items-center gap-1">
                            <span className="text-xs font-semibold text-amber-700 dark:text-amber-200">PIX:</span>
                            <span className="text-xs break-all text-amber-900 dark:text-amber-100 flex-1">{seamstress.pix}</span>
                            <Button
                              size="icon"
                              variant="ghost"
                              className="h-5 w-5 flex-shrink-0"
                              onClick={(e) => { e.stopPropagation(); copyToClipboard(seamstress.pix, `PIX-${seamstress.id}`); }}
                              data-testid={`button-copy-pix-card-${seamstress.id}`}
                            >
                              {copiedField === `PIX-${seamstress.id}` ? <Check className="w-3 h-3 text-green-400" /> : <Copy className="w-3 h-3" />}
                            </Button>
                          </div>
                        </div>
                      )}

                      {/* Action Buttons */}
                      <div className="flex gap-1 pt-2 border-t border-amber-200 dark:border-amber-800">
                        <Button
                          size="sm"
                          variant="outline"
                          className="flex-1"
                          onClick={() => handleEditClick(seamstress)}
                          data-testid={`button-edit-seamstress-${seamstress.id}`}
                        >
                          <Edit2 className="w-3 h-3 mr-1" />
                          Editar
                        </Button>
                        <Button
                          size="sm"
                          className="flex-1 bg-[#25D366] hover:bg-[#1fa754] text-white"
                          onClick={() => {
                            const phone = seamstress.phone.replace(/[^0-9]/g, "");
                            const fullPhone = phone.startsWith("55") ? phone : `55${phone}`;
                            window.location.href = `/whatsapp-redirect?phone=${fullPhone}`;
                          }}
                          data-testid={`button-whatsapp-seamstress-${seamstress.id}`}
                        >
                          <MessageCircle className="w-3 h-3 mr-1" />
                          WhatsApp
                        </Button>
                        <Button
                          size="sm"
                          variant="outline"
                          className="flex-1 text-red-600 hover:text-red-700 dark:text-red-400 dark:hover:text-red-300"
                          onClick={() => handleDeleteClick(seamstress.id)}
                          data-testid={`button-delete-seamstress-${seamstress.id}`}
                        >
                          <Trash2 className="w-3 h-3 mr-1" />
                          Deletar
                        </Button>
                      </div>
                    </div>
                  )}
                </Card>
              );
            })}
          </div>
        </div>
      )}

      {/* Seamstresses com Lotes Concluídos - Disponível */}
      {seamstressesWithCompletedBatches.length > 0 && (
        <div className="space-y-4">
          <div className="flex items-center gap-3">
            <div className="h-1 w-8 bg-blue-500 rounded-full"></div>
            <h2 className="text-lg font-bold text-blue-700 dark:text-blue-300">⭐ Experiência - {seamstressesWithCompletedBatches.length} costureira{seamstressesWithCompletedBatches.length !== 1 ? 's' : ''}</h2>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-3 md:gap-4">
            {seamstressesWithCompletedBatches.map((seamstress: any) => {
              const isExpanded = expandedSeamstresses.has(seamstress.id);
              
              return (
                <Card 
                  key={seamstress.id} 
                  className="p-3 md:p-4 transition-all border-blue-200 bg-blue-50 dark:border-blue-800 dark:bg-blue-950"
                  data-testid={`card-seamstress-completed-${seamstress.id}`}
                >
                  {!isExpanded ? (
                    <div className="space-y-2">
                      <div className="flex items-center justify-between cursor-pointer" onClick={() => toggleExpanded(seamstress.id)}>
                        <h3 className="text-sm md:text-base font-bold truncate text-blue-900 dark:text-blue-100" data-testid={`text-seamstress-name-completed-${seamstress.id}`}>{seamstress.name}</h3>
                        <ChevronDown className="w-4 h-4 flex-shrink-0 text-blue-600 dark:text-blue-400" />
                      </div>
                      <div className="flex items-center justify-between gap-2">
                        <div className="flex items-center gap-1">
                          <span className="text-xs text-blue-700 dark:text-blue-300">{seamstress.phone}</span>
                          <Button size="icon" variant="ghost" className="h-5 w-5" onClick={(e) => { e.stopPropagation(); copyToClipboard(seamstress.phone, `Tel-completed-${seamstress.id}`); }}>
                            {copiedField === `Tel-completed-${seamstress.id}` ? <Check className="w-3 h-3 text-green-500" /> : <Copy className="w-3 h-3 text-blue-600" />}
                          </Button>
                        </div>
                        <span className="inline-flex items-center px-2 py-0.5 rounded-lg text-xs font-bold bg-blue-600 text-white dark:bg-blue-700 whitespace-nowrap shadow-md" data-testid={`workers-count-completed-${seamstress.id}`}>
                          👥 {seamstress.numberOfWorkers || 1}
                        </span>
                      </div>
                      {seamstress.pix && (
                        <div className="flex items-center gap-1 border-t border-blue-200 dark:border-blue-800 pt-1">
                          <span className="text-xs font-semibold text-blue-700 dark:text-blue-300">PIX:</span>
                          <span className="text-xs break-all text-blue-900 dark:text-blue-100 flex-1 truncate">{seamstress.pix}</span>
                          <Button size="icon" variant="ghost" className="h-5 w-5 flex-shrink-0" onClick={(e) => { e.stopPropagation(); copyToClipboard(seamstress.pix, `PIX-completed-${seamstress.id}`); }}>
                            {copiedField === `PIX-completed-${seamstress.id}` ? <Check className="w-3 h-3 text-green-500" /> : <Copy className="w-3 h-3 text-blue-600" />}
                          </Button>
                        </div>
                      )}
                    </div>
                  ) : (
                    <div className="space-y-2">
                      <div 
                        className="flex items-center justify-between cursor-pointer"
                        onClick={() => toggleExpanded(seamstress.id)}
                      >
                        <h3 className="text-sm md:text-base font-bold truncate text-blue-900 dark:text-blue-100" data-testid={`text-seamstress-name-completed-${seamstress.id}`}>{seamstress.name}</h3>
                        <ChevronUp className="w-4 h-4 flex-shrink-0 text-blue-600 dark:text-blue-400" />
                      </div>
                      <div className="flex items-center justify-between gap-2">
                        <p className="text-xs text-blue-700 dark:text-blue-300">{seamstress.phone}</p>
                        <span className="inline-flex items-center px-3 py-1 rounded-lg text-xs font-bold bg-blue-600 text-white dark:bg-blue-700 whitespace-nowrap shadow-md" data-testid={`workers-count-completed-${seamstress.id}`}>👥 {seamstress.numberOfWorkers || 1}</span>
                      </div>

                      <span className={`inline-flex px-2 py-0.5 rounded text-xs font-semibold ${
                        seamstress.status === "active" ? "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200" :
                        seamstress.status === "paused" ? "bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200" :
                        "bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200"
                      }`} data-testid={`status-seamstress-completed-${seamstress.id}`}>
                        {seamstress.status === "active" ? "Ativa" : seamstress.status === "paused" ? "Pausada" : "Bloqueada"}
                      </span>

                      {/* Address Info */}
                      <div className="border-t border-blue-200 dark:border-blue-800 pt-2">
                        <div className="space-y-1">
                          <div className="flex flex-col gap-1">
                            <span className="text-xs font-semibold text-blue-700 dark:text-blue-300">Endereço:</span>
                            <span className="text-xs break-all text-blue-900 dark:text-blue-100">{seamstress.address || "N/A"}</span>
                          </div>
                          <div className="flex flex-col gap-1">
                            <span className="text-xs font-semibold text-blue-700 dark:text-blue-300">Bairro:</span>
                            <span className="text-xs break-all text-blue-900 dark:text-blue-100">{seamstress.neighborhood || "N/A"}</span>
                          </div>
                        </div>
                      </div>

                      {/* PIX Info */}
                      {seamstress.pix && (
                        <div className="border-t border-blue-200 dark:border-blue-800 pt-2">
                          <div className="flex items-center gap-1">
                            <span className="text-xs font-semibold text-blue-700 dark:text-blue-300">PIX:</span>
                            <span className="text-xs break-all text-blue-900 dark:text-blue-100 flex-1">{seamstress.pix}</span>
                            <Button
                              size="icon"
                              variant="ghost"
                              className="h-5 w-5 flex-shrink-0"
                              onClick={(e) => { e.stopPropagation(); copyToClipboard(seamstress.pix, `PIX-completed-${seamstress.id}`); }}
                              data-testid={`button-copy-pix-card-completed-${seamstress.id}`}
                            >
                              {copiedField === `PIX-completed-${seamstress.id}` ? <Check className="w-3 h-3 text-green-500" /> : <Copy className="w-3 h-3" />}
                            </Button>
                          </div>
                        </div>
                      )}

                      {/* Action Buttons */}
                      <div className="flex gap-1 pt-2 border-t border-blue-200 dark:border-blue-800">
                        <Button
                          size="sm"
                          variant="outline"
                          className="flex-1"
                          onClick={() => handleEditClick(seamstress)}
                          data-testid={`button-edit-seamstress-completed-${seamstress.id}`}
                        >
                          <Edit2 className="w-3 h-3 mr-1" />
                          Editar
                        </Button>
                        <Button
                          size="sm"
                          className="flex-1 bg-[#25D366] hover:bg-[#1fa754] text-white"
                          onClick={() => {
                            const phone = seamstress.phone.replace(/[^0-9]/g, "");
                            const fullPhone = phone.startsWith("55") ? phone : `55${phone}`;
                            window.location.href = `/whatsapp-redirect?phone=${fullPhone}`;
                          }}
                          data-testid={`button-whatsapp-seamstress-completed-${seamstress.id}`}
                        >
                          <MessageCircle className="w-3 h-3 mr-1" />
                          WhatsApp
                        </Button>
                        <Button
                          size="sm"
                          variant="outline"
                          className="flex-1 text-red-600 hover:text-red-700 dark:text-red-400 dark:hover:text-red-300"
                          onClick={() => handleDeleteClick(seamstress.id)}
                          data-testid={`button-delete-seamstress-completed-${seamstress.id}`}
                        >
                          <Trash2 className="w-3 h-3 mr-1" />
                          Deletar
                        </Button>
                      </div>
                    </div>
                  )}
                </Card>
              );
            })}
          </div>
        </div>
      )}

      {/* Seamstresses Nunca Utilizadas - Iniciantes */}
      {seamstressesNeverUsed.length > 0 && (
        <div className="space-y-4">
          <div className="flex items-center gap-3">
            <div className="h-1 w-8 bg-green-500 rounded-full"></div>
            <h2 className="text-lg font-bold text-green-700 dark:text-green-300">✓ Iniciante - {seamstressesNeverUsed.length} costureira{seamstressesNeverUsed.length !== 1 ? 's' : ''}</h2>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-3 md:gap-4">
            {seamstressesNeverUsed.map((seamstress: any) => {
              const isExpanded = expandedSeamstresses.has(seamstress.id);
              
              return (
                <Card 
                  key={seamstress.id} 
                  className="p-3 md:p-4 transition-all border-green-200 bg-green-50 dark:border-green-800 dark:bg-green-950"
                  data-testid={`card-seamstress-iniciante-${seamstress.id}`}
                >
                  {!isExpanded ? (
                    <div className="space-y-2">
                      <div className="flex items-center justify-between cursor-pointer" onClick={() => toggleExpanded(seamstress.id)}>
                        <h3 className="text-sm md:text-base font-bold truncate text-green-900 dark:text-green-100" data-testid={`text-seamstress-name-iniciante-${seamstress.id}`}>{seamstress.name}</h3>
                        <ChevronDown className="w-4 h-4 flex-shrink-0 text-green-600 dark:text-green-400" />
                      </div>
                      <div className="flex items-center justify-between gap-2">
                        <div className="flex items-center gap-1">
                          <span className="text-xs text-green-700 dark:text-green-300">{seamstress.phone}</span>
                          <Button size="icon" variant="ghost" className="h-5 w-5" onClick={(e) => { e.stopPropagation(); copyToClipboard(seamstress.phone, `Tel-iniciante-${seamstress.id}`); }}>
                            {copiedField === `Tel-iniciante-${seamstress.id}` ? <Check className="w-3 h-3 text-green-500" /> : <Copy className="w-3 h-3 text-green-600" />}
                          </Button>
                        </div>
                        <span className="inline-flex items-center px-2 py-0.5 rounded-lg text-xs font-bold bg-green-600 text-white dark:bg-green-700 whitespace-nowrap shadow-md" data-testid={`workers-count-iniciante-${seamstress.id}`}>
                          👥 {seamstress.numberOfWorkers || 1}
                        </span>
                      </div>
                      {seamstress.pix && (
                        <div className="flex items-center gap-1 border-t border-green-200 dark:border-green-800 pt-1">
                          <span className="text-xs font-semibold text-green-700 dark:text-green-300">PIX:</span>
                          <span className="text-xs break-all text-green-900 dark:text-green-100 flex-1 truncate">{seamstress.pix}</span>
                          <Button size="icon" variant="ghost" className="h-5 w-5 flex-shrink-0" onClick={(e) => { e.stopPropagation(); copyToClipboard(seamstress.pix, `PIX-iniciante-${seamstress.id}`); }}>
                            {copiedField === `PIX-iniciante-${seamstress.id}` ? <Check className="w-3 h-3 text-green-500" /> : <Copy className="w-3 h-3 text-green-600" />}
                          </Button>
                        </div>
                      )}
                    </div>
                  ) : (
                    <div className="space-y-2">
                      <div 
                        className="flex items-center justify-between cursor-pointer"
                        onClick={() => toggleExpanded(seamstress.id)}
                      >
                        <h3 className="text-sm md:text-base font-bold truncate text-green-900 dark:text-green-100" data-testid={`text-seamstress-name-iniciante-${seamstress.id}`}>{seamstress.name}</h3>
                        <ChevronUp className="w-4 h-4 flex-shrink-0 text-green-600 dark:text-green-400" />
                      </div>
                      <div className="flex items-center justify-between gap-2">
                        <p className="text-xs text-green-700 dark:text-green-300">{seamstress.phone}</p>
                        <span className="inline-flex items-center px-3 py-1 rounded-lg text-xs font-bold bg-green-600 text-white dark:bg-green-700 whitespace-nowrap shadow-md" data-testid={`workers-count-iniciante-${seamstress.id}`}>👥 {seamstress.numberOfWorkers || 1}</span>
                      </div>

                      <span className={`inline-flex px-2 py-0.5 rounded text-xs font-semibold ${
                        seamstress.status === "active" ? "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200" :
                        seamstress.status === "paused" ? "bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200" :
                        "bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200"
                      }`} data-testid={`status-seamstress-iniciante-${seamstress.id}`}>
                        {seamstress.status === "active" ? "Ativa" : seamstress.status === "paused" ? "Pausada" : "Bloqueada"}
                      </span>

                      {/* Address Info */}
                      <div className="border-t border-green-200 dark:border-green-800 pt-2">
                        <div className="space-y-1">
                          <div className="flex flex-col gap-1">
                            <span className="text-xs font-semibold text-green-700 dark:text-green-300">Endereço:</span>
                            <span className="text-xs break-all text-green-900 dark:text-green-100">{seamstress.address || "N/A"}</span>
                          </div>
                          <div className="flex flex-col gap-1">
                            <span className="text-xs font-semibold text-green-700 dark:text-green-300">Bairro:</span>
                            <span className="text-xs break-all text-green-900 dark:text-green-100">{seamstress.neighborhood || "N/A"}</span>
                          </div>
                        </div>
                      </div>

                      {/* PIX Info */}
                      {seamstress.pix && (
                        <div className="border-t border-green-200 dark:border-green-800 pt-2">
                          <div className="flex items-center gap-1">
                            <span className="text-xs font-semibold text-green-700 dark:text-green-300">PIX:</span>
                            <span className="text-xs break-all text-green-900 dark:text-green-100 flex-1">{seamstress.pix}</span>
                            <Button
                              size="icon"
                              variant="ghost"
                              className="h-5 w-5 flex-shrink-0"
                              onClick={(e) => { e.stopPropagation(); copyToClipboard(seamstress.pix, `PIX-iniciante-${seamstress.id}`); }}
                              data-testid={`button-copy-pix-card-iniciante-${seamstress.id}`}
                            >
                              {copiedField === `PIX-iniciante-${seamstress.id}` ? <Check className="w-3 h-3 text-green-500" /> : <Copy className="w-3 h-3" />}
                            </Button>
                          </div>
                        </div>
                      )}

                      {/* Action Buttons */}
                      <div className="flex gap-1 pt-2 border-t border-green-200 dark:border-green-800">
                        <Button
                          size="sm"
                          variant="outline"
                          className="flex-1"
                          onClick={() => handleEditClick(seamstress)}
                          data-testid={`button-edit-seamstress-iniciante-${seamstress.id}`}
                        >
                          <Edit2 className="w-3 h-3 mr-1" />
                          Editar
                        </Button>
                        <Button
                          size="sm"
                          className="flex-1 bg-[#25D366] hover:bg-[#1fa754] text-white"
                          onClick={() => {
                            const phone = seamstress.phone.replace(/[^0-9]/g, "");
                            const fullPhone = phone.startsWith("55") ? phone : `55${phone}`;
                            window.location.href = `/whatsapp-redirect?phone=${fullPhone}`;
                          }}
                          data-testid={`button-whatsapp-seamstress-iniciante-${seamstress.id}`}
                        >
                          <MessageCircle className="w-3 h-3 mr-1" />
                          WhatsApp
                        </Button>
                        <Button
                          size="sm"
                          variant="outline"
                          className="flex-1 text-red-600 hover:text-red-700 dark:text-red-400 dark:hover:text-red-300"
                          onClick={() => handleDeleteClick(seamstress.id)}
                          data-testid={`button-delete-seamstress-iniciante-${seamstress.id}`}
                        >
                          <Trash2 className="w-3 h-3 mr-1" />
                          Deletar
                        </Button>
                      </div>
                    </div>
                  )}
                </Card>
              );
            })}
          </div>
        </div>
      )}

      {/* Seamstress Details Drawer */}
      <Drawer open={drawerOpen} onOpenChange={setDrawerOpen}>
        <DrawerContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
          <DrawerHeader className="flex items-center justify-between sticky top-0 bg-background z-10">
            <DrawerTitle>Detalhes da Costureira</DrawerTitle>
            <DrawerClose asChild>
              <Button variant="ghost" size="icon" data-testid="button-close-seamstress-drawer">
                <X className="w-4 h-4" />
              </Button>
            </DrawerClose>
          </DrawerHeader>

          {selectedSeamstress && (
            <div className="p-6 space-y-4">
              {/* Basic Info */}
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <p className="text-xs text-muted-foreground">Nome</p>
                  <p className="text-lg font-semibold mt-1">{selectedSeamstress.name}</p>
                </div>
                <div>
                  <p className="text-xs text-muted-foreground">Status</p>
                  <p className="font-semibold mt-1">
                    <span
                      className={`inline-block px-2 py-1 rounded text-xs font-bold ${
                        selectedSeamstress.status === "active"
                          ? "bg-green-900/50 text-green-400"
                          : selectedSeamstress.status === "paused"
                          ? "bg-yellow-900/50 text-yellow-400"
                          : "bg-red-900/50 text-red-400"
                      }`}
                    >
                      {selectedSeamstress.status === "active" ? "Ativa" : selectedSeamstress.status === "paused" ? "Pausada" : "Bloqueada"}
                    </span>
                  </p>
                </div>
              </div>

              {/* Contact Info */}
              <div className="grid grid-cols-2 gap-4 pt-4 border-t">
                <div>
                  <p className="text-xs text-muted-foreground">Telefone</p>
                  <div className="flex items-center gap-2 mt-1">
                    <p className="font-semibold">{selectedSeamstress.phone || "N/A"}</p>
                    {selectedSeamstress.phone && (
                      <Button
                        size="icon"
                        variant="ghost"
                        className="h-6 w-6"
                        onClick={() => copyToClipboard(selectedSeamstress.phone, "Telefone")}
                        data-testid="button-copy-phone-drawer"
                      >
                        {copiedField === "Telefone" ? <Check className="w-3 h-3 text-green-500" /> : <Copy className="w-3 h-3" />}
                      </Button>
                    )}
                  </div>
                </div>
                <div>
                  <p className="text-xs text-muted-foreground">Costureiras/Funcionários</p>
                  <p className="font-semibold mt-1">{selectedSeamstress.numberOfWorkers || 1}</p>
                </div>
              </div>

              {/* PIX Info */}
              {selectedSeamstress.pix && (
                <div className="pt-4 border-t">
                  <p className="text-xs text-muted-foreground">Chave PIX</p>
                  <div className="flex items-center gap-2 mt-1">
                    <p className="font-semibold">{selectedSeamstress.pix}</p>
                    <Button
                      size="icon"
                      variant="ghost"
                      className="h-6 w-6"
                      onClick={() => copyToClipboard(selectedSeamstress.pix, "PIX")}
                      data-testid="button-copy-pix-drawer"
                    >
                      {copiedField === "PIX" ? <Check className="w-3 h-3 text-green-500" /> : <Copy className="w-3 h-3" />}
                    </Button>
                  </div>
                  <p className="text-xs text-muted-foreground mt-1">
                    Tipo: {validatePix(selectedSeamstress.pix).type === "cpf" ? "CPF" : 
                           validatePix(selectedSeamstress.pix).type === "phone" ? "Telefone" :
                           validatePix(selectedSeamstress.pix).type === "email" ? "E-mail" :
                           validatePix(selectedSeamstress.pix).type === "random" ? "Chave Aleatória" : "Desconhecido"}
                  </p>
                </div>
              )}

              {/* Address Info */}
              <div className="pt-4 border-t space-y-3">
                <div>
                  <p className="text-xs text-muted-foreground">Endereço</p>
                  <p className="font-semibold mt-1">{selectedSeamstress.address || "N/A"}</p>
                </div>
                <div>
                  <p className="text-xs text-muted-foreground">Bairro</p>
                  <p className="font-semibold mt-1">{selectedSeamstress.neighborhood || "N/A"}</p>
                </div>
              </div>

              {/* Skills and Machines */}
              {(selectedSeamstress.skills?.length > 0 || selectedSeamstress.machines?.length > 0) && (
                <div className="pt-4 border-t space-y-3">
                  {selectedSeamstress.skills?.length > 0 && (
                    <div>
                      <p className="text-xs text-muted-foreground mb-2">Habilidades</p>
                      <div className="flex flex-wrap gap-2">
                        {selectedSeamstress.skills.map((skill: string, idx: number) => (
                          <span key={idx} className="px-2 py-1 bg-blue-900/50 text-blue-400 text-xs rounded-full font-semibold">
                            {skill}
                          </span>
                        ))}
                      </div>
                    </div>
                  )}
                  {selectedSeamstress.machines?.length > 0 && (
                    <div>
                      <p className="text-xs text-muted-foreground mb-2">Máquinas</p>
                      <div className="flex flex-wrap gap-2">
                        {selectedSeamstress.machines.map((machine: string, idx: number) => (
                          <span key={idx} className="px-2 py-1 bg-purple-900/50 text-purple-400 text-xs rounded-full font-semibold">
                            {machine}
                          </span>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              )}

              {/* Ratings Section */}
              <div className="pt-4 border-t space-y-4">
                <div>
                  <p className="text-xs text-muted-foreground mb-3">Avaliação de Prazo (Deadline)</p>
                  <div className="flex gap-2 items-center">
                    <div className="flex gap-1">
                      {[1, 2, 3, 4, 5].map((star) => (
                        <button
                          key={star}
                          onClick={() => setRatingDeadline(star)}
                          className="transition-colors"
                          data-testid={`button-rating-deadline-${star}`}
                        >
                          <Star
                            className={`w-5 h-5 ${
                              star <= ratingDeadline
                                ? 'fill-yellow-400 text-yellow-400'
                                : 'text-gray-400'
                            }`}
                          />
                        </button>
                      ))}
                    </div>
                    <span className="text-sm font-semibold">{ratingDeadline}/5</span>
                  </div>
                </div>

                <div>
                  <p className="text-xs text-muted-foreground mb-3">Avaliação de Acabamento (Finish)</p>
                  <div className="flex gap-2 items-center">
                    <div className="flex gap-1">
                      {[1, 2, 3, 4, 5].map((star) => (
                        <button
                          key={star}
                          onClick={() => setRatingFinish(star)}
                          className="transition-colors"
                          data-testid={`button-rating-finish-${star}`}
                        >
                          <Star
                            className={`w-5 h-5 ${
                              star <= ratingFinish
                                ? 'fill-blue-400 text-blue-400'
                                : 'text-gray-400'
                            }`}
                          />
                        </button>
                      ))}
                    </div>
                    <span className="text-sm font-semibold">{ratingFinish}/5</span>
                  </div>
                </div>

                <Button onClick={handleSaveRatings} className="w-full mt-4" data-testid="button-save-ratings">
                  Salvar Avaliações
                </Button>
              </div>
            </div>
          )}
        </DrawerContent>
      </Drawer>

      <Dialog open={duplicatesDialogOpen} onOpenChange={setDuplicatesDialogOpen}>
        <DialogContent className="max-w-3xl max-h-[80vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Costureiras Duplicadas</DialogTitle>
          </DialogHeader>
          
          {duplicateGroups.length === 0 ? (
            <div className="text-center py-8">
              <Users className="w-12 h-12 mx-auto text-muted-foreground mb-4" />
              <p className="text-lg font-medium">Nenhuma duplicata encontrada</p>
              <p className="text-sm text-muted-foreground">Todas as costureiras são únicas.</p>
            </div>
          ) : (
            <div className="space-y-6">
              <p className="text-sm text-muted-foreground">
                Encontrados {duplicateGroups.length} grupo(s) de duplicatas. Selecione as costureiras que deseja excluir.
              </p>
              
              {duplicateGroups.map((group, groupIndex) => (
                <div key={groupIndex} className="border rounded-lg p-4 space-y-3">
                  <p className="text-sm font-medium text-muted-foreground">
                    Grupo {groupIndex + 1} - {group.length} costureiras similares
                  </p>
                  {group.map((seamstress) => (
                    <div
                      key={seamstress.id}
                      className={`flex items-center gap-3 p-3 rounded-lg border cursor-pointer transition-colors ${
                        selectedDuplicates.has(seamstress.id) 
                          ? 'bg-red-50 dark:bg-red-950 border-red-300 dark:border-red-700' 
                          : 'hover:bg-muted/50'
                      }`}
                      onClick={() => toggleDuplicateSelection(seamstress.id)}
                      data-testid={`duplicate-item-${seamstress.id}`}
                    >
                      <input
                        type="checkbox"
                        checked={selectedDuplicates.has(seamstress.id)}
                        onChange={() => toggleDuplicateSelection(seamstress.id)}
                        className="w-4 h-4"
                      />
                      <div className="flex-1">
                        <p className="font-medium">{seamstress.name}</p>
                        <p className="text-sm text-muted-foreground">{seamstress.phone}</p>
                        <p className="text-xs text-muted-foreground">{seamstress.address}, {seamstress.neighborhood}</p>
                      </div>
                      <div className="text-xs text-muted-foreground">
                        {new Date(seamstress.createdAt).toLocaleDateString('pt-BR')}
                      </div>
                    </div>
                  ))}
                </div>
              ))}
              
              <div className="flex justify-between items-center pt-4 border-t">
                <p className="text-sm">
                  {selectedDuplicates.size} selecionada(s) para exclusão
                </p>
                <div className="flex gap-2">
                  <Button variant="outline" onClick={() => setDuplicatesDialogOpen(false)}>
                    Cancelar
                  </Button>
                  <Button 
                    variant="destructive" 
                    onClick={handleDeleteDuplicates}
                    disabled={selectedDuplicates.size === 0}
                    data-testid="button-delete-duplicates"
                  >
                    <Trash2 className="w-4 h-4 mr-2" />
                    Excluir Selecionadas
                  </Button>
                </div>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default Seamstresses;