import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Printer, ArrowUpDown } from "lucide-react";
import { useState } from "react";
import { PrintFormatDialog, PrintFormat, getCupomBaseStyles, printContent as printHtml } from "@/components/print-format-dialog";

interface Production {
  id: string;
  productName: string;
  product_name: string;
  quantity: number;
  pricePerUnit: number;
  price_per_unit: number;
}

interface Batch {
  id: string;
  production_id: string;
  productionId: string;
  quantity: number;
  pricePerUnit: number;
  price_per_unit: number;
}

const Profits = () => {
  const [sortBy, setSortBy] = useState<string>("profit");
  const [sortOrder, setSortOrder] = useState<"asc" | "desc">("desc");
  
  // Print format dialog state
  const [printFormatDialogOpen, setPrintFormatDialogOpen] = useState(false);
  const [pendingPrintAction, setPendingPrintAction] = useState<{
    type: 'all' | 'single';
    data?: any;
  } | null>(null);

  const { data: productions = [] } = useQuery<Production[]>({
    queryKey: ["/api/productions"],
  });

  const { data: batches = [] } = useQuery<Batch[]>({
    queryKey: ["/api/batches"],
  });

  // Calculate profit for each production
  const productionsWithProfits = productions.map((prod: any) => {
    const productionId = prod.id;
    // CORRIGIDO: Usar productionId (camelCase) em vez de production_id
    const prodBatches = batches.filter((b: any) => b.productionId === productionId || b.production_id === productionId);
    const pricePerUnit = parseFloat(prod.price_per_unit || prod.pricePerUnit || 0);
    const totalRevenue = (prod.quantity || 0) * pricePerUnit;
    const totalCost = prodBatches.reduce((sum: number, b: any) => {
      const bPrice = parseFloat(b.pricePerUnit || b.price_per_unit || 0);
      const batchCost = (b.quantity || 0) * bPrice;
      return sum + batchCost;
    }, 0);
    const profit = totalRevenue - totalCost;
    const profitPercentage = totalRevenue > 0 ? (profit / totalRevenue) * 100 : 0;

    return {
      ...prod,
      totalRevenue,
      totalCost,
      profit,
      profitPercentage,
      batchCount: prodBatches.length,
      pricePerUnit,
    };
  });

  // Sort productions based on selected column
  const sortedProductions = [...productionsWithProfits].sort((a: any, b: any) => {
    let aVal = 0, bVal = 0;
    
    switch (sortBy) {
      case "product":
        aVal = (a.product_name || "").localeCompare(b.product_name || "");
        return sortOrder === "desc" ? -aVal : aVal;
      case "quantity":
        aVal = a.quantity;
        bVal = b.quantity;
        break;
      case "price":
        aVal = a.pricePerUnit;
        bVal = b.pricePerUnit;
        break;
      case "revenue":
        aVal = a.totalRevenue;
        bVal = b.totalRevenue;
        break;
      case "cost":
        aVal = a.totalCost;
        bVal = b.totalCost;
        break;
      case "profit":
        aVal = a.profit;
        bVal = b.profit;
        break;
      case "profitPercentage":
        aVal = a.profitPercentage;
        bVal = b.profitPercentage;
        break;
      default:
        aVal = a.profit;
        bVal = b.profit;
    }
    
    return sortOrder === "desc" ? bVal - aVal : aVal - bVal;
  });

  const handleSort = (column: string) => {
    if (sortBy === column) {
      setSortOrder(sortOrder === "desc" ? "asc" : "desc");
    } else {
      setSortBy(column);
      setSortOrder("desc");
    }
  };

  // Print format dialog functions
  const openPrintAllDialog = () => {
    setPendingPrintAction({ type: 'all' });
    setPrintFormatDialogOpen(true);
  };

  const openPrintProductionDialog = (prod: any) => {
    setPendingPrintAction({ type: 'single', data: prod });
    setPrintFormatDialogOpen(true);
  };

  const handlePrintFormatSelect = (format: PrintFormat) => {
    setPrintFormatDialogOpen(false);
    if (!pendingPrintAction) return;
    
    if (pendingPrintAction.type === 'all') {
      handlePrintAll(format);
    } else {
      handlePrintProduction(pendingPrintAction.data, format);
    }
    setPendingPrintAction(null);
  };

  const renderSortIcon = (column: string) => {
    if (sortBy !== column) {
      return <ArrowUpDown className="w-3 h-3 opacity-50" />;
    }
    return <ArrowUpDown className="w-3 h-3" />;
  };

  // Calculate total profit across all productions
  const totalProfit = productionsWithProfits.reduce((sum: number, p: any) => sum + p.profit, 0);
  const totalRevenue = productionsWithProfits.reduce((sum: number, p: any) => sum + p.totalRevenue, 0);
  const totalCost = productionsWithProfits.reduce((sum: number, p: any) => sum + p.totalCost, 0);

  const handlePrintAll = (format: PrintFormat = 'a4') => {
    const printContent = `<!DOCTYPE html><html lang="pt-BR"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0"><title>Relatório de Lucros</title><style>* {margin:0;padding:0;box-sizing:border-box}body {font-family:Arial,sans-serif;background:#fff;color:#000;line-height:1.3;padding:10mm}.container {max-width:210mm}.header {text-align:center;margin-bottom:8mm;border-bottom:2px solid #000;padding-bottom:5mm}.header h1 {font-size:24px;font-weight:900;letter-spacing:1px;text-transform:uppercase;margin-bottom:3px}.header p {font-size:11px;color:#333}.summary {display:grid;grid-template-columns:1fr 1fr 1fr;gap:8mm;margin-bottom:8mm}.summary-box {border:2px solid #000;padding:8px;text-align:center}.summary-label {font-size:10px;font-weight:700;text-transform:uppercase;letter-spacing:0.5px;margin-bottom:3px;color:#333}.summary-value {font-size:18px;font-weight:900;color:#000}table {width:100%;border-collapse:collapse;margin-bottom:8mm}.table-title {font-size:12px;font-weight:700;text-transform:uppercase;margin-bottom:3px;letter-spacing:0.5px}th {background:#000;color:#fff;padding:6px 4px;text-align:left;font-weight:700;font-size:9px;border:1px solid #000}td {padding:5px 4px;border:0.5px solid #000;font-size:9px;font-weight:500}tr:nth-child(even) {background:#f8f8f8}tr:nth-child(odd) {background:#fff}.footer {margin-top:10mm;border-top:2px solid #000;padding-top:5mm;text-align:center;font-size:9px;color:#333}@media print {body {padding:10mm}}</style></head><body><div class="container"><div class="header"><h1>ANÁLISE DE LUCROS</h1><p>GoFast Produções - ${new Date().toLocaleDateString('pt-BR')}</p></div><div class="summary"><div class="summary-box">
              <div class="summary-label">Receita Total</div>
              <div class="summary-value">R$ ${totalRevenue.toFixed(2)}</div>
            </div>
            <div class="summary-box">
              <div class="summary-label">Custo Total</div>
              <div class="summary-value">R$ ${totalCost.toFixed(2)}</div>
            </div>
            <div class="summary-box" style="background: linear-gradient(135deg, ${totalProfit >= 0 ? '#10B981' : '#EF4444'} 0%, ${totalProfit >= 0 ? '#059669' : '#DC2626'} 100%);">
              <div class="summary-label">Lucro Total</div>
              <div class="summary-value">R$ ${totalProfit.toFixed(2)}</div>
            </div>
          </div>

          <table>
            <thead>
              <tr>
                <th>Produção</th>
                <th>Quantidade</th>
                <th>Preço Unit.</th>
                <th>Receita</th>
                <th>Custo</th>
                <th>Lucro</th>
                <th>Lotes</th>
              </tr>
            </thead>
            <tbody>
              ${productionsWithProfits.map((prod: any) => `
                <tr>
                  <td>${prod.product_name || prod.productName}</td>
                  <td>${prod.quantity}</td>
                  <td>R$ ${(prod.pricePerUnit).toFixed(2)}</td>
                  <td>R$ ${(prod.totalRevenue).toFixed(2)}</td>
                  <td>R$ ${(prod.totalCost).toFixed(2)}</td>
                  <td class="${(prod.profit) >= 0 ? 'profit-positive' : 'profit-negative'}">R$ ${(prod.profit).toFixed(2)}</td>
                  <td>${prod.batchCount}</td>
                </tr>
              `).join('')}
            </tbody>
          </table>

          <div class="footer">
            <p>Impresso em ${new Date().toLocaleString('pt-BR')}</p>
          </div>
        </div>
      </body>
      </html>
    `;

    let content = '';
    if (format === 'cupom') {
      let prodLines = '';
      productionsWithProfits.forEach((prod: any) => {
        prodLines += `
          <div class="item">
            <div class="item-header">${(prod.product_name || prod.productName || 'N/A').substring(0, 18)}</div>
            <div class="item-row"><span>Rec:</span><span>R$${(prod.totalRevenue).toFixed(0)}</span></div>
            <div class="item-row"><span>Cust:</span><span>R$${(prod.totalCost).toFixed(0)}</span></div>
            <div class="item-row"><span>Lucro:</span><span>R$${(prod.profit).toFixed(0)}</span></div>
          </div>
        `;
      });

      content = `<!DOCTYPE html><html lang="pt-BR"><head><meta charset="UTF-8">
        <title>Lucros</title>
        <style>${getCupomBaseStyles()}</style>
      </head><body>
        <div class="cupom">
          <div class="header">GOFAST PRODUCOES</div>
          <div class="title">ANALISE LUCROS</div>
          <div class="divider"></div>
          <div class="total">RECEITA: R$ ${totalRevenue.toFixed(2)}</div>
          <div class="total">CUSTO: R$ ${totalCost.toFixed(2)}</div>
          <div class="total">LUCRO: R$ ${totalProfit.toFixed(2)}</div>
          <div class="divider"></div>
          ${prodLines}
          <div class="divider"></div>
          <div class="footer">${new Date().toLocaleString('pt-BR')}</div>
        </div>
      </body></html>`;
    } else {
      content = printContent;
    }
    
    printHtml(content);
  };

  const handlePrintProduction = (prod: any, format: PrintFormat = 'a4') => {
    const prodName = prod.product_name || prod.productName;
    const priceUnit = parseFloat(prod.pricePerUnit || prod.price_per_unit || 0);
    
    const printContent = `
      <!DOCTYPE html>
      <html lang="pt-BR">
      <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Detalhes - ${prodName}</title>
        <style>
          * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
          }
          body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #fff;
            padding: 30px;
            line-height: 1.6;
          }
          .container {
            max-width: 800px;
            margin: 0 auto;
          }
          .header {
            text-align: center;
            margin-bottom: 40px;
            border-bottom: 3px solid #4C8BF5;
            padding-bottom: 20px;
          }
          .header h1 {
            font-size: 32px;
            color: #0F0F1A;
            margin-bottom: 10px;
          }
          .header p {
            color: #666;
            font-size: 14px;
          }
          .section {
            margin-bottom: 30px;
          }
          .section-title {
            font-size: 14px;
            font-weight: 700;
            text-transform: uppercase;
            color: #4C8BF5;
            margin-bottom: 15px;
            padding-bottom: 10px;
            border-bottom: 2px solid #4C8BF5;
          }
          .detail-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 30px;
            margin-bottom: 15px;
          }
          .detail-item {
            background-color: #f9fafb;
            padding: 15px;
            border-radius: 6px;
            border: 1px solid #e5e7eb;
          }
          .detail-label {
            font-size: 11px;
            font-weight: 600;
            text-transform: uppercase;
            color: #666;
            margin-bottom: 8px;
          }
          .detail-value {
            font-size: 18px;
            font-weight: 600;
            color: #1F2937;
          }
          .summary-box {
            background: linear-gradient(135deg, #1B1B2E 0%, #2D2D4D 100%);
            color: white;
            padding: 25px;
            border-radius: 8px;
            text-align: center;
          }
          .summary-label {
            font-size: 12px;
            font-weight: 600;
            text-transform: uppercase;
            opacity: 0.9;
            margin-bottom: 10px;
          }
          .summary-value {
            font-size: 28px;
            font-weight: 700;
          }
          .profit-positive {
            background: linear-gradient(135deg, #10B981 0%, #059669 100%) !important;
          }
          .profit-negative {
            background: linear-gradient(135deg, #EF4444 0%, #DC2626 100%) !important;
          }
          .footer {
            margin-top: 40px;
            text-align: center;
            font-size: 12px;
            color: #999;
            border-top: 1px solid #e5e7eb;
            padding-top: 20px;
          }
        </style>
      </head>
      <body>
        <div class="container">
          <div class="header">
            <h1>${prodName}</h1>
            <p>GoFast Produções - ${new Date().toLocaleDateString('pt-BR')}</p>
          </div>

          <div class="section">
            <div class="section-title">Informações da Produção</div>
            <div class="detail-grid">
              <div class="detail-item">
                <div class="detail-label">Quantidade Total</div>
                <div class="detail-value">${prod.quantity} peças</div>
              </div>
              <div class="detail-item">
                <div class="detail-label">Preço Unitário</div>
                <div class="detail-value">R$ ${priceUnit.toFixed(2)}</div>
              </div>
            </div>
          </div>

          <div class="section">
            <div class="section-title">Análise Financeira</div>
            <div class="detail-grid">
              <div class="detail-item">
                <div class="detail-label">Receita Total</div>
                <div class="detail-value">R$ ${(prod.totalRevenue || 0).toFixed(2)}</div>
              </div>
              <div class="detail-item">
                <div class="detail-label">Custo com Costureiras</div>
                <div class="detail-value">R$ ${(prod.totalCost || 0).toFixed(2)}</div>
              </div>
            </div>
            <div class="detail-grid">
              <div class="detail-item">
                <div class="detail-label">Total de Lotes</div>
                <div class="detail-value">${prod.batchCount || 0}</div>
              </div>
            </div>
          </div>

          <div class="section">
            <div class="summary-box ${(prod.profit || 0) >= 0 ? 'profit-positive' : 'profit-negative'}">
              <div class="summary-label">Lucro Esperado</div>
              <div class="summary-value">R$ ${((prod.profit || 0)).toFixed(2)}</div>
            </div>
          </div>

          <div class="footer">
            <p>Impresso em ${new Date().toLocaleString('pt-BR')}</p>
          </div>
        </div>
      </body>
      </html>
    `;

    let content = '';
    if (format === 'cupom') {
      content = `<!DOCTYPE html><html lang="pt-BR"><head><meta charset="UTF-8">
        <title>Detalhe Lucro</title>
        <style>${getCupomBaseStyles()}</style>
      </head><body>
        <div class="cupom">
          <div class="header">GOFAST PRODUCOES</div>
          <div class="title">DETALHE LUCRO</div>
          <div class="divider"></div>
          <div class="info">${prodName}</div>
          <div class="info">Qtd: ${prod.quantity} | R$${priceUnit.toFixed(2)}/un</div>
          <div class="divider"></div>
          <div class="total">RECEITA: R$ ${(prod.totalRevenue || 0).toFixed(2)}</div>
          <div class="total">CUSTO: R$ ${(prod.totalCost || 0).toFixed(2)}</div>
          <div class="total">LUCRO: R$ ${(prod.profit || 0).toFixed(2)}</div>
          <div class="info">Lotes: ${prod.batchCount || 0}</div>
          <div class="divider"></div>
          <div class="footer">${new Date().toLocaleString('pt-BR')}</div>
        </div>
      </body></html>`;
    } else {
      content = printContent;
    }
    
    printHtml(content);
  };

  return (
    <div className="p-8 space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-semibold">Análise de Lucros</h1>
        <Button onClick={openPrintAllDialog} className="gap-2" data-testid="button-print-all-profits">
          <Printer className="w-4 h-4" />
          Imprimir Tudo
        </Button>
      </div>

      {/* Resumo Total */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card className="p-6 bg-gradient-to-br from-blue-900 to-blue-800 text-white">
          <p className="text-sm font-semibold opacity-90">Receita Total</p>
          <p className="text-3xl font-bold mt-2">R$ {totalRevenue.toFixed(2)}</p>
        </Card>
        <Card className="p-6 bg-gradient-to-br from-amber-900 to-amber-800 text-white">
          <p className="text-sm font-semibold opacity-90">Custo Total</p>
          <p className="text-3xl font-bold mt-2">R$ {totalCost.toFixed(2)}</p>
        </Card>
        <Card className={`p-6 bg-gradient-to-br ${totalProfit >= 0 ? 'from-green-900 to-green-800' : 'from-red-900 to-red-800'} text-white`}>
          <p className="text-sm font-semibold opacity-90">Lucro Total</p>
          <p className="text-3xl font-bold mt-2">R$ {totalProfit.toFixed(2)}</p>
        </Card>
      </div>

      {/* Tabela de Produções */}
      <Card className="overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-primary text-white">
              <tr>
                <th className="px-6 py-3 text-left text-sm font-semibold cursor-pointer hover:opacity-75 transition-opacity" onClick={() => handleSort("product")} data-testid="header-product">
                  <div className="flex items-center gap-2">Produção {renderSortIcon("product")}</div>
                </th>
                <th className="px-6 py-3 text-center text-sm font-semibold cursor-pointer hover:opacity-75 transition-opacity" onClick={() => handleSort("quantity")} data-testid="header-quantity">
                  <div className="flex items-center justify-center gap-2">Quantidade {renderSortIcon("quantity")}</div>
                </th>
                <th className="px-6 py-3 text-right text-sm font-semibold cursor-pointer hover:opacity-75 transition-opacity" onClick={() => handleSort("price")} data-testid="header-price">
                  <div className="flex items-center justify-end gap-2">Preço Unit. {renderSortIcon("price")}</div>
                </th>
                <th className="px-6 py-3 text-right text-sm font-semibold cursor-pointer hover:opacity-75 transition-opacity" onClick={() => handleSort("revenue")} data-testid="header-revenue">
                  <div className="flex items-center justify-end gap-2">Receita {renderSortIcon("revenue")}</div>
                </th>
                <th className="px-6 py-3 text-right text-sm font-semibold cursor-pointer hover:opacity-75 transition-opacity" onClick={() => handleSort("cost")} data-testid="header-cost">
                  <div className="flex items-center justify-end gap-2">Custo {renderSortIcon("cost")}</div>
                </th>
                <th className="px-6 py-3 text-right text-sm font-semibold cursor-pointer hover:opacity-75 transition-opacity" onClick={() => handleSort("profit")} data-testid="header-profit">
                  <div className="flex items-center justify-end gap-2">Lucro {renderSortIcon("profit")}</div>
                </th>
                <th className="px-6 py-3 text-center text-sm font-semibold cursor-pointer hover:opacity-75 transition-opacity" onClick={() => handleSort("profitPercentage")} data-testid="header-profit-percentage">
                  <div className="flex items-center justify-center gap-2">% Lucro {renderSortIcon("profitPercentage")}</div>
                </th>
                <th className="px-6 py-3 text-center text-sm font-semibold">Ação</th>
              </tr>
            </thead>
            <tbody className="divide-y">
              {sortedProductions.length === 0 ? (
                <tr>
                  <td colSpan={8} className="px-6 py-4 text-center text-muted-foreground">
                    Nenhuma produção encontrada
                  </td>
                </tr>
              ) : (
                sortedProductions.map((prod: any) => (
                  <tr key={prod.id} className="hover:bg-muted/50 transition-colors">
                    <td className="px-6 py-4 font-medium">{prod.product_name || prod.productName}</td>
                    <td className="px-6 py-4 text-center">{prod.quantity}</td>
                    <td className="px-6 py-4 text-right">R$ {(prod.pricePerUnit).toFixed(2)}</td>
                    <td className="px-6 py-4 text-right">R$ {(prod.totalRevenue).toFixed(2)}</td>
                    <td className="px-6 py-4 text-right">R$ {(prod.totalCost).toFixed(2)}</td>
                    <td className={`px-6 py-4 text-right font-bold ${(prod.profit) >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                      R$ {(prod.profit).toFixed(2)}
                    </td>
                    <td className="px-6 py-4 text-center font-semibold">
                      <span className={prod.profitPercentage >= 0 ? 'text-green-600' : 'text-red-600'}>
                        {(prod.profitPercentage).toFixed(1)}%
                      </span>
                    </td>
                    <td className="px-6 py-4 text-center">
                      <Button
                        onClick={() => openPrintProductionDialog(prod)}
                        variant="ghost"
                        size="sm"
                        className="gap-1"
                        data-testid={`button-print-profit-${prod.id}`}
                      >
                        <Printer className="w-4 h-4" />
                      </Button>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </Card>

      <PrintFormatDialog
        open={printFormatDialogOpen}
        onOpenChange={setPrintFormatDialogOpen}
        onSelectFormat={handlePrintFormatSelect}
      />
    </div>
  );
};

export default Profits;
