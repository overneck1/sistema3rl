import { getAuthHeader } from "../lib/auth";
import { useState, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { apiRequest } from "@/lib/queryClient";
import { queryClient } from "@/lib/queryClient";
import { Plus, Trash2, Edit2, Users, Printer, ChevronDown, ChevronUp, CheckCircle, Camera, Loader2 } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { PrintFormatDialog, PrintFormat, getCupomBaseStyles, printContent as printHtml } from "@/components/print-format-dialog";

interface Variant {
  size: string;
  color: string;
  quantity: number;
}

const statusLabels: Record<string, string> = {
  em_separacao: "Em Separação",
  para_entrega: "Para Entrega",
  em_producao: "Em Produção",
  para_recolha: "Para Recolha",
  concluido: "Concluído",
};

const statusColors: Record<string, string> = {
  em_separacao: "bg-blue-900/20 border-blue-600/30",
  para_entrega: "bg-cyan-900/20 border-cyan-600/30",
  em_producao: "bg-amber-900/20 border-amber-600/30",
  para_recolha: "bg-purple-900/20 border-purple-600/30",
  concluido: "bg-green-900/20 border-green-600/30",
};

const ProductionCard = ({ production, onEdit, onDelete, getAvailableQuantity, getExpectedProfit, onStatusChange, isLoading, isExpanded, onToggleExpanded, onPaymentReceived }: any) => {
  const [printFormatDialogOpen, setPrintFormatDialogOpen] = useState(false);
  
  // Usa os dados já incluídos na resposta de produções (otimizado para performance)
  const batches = production.batches || [];

  // Usa os valores calculados corretamente pelo backend
  const totalQuantity = production.quantity || 0;
  const allocatedQuantity = production.allocatedQuantity || 0;
  const availableQuantity = production.availableQuantity || 0;

  // Helper para parseFloat seguro
  const safeParseFloat = (value: any): number => {
    const parsed = parseFloat(value || 0);
    return isNaN(parsed) ? 0 : parsed;
  };

  // Usa o custo calculado pelo backend (ou calcula localmente se não disponível)
  const batchesCost = production.totalCost ?? batches.reduce((sum: number, item: any) => {
    const batch = item.batch || item;
    const qty = batch.quantity || 0;
    const price = safeParseFloat(batch.pricePerUnit);
    return sum + (qty * price);
  }, 0);

  // Calcula lucro: (Quantidade TOTAL × Preço de Venda) - Custo dos Lotes
  const totalRevenue = totalQuantity * safeParseFloat(production.pricePerUnit);
  const expectedProfit = totalRevenue - batchesCost;

  // Agrupa as costureiras por lotes
  const seamstressesMap = new Map<string, { name: string; batchCount: number }>();
  batches.forEach((item: any) => {
    const seamstress = item.seamstress;
    if (seamstress) {
      const existing = seamstressesMap.get(seamstress.id) || { name: seamstress.name, batchCount: 0 };
      existing.batchCount += 1;
      seamstressesMap.set(seamstress.id, existing);
    }
  });

  const openPrintDialog = () => {
    setPrintFormatDialogOpen(true);
  };

  const handlePrintFormatSelect = (format: PrintFormat) => {
    setPrintFormatDialogOpen(false);
    handlePrintProduction(format);
  };

  const handlePrintProduction = async (format: PrintFormat = 'a4') => {
    // Calcular valores financeiros
    const safeParseFloat = (value: any): number => {
      const parsed = parseFloat(value || 0);
      return isNaN(parsed) ? 0 : parsed;
    };
    const totalRevenue = totalQuantity * safeParseFloat(production.pricePerUnit);
    const expectedProfit = totalRevenue - batchesCost;

    // Buscar variantes, batches e costureiras da produção
    const variantsRes = await fetch(`/api/tenant/productions/${production.id}/variants`, { headers: getAuthHeader() });
    const productionVariants = await variantsRes.json();
    
    const batchesRes = await fetch(`/api/tenant/productions/${production.id}/batches`, { headers: getAuthHeader() });
    const productionBatches = await batchesRes.json();
    
    const seamstressesRes = await fetch('/api/tenant/seamstresses', { headers: getAuthHeader() });
    const allSeamstresses = await seamstressesRes.json();

    // Construir HTML das costureiras
    let seamstressesHtml = '';
    if (productionBatches && productionBatches.length > 0) {
      seamstressesHtml = `
        <div class="info-section">
          <h3>Costureiras Responsáveis</h3>
          <table>
            <thead>
              <tr>
                <th>Costureira</th>
                <th>Tamanho</th>
                <th>Cor</th>
                <th>Quantidade</th>
              </tr>
            </thead>
            <tbody>
      `;
      
      // Para cada lote, buscar suas alocações
      for (const item of productionBatches) {
        const batchData = item.batch || item;
        const seamstressData = item.seamstress;
        const seamstressName = seamstressData?.name || 'N/A';
        
        const allocationsRes = await fetch(`/api/tenant/batches/${batchData.id}/allocations`, { headers: getAuthHeader() });
        const allocations = await allocationsRes.json();
        
        for (const alloc of allocations) {
          const variant = productionVariants.find((v: any) => v.id === alloc.variantId);
          seamstressesHtml += `
            <tr>
              <td>${seamstressName}</td>
              <td>${variant?.size || 'N/A'}</td>
              <td>${variant?.color || 'N/A'}</td>
              <td>${alloc.quantity}</td>
            </tr>
          `;
        }
      }
      
      seamstressesHtml += `
            </tbody>
          </table>
        </div>
      `;
    }

    const printContent = `
      <!DOCTYPE html>
      <html lang="pt-BR">
      <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Impressão de Produção</title>
        <style>
          * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
          }
          body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #fff;
            padding: 10px;
            line-height: 1.4;
          }
          .container {
            max-width: 210mm;
            height: 297mm;
            margin: 0 auto;
            display: flex;
            flex-direction: column;
            padding: 12px;
          }
          .header {
            text-align: center;
            margin-bottom: 10px;
            border-bottom: 3px solid #8B5CF6;
            padding-bottom: 8px;
          }
          .header h1 {
            margin: 0;
            font-size: 22px;
            color: #1F2937;
            font-weight: 700;
          }
          .header .code {
            font-size: 12px;
            color: #6B7280;
            margin-top: 2px;
            font-weight: 500;
          }
          .grid-2 {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 8px;
            margin-bottom: 10px;
          }
          .grid-3 {
            display: grid;
            grid-template-columns: 1fr 1fr 1fr;
            gap: 8px;
            margin-bottom: 10px;
          }
          .info-box {
            background-color: #F9FAFB;
            border: 1px solid #E5E7EB;
            border-radius: 6px;
            padding: 8px;
          }
          .info-box.highlight {
            background: linear-gradient(135deg, #8B5CF6 0%, #6366F1 100%);
            border: 2px solid #8B5CF6;
            color: white;
          }
          .info-box.highlight .label {
            color: #E0E7FF;
            font-weight: 600;
          }
          .info-box.highlight .value {
            color: white;
            font-size: 16px;
            font-weight: 700;
          }
          .label {
            font-size: 11px;
            font-weight: 600;
            color: #6B7280;
            text-transform: uppercase;
            letter-spacing: 0.5px;
          }
          .value {
            font-size: 13px;
            color: #1F2937;
            margin-top: 2px;
            font-weight: 500;
          }
          .section-title {
            font-size: 11px;
            font-weight: 700;
            color: #1F2937;
            text-transform: uppercase;
            margin-bottom: 6px;
            padding-bottom: 4px;
            border-bottom: 2px solid #E5E7EB;
            letter-spacing: 0.5px;
          }
          table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 8px;
            font-size: 12px;
          }
          table thead {
            background-color: #8B5CF6;
            color: white;
          }
          table th {
            padding: 6px 4px;
            text-align: left;
            font-weight: 600;
            font-size: 11px;
          }
          table td {
            padding: 5px 4px;
            border-bottom: 1px solid #E5E7EB;
          }
          table tbody tr:nth-child(even) {
            background-color: #F9FAFB;
          }
          .financial-box {
            background: linear-gradient(135deg, #10B981 0%, #059669 100%);
            border: 2px solid #10B981;
            color: white;
          }
          .financial-box.loss {
            background: linear-gradient(135deg, #EF4444 0%, #DC2626 100%);
            border: 2px solid #EF4444;
          }
          .financial-box .label {
            color: rgba(255,255,255,0.9);
          }
          .financial-box .value {
            color: white;
            font-size: 15px;
            font-weight: 700;
          }
          .footer {
            margin-top: auto;
            text-align: center;
            font-size: 10px;
            color: #9CA3AF;
            border-top: 1px solid #E5E7EB;
            padding-top: 6px;
          }
          @media print {
            body {
              padding: 0;
              margin: 0;
            }
            .container {
              max-width: 100%;
              height: 100%;
              padding: 10mm;
            }
          }
        </style>
      </head>
      <body>
        <div class="container">
          <div class="header">
            <h1>ETIQUETA DE PRODUÇÃO</h1>
            <div class="code">${production.productionCode}</div>
          </div>

          <div class="grid-2">
            <div class="info-box">
              <div class="label">Produto</div>
              <div class="value">${production.productName || 'N/A'}</div>
            </div>
            <div class="info-box">
              <div class="label">Fornecedor</div>
              <div class="value">${production.supplier || 'N/A'}</div>
            </div>
          </div>

          <div class="grid-2">
            <div class="info-box highlight">
              <div class="label">Data de Entrega</div>
              <div class="value">${new Date(production.deliveryDate).toLocaleDateString('pt-BR')}</div>
            </div>
            <div class="info-box highlight">
              <div class="label">Data de Recebimento</div>
              <div class="value">${production.expectedPaymentDate ? new Date(production.expectedPaymentDate).toLocaleDateString('pt-BR') : 'Pendente'}</div>
            </div>
          </div>

          <div class="grid-3">
            <div class="info-box">
              <div class="label">Total de Peças</div>
              <div class="value">${totalQuantity}</div>
            </div>
            <div class="info-box">
              <div class="label">Valor Unitário</div>
              <div class="value">R$ ${parseFloat(production.pricePerUnit).toFixed(2)}</div>
            </div>
            <div class="financial-box ${expectedProfit < 0 ? 'loss' : ''}">
              <div class="label">Lucro Esperado</div>
              <div class="value">R$ ${expectedProfit.toFixed(2)}</div>
            </div>
          </div>

          <div class="section-title">Variações do Produto</div>
          <table>
            <thead>
              <tr>
                <th>Tamanho</th>
                <th>Cor</th>
                <th>Quantidade</th>
              </tr>
            </thead>
            <tbody>
              ${production.variants && production.variants.length > 0 ? production.variants.map((v: any) => `
                <tr>
                  <td>${v.size}</td>
                  <td>${v.color}</td>
                  <td>${v.quantity}</td>
                </tr>
              `).join('') : '<tr><td colspan="3">Sem variações</td></tr>'}
            </tbody>
          </table>

          <div class="grid-2" style="margin-bottom: 8px;">
            <div class="info-box">
              <div class="label">Receita Total</div>
              <div class="value">R$ ${totalRevenue.toFixed(2)}</div>
            </div>
            <div class="info-box">
              <div class="label">Custo (Costureiras)</div>
              <div class="value">R$ ${batchesCost.toFixed(2)}</div>
            </div>
          </div>

          <div class="section-title">Costureiras Responsáveis</div>
          <table>
            <thead>
              <tr>
                <th style="width: 30%">Costureira</th>
                <th style="width: 25%">Tamanho</th>
                <th style="width: 25%">Cor</th>
                <th style="width: 20%">Qtd</th>
              </tr>
            </thead>
            <tbody>
              ${seamstressesHtml ? seamstressesHtml.split('<tbody>')[1]?.split('</tbody>')[0] || '<tr><td colspan="4">Nenhuma costureira atribuída</td></tr>' : '<tr><td colspan="4">Nenhuma costureira atribuída</td></tr>'}
            </tbody>
          </table>

          <div class="footer">
            Impresso em: ${new Date().toLocaleString('pt-BR')}
          </div>
        </div>
      </body>
      </html>
    `;

    let content = '';
    if (format === 'cupom') {
      // Build seamstress list for cupom
      let seamstressCupom = '';
      if (productionBatches && productionBatches.length > 0) {
        for (const item of productionBatches) {
          const batchData = item.batch || item;
          const seamstressData = item.seamstress;
          const seamstressName = seamstressData?.name || 'N/A';
          seamstressCupom += `<div class="item-row"><span>${seamstressName.substring(0, 15)}</span><span>${batchData.quantity || 0}un</span></div>`;
        }
      }

      content = `<!DOCTYPE html><html lang="pt-BR"><head><meta charset="UTF-8">
        <title>Producao - ${production.productName}</title>
        <style>${getCupomBaseStyles()}</style>
      </head><body>
        <div class="cupom">
          <div class="header">GOFAST PRODUCOES</div>
          <div class="title">PRODUCAO</div>
          <div class="divider"></div>
          <div class="info">${production.productName || 'N/A'}</div>
          <div class="info">${production.productionCode}</div>
          <div class="info">Forn: ${production.supplier || 'N/A'}</div>
          <div class="divider"></div>
          <div class="item-row"><span>Qtd Total:</span><span>${totalQuantity}un</span></div>
          <div class="item-row"><span>Disponivel:</span><span>${availableQuantity}un</span></div>
          <div class="item-row"><span>Preco/un:</span><span>R$${safeParseFloat(production.pricePerUnit).toFixed(2)}</span></div>
          <div class="divider"></div>
          <div class="total">RECEITA: R$ ${totalRevenue.toFixed(2)}</div>
          <div class="total">CUSTO: R$ ${batchesCost.toFixed(2)}</div>
          <div class="total">LUCRO: R$ ${expectedProfit.toFixed(2)}</div>
          ${seamstressCupom ? `<div class="divider"></div><div class="info">COSTUREIRAS:</div>${seamstressCupom}` : ''}
          <div class="divider"></div>
          <div class="footer">${new Date().toLocaleString('pt-BR')}</div>
        </div>
      </body></html>`;
    } else {
      content = printContent;
    }
    
    printHtml(content);
  };

  return (
    <>
    <Card className="p-4 cursor-pointer transition-all" data-testid={`card-production-${production.id}`}>
      {!isExpanded ? (
        <div className="flex items-center justify-between" onClick={() => onToggleExpanded(production.id)}>
          <p className="text-sm font-bold text-primary truncate">{production.productName || "Sem nome definido"}</p>
          <ChevronDown className="w-4 h-4 flex-shrink-0" />
        </div>
      ) : (
        <div className="space-y-3">
          <div className="flex items-center justify-between cursor-pointer" onClick={() => onToggleExpanded(production.id)}>
            <div>
              <p className="text-lg font-bold text-primary">{production.productName || "Sem nome definido"}</p>
              <p className="font-mono text-xs font-semibold text-muted-foreground">{production.productionCode}</p>
            </div>
            <ChevronUp className="w-4 h-4 flex-shrink-0" />
          </div>

          <p className="text-sm font-medium">{production.supplier}</p>

          <div className="flex gap-1">
            {production.paymentStatus === 'Pendente' && (
              <Button
                size="sm"
                className="bg-green-600 hover:bg-green-700 text-white flex-1"
                onClick={() => onPaymentReceived(production.id)}
                data-testid={`button-payment-received-${production.id}`}
              >
                <CheckCircle className="w-3 h-3 mr-1" />
                Recebido
              </Button>
            )}
            <Button
              size="icon"
              variant="ghost"
              onClick={openPrintDialog}
              data-testid={`button-print-production-${production.id}`}
              className="h-7 w-7"
            >
              <Printer className="w-3 h-3" />
            </Button>
            <Button
              size="icon"
              variant="ghost"
              onClick={() => onEdit(production)}
              data-testid={`button-edit-production-${production.id}`}
              className="h-7 w-7"
            >
              <Edit2 className="w-3 h-3" />
            </Button>
            <Button
              size="icon"
              variant="ghost"
              onClick={() => onDelete(production.id)}
              data-testid={`button-delete-production-${production.id}`}
              className="h-7 w-7 text-destructive"
            >
              <Trash2 className="w-3 h-3" />
            </Button>
          </div>

          <div className="border-t pt-2">
            <label className="text-xs font-semibold mb-2 block">Status</label>
            <Select value={production.status} onValueChange={(newStatus) => onStatusChange(production.id, newStatus)} disabled={isLoading}>
              <SelectTrigger data-testid={`select-production-status-${production.id}`} className="h-8 text-xs">
                <SelectValue>{statusLabels[production.status] || production.status}</SelectValue>
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="em_separacao">{statusLabels.em_separacao}</SelectItem>
                <SelectItem value="para_entrega">{statusLabels.para_entrega}</SelectItem>
                <SelectItem value="em_producao">{statusLabels.em_producao}</SelectItem>
                <SelectItem value="para_recolha">{statusLabels.para_recolha}</SelectItem>
                <SelectItem value="concluido">{statusLabels.concluido}</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="text-xs text-muted-foreground space-y-1">
            <p>Total: <span className="font-semibold text-foreground">{totalQuantity}</span> un | Alocado: <span className="font-semibold text-foreground">{allocatedQuantity}</span> un | Disponível: <span className="font-semibold text-foreground">{availableQuantity}</span> un</p>
            <p>Receita Total: <span className="font-semibold text-foreground">R$ {totalRevenue.toFixed(2)}</span></p>
            <p>Custo Costureiras: <span className="font-semibold text-foreground">R$ {batchesCost.toFixed(2)}</span></p>
            <p>Lucro: <span className={`font-semibold ${expectedProfit >= 0 ? 'text-green-600' : 'text-destructive'}`}>R$ {expectedProfit.toFixed(2)}</span></p>
            <p>R$ {parseFloat(production.pricePerUnit).toFixed(2)}/un</p>
            <p>Entrega: {new Date(production.deliveryDate).toLocaleDateString("pt-BR")}</p>
            <p>Pagamento: <span className={`font-semibold ${production.paymentStatus === 'Recebido' ? 'text-green-600' : 'text-amber-600'}`}>{production.paymentStatus || 'Pendente'}</span></p>
            {production.expectedPaymentDate && <p>Recebimento Esperado: {new Date(production.expectedPaymentDate).toLocaleDateString("pt-BR")}</p>}
          </div>

          {seamstressesMap.size > 0 && (
            <div className="border-t pt-2">
              <p className="text-xs font-semibold flex items-center gap-1 mb-1">
                <Users className="w-3 h-3" />
                Costureiras:
              </p>
              <div className="space-y-1">
                {Array.from(seamstressesMap.values()).map((s: any, idx: number) => (
                  <p key={idx} className="text-xs">
                    • {s.name} <span className="text-muted-foreground">({s.batchCount} lotes)</span>
                  </p>
                ))}
              </div>
            </div>
          )}

          {production.variants && production.variants.length > 0 && (
            <div className="text-xs space-y-1 border-t pt-2">
              {production.variants.map((v: any, idx: number) => (
                <div key={idx} className="flex justify-between">
                  <span>{v.size}/{v.color}:</span>
                  <span>{v.quantity} un</span>
                </div>
              ))}
            </div>
          )}
        </div>
      )}
    </Card>
    <PrintFormatDialog
      open={printFormatDialogOpen}
      onOpenChange={setPrintFormatDialogOpen}
      onSelectFormat={handlePrintFormatSelect}
    />
    </>
  );
};

const Productions = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [editingProductionId, setEditingProductionId] = useState<string | null>(null);
  const [expandedProductions, setExpandedProductions] = useState<Set<string>>(new Set());
  const [formData, setFormData] = useState({
    supplier: "",
    productName: "",
    date: new Date().toISOString().split("T")[0],
    deliveryDate: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString().split("T")[0],
    pricePerUnit: 0,
    paymentStatus: "Pendente" as "Pendente" | "Recebido",
    expectedPaymentDate: new Date(Date.now() + 18 * 24 * 60 * 60 * 1000).toISOString().split("T")[0],
    variants: [{ size: "", color: "", quantity: 0 }] as Variant[],
  });

  const [currentEditingProduction, setCurrentEditingProduction] = useState<any>(null);
  const [isOcrLoading, setIsOcrLoading] = useState(false);
  const { toast } = useToast();

  const { data: productions = [], isLoading } = useQuery({
    queryKey: ["/api/productions"],
  });

  const { data: editingVariants = [] } = useQuery<any[]>({
    queryKey: ["/api/productions", editingProductionId, "variants"],
    enabled: !!editingProductionId,
  });

  const { data: allBatches = [] } = useQuery({
    queryKey: ["/api/batches"],
  });

  const { data: suppliers = [] } = useQuery<any[]>({
    queryKey: ["/api/suppliers"],
  });

  const deleteMutation = useMutation({
    mutationFn: async (productionId: string) => {
      await apiRequest("DELETE", `/api/tenant/productions/${productionId}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/productions"] });
      toast({ title: "Sucesso", description: "Produção excluída!" });
    },
    onError: (error: any) => {
      toast({ title: "Erro ao excluir produção", description: error.message, variant: "destructive" });
    },
  });

  const statusMutation = useMutation({
    mutationFn: async ({ productionId, status }: { productionId: string; status: string }) => {
      const res = await apiRequest("PATCH", `/api/tenant/productions/${productionId}`, { status });
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/productions"] });
      toast({ title: "Sucesso", description: "Status da produção atualizado!" });
    },
    onError: (error: any) => {
      toast({ title: "Erro ao atualizar status", description: error.message, variant: "destructive" });
    },
  });

  const paymentMutation = useMutation({
    mutationFn: async (productionId: string) => {
      const res = await apiRequest("PATCH", `/api/tenant/productions/${productionId}`, { paymentStatus: "Recebido" });
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/productions"] });
      toast({ title: "Sucesso", description: "Pagamento marcado como recebido!" });
    },
    onError: (error: any) => {
      toast({ title: "Erro ao atualizar pagamento", description: error.message, variant: "destructive" });
    },
  });

  const handleDeleteProduction = (productionId: string) => {
    if (confirm("Tem certeza que deseja excluir esta produção? Todos os lotes associados também serão removidos.")) {
      deleteMutation.mutate(productionId);
    }
  };

  const handleStatusChange = (productionId: string, newStatus: string) => {
    statusMutation.mutate({ productionId, status: newStatus });
  };

  const handlePaymentReceived = (productionId: string) => {
    paymentMutation.mutate(productionId);
  };

  const toggleExpandedProduction = (id: string) => {
    const newExpanded = new Set(expandedProductions);
    if (newExpanded.has(id)) {
      newExpanded.delete(id);
    } else {
      newExpanded.add(id);
    }
    setExpandedProductions(newExpanded);
  };

  const createMutation = useMutation({
    mutationFn: async (data: any) => {
      const res = await apiRequest("POST", "/api/productions", {
        supplier: data.supplier,
        productName: data.productName,
        date: new Date(data.date),
        deliveryDate: new Date(data.deliveryDate),
        quantity: data.variants.reduce((sum: number, v: Variant) => sum + v.quantity, 0),
        pricePerUnit: data.pricePerUnit.toString(),
        paymentStatus: data.paymentStatus,
        expectedPaymentDate: data.expectedPaymentDate ? new Date(data.expectedPaymentDate) : null,
        variants: data.variants,
      });
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/productions"] });
      queryClient.invalidateQueries({ queryKey: ["/api/batches"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard"] });
      queryClient.invalidateQueries({ queryKey: ["/api/tenant/dashboard"] });
      setIsOpen(false);
      resetForm();
      toast({ title: "Sucesso", description: "Produção criada!" });
    },
    onError: (error: any) => {
      toast({ title: "Erro ao criar produção", description: error.message, variant: "destructive" });
    },
  });

  const updateMutation = useMutation({
    mutationFn: async ({ productionId, data }: any) => {
      const updateData: any = {};
      
      if (data.supplier && data.supplier.trim()) updateData.supplier = data.supplier;
      if (data.productName && data.productName.trim()) updateData.productName = data.productName;
      if (data.date) updateData.date = new Date(data.date);
      if (data.deliveryDate) updateData.deliveryDate = new Date(data.deliveryDate);
      if (data.pricePerUnit && data.pricePerUnit > 0) updateData.pricePerUnit = data.pricePerUnit.toString();
      if (data.paymentStatus) updateData.paymentStatus = data.paymentStatus;
      if (data.expectedPaymentDate) updateData.expectedPaymentDate = new Date(data.expectedPaymentDate);
      
      if (data.variants && data.variants.length > 0 && data.variants.some((v: Variant) => v.size || v.color || v.quantity > 0)) {
        updateData.variants = data.variants;
        updateData.quantity = data.variants.reduce((sum: number, v: Variant) => sum + v.quantity, 0);
      }
      
      const res = await apiRequest("PATCH", `/api/tenant/productions/${productionId}`, updateData);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/productions"] });
      queryClient.invalidateQueries({ queryKey: ["/api/batches"] });
      setIsOpen(false);
      setEditingProductionId(null);
      setCurrentEditingProduction(null);
      resetForm();
      toast({ title: "Sucesso", description: "Produção atualizada!" });
    },
    onError: (error: any) => {
      toast({ title: "Erro ao atualizar produção", description: error.message, variant: "destructive" });
    },
  });

  const resetForm = () => {
    setFormData({
      supplier: "",
      productName: "",
      date: new Date().toISOString().split("T")[0],
      deliveryDate: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString().split("T")[0],
      pricePerUnit: 0,
      paymentStatus: "Pendente",
      expectedPaymentDate: new Date(Date.now() + 18 * 24 * 60 * 60 * 1000).toISOString().split("T")[0],
      variants: [{ size: "", color: "", quantity: 0 }],
    });
    setEditingProductionId(null);
  };

  const handleEditProduction = (prod: any) => {
    setEditingProductionId(prod.id);
    setCurrentEditingProduction(prod);
    setFormData({
      supplier: prod.supplier,
      productName: prod.productName || "",
      date: prod.date.split("T")[0],
      deliveryDate: prod.deliveryDate.split("T")[0],
      pricePerUnit: parseFloat(prod.pricePerUnit),
      paymentStatus: prod.paymentStatus || "Pendente",
      expectedPaymentDate: prod.expectedPaymentDate ? prod.expectedPaymentDate.split("T")[0] : new Date(Date.now() + 18 * 24 * 60 * 60 * 1000).toISOString().split("T")[0],
      variants: prod.variants && prod.variants.length > 0 
        ? prod.variants.map((v: any) => ({ size: v.size, color: v.color, quantity: v.quantity }))
        : [{ size: "", color: "", quantity: 0 }],
    });
    setIsOpen(true);
  };

  // Load editing variants when available
  useEffect(() => {
    if (editingProductionId && editingVariants.length > 0) {
      setFormData(prev => ({
        ...prev,
        variants: editingVariants.map((v: any) => ({
          size: v.size,
          color: v.color,
          quantity: v.quantity,
        })),
      }));
    }
  }, [editingVariants, editingProductionId]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Se estiver editando, permite campos opcionais
    if (!editingProductionId) {
      // Validar todos os campos obrigatórios apenas para CRIAR nova produção
      if (!formData.supplier.trim()) {
        alert("Por favor, preencha o Fornecedor");
        return;
      }
      if (!formData.productName.trim()) {
        alert("Por favor, preencha o Nome da Produção (Model)");
        return;
      }
      if (!formData.pricePerUnit || formData.pricePerUnit <= 0) {
        alert("Por favor, preencha o Preço por Unidade com um valor maior que 0");
        return;
      }
      if (!formData.date) {
        alert("Por favor, preencha a Data de Recebimento");
        return;
      }
      if (!formData.deliveryDate) {
        alert("Por favor, preencha a Data de Entrega");
        return;
      }
      if (formData.variants.length === 0 || formData.variants.some(v => !v.size || !v.color || v.quantity === 0)) {
        alert("Por favor, preencha todas as variações com tamanho, cor e quantidade");
        return;
      }
      createMutation.mutate(formData);
    } else {
      // Ao editar, permite deixar campos em branco
      updateMutation.mutate({ productionId: editingProductionId, data: formData });
    }
  };

  const addVariant = () => {
    setFormData({
      ...formData,
      variants: [...formData.variants, { size: "", color: "", quantity: 0 }],
    });
  };

  const removeVariant = (index: number) => {
    setFormData({
      ...formData,
      variants: formData.variants.filter((_, i) => i !== index),
    });
  };

  const updateVariant = (index: number, field: keyof Variant, value: any) => {
    const newVariants = [...formData.variants];
    newVariants[index] = { ...newVariants[index], [field]: value };
    setFormData({ ...formData, variants: newVariants });
  };

  const handleOcrUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    
    setIsOcrLoading(true);
    
    try {
      const reader = new FileReader();
      reader.onload = async (event) => {
        try {
          const base64 = (event.target?.result as string)?.split(',')[1];
          if (!base64) {
            throw new Error("Erro ao ler arquivo");
          }
          
          const response = await apiRequest("POST", "/api/ocr/parse-variations", {
            imageBase64: base64,
            mimeType: file.type,
          });
          
          const data = await response.json();
          
          if (data.error) {
            throw new Error(data.error);
          }
          
          if (data.variations && data.variations.length > 0) {
            const newVariants = data.variations.map((v: any) => ({
              size: v.size || "",
              color: v.color || "",
              quantity: parseInt(v.quantity) || 0,
            }));
            
            setFormData(prev => ({
              ...prev,
              variants: newVariants,
            }));
            
            toast({
              title: "Variações importadas",
              description: `${newVariants.length} variações foram extraídas da imagem.`,
            });
          } else {
            toast({
              title: "Nenhuma variação encontrada",
              description: "Não foi possível extrair variações da imagem. Tente com uma imagem mais clara.",
              variant: "destructive",
            });
          }
        } catch (error: any) {
          console.error("OCR error:", error);
          toast({
            title: "Erro ao processar imagem",
            description: error?.message || "Não foi possível ler a imagem. Tente novamente.",
            variant: "destructive",
          });
        } finally {
          setIsOcrLoading(false);
        }
      };
      
      reader.onerror = () => {
        setIsOcrLoading(false);
        toast({
          title: "Erro ao ler arquivo",
          description: "Não foi possível ler o arquivo selecionado.",
          variant: "destructive",
        });
      };
      
      reader.readAsDataURL(file);
    } catch (error: any) {
      setIsOcrLoading(false);
      toast({
        title: "Erro",
        description: error?.message || "Erro desconhecido",
        variant: "destructive",
      });
    }
    
    if (e.target) {
      e.target.value = "";
    }
  };

  if (isLoading) {
    return <div className="p-8">Carregando produções...</div>;
  }

  const statusLabels2: Record<string, string> = {
    em_separacao: "Em Separação",
    para_entrega: "Para Entrega",
    em_producao: "Em Produção",
    para_recolha: "Para Recolha",
    concluido: "Concluído",
  };

  // Calcula a quantidade disponível para cada produção (usa valores do backend)
  const getAvailableQuantity = (prod: any) => {
    // Prioridade: usar availableQuantity calculado pelo backend
    if (typeof prod.availableQuantity === 'number') {
      return prod.availableQuantity;
    }
    // Fallback: calcular a partir das variantes
    if (!prod.variants || prod.variants.length === 0) return 0;
    return prod.variants.reduce((sum: number, v: any) => sum + (v.availableQuantity || 0), 0);
  };

  // Calcula a quantidade TOTAL de uma produção (soma de todas as variantes)
  const getTotalQuantity = (prod: any) => {
    // Prioridade 1: soma de variantes
    if (prod.variants && prod.variants.length > 0) {
      const variantSum = prod.variants.reduce((sum: number, v: any) => sum + v.quantity, 0);
      // Se variantes existem MAS soma é 0, usar production.quantity como fallback
      if (variantSum > 0) {
        return variantSum;
      }
    }
    // Prioridade 2: production.quantity se for > 0
    if (prod.quantity && prod.quantity > 0) {
      return prod.quantity;
    }
    // Fallback: usar 0 se nada funcionar
    return 0;
  };

  // Classifica produção na aba correta - usa status salvo se disponível
  const classifyProduction = (prod: any): string => {
    // Se o status foi definido manualmente, usar esse
    if (prod.status && kanbanStatuses.includes(prod.status)) {
      return prod.status;
    }
    
    // Caso contrário, classificar automaticamente
    const availableQty = getAvailableQuantity(prod);
    const prodBatches = Array.isArray(allBatches) ? allBatches.filter((b: any) => b.productionId === prod.id) : [];
    
    // Se tem peças disponíveis, fica em "Em Separação"
    if (availableQty > 0) {
      return "em_separacao";
    }
    
    // Se não tem peças disponíveis mas tem lotes
    if (prodBatches.length === 0) {
      return "para_entrega";
    }
    
    // Verifica status de todos os lotes
    const allConcluido = prodBatches.every((b: any) => b.status === "concluido");
    if (allConcluido) {
      return "concluido";
    }
    
    const allParaRecolha = prodBatches.every((b: any) => b.status === "para_recolha");
    if (allParaRecolha) {
      return "para_recolha";
    }
    
    const allEmProducao = prodBatches.every((b: any) => b.status === "em_producao");
    if (allEmProducao) {
      return "em_producao";
    }
    
    // Default: "Para Entrega" quando não tem peças e lotes estão em estados variados
    return "para_entrega";
  };

  // Kanban view com 5 abas
  const kanbanStatuses = ["em_separacao", "para_entrega", "em_producao", "para_recolha", "concluido"];
  const productionsByStatus = kanbanStatuses.map(status => ({
    status,
    productions: ((productions as any[]) || []).filter((p: any) => {
      const status_ = classifyProduction(p);
      // Mostrar todas as produções que pertencem a este status
      return status_ === status;
    }),
  }));

  // Calcula o lucro esperado: (Quantidade TOTAL x Preço Unitário) - (Quantidade em Lotes x Preço do Lote)
  const getExpectedProfit = (prod: any, batchesCost: number) => {
    const safeParseFloat = (value: any): number => {
      const parsed = parseFloat(value || 0);
      return isNaN(parsed) ? 0 : parsed;
    };
    const totalQty = getTotalQuantity(prod);
    const totalRevenue = totalQty * safeParseFloat(prod.pricePerUnit);
    return totalRevenue - batchesCost;
  };

  return (
    <div className="p-8 space-y-8">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-semibold">Produções</h1>
        <Dialog open={isOpen} onOpenChange={(open) => {
          setIsOpen(open);
          if (!open) resetForm();
        }}>
          <DialogTrigger asChild>
            <Button className="gap-2" data-testid="button-create-production">
              <Plus className="w-4 h-4" />
              Nova Produção
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>{editingProductionId ? "Editar Produção" : "Registrar Nova Produção"}</DialogTitle>
            </DialogHeader>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="supplier">Fornecedor *</Label>
                  <Select
                    value={formData.supplier}
                    onValueChange={(value) => setFormData({ ...formData, supplier: value })}
                  >
                    <SelectTrigger data-testid="select-production-supplier">
                      <SelectValue placeholder="Selecione o fornecedor" />
                    </SelectTrigger>
                    <SelectContent>
                      {suppliers.map((s: any) => (
                        <SelectItem key={s.id} value={s.name}>{s.name}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="productName">Nome da Produção (Model) *</Label>
                  <Input
                    id="productName"
                    value={formData.productName}
                    onChange={(e) => setFormData({ ...formData, productName: e.target.value })}
                    placeholder="Ex: Camiseta Verão 2024"
                    required
                    data-testid="input-production-name"
                  />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="price">Preço por Unidade (R$) *</Label>
                  <Input
                    id="price"
                    type="number"
                    step="0.01"
                    value={formData.pricePerUnit}
                    onChange={(e) => setFormData({ ...formData, pricePerUnit: parseFloat(e.target.value) })}
                    required
                    data-testid="input-production-price"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="date">Data de Recebimento *</Label>
                  <Input
                    id="date"
                    type="date"
                    value={formData.date}
                    onChange={(e) => setFormData({ ...formData, date: e.target.value })}
                    required
                    data-testid="input-production-date"
                  />
                </div>
                <div>
                  <Label htmlFor="deliveryDate">Data de Entrega *</Label>
                  <Input
                    id="deliveryDate"
                    type="date"
                    value={formData.deliveryDate}
                    onChange={(e) => setFormData({ ...formData, deliveryDate: e.target.value })}
                    required
                    data-testid="input-production-delivery-date"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="paymentStatus">Status de Pagamento *</Label>
                  <select
                    id="paymentStatus"
                    value={formData.paymentStatus}
                    onChange={(e) => setFormData({ ...formData, paymentStatus: e.target.value as "Pendente" | "Recebido" })}
                    required
                    data-testid="select-payment-status"
                    className="w-full px-3 py-2 border rounded-md border-input bg-background text-sm"
                  >
                    <option value="Pendente">Pendente</option>
                    <option value="Recebido">Recebido</option>
                  </select>
                </div>
                <div>
                  <Label htmlFor="expectedPaymentDate">Data de Recebimento Esperado *</Label>
                  <Input
                    id="expectedPaymentDate"
                    type="date"
                    value={formData.expectedPaymentDate}
                    onChange={(e) => setFormData({ ...formData, expectedPaymentDate: e.target.value })}
                    required
                    data-testid="input-expected-payment-date"
                  />
                </div>
              </div>

              <div className="bg-muted/50 p-4 rounded-lg">
                <div className="flex items-center justify-between mb-4 gap-2 flex-wrap">
                  <h3 className="font-semibold">Variações (Tamanho, Cor, Quantidade) *</h3>
                  <div className="flex gap-2">
                    <label>
                      <input
                        type="file"
                        accept="image/*,application/pdf"
                        onChange={handleOcrUpload}
                        style={{ display: "none" }}
                        disabled={isOcrLoading}
                      />
                      <Button
                        type="button"
                        variant="outline"
                        size="sm"
                        asChild
                        className="gap-1 cursor-pointer"
                        data-testid="button-ocr-upload"
                      >
                        <span>
                          {isOcrLoading ? (
                            <Loader2 className="w-3 h-3 animate-spin" />
                          ) : (
                            <Camera className="w-3 h-3" />
                          )}
                          {isOcrLoading ? "Processando..." : "Enviar Foto"}
                        </span>
                      </Button>
                    </label>
                    <Button
                      type="button"
                      variant="outline"
                      size="sm"
                      onClick={addVariant}
                      className="gap-1"
                      data-testid="button-add-variant"
                    >
                      <Plus className="w-3 h-3" />
                      Adicionar
                    </Button>
                  </div>
                </div>

                <div className="space-y-3">
                  {formData.variants.map((variant, index) => (
                    <div key={index} className="grid grid-cols-4 gap-2 items-end bg-white p-3 rounded border">
                      <div>
                        <Label className="text-xs">Tamanho</Label>
                        <Input
                          placeholder="P, M, G..."
                          value={variant.size}
                          onChange={(e) => updateVariant(index, "size", e.target.value)}
                          required
                          data-testid={`input-variant-size-${index}`}
                        />
                      </div>
                      <div>
                        <Label className="text-xs">Cor</Label>
                        <Input
                          placeholder="Azul, Vermelho..."
                          value={variant.color}
                          onChange={(e) => updateVariant(index, "color", e.target.value)}
                          required
                          data-testid={`input-variant-color-${index}`}
                        />
                      </div>
                      <div>
                        <Label className="text-xs">Quantidade</Label>
                        <Input
                          type="number"
                          placeholder="0"
                          value={variant.quantity}
                          onChange={(e) => updateVariant(index, "quantity", parseInt(e.target.value) || 0)}
                          required
                          data-testid={`input-variant-quantity-${index}`}
                        />
                      </div>
                      <Button
                        type="button"
                        variant="ghost"
                        size="icon"
                        onClick={() => removeVariant(index)}
                        data-testid={`button-remove-variant-${index}`}
                      >
                        <Trash2 className="w-4 h-4 text-destructive" />
                      </Button>
                    </div>
                  ))}
                </div>
              </div>

              <Button 
                type="submit" 
                className="w-full" 
                data-testid="button-submit-production"
                disabled={createMutation.isPending || updateMutation.isPending}
              >
                {createMutation.isPending || updateMutation.isPending ? (
                  <Loader2 className="w-4 h-4 animate-spin mr-2" />
                ) : null}
                {editingProductionId ? "Atualizar Produção" : "Criar Produção"}
              </Button>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      {/* Kanban Board */}
      <div className="w-full">
        <div className="grid grid-cols-5 gap-3">
          {((productionsByStatus || []) as any[]).map((column) => (
            <div key={column.status} className="min-w-0">
              <div className="bg-muted/50 rounded-lg p-4">
                <h3 className="font-semibold mb-4 text-sm uppercase">{statusLabels2[column.status]} ({column.productions.length})</h3>
                <div className="space-y-3">
                  {column.productions.length > 0 ? column.productions.map((prod: any) => {
                    const availableQty = getAvailableQuantity(prod);
                    return (
                      <div key={prod.id}>
                        {column.status === "em_separacao" && availableQty > 0 && (
                          <div className="mb-2 p-2 bg-amber-100 dark:bg-amber-900 rounded border border-amber-200 dark:border-amber-800">
                            <p className="text-xs font-semibold text-amber-900 dark:text-amber-100">
                              Disponível: {availableQty} un.
                            </p>
                          </div>
                        )}
                        <ProductionCard key={prod.id} production={prod} onEdit={handleEditProduction} onDelete={handleDeleteProduction} getAvailableQuantity={getAvailableQuantity} getExpectedProfit={getExpectedProfit} onStatusChange={handleStatusChange} isLoading={statusMutation.isPending} isExpanded={expandedProductions.has(prod.id)} onToggleExpanded={toggleExpandedProduction} onPaymentReceived={handlePaymentReceived} />
                      </div>
                    );
                  }) : (
                    <p className="text-xs text-muted-foreground text-center py-4">Nenhuma produção</p>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default Productions;
