import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { apiRequest } from "@/lib/queryClient";
import { queryClient } from "@/lib/queryClient";
import { Plus, Trash2 } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

const ExtraCosts = () => {
  const { toast } = useToast();
  const [isOpen, setIsOpen] = useState(false);
  const [formData, setFormData] = useState({
    description: "",
    amount: 0,
    category: "Geral",
    date: new Date().toISOString().split("T")[0],
    notes: "",
  });

  const { data: costs = [], isLoading } = useQuery<any[]>({
    queryKey: ["/api/extra-costs"],
  });

  const createMutation = useMutation({
    mutationFn: async (data: any) => {
      const res = await apiRequest("POST", "/api/extra-costs", {
        ...data,
        date: new Date(data.date),
      });
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/extra-costs"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard"] });
      setIsOpen(false);
      resetForm();
      toast({ title: "Sucesso", description: "Custo extra registrado!" });
    },
    onError: (error: any) => {
      toast({ title: "Erro ao salvar custo extra", description: error.message, variant: "destructive" });
    },
  });

  const deleteMutation = useMutation({
    mutationFn: async (id: string) => {
      await apiRequest("DELETE", `/api/extra-costs/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/extra-costs"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard"] });
      toast({ title: "Sucesso", description: "Custo extra excluído!" });
    },
    onError: (error: any) => {
      toast({ title: "Erro ao excluir custo extra", description: error.message, variant: "destructive" });
    },
  });

  const resetForm = () => {
    setFormData({
      description: "",
      amount: 0,
      category: "Geral",
      date: new Date().toISOString().split("T")[0],
      notes: "",
    });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.description.trim()) {
      alert("Por favor, preencha a descrição");
      return;
    }
    if (!formData.amount || formData.amount <= 0) {
      alert("Por favor, preencha o valor com um número maior que 0");
      return;
    }
    createMutation.mutate(formData);
  };

  const totalCosts = costs.reduce((sum: number, cost: any) => sum + parseFloat(cost.amount.toString()), 0);

  if (isLoading) {
    return <div className="p-8">Carregando custos extras...</div>;
  }

  return (
    <div className="p-8 space-y-8">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-semibold">Custos Extras</h1>
        <Dialog open={isOpen} onOpenChange={(open) => {
          setIsOpen(open);
          if (!open) resetForm();
        }}>
          <DialogTrigger asChild>
            <Button className="gap-2" data-testid="button-create-extra-cost">
              <Plus className="w-4 h-4" />
              Adicionar Custo
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-md">
            <DialogHeader>
              <DialogTitle>Adicionar Novo Custo Extra</DialogTitle>
            </DialogHeader>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <Label htmlFor="description">Descrição *</Label>
                <Input
                  id="description"
                  value={formData.description}
                  onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                  placeholder="Ex: Aluguel, Utilitários, Matéria Prima Extra"
                  required
                  data-testid="input-extra-cost-description"
                />
              </div>
              <div>
                <Label htmlFor="amount">Valor (R$) *</Label>
                <Input
                  id="amount"
                  type="number"
                  step="0.01"
                  value={formData.amount}
                  onChange={(e) => setFormData({ ...formData, amount: parseFloat(e.target.value) })}
                  required
                  data-testid="input-extra-cost-amount"
                />
              </div>
              <div>
                <Label htmlFor="category">Categoria</Label>
                <select
                  id="category"
                  value={formData.category}
                  onChange={(e) => setFormData({ ...formData, category: e.target.value })}
                  data-testid="select-extra-cost-category"
                  className="w-full px-3 py-2 border rounded-md border-input bg-background text-sm"
                >
                  <option value="Geral">Geral</option>
                  <option value="Aluguel">Aluguel</option>
                  <option value="Utilitários">Utilitários</option>
                  <option value="Matéria Prima">Matéria Prima</option>
                  <option value="Transporte">Transporte</option>
                  <option value="Manutenção">Manutenção</option>
                </select>
              </div>
              <div>
                <Label htmlFor="date">Data *</Label>
                <Input
                  id="date"
                  type="date"
                  value={formData.date}
                  onChange={(e) => setFormData({ ...formData, date: e.target.value })}
                  required
                  data-testid="input-extra-cost-date"
                />
              </div>
              <div>
                <Label htmlFor="notes">Observações</Label>
                <Input
                  id="notes"
                  value={formData.notes}
                  onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                  placeholder="Informações adicionais (opcional)"
                  data-testid="input-extra-cost-notes"
                />
              </div>
              <Button type="submit" className="w-full" data-testid="button-submit-extra-cost">
                Adicionar Custo
              </Button>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      {/* Summary Card */}
      <Card className="p-6 bg-blue-50 dark:bg-blue-950 border-blue-200 dark:border-blue-800">
        <p className="text-sm font-medium text-muted-foreground">Total de Custos Extras</p>
        <p className="text-4xl font-bold mt-2 text-blue-600 dark:text-blue-400">R$ {totalCosts.toFixed(2)}</p>
      </Card>

      {/* Costs List */}
      <div className="grid gap-4">
        {costs.length === 0 ? (
          <Card className="p-8 text-center">
            <p className="text-muted-foreground">Nenhum custo extra registrado</p>
          </Card>
        ) : (
          costs.map((cost: any) => (
            <Card key={cost.id} className="p-4" data-testid={`card-extra-cost-${cost.id}`}>
              <div className="flex items-start justify-between">
                <div className="flex-1">
                  <p className="font-semibold">{cost.description}</p>
                  <p className="text-sm text-muted-foreground mt-1">
                    {new Date(cost.date).toLocaleDateString("pt-BR")} • {cost.category}
                  </p>
                  {cost.notes && <p className="text-sm mt-2">{cost.notes}</p>}
                </div>
                <div className="text-right">
                  <p className="text-2xl font-bold text-red-600">R$ {parseFloat(cost.amount.toString()).toFixed(2)}</p>
                  <Button
                    size="icon"
                    variant="ghost"
                    onClick={() => deleteMutation.mutate(cost.id)}
                    data-testid={`button-delete-extra-cost-${cost.id}`}
                    className="mt-2"
                  >
                    <Trash2 className="w-4 h-4 text-destructive" />
                  </Button>
                </div>
              </div>
            </Card>
          ))
        )}
      </div>
    </div>
  );
};

export default ExtraCosts;
