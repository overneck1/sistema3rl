import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { apiRequest } from "@/lib/queryClient";
import { queryClient } from "@/lib/queryClient";
import { Plus, Trash2, Edit2, Search, Building2, Phone, Mail, MapPin, Package, Printer } from "lucide-react";
import type { Supplier } from "@shared/schema";
import { Badge } from "@/components/ui/badge";
import { PrintFormatDialog, PrintFormat, getCupomBaseStyles, printContent as printHtml } from "@/components/print-format-dialog";

const Suppliers = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState("");
  const [formData, setFormData] = useState({
    name: "",
    phone: "",
    email: "",
    address: "",
    notes: "",
  });
  
  // Print format dialog state
  const [printFormatDialogOpen, setPrintFormatDialogOpen] = useState(false);
  const [pendingPrintSupplier, setPendingPrintSupplier] = useState<Supplier | null>(null);

  const { data: suppliers = [], isLoading } = useQuery<Supplier[]>({
    queryKey: ["/api/suppliers"],
  });

  const { data: productions = [] } = useQuery<any[]>({
    queryKey: ["/api/productions"],
  });

  const getSupplierProductions = (supplierName: string) => {
    return productions.filter((p) => 
      p.supplier && p.supplier.toLowerCase() === supplierName.toLowerCase()
    );
  };

  const createMutation = useMutation({
    mutationFn: async (data: any) => {
      const res = await apiRequest("POST", "/api/suppliers", data);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/suppliers"] });
      setIsOpen(false);
      resetForm();
    },
  });

  const updateMutation = useMutation({
    mutationFn: async (data: any) => {
      const res = await apiRequest("PATCH", `/api/suppliers/${editingId}`, data);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/suppliers"] });
      setIsOpen(false);
      setEditingId(null);
      resetForm();
    },
  });

  const deleteMutation = useMutation({
    mutationFn: async (id: string) => {
      const res = await apiRequest("DELETE", `/api/suppliers/${id}`);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/suppliers"] });
    },
  });

  const resetForm = () => {
    setFormData({
      name: "",
      phone: "",
      email: "",
      address: "",
      notes: "",
    });
    setEditingId(null);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (editingId) {
      updateMutation.mutate(formData);
    } else {
      createMutation.mutate(formData);
    }
  };

  const handleEditClick = (supplier: Supplier) => {
    setEditingId(supplier.id);
    setFormData({
      name: supplier.name,
      phone: supplier.phone || "",
      email: supplier.email || "",
      address: supplier.address || "",
      notes: supplier.notes || "",
    });
    setIsOpen(true);
  };

  const handleDeleteClick = (id: string) => {
    if (confirm("Tem certeza que deseja deletar este fornecedor?")) {
      deleteMutation.mutate(id);
    }
  };

  // Print format dialog functions
  const openPrintSupplierDialog = (supplier: Supplier) => {
    setPendingPrintSupplier(supplier);
    setPrintFormatDialogOpen(true);
  };

  const handlePrintFormatSelect = (format: PrintFormat) => {
    setPrintFormatDialogOpen(false);
    if (!pendingPrintSupplier) return;
    handlePrintSupplier(pendingPrintSupplier, format);
    setPendingPrintSupplier(null);
  };

  const handlePrintSupplier = (supplier: Supplier, format: PrintFormat = 'a4') => {
    const supplierProductions = getSupplierProductions(supplier.name);
    
    const printContent = `
      <!DOCTYPE html>
      <html lang="pt-BR">
      <head>
        <meta charset="UTF-8">
        <title>Fornecedor - ${supplier.name}</title>
        <style>
          * { margin: 0; padding: 0; box-sizing: border-box; }
          body { font-family: 'Segoe UI', sans-serif; padding: 20px; line-height: 1.5; }
          .header { text-align: center; border-bottom: 3px solid #8B5CF6; padding-bottom: 15px; margin-bottom: 20px; }
          .header h1 { font-size: 24px; color: #1F2937; }
          .info-section { margin-bottom: 20px; }
          .info-section h3 { font-size: 14px; font-weight: 600; color: #6B7280; margin-bottom: 8px; border-bottom: 1px solid #E5E7EB; padding-bottom: 4px; }
          .info-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 10px; }
          .info-item { background: #F9FAFB; padding: 10px; border-radius: 6px; }
          .info-item .label { font-size: 11px; color: #6B7280; text-transform: uppercase; }
          .info-item .value { font-size: 14px; color: #1F2937; font-weight: 500; }
          table { width: 100%; border-collapse: collapse; margin-top: 10px; }
          table th { background: #8B5CF6; color: white; padding: 8px; text-align: left; font-size: 12px; }
          table td { padding: 8px; border-bottom: 1px solid #E5E7EB; font-size: 12px; }
          table tr:nth-child(even) { background: #F9FAFB; }
          .footer { margin-top: 30px; text-align: center; font-size: 11px; color: #9CA3AF; border-top: 1px solid #E5E7EB; padding-top: 10px; }
          .no-productions { text-align: center; color: #6B7280; padding: 20px; }
          @media print { body { padding: 10mm; } }
        </style>
      </head>
      <body>
        <div class="header">
          <h1>${supplier.name}</h1>
        </div>
        
        <div class="info-section">
          <h3>Informações do Fornecedor</h3>
          <div class="info-grid">
            ${supplier.phone ? `<div class="info-item"><div class="label">Telefone</div><div class="value">${supplier.phone}</div></div>` : ''}
            ${supplier.email ? `<div class="info-item"><div class="label">Email</div><div class="value">${supplier.email}</div></div>` : ''}
            ${supplier.address ? `<div class="info-item"><div class="label">Endereço</div><div class="value">${supplier.address}</div></div>` : ''}
          </div>
          ${supplier.notes ? `<div class="info-item" style="margin-top: 10px;"><div class="label">Observações</div><div class="value">${supplier.notes}</div></div>` : ''}
        </div>

        <div class="info-section">
          <h3>Produções (${supplierProductions.length})</h3>
          ${supplierProductions.length > 0 ? `
            <table>
              <thead>
                <tr>
                  <th>Código</th>
                  <th>Produto</th>
                  <th>Quantidade</th>
                  <th>Preço/Un</th>
                  <th>Status</th>
                  <th>Entrega</th>
                </tr>
              </thead>
              <tbody>
                ${supplierProductions.map((p: any) => `
                  <tr>
                    <td>${p.productionCode}</td>
                    <td>${p.productName || 'Sem nome'}</td>
                    <td>${p.quantity || 0} un</td>
                    <td>R$ ${parseFloat(p.pricePerUnit || 0).toFixed(2)}</td>
                    <td>${p.status || '-'}</td>
                    <td>${p.deliveryDate ? new Date(p.deliveryDate).toLocaleDateString('pt-BR') : '-'}</td>
                  </tr>
                `).join('')}
              </tbody>
            </table>
          ` : '<div class="no-productions">Nenhuma produção registrada</div>'}
        </div>

        <div class="footer">
          Impresso em: ${new Date().toLocaleString('pt-BR')}
        </div>
      </body>
      </html>
    `;

    let content = '';
    if (format === 'cupom') {
      let productionLines = '';
      supplierProductions.forEach((p: any) => {
        productionLines += `
          <div class="item">
            <div class="item-row"><span>${p.productName?.substring(0, 15) || 'N/A'}</span><span>${p.quantity || 0}un</span></div>
            <div class="item-row"><span>${p.productionCode}</span><span>R$${parseFloat(p.pricePerUnit || 0).toFixed(2)}</span></div>
          </div>
        `;
      });

      content = `<!DOCTYPE html><html lang="pt-BR"><head><meta charset="UTF-8">
        <title>Fornecedor - ${supplier.name}</title>
        <style>${getCupomBaseStyles()}</style>
      </head><body>
        <div class="cupom">
          <div class="header">GOFAST PRODUCOES</div>
          <div class="title">FORNECEDOR</div>
          <div class="divider"></div>
          <div class="info">${supplier.name}</div>
          ${supplier.phone ? `<div class="info">Tel: ${supplier.phone}</div>` : ''}
          ${supplier.email ? `<div class="info">${supplier.email.substring(0, 25)}</div>` : ''}
          ${supplier.address ? `<div class="info">${supplier.address.substring(0, 25)}</div>` : ''}
          <div class="divider"></div>
          <div class="total">Prods: ${supplierProductions.length}</div>
          ${productionLines}
          <div class="divider"></div>
          <div class="footer">${new Date().toLocaleString('pt-BR')}</div>
        </div>
      </body></html>`;
    } else {
      content = printContent;
    }
    
    printHtml(content);
  };

  const filteredSuppliers = suppliers.filter((supplier) =>
    supplier.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    (supplier.email && supplier.email.toLowerCase().includes(searchQuery.toLowerCase())) ||
    (supplier.phone && supplier.phone.includes(searchQuery))
  );

  if (isLoading) {
    return (
      <div className="p-6 flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
      </div>
    );
  }

  return (
    <div className="p-6 space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <h1 className="text-2xl font-bold" data-testid="text-page-title">Fornecedores</h1>
        <Button
          onClick={() => {
            resetForm();
            setIsOpen(true);
          }}
          data-testid="button-add-supplier"
        >
          <Plus className="w-4 h-4 mr-2" />
          Novo Fornecedor
        </Button>
      </div>

      <div className="relative max-w-md">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
        <Input
          placeholder="Buscar por nome, email ou telefone..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className="pl-10"
          data-testid="input-search-suppliers"
        />
      </div>

      {filteredSuppliers.length === 0 ? (
        <Card>
          <CardContent className="p-8 text-center text-muted-foreground">
            <Building2 className="w-12 h-12 mx-auto mb-4 opacity-50" />
            <p>Nenhum fornecedor encontrado.</p>
            {searchQuery && <p className="text-sm mt-2">Tente ajustar sua busca.</p>}
          </CardContent>
        </Card>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredSuppliers.map((supplier) => (
            <Card key={supplier.id} data-testid={`card-supplier-${supplier.id}`}>
              <CardHeader className="pb-2">
                <div className="flex items-start justify-between gap-2">
                  <CardTitle className="text-lg" data-testid={`text-supplier-name-${supplier.id}`}>
                    {supplier.name}
                  </CardTitle>
                  <div className="flex gap-1">
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => openPrintSupplierDialog(supplier)}
                      data-testid={`button-print-supplier-${supplier.id}`}
                    >
                      <Printer className="w-4 h-4" />
                    </Button>
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => handleEditClick(supplier)}
                      data-testid={`button-edit-supplier-${supplier.id}`}
                    >
                      <Edit2 className="w-4 h-4" />
                    </Button>
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => handleDeleteClick(supplier.id)}
                      data-testid={`button-delete-supplier-${supplier.id}`}
                    >
                      <Trash2 className="w-4 h-4 text-destructive" />
                    </Button>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="space-y-2">
                {supplier.phone && (
                  <div className="flex items-center gap-2 text-sm text-muted-foreground">
                    <Phone className="w-4 h-4" />
                    <span data-testid={`text-supplier-phone-${supplier.id}`}>{supplier.phone}</span>
                  </div>
                )}
                {supplier.email && (
                  <div className="flex items-center gap-2 text-sm text-muted-foreground">
                    <Mail className="w-4 h-4" />
                    <span data-testid={`text-supplier-email-${supplier.id}`}>{supplier.email}</span>
                  </div>
                )}
                {supplier.address && (
                  <div className="flex items-center gap-2 text-sm text-muted-foreground">
                    <MapPin className="w-4 h-4" />
                    <span data-testid={`text-supplier-address-${supplier.id}`}>{supplier.address}</span>
                  </div>
                )}
                {supplier.notes && (
                  <p className="text-sm text-muted-foreground mt-2 pt-2 border-t" data-testid={`text-supplier-notes-${supplier.id}`}>
                    {supplier.notes}
                  </p>
                )}
                {(() => {
                  const supplierProductions = getSupplierProductions(supplier.name);
                  if (supplierProductions.length > 0) {
                    return (
                      <div className="mt-3 pt-3 border-t">
                        <div className="flex items-center gap-2 mb-2">
                          <Package className="w-4 h-4 text-primary" />
                          <span className="text-sm font-medium">Produções ({supplierProductions.length})</span>
                        </div>
                        <div className="space-y-2">
                          {supplierProductions.map((prod: any) => (
                            <div key={prod.id} className="text-sm p-2 rounded bg-muted/50" data-testid={`production-${prod.id}`}>
                              <div className="flex items-center justify-between gap-2">
                                <span className="font-medium truncate">{prod.productName || "Sem nome"}</span>
                                <Badge variant="outline" className="text-xs shrink-0">
                                  {prod.quantity || 0} un
                                </Badge>
                              </div>
                              <div className="text-xs text-muted-foreground mt-1">
                                {prod.productionCode} • R$ {parseFloat(prod.pricePerUnit || 0).toFixed(2)}/un
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>
                    );
                  }
                  return null;
                })()}
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      <Dialog open={isOpen} onOpenChange={(open) => {
        setIsOpen(open);
        if (!open) resetForm();
      }}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle data-testid="text-dialog-title">
              {editingId ? "Editar Fornecedor" : "Novo Fornecedor"}
            </DialogTitle>
          </DialogHeader>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="name">Nome *</Label>
              <Input
                id="name"
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                required
                placeholder="Nome do fornecedor"
                data-testid="input-supplier-name"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="phone">Telefone</Label>
              <Input
                id="phone"
                value={formData.phone}
                onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                placeholder="(00) 00000-0000"
                data-testid="input-supplier-phone"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="email">Email</Label>
              <Input
                id="email"
                type="email"
                value={formData.email}
                onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                placeholder="email@exemplo.com"
                data-testid="input-supplier-email"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="address">Endereço</Label>
              <Input
                id="address"
                value={formData.address}
                onChange={(e) => setFormData({ ...formData, address: e.target.value })}
                placeholder="Endereço completo"
                data-testid="input-supplier-address"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="notes">Observações</Label>
              <Textarea
                id="notes"
                value={formData.notes}
                onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                placeholder="Observações sobre o fornecedor..."
                data-testid="input-supplier-notes"
              />
            </div>
            <div className="flex gap-2 justify-end">
              <Button
                type="button"
                variant="outline"
                onClick={() => {
                  setIsOpen(false);
                  resetForm();
                }}
                data-testid="button-cancel-supplier"
              >
                Cancelar
              </Button>
              <Button
                type="submit"
                disabled={createMutation.isPending || updateMutation.isPending}
                data-testid="button-save-supplier"
              >
                {createMutation.isPending || updateMutation.isPending ? "Salvando..." : "Salvar"}
              </Button>
            </div>
          </form>
        </DialogContent>
      </Dialog>

      <PrintFormatDialog
        open={printFormatDialogOpen}
        onOpenChange={setPrintFormatDialogOpen}
        onSelectFormat={handlePrintFormatSelect}
      />
    </div>
  );
};

export default Suppliers;
