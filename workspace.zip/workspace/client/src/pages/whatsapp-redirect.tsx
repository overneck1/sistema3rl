import { useEffect } from "react";
import { useLocation } from "wouter";

const WhatsAppRedirect = () => {
  const [, navigate] = useLocation();

  useEffect(() => {
    // Extract phone from URL query parameters
    const params = new URLSearchParams(window.location.search);
    const phone = params.get("phone");

    if (phone) {
      // Format phone number if needed and redirect to WhatsApp
      const whatsappUrl = `https://wa.me/${phone.replace(/[^0-9]/g, "")}`;
      window.location.href = whatsappUrl;
    } else {
      // If no phone parameter, redirect back to seamstresses page
      setTimeout(() => navigate("/seamstresses"), 1000);
    }
  }, [navigate]);

  return (
    <div className="flex items-center justify-center h-screen bg-background">
      <div className="text-center space-y-4">
        <div className="w-12 h-12 rounded-full border-4 border-primary border-t-transparent animate-spin mx-auto" />
        <p className="text-foreground font-semibold">Abrindo WhatsApp...</p>
      </div>
    </div>
  );
};

export default WhatsAppRedirect;
