import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { DollarSign, ChevronDown, ChevronUp, AlertCircle, Printer, CheckCircle, FileText, TrendingUp } from "lucide-react";
import { useState } from "react";
import { useToast } from "@/hooks/use-toast";
import { format, isPast, isToday } from "date-fns";
import { PrintFormatDialog, PrintFormat, getCupomBaseStyles, printContent as printHtml } from "@/components/print-format-dialog";

interface Seamstress {
  id: string;
  name: string;
  phone: string;
  address: string;
}

interface Payment {
  id: string;
  seamstressId: string;
  batchId: string;
  amount: string;
  status: "pending" | "paid" | "overdue";
  dueDate?: string;
  paidDate?: string;
  createdAt: string;
}

interface Batch {
  id: string;
  seamstressId: string;
  productionId: string;
  status: string;
  batchCode: string;
}

interface Production {
  id: string;
  supplier: string;
  productName: string;
  paymentStatus?: string;
}

interface ExtraCost {
  id: string;
  description: string;
  amount: string;
  category: string;
  date: string;
  status: "pending" | "paid";
}

const Financeiro = () => {
  const { toast } = useToast();
  const [expandedSeamstress, setExpandedSeamstress] = useState<string | null>(null);
  const [expandedExtraCost, setExpandedExtraCost] = useState<string | null>(null);
  const [filterPaymentStatus, setFilterPaymentStatus] = useState("pendente");
  const [filterSupplier, setFilterSupplier] = useState<string>("todos");
  
  // Print format dialog state
  const [printFormatDialogOpen, setPrintFormatDialogOpen] = useState(false);
  const [pendingPrintAction, setPendingPrintAction] = useState<{
    type: 'allPayments' | 'singlePayment' | 'allExtraCosts' | 'singleExtraCost';
    data?: any;
  } | null>(null);

  // Queries
  const { data: seamstresses = [] } = useQuery({
    queryKey: ["/api/seamstresses"],
  }) as { data: Seamstress[] };

  const { data: payments = [] } = useQuery({
    queryKey: ["/api/tenant/payments"],
  }) as { data: Payment[] };

  const { data: batches = [] } = useQuery({
    queryKey: ["/api/tenant/batches"],
  }) as { data: Batch[] };

  const { data: productions = [] } = useQuery({
    queryKey: ["/api/productions"],
  }) as { data: Production[] };

  const { data: extraCosts = [] } = useQuery({
    queryKey: ["/api/extra-costs"],
  }) as { data: ExtraCost[] };

  // Get unique suppliers from productions
  const uniqueSuppliers = Array.from(new Set(productions.map(p => p.supplier).filter(Boolean))).sort();

  // Helper to get supplier from payment
  const getSupplierForPayment = (payment: Payment): string | null => {
    const batch = batches.find((b: Batch) => b.id === payment.batchId);
    if (!batch) return null;
    const production = productions.find((p: Production) => p.id === batch.productionId);
    return production?.supplier || null;
  };

  // Helper to check if production is paid
  const isProductionPaid = (payment: Payment): boolean => {
    const batch = batches.find((b: Batch) => b.id === payment.batchId);
    if (!batch) return false;
    const production = productions.find((p: Production) => p.id === batch.productionId);
    return production?.paymentStatus === "Pago";
  };

  // Helper functions
  const isPaymentOverdue = (payment: Payment) => {
    if (!payment.dueDate) return false;
    return new Date(payment.dueDate) < new Date() && payment.status !== "paid";
  };

  const getPaymentStatus = (payment: Payment) => {
    if (payment.status === "paid") return "paid";
    if (!payment.dueDate) return payment.status || "pending";
    const dueDate = new Date(payment.dueDate);
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    if (isPast(dueDate) && !isToday(dueDate)) {
      return "overdue";
    }
    return payment.status || "pending";
  };

  const getSeamstressPayments = (seamstressId: string) => {
    let filtered = payments.filter(
      (p: Payment) => p.seamstressId === seamstressId && p.status !== "paid"
    );
    
    // Exclude payments for productions that are marked as paid
    filtered = filtered.filter((p: Payment) => !isProductionPaid(p));
    
    // Filter by supplier
    if (filterSupplier !== "todos") {
      filtered = filtered.filter((p: Payment) => getSupplierForPayment(p) === filterSupplier);
    }
    
    if (filterPaymentStatus === "pendente") {
      filtered = filtered.filter((p: Payment) => !isPaymentOverdue(p));
    } else if (filterPaymentStatus === "atrasados") {
      filtered = filtered.filter((p: Payment) => isPaymentOverdue(p));
    }
    return filtered;
  };

  // Totals
  const totalPaymentsPaid = payments.filter((p: Payment) => p.status === "paid").reduce((sum: number, p: Payment) => sum + parseFloat(p.amount), 0);
  const totalPaymentsPending = payments.filter((p: Payment) => p.status === "pending" && !isPaymentOverdue(p)).reduce((sum: number, p: Payment) => sum + parseFloat(p.amount), 0);
  const totalPaymentsOverdue = payments.filter((p: Payment) => isPaymentOverdue(p)).reduce((sum: number, p: Payment) => sum + parseFloat(p.amount), 0);

  const totalExtraCostsPaid = extraCosts.filter((c: ExtraCost) => c.status === "paid").reduce((sum: number, c: ExtraCost) => sum + parseFloat(c.amount), 0);
  const totalExtraCostsPending = extraCosts.filter((c: ExtraCost) => c.status === "pending").reduce((sum: number, c: ExtraCost) => sum + parseFloat(c.amount), 0);

  // Print format dialog functions
  const openPrintAllPaymentsDialog = () => {
    setPendingPrintAction({ type: 'allPayments' });
    setPrintFormatDialogOpen(true);
  };

  const openPrintSinglePaymentDialog = (payment: Payment, seamstress: Seamstress) => {
    setPendingPrintAction({ type: 'singlePayment', data: { payment, seamstress } });
    setPrintFormatDialogOpen(true);
  };

  const openPrintAllExtraCostsDialog = () => {
    setPendingPrintAction({ type: 'allExtraCosts' });
    setPrintFormatDialogOpen(true);
  };

  const openPrintSingleExtraCostDialog = (cost: ExtraCost) => {
    setPendingPrintAction({ type: 'singleExtraCost', data: cost });
    setPrintFormatDialogOpen(true);
  };

  const handlePrintFormatSelect = (format: PrintFormat) => {
    setPrintFormatDialogOpen(false);
    if (!pendingPrintAction) return;

    switch (pendingPrintAction.type) {
      case 'allPayments':
        handlePrintAllPayments(format);
        break;
      case 'singlePayment':
        handlePrintSinglePayment(pendingPrintAction.data.payment, pendingPrintAction.data.seamstress, format);
        break;
      case 'allExtraCosts':
        handlePrintAllExtraCosts(format);
        break;
      case 'singleExtraCost':
        handlePrintSingleExtraCost(pendingPrintAction.data, format);
        break;
    }
    setPendingPrintAction(null);
  };

  // Print functions
  const handlePrintAllPayments = (format: PrintFormat = 'a4') => {
    let paymentRows = '';
    seamstresses.forEach((seamstress: Seamstress) => {
      const sPayments = payments.filter((p: Payment) => p.seamstressId === seamstress.id);
      sPayments.forEach((payment: Payment) => {
        const batch = batches.find((b: Batch) => b.id === payment.batchId);
        const dueDate = payment.dueDate ? new Date(payment.dueDate).toLocaleDateString('pt-BR') : 'N/A';
        const status = getPaymentStatus(payment);
        const statusLabel = status === "paid" ? "Pago" : status === "overdue" ? "Atrasado" : "Pendente";
        paymentRows += `<tr><td>${seamstress.name}</td><td>${batch?.batchCode || payment.batchId.slice(0, 8)}</td><td>R$ ${parseFloat(payment.amount).toFixed(2)}</td><td>${statusLabel}</td><td>${dueDate}</td></tr>`;
      });
    });

    const printContent = `
      <!DOCTYPE html><html lang="pt-BR"><head>
        <meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Relatório - Pagamentos a Receber</title>
        <style>
          body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background-color: #fff; padding: 20px; }
          .container { max-width: 210mm; margin: 0 auto; }
          .header { text-align: center; margin-bottom: 30px; border-bottom: 3px solid #8B5CF6; padding-bottom: 15px; }
          .header h1 { font-size: 28px; color: #1F2937; margin-bottom: 5px; }
          .header p { font-size: 12px; color: #6B7280; margin-bottom: 10px; }
          .summary { display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 15px; margin-bottom: 30px; }
          .summary-box { border: 1px solid #E5E7EB; padding: 15px; border-radius: 6px; text-align: center; }
          .summary-box.green { background-color: #ECFDF5; border-color: #10B981; }
          .summary-box.red { background-color: #FEF2F2; border-color: #EF4444; }
          .summary-box.orange { background-color: #FEF3C7; border-color: #F59E0B; }
          .summary-box .label { font-size: 12px; color: #6B7280; font-weight: 600; }
          .summary-box .value { font-size: 20px; font-weight: 700; margin-top: 8px; color: #1F2937; }
          .summary-box.green .value { color: #10B981; }
          .summary-box.red .value { color: #EF4444; }
          .summary-box.orange .value { color: #F59E0B; }
          table { width: 100%; border-collapse: collapse; margin-bottom: 20px; }
          table thead { background-color: #8B5CF6; color: white; }
          table th, table td { padding: 10px; text-align: left; font-size: 12px; border-bottom: 1px solid #E5E7EB; }
          .footer { text-align: center; margin-top: 30px; padding-top: 20px; border-top: 1px solid #E5E7EB; font-size: 11px; color: #6B7280; }
        </style>
      </head><body>
        <div class="container">
          <div class="header">
            <h1>Pagamentos a Receber</h1>
            <p>GoFast Produções</p>
            <p>Gerado em: ${new Date().toLocaleDateString('pt-BR')} às ${new Date().toLocaleTimeString('pt-BR')}</p>
          </div>
          <div class="summary">
            <div class="summary-box green"><div class="label">Total Pago</div><div class="value">R$ ${totalPaymentsPaid.toFixed(2)}</div></div>
            <div class="summary-box orange"><div class="label">Total Pendente</div><div class="value">R$ ${totalPaymentsPending.toFixed(2)}</div></div>
            <div class="summary-box red"><div class="label">Total Atrasado</div><div class="value">R$ ${totalPaymentsOverdue.toFixed(2)}</div></div>
          </div>
          <h2 style="margin-bottom: 15px; font-size: 14px; font-weight: 700; color: #1F2937;">Detalhes dos Pagamentos</h2>
          <table><thead><tr><th>Costureira</th><th>Código Lote</th><th>Valor</th><th>Status</th><th>Vencimento</th></tr></thead><tbody>${paymentRows}</tbody></table>
          <div class="footer"><p>Este é um documento gerado automaticamente por GoFast Produções</p></div>
        </div>
      </body></html>
    `;

    let content = '';
    if (format === 'cupom') {
      let paymentLines = '';
      seamstresses.forEach((seamstress: Seamstress) => {
        const sPayments = payments.filter((p: Payment) => p.seamstressId === seamstress.id);
        sPayments.forEach((payment: Payment) => {
          const batch = batches.find((b: Batch) => b.id === payment.batchId);
          const status = getPaymentStatus(payment);
          const statusLabel = status === "paid" ? "Pago" : status === "overdue" ? "Atraso" : "Pend";
          paymentLines += `
            <div class="item">
              <div class="item-row"><span>${seamstress.name.substring(0, 15)}</span><span>${statusLabel}</span></div>
              <div class="item-row"><span>${batch?.batchCode || payment.batchId.slice(0, 8)}</span><span>R$ ${parseFloat(payment.amount).toFixed(2)}</span></div>
            </div>
          `;
        });
      });

      content = `<!DOCTYPE html><html lang="pt-BR"><head><meta charset="UTF-8">
        <title>Pagamentos</title>
        <style>${getCupomBaseStyles()}</style>
      </head><body>
        <div class="cupom">
          <div class="header">GOFAST PRODUCOES</div>
          <div class="title">PAGAMENTOS</div>
          <div class="divider"></div>
          <div class="total">PAGO: R$ ${totalPaymentsPaid.toFixed(2)}</div>
          <div class="total">PEND: R$ ${totalPaymentsPending.toFixed(2)}</div>
          <div class="total">ATRASO: R$ ${totalPaymentsOverdue.toFixed(2)}</div>
          <div class="divider"></div>
          ${paymentLines}
          <div class="divider"></div>
          <div class="footer">${new Date().toLocaleString('pt-BR')}</div>
        </div>
      </body></html>`;
    } else {
      content = printContent;
    }
    
    printHtml(content);
  };

  const handlePrintSinglePayment = (payment: Payment, seamstress: Seamstress, format: PrintFormat = 'a4') => {
    const batch = batches.find((b: Batch) => b.id === payment.batchId);
    const dueDate = payment.dueDate ? new Date(payment.dueDate).toLocaleDateString('pt-BR') : 'N/A';
    const paidDate = payment.paidDate ? new Date(payment.paidDate).toLocaleDateString('pt-BR') : 'N/A';
    const status = getPaymentStatus(payment);
    const statusLabel = status === "paid" ? "Pago" : status === "overdue" ? "Atrasado" : "Pendente";

    const printContent = `
      <!DOCTYPE html><html lang="pt-BR"><head>
        <meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Comprovante de Pagamento</title>
        <style>
          body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background-color: #fff; padding: 40px; }
          .container { max-width: 210mm; margin: 0 auto; border: 2px solid #8B5CF6; border-radius: 8px; padding: 40px; background-color: #F9FAFB; }
          .header { text-align: center; margin-bottom: 40px; border-bottom: 3px solid #8B5CF6; padding-bottom: 20px; }
          .header h1 { font-size: 32px; color: #1F2937; margin-bottom: 10px; font-weight: 700; }
          .section { margin-bottom: 30px; }
          .section-title { font-size: 13px; font-weight: 700; color: #8B5CF6; text-transform: uppercase; margin-bottom: 15px; border-bottom: 2px solid #E5E7EB; padding-bottom: 10px; }
          .info-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 20px; margin-bottom: 20px; }
          .info-item { display: flex; flex-direction: column; }
          .info-label { font-size: 12px; font-weight: 600; color: #6B7280; text-transform: uppercase; margin-bottom: 5px; }
          .info-value { font-size: 14px; color: #1F2937; font-weight: 500; }
          .status-box { padding: 15px; border-radius: 6px; text-align: center; margin-bottom: 20px; }
          .status-box.pending { background-color: #FEF3C7; border: 2px solid #FCD34D; }
          .status-box.paid { background-color: #ECFDF5; border: 2px solid #10B981; }
          .status-box.overdue { background-color: #FEE2E2; border: 2px solid #EF4444; }
          .amount-display { display: flex; justify-content: space-between; align-items: center; padding: 20px; background-color: white; border: 2px solid #8B5CF6; border-radius: 6px; margin-bottom: 20px; }
          .amount-label { font-size: 14px; font-weight: 600; color: #6B7280; }
          .amount-value { font-size: 28px; font-weight: 700; color: #8B5CF6; }
          .footer { text-align: center; margin-top: 40px; padding-top: 20px; border-top: 1px solid #E5E7EB; font-size: 11px; color: #6B7280; }
        </style>
      </head><body>
        <div class="container">
          <div class="header">
            <h1>Comprovante de Pagamento</h1>
            <p>GoFast Produções</p>
            <p>Gerado em: ${new Date().toLocaleDateString('pt-BR')} às ${new Date().toLocaleTimeString('pt-BR')}</p>
          </div>
          <div class="section">
            <div class="section-title">Dados da Costureira</div>
            <div class="info-grid">
              <div class="info-item"><span class="info-label">Nome</span><span class="info-value">${seamstress.name}</span></div>
              <div class="info-item"><span class="info-label">Telefone</span><span class="info-value">${seamstress.phone}</span></div>
              <div class="info-item"><span class="info-label">Endereço</span><span class="info-value">${seamstress.address}</span></div>
              <div class="info-item"><span class="info-label">Código do Lote</span><span class="info-value">${batch?.batchCode || payment.batchId.slice(0, 8)}</span></div>
            </div>
          </div>
          <div class="section">
            <div class="section-title">Detalhes do Pagamento</div>
            <div class="status-box ${status}"><div style="font-size: 16px; font-weight: 700;">${statusLabel}</div></div>
            <div class="amount-display">
              <span class="amount-label">Valor do Pagamento</span>
              <span class="amount-value">R$ ${parseFloat(payment.amount).toFixed(2)}</span>
            </div>
            <div class="info-grid">
              <div class="info-item"><span class="info-label">Data de Vencimento</span><span class="info-value">${dueDate}</span></div>
              <div class="info-item"><span class="info-label">Data do Pagamento</span><span class="info-value">${status === 'paid' ? paidDate : '---'}</span></div>
            </div>
          </div>
          <div class="footer"><p>Este é um documento gerado automaticamente por GoFast Produções</p></div>
        </div>
      </body></html>
    `;

    let content = '';
    if (format === 'cupom') {
      content = `<!DOCTYPE html><html lang="pt-BR"><head><meta charset="UTF-8">
        <title>Comprovante</title>
        <style>${getCupomBaseStyles()}</style>
      </head><body>
        <div class="cupom">
          <div class="header">GOFAST PRODUCOES</div>
          <div class="title">COMPROVANTE</div>
          <div class="divider"></div>
          <div class="info">${seamstress.name}</div>
          <div class="info">Tel: ${seamstress.phone}</div>
          <div class="info">${seamstress.address}</div>
          <div class="divider"></div>
          <div class="info">Lote: ${batch?.batchCode || payment.batchId.slice(0, 8)}</div>
          <div class="info">Status: ${statusLabel}</div>
          <div class="total">VALOR: R$ ${parseFloat(payment.amount).toFixed(2)}</div>
          <div class="info">Venc: ${dueDate}</div>
          <div class="info">Pago: ${status === 'paid' ? paidDate : '---'}</div>
          <div class="divider"></div>
          <div class="footer">${new Date().toLocaleString('pt-BR')}</div>
        </div>
      </body></html>`;
    } else {
      content = printContent;
    }
    
    printHtml(content);
  };

  const handlePrintAllExtraCosts = (format: PrintFormat = 'a4') => {
    let costRows = '';
    extraCosts.forEach((cost: ExtraCost) => {
      const date = new Date(cost.date).toLocaleDateString('pt-BR');
      costRows += `<tr><td>${cost.description}</td><td>${cost.category}</td><td>R$ ${parseFloat(cost.amount).toFixed(2)}</td><td>${cost.status === 'paid' ? 'Pago' : 'Pendente'}</td><td>${date}</td></tr>`;
    });

    const printContent = `
      <!DOCTYPE html><html lang="pt-BR"><head>
        <meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Relatório - Custos Extras</title>
        <style>
          body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background-color: #fff; padding: 20px; }
          .container { max-width: 210mm; margin: 0 auto; }
          .header { text-align: center; margin-bottom: 30px; border-bottom: 3px solid #8B5CF6; padding-bottom: 15px; }
          .header h1 { font-size: 28px; color: #1F2937; margin-bottom: 5px; }
          .summary { display: grid; grid-template-columns: 1fr 1fr; gap: 15px; margin-bottom: 30px; }
          .summary-box { border: 1px solid #E5E7EB; padding: 15px; border-radius: 6px; text-align: center; }
          .summary-box.green { background-color: #ECFDF5; border-color: #10B981; }
          .summary-box.orange { background-color: #FEF3C7; border-color: #F59E0B; }
          .summary-box .label { font-size: 12px; color: #6B7280; font-weight: 600; }
          .summary-box .value { font-size: 20px; font-weight: 700; margin-top: 8px; color: #1F2937; }
          .summary-box.green .value { color: #10B981; }
          .summary-box.orange .value { color: #F59E0B; }
          table { width: 100%; border-collapse: collapse; margin-bottom: 20px; }
          table thead { background-color: #8B5CF6; color: white; }
          table th, table td { padding: 10px; text-align: left; font-size: 12px; border-bottom: 1px solid #E5E7EB; }
          .footer { text-align: center; margin-top: 30px; padding-top: 20px; border-top: 1px solid #E5E7EB; font-size: 11px; color: #6B7280; }
        </style>
      </head><body>
        <div class="container">
          <div class="header">
            <h1>Custos Extras</h1>
            <p>GoFast Produções</p>
            <p>Gerado em: ${new Date().toLocaleDateString('pt-BR')} às ${new Date().toLocaleTimeString('pt-BR')}</p>
          </div>
          <div class="summary">
            <div class="summary-box green"><div class="label">Total Pago</div><div class="value">R$ ${totalExtraCostsPaid.toFixed(2)}</div></div>
            <div class="summary-box orange"><div class="label">Total Pendente</div><div class="value">R$ ${totalExtraCostsPending.toFixed(2)}</div></div>
          </div>
          <h2 style="margin-bottom: 15px; font-size: 14px; font-weight: 700; color: #1F2937;">Detalhes dos Custos</h2>
          <table><thead><tr><th>Descrição</th><th>Categoria</th><th>Valor</th><th>Status</th><th>Data</th></tr></thead><tbody>${costRows}</tbody></table>
          <div class="footer"><p>Este é um documento gerado automaticamente por GoFast Produções</p></div>
        </div>
      </body></html>
    `;

    let content = '';
    if (format === 'cupom') {
      let costLines = '';
      extraCosts.forEach((cost: ExtraCost) => {
        costLines += `
          <div class="item">
            <div class="item-header">${cost.description.substring(0, 20)}</div>
            <div class="item-row"><span>${cost.category}</span><span>${cost.status === 'paid' ? 'Pago' : 'Pend'}</span></div>
            <div class="item-row"><span>Valor:</span><span>R$ ${parseFloat(cost.amount).toFixed(2)}</span></div>
          </div>
        `;
      });

      content = `<!DOCTYPE html><html lang="pt-BR"><head><meta charset="UTF-8">
        <title>Custos Extras</title>
        <style>${getCupomBaseStyles()}</style>
      </head><body>
        <div class="cupom">
          <div class="header">GOFAST PRODUCOES</div>
          <div class="title">CUSTOS EXTRAS</div>
          <div class="divider"></div>
          <div class="total">PAGO: R$ ${totalExtraCostsPaid.toFixed(2)}</div>
          <div class="total">PEND: R$ ${totalExtraCostsPending.toFixed(2)}</div>
          <div class="divider"></div>
          ${costLines}
          <div class="divider"></div>
          <div class="footer">${new Date().toLocaleString('pt-BR')}</div>
        </div>
      </body></html>`;
    } else {
      content = printContent;
    }
    
    printHtml(content);
  };

  const handlePrintSingleExtraCost = (cost: ExtraCost, format: PrintFormat = 'a4') => {
    const date = new Date(cost.date).toLocaleDateString('pt-BR');
    const printContent = `
      <!DOCTYPE html><html lang="pt-BR"><head>
        <meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Comprovante - Custo Extra</title>
        <style>
          body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background-color: #fff; padding: 40px; }
          .container { max-width: 210mm; margin: 0 auto; border: 2px solid #8B5CF6; border-radius: 8px; padding: 40px; background-color: #F9FAFB; }
          .header { text-align: center; margin-bottom: 40px; border-bottom: 3px solid #8B5CF6; padding-bottom: 20px; }
          .header h1 { font-size: 32px; color: #1F2937; margin-bottom: 10px; font-weight: 700; }
          .section { margin-bottom: 30px; }
          .section-title { font-size: 13px; font-weight: 700; color: #8B5CF6; text-transform: uppercase; margin-bottom: 15px; border-bottom: 2px solid #E5E7EB; padding-bottom: 10px; }
          .info-item { margin-bottom: 15px; }
          .info-label { font-size: 12px; font-weight: 600; color: #6B7280; text-transform: uppercase; margin-bottom: 5px; }
          .info-value { font-size: 14px; color: #1F2937; font-weight: 500; }
          .amount-display { display: flex; justify-content: space-between; align-items: center; padding: 20px; background-color: white; border: 2px solid #8B5CF6; border-radius: 6px; margin-bottom: 20px; }
          .amount-label { font-size: 14px; font-weight: 600; color: #6B7280; }
          .amount-value { font-size: 28px; font-weight: 700; color: #8B5CF6; }
          .footer { text-align: center; margin-top: 40px; padding-top: 20px; border-top: 1px solid #E5E7EB; font-size: 11px; color: #6B7280; }
        </style>
      </head><body>
        <div class="container">
          <div class="header">
            <h1>Comprovante - Custo Extra</h1>
            <p>GoFast Produções</p>
            <p>Gerado em: ${new Date().toLocaleDateString('pt-BR')} às ${new Date().toLocaleTimeString('pt-BR')}</p>
          </div>
          <div class="section">
            <div class="section-title">Detalhes do Custo</div>
            <div class="info-item"><div class="info-label">Descrição</div><div class="info-value">${cost.description}</div></div>
            <div class="info-item"><div class="info-label">Categoria</div><div class="info-value">${cost.category}</div></div>
            <div class="info-item"><div class="info-label">Data</div><div class="info-value">${date}</div></div>
            <div class="amount-display">
              <span class="amount-label">Valor</span>
              <span class="amount-value">R$ ${parseFloat(cost.amount).toFixed(2)}</span>
            </div>
            <div class="info-item"><div class="info-label">Status</div><div class="info-value">${cost.status === 'paid' ? '✓ Pago' : 'Pendente'}</div></div>
          </div>
          <div class="footer"><p>Este é um documento gerado automaticamente por GoFast Produções</p></div>
        </div>
      </body></html>
    `;

    let content = '';
    if (format === 'cupom') {
      content = `<!DOCTYPE html><html lang="pt-BR"><head><meta charset="UTF-8">
        <title>Custo Extra</title>
        <style>${getCupomBaseStyles()}</style>
      </head><body>
        <div class="cupom">
          <div class="header">GOFAST PRODUCOES</div>
          <div class="title">CUSTO EXTRA</div>
          <div class="divider"></div>
          <div class="info">${cost.description}</div>
          <div class="info">Cat: ${cost.category}</div>
          <div class="info">Data: ${date}</div>
          <div class="total">R$ ${parseFloat(cost.amount).toFixed(2)}</div>
          <div class="info">Status: ${cost.status === 'paid' ? 'Pago' : 'Pendente'}</div>
          <div class="divider"></div>
          <div class="footer">${new Date().toLocaleString('pt-BR')}</div>
        </div>
      </body></html>`;
    } else {
      content = printContent;
    }
    
    printHtml(content);
  };

  const filteredSeamstresses = seamstresses.filter((s: Seamstress) => {
    const sPendingPayments = payments.filter((p: Payment) => {
      if (p.seamstressId !== s.id || p.status === "paid") return false;
      
      // Exclude payments for productions that are marked as paid
      if (isProductionPaid(p)) return false;
      
      // Filter by supplier
      if (filterSupplier !== "todos" && getSupplierForPayment(p) !== filterSupplier) return false;
      
      if (filterPaymentStatus === "pendente") {
        return !isPaymentOverdue(p);
      } else if (filterPaymentStatus === "atrasados") {
        return isPaymentOverdue(p);
      }
      return true;
    });
    return sPendingPayments.length > 0;
  });

  return (
    <div className="p-8 space-y-8">
      {/* Header */}
      <div>
        <h1 className="text-4xl font-bold bg-gradient-to-r from-cyan-400 to-purple-500 bg-clip-text text-transparent mb-2">
          Gestão Financeira
        </h1>
        <p className="text-muted-foreground">Centro de controle de todos os pagamentos e custos</p>
      </div>

      {/* Module 1: Pagamentos a Receber */}
      <div className="space-y-6 border-t border-border pt-8">
        <div className="flex items-center gap-3">
          <DollarSign className="w-8 h-8 text-amber-500" />
          <h2 className="text-2xl font-bold">💰 Pagamentos a Receber das Costureiras</h2>
        </div>

        {/* Summary Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
          <Card className="p-6 bg-gradient-to-br from-green-900/20 to-green-800/10 border-green-600/30">
            <div className="flex items-start justify-between">
              <div>
                <p className="text-sm font-medium text-green-400">Total Pago</p>
                <p className="text-3xl font-bold mt-2">R$ {totalPaymentsPaid.toFixed(2)}</p>
              </div>
              <CheckCircle className="w-8 h-8 text-green-500" />
            </div>
          </Card>

          <Card className="p-6 bg-gradient-to-br from-orange-900/20 to-orange-800/10 border-orange-600/30">
            <div className="flex items-start justify-between">
              <div>
                <p className="text-sm font-medium text-orange-400">Total Pendente</p>
                <p className="text-3xl font-bold mt-2">R$ {totalPaymentsPending.toFixed(2)}</p>
              </div>
              <AlertCircle className="w-8 h-8 text-orange-500" />
            </div>
          </Card>

          <Card className="p-6 bg-gradient-to-br from-red-900/20 to-red-800/10 border-red-600/30">
            <div className="flex items-start justify-between">
              <div>
                <p className="text-sm font-medium text-red-400">Total Atrasado</p>
                <p className="text-3xl font-bold mt-2">R$ {totalPaymentsOverdue.toFixed(2)}</p>
              </div>
              <AlertCircle className="w-8 h-8 text-red-500" />
            </div>
          </Card>

          <Card className="p-6 bg-gradient-to-br from-purple-900/20 to-purple-800/10 border-purple-600/30">
            <div className="flex items-start justify-between">
              <div>
                <p className="text-sm font-medium text-purple-400">Total Geral</p>
                <p className="text-3xl font-bold mt-2">R$ {(totalPaymentsPaid + totalPaymentsPending + totalPaymentsOverdue).toFixed(2)}</p>
              </div>
              <DollarSign className="w-8 h-8 text-purple-500" />
            </div>
          </Card>
        </div>

        {/* Print Buttons */}
        <div className="flex gap-3">
          <Button onClick={openPrintAllPaymentsDialog} className="gap-2" data-testid="button-print-all-payments">
            <Printer className="w-4 h-4" />
            Imprimir Todos os Pagamentos
          </Button>
        </div>

        {/* Filters */}
        <Card className="p-6">
          <div className="flex flex-wrap gap-6">
            <div>
              <label className="text-sm font-medium">Filtro de Status</label>
              <select
                value={filterPaymentStatus}
                onChange={(e) => setFilterPaymentStatus(e.target.value)}
                className="w-full md:w-48 mt-2 p-2 border rounded-md bg-background"
                data-testid="select-payment-status-filter"
              >
                <option value="pendente">Pendente</option>
                <option value="atrasados">Atrasados</option>
              </select>
            </div>
            <div>
              <label className="text-sm font-medium">Filtro por Fornecedor</label>
              <select
                value={filterSupplier}
                onChange={(e) => setFilterSupplier(e.target.value)}
                className="w-full md:w-48 mt-2 p-2 border rounded-md bg-background"
                data-testid="select-supplier-filter"
              >
                <option value="todos">Todos os Fornecedores</option>
                {uniqueSuppliers.map((supplier) => (
                  <option key={supplier} value={supplier}>
                    {supplier}
                  </option>
                ))}
              </select>
            </div>
          </div>
        </Card>

        {/* Payments List */}
        <div className="space-y-4">
          {filteredSeamstresses.map((seamstress: Seamstress) => {
            const sPayments = getSeamstressPayments(seamstress.id);
            const isExpanded = expandedSeamstress === seamstress.id;

            return (
              <Card key={seamstress.id} className="p-6 border-blue-500/30">
                <div className="flex items-center justify-between gap-4">
                  <div
                    className="cursor-pointer flex-1"
                    onClick={() => setExpandedSeamstress(isExpanded ? null : seamstress.id)}
                  >
                    <div className="flex items-center justify-between">
                      <h3 className="text-lg font-semibold">{seamstress.name}</h3>
                      <button data-testid={`button-expand-${seamstress.id}`}>
                        {isExpanded ? (
                          <ChevronUp className="w-6 h-6" />
                        ) : (
                          <ChevronDown className="w-6 h-6" />
                        )}
                      </button>
                    </div>
                  </div>
                </div>

                {isExpanded && (
                  <div className="mt-6 border-t border-border pt-6">
                    <div className="space-y-4 mb-6">
                      {sPayments.map((payment: Payment) => {
                        const batch = batches.find((b: Batch) => b.id === payment.batchId);
                        const production = batch ? productions.find((p: Production) => p.id === batch.productionId) : null;
                        
                        return (
                          <div key={payment.id} className="flex items-center justify-between p-4 bg-card rounded border border-border">
                            <div className="flex-1">
                              <p className="font-medium">R$ {parseFloat(payment.amount).toFixed(2)}</p>
                              {production && (
                                <p className="text-xs text-muted-foreground">
                                  {production.productName} - <span className="font-semibold">{production.supplier}</span>
                                </p>
                              )}
                              <p className="text-xs text-muted-foreground">
                                Vencimento: {payment.dueDate ? new Date(payment.dueDate).toLocaleDateString('pt-BR') : 'N/A'}
                              </p>
                            </div>
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => openPrintSinglePaymentDialog(payment, seamstress)}
                              className="gap-1"
                              data-testid={`button-print-payment-${payment.id}`}
                            >
                              <Printer className="w-3 h-3" />
                              Imprimir
                            </Button>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                )}
              </Card>
            );
          })}
        </div>
      </div>

      {/* Module 2: Custos Extras */}
      <div className="space-y-6 border-t border-border pt-8">
        <div className="flex items-center gap-3">
          <TrendingUp className="w-8 h-8 text-cyan-500" />
          <h2 className="text-2xl font-bold">📊 Custos Extras</h2>
        </div>

        {/* Summary Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <Card className="p-6 bg-gradient-to-br from-green-900/20 to-green-800/10 border-green-600/30">
            <div className="flex items-start justify-between">
              <div>
                <p className="text-sm font-medium text-green-400">Total Pago</p>
                <p className="text-3xl font-bold mt-2">R$ {totalExtraCostsPaid.toFixed(2)}</p>
              </div>
              <CheckCircle className="w-8 h-8 text-green-500" />
            </div>
          </Card>

          <Card className="p-6 bg-gradient-to-br from-orange-900/20 to-orange-800/10 border-orange-600/30">
            <div className="flex items-start justify-between">
              <div>
                <p className="text-sm font-medium text-orange-400">Total Pendente</p>
                <p className="text-3xl font-bold mt-2">R$ {totalExtraCostsPending.toFixed(2)}</p>
              </div>
              <AlertCircle className="w-8 h-8 text-orange-500" />
            </div>
          </Card>

          <Card className="p-6 bg-gradient-to-br from-purple-900/20 to-purple-800/10 border-purple-600/30">
            <div className="flex items-start justify-between">
              <div>
                <p className="text-sm font-medium text-purple-400">Total Geral</p>
                <p className="text-3xl font-bold mt-2">R$ {(totalExtraCostsPaid + totalExtraCostsPending).toFixed(2)}</p>
              </div>
              <DollarSign className="w-8 h-8 text-purple-500" />
            </div>
          </Card>
        </div>

        {/* Print Button */}
        <div className="flex gap-3">
          <Button onClick={openPrintAllExtraCostsDialog} className="gap-2" data-testid="button-print-all-extra-costs">
            <Printer className="w-4 h-4" />
            Imprimir Todos os Custos
          </Button>
        </div>

        {/* Extra Costs List */}
        <div className="space-y-4">
          {extraCosts.length === 0 ? (
            <Card className="p-6">
              <p className="text-muted-foreground text-center">Nenhum custo extra registrado.</p>
            </Card>
          ) : (
            extraCosts.map((cost: ExtraCost) => (
              <Card key={cost.id} className="p-6 border-cyan-500/30">
                <div
                  className="cursor-pointer"
                  onClick={() => setExpandedExtraCost(expandedExtraCost === cost.id ? null : cost.id)}
                >
                  <div className="flex items-center justify-between">
                    <div className="flex-1">
                      <h3 className="text-lg font-semibold">{cost.description}</h3>
                      <p className="text-sm text-muted-foreground">{cost.category}</p>
                      <div className="flex gap-4 mt-2 text-sm">
                        <span>R$ {parseFloat(cost.amount).toFixed(2)}</span>
                        <span className={`px-2 py-1 rounded text-xs font-semibold ${cost.status === 'paid' ? 'bg-green-900/50 text-green-400' : 'bg-orange-900/50 text-orange-400'}`}>
                          {cost.status === 'paid' ? '✓ Pago' : 'Pendente'}
                        </span>
                      </div>
                    </div>
                    <div className="flex gap-2">
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={(e) => {
                          e.stopPropagation();
                          openPrintSingleExtraCostDialog(cost);
                        }}
                        className="gap-1"
                        data-testid={`button-print-cost-${cost.id}`}
                      >
                        <Printer className="w-3 h-3" />
                        Imprimir
                      </Button>
                      <button data-testid={`button-expand-cost-${cost.id}`}>
                        {expandedExtraCost === cost.id ? (
                          <ChevronUp className="w-6 h-6" />
                        ) : (
                          <ChevronDown className="w-6 h-6" />
                        )}
                      </button>
                    </div>
                  </div>
                </div>

                {expandedExtraCost === cost.id && (
                  <div className="mt-6 border-t border-border pt-6">
                    <div className="text-sm space-y-2">
                      <div><span className="font-semibold">Data:</span> {new Date(cost.date).toLocaleDateString('pt-BR')}</div>
                      <div><span className="font-semibold">Descrição:</span> {cost.description}</div>
                      <div><span className="font-semibold">Categoria:</span> {cost.category}</div>
                      <div><span className="font-semibold">Valor:</span> R$ {parseFloat(cost.amount).toFixed(2)}</div>
                    </div>
                  </div>
                )}
              </Card>
            ))
          )}
        </div>
      </div>

      <PrintFormatDialog
        open={printFormatDialogOpen}
        onOpenChange={setPrintFormatDialogOpen}
        onSelectFormat={handlePrintFormatSelect}
      />
    </div>
  );
};

export default Financeiro;
