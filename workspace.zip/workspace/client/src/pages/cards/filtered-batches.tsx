import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useLocation } from "wouter";
import { ArrowLeft, Package, User, Printer } from "lucide-react";
import { PrintFormatDialog, PrintFormat, getCupomBaseStyles, printContent as printHtml } from "@/components/print-format-dialog";

const FilteredBatches = () => {
  const [, navigate] = useLocation();
  const queryParams = new URLSearchParams(window.location.search);
  const filterType = queryParams.get("type") || "pendentes";
  
  // Print format dialog state
  const [printFormatDialogOpen, setPrintFormatDialogOpen] = useState(false);
  const [pendingPrintAction, setPendingPrintAction] = useState<{
    type: 'all' | 'production';
    data?: any;
  } | null>(null);

  const { data: batches = [] } = useQuery({
    queryKey: ["/api/batches"],
  });

  const { data: productions = [] } = useQuery({
    queryKey: ["/api/productions"],
  });

  const { data: seamstresses = [] } = useQuery({
    queryKey: ["/api/seamstresses"],
  });

  const filterBatches = () => {
    switch (filterType) {
      case "em_separacao":
        return batches.filter((b: any) => b.status === "em_separacao");
      case "para_entrega":
        return batches.filter((b: any) => b.status === "para_entrega");
      case "em_producao":
        return batches.filter((b: any) => b.status === "em_producao");
      case "para_recolha":
        return batches.filter((b: any) => b.status === "para_recolha");
      case "concluidos":
        return batches.filter((b: any) => b.status === "concluido");
      case "pendentes":
      default:
        return batches.filter((b: any) => ["em_separacao", "para_entrega", "em_producao"].includes(b.status));
    }
  };

  const getFilterLabel = () => {
    const labels: Record<string, string> = {
      pendentes: "Lotes Pendentes",
      em_separacao: "Lotes em Separação",
      para_entrega: "Lotes para Entrega",
      em_producao: "Lotes em Produção",
      para_recolha: "Lotes para Recolha",
      concluidos: "Lotes Concluídos",
    };
    return labels[filterType] || "Lotes";
  };

  const getProductionName = (productionId: string) => {
    const prod = productions.find((p: any) => p.id === productionId);
    return prod?.productionCode || "Produção desconhecida";
  };

  const getSeamstressName = (seamstressId: string) => {
    const seamstress = seamstresses.find((s: any) => s.id === seamstressId);
    return seamstress?.name || "Costureira desconhecida";
  };

  const getProduction = (productionId: string) => {
    return productions.find((p: any) => p.id === productionId);
  };

  const filteredBatches = filterBatches();

  // Print format dialog functions
  const openPrintAllDialog = () => {
    setPendingPrintAction({ type: 'all' });
    setPrintFormatDialogOpen(true);
  };

  const openPrintByProductionDialog = (group: any) => {
    setPendingPrintAction({ type: 'production', data: group });
    setPrintFormatDialogOpen(true);
  };

  const handlePrintFormatSelect = (format: PrintFormat) => {
    setPrintFormatDialogOpen(false);
    if (!pendingPrintAction) return;

    if (pendingPrintAction.type === 'all') {
      handlePrintAll(format);
    } else if (pendingPrintAction.type === 'production') {
      handlePrintByProduction(pendingPrintAction.data, format);
    }
    setPendingPrintAction(null);
  };

  const handlePrintAll = (format: PrintFormat = 'a4') => {
    let content = '';

    if (format === 'cupom') {
      let batchLines = '';
      filteredBatches.forEach((batch: any) => {
        const prod = getProduction(batch.productionId);
        const seamstress = batch.seamstressId ? getSeamstressName(batch.seamstressId) : "N/A";
        const valor = (batch.quantity * parseFloat(batch.pricePerUnit || 0)).toFixed(2);
        batchLines += `
          <div class="item">
            <div class="item-header">${batch.batchCode}</div>
            <div class="item-row"><span>Prod:</span><span>${prod?.productionCode || "N/A"}</span></div>
            <div class="item-row"><span>Cost:</span><span>${seamstress.substring(0, 15)}</span></div>
            <div class="item-row"><span>Qtd:</span><span>${batch.quantity}</span></div>
            <div class="item-row"><span>Valor:</span><span>R$ ${valor}</span></div>
          </div>
        `;
      });

      content = `<!DOCTYPE html><html lang="pt-BR"><head><meta charset="UTF-8">
        <title>${getFilterLabel()}</title>
        <style>${getCupomBaseStyles()}</style>
      </head><body>
        <div class="cupom">
          <div class="header">GOFAST PRODUCOES</div>
          <div class="title">${getFilterLabel()}</div>
          <div class="divider"></div>
          ${batchLines}
          <div class="divider"></div>
          <div class="total">TOTAL: ${filteredBatches.length} lotes</div>
          <div class="footer">${new Date().toLocaleString('pt-BR')}</div>
        </div>
      </body></html>`;
    } else {
      let batchRows = "";
      filteredBatches.forEach((batch: any) => {
        const prod = getProduction(batch.productionId);
        const seamstress = batch.seamstressId ? getSeamstressName(batch.seamstressId) : "Não atribuído";
        batchRows += `
          <tr>
            <td>${batch.batchCode}</td>
            <td>${prod?.productionCode || "N/A"}</td>
            <td>${seamstress}</td>
            <td>${batch.quantity}</td>
            <td>R$ ${(batch.quantity * parseFloat(batch.pricePerUnit || 0)).toFixed(2)}</td>
            <td>${batch.status}</td>
          </tr>
        `;
      });

      content = `<!DOCTYPE html><html><head><meta charset="UTF-8">
        <title>Lotes - ${getFilterLabel()}</title>
        <style>
          body { font-family: Arial, sans-serif; margin: 20px; background: white; }
          h1 { text-align: center; color: #333; }
          table { width: 100%; border-collapse: collapse; margin-top: 20px; }
          th, td { border: 1px solid #ddd; padding: 12px; text-align: left; }
          th { background-color: #4C8BF5; color: white; font-weight: bold; }
          tr:nth-child(even) { background-color: #f9f9f9; }
          .footer { text-align: center; margin-top: 30px; font-size: 12px; color: #666; }
        </style>
      </head><body>
        <h1>${getFilterLabel()}</h1>
        <table>
          <thead><tr><th>Código do Lote</th><th>Produção</th><th>Costureira</th><th>Quantidade</th><th>Valor</th><th>Status</th></tr></thead>
          <tbody>${batchRows}</tbody>
        </table>
        <div class="footer">
          <p>Relatório gerado em ${new Date().toLocaleDateString("pt-BR")} às ${new Date().toLocaleTimeString("pt-BR")}</p>
          <p>GoFast Produções - Sistema de Gestão</p>
        </div>
      </body></html>`;
    }

    printHtml(content);
  };

  const handlePrintByProduction = (group: any, format: PrintFormat = 'a4') => {
    let content = '';

    if (format === 'cupom') {
      let batchLines = '';
      group.batches.forEach((batch: any) => {
        const seamstress = batch.seamstressId ? getSeamstressName(batch.seamstressId) : "N/A";
        const valor = (batch.quantity * parseFloat(batch.pricePerUnit || 0)).toFixed(2);
        batchLines += `
          <div class="item">
            <div class="item-header">${batch.batchCode}</div>
            <div class="item-row"><span>Cost:</span><span>${seamstress.substring(0, 15)}</span></div>
            <div class="item-row"><span>Qtd:</span><span>${batch.quantity}</span></div>
            <div class="item-row"><span>Valor:</span><span>R$ ${valor}</span></div>
          </div>
        `;
      });

      content = `<!DOCTYPE html><html lang="pt-BR"><head><meta charset="UTF-8">
        <title>Lotes - ${group.productionCode}</title>
        <style>${getCupomBaseStyles()}</style>
      </head><body>
        <div class="cupom">
          <div class="header">GOFAST PRODUCOES</div>
          <div class="title">Lotes da Producao</div>
          <div class="subtitle">${group.productionCode}</div>
          <div class="divider"></div>
          ${batchLines}
          <div class="divider"></div>
          <div class="total">TOTAL: ${group.batches.length} lotes</div>
          <div class="footer">${new Date().toLocaleString('pt-BR')}</div>
        </div>
      </body></html>`;
    } else {
      let batchRows = "";
      group.batches.forEach((batch: any) => {
        const seamstress = batch.seamstressId ? getSeamstressName(batch.seamstressId) : "Não atribuído";
        batchRows += `
          <tr>
            <td>${batch.batchCode}</td>
            <td>${seamstress}</td>
            <td>${batch.quantity}</td>
            <td>R$ ${(batch.quantity * parseFloat(batch.pricePerUnit || 0)).toFixed(2)}</td>
            <td>${batch.status}</td>
          </tr>
        `;
      });

      content = `<!DOCTYPE html><html><head><meta charset="UTF-8">
        <title>Lotes - ${group.productionCode}</title>
        <style>
          body { font-family: Arial, sans-serif; margin: 20px; background: white; }
          h1 { text-align: center; color: #333; }
          .production-header { text-align: center; margin-bottom: 20px; }
          .production-code { font-size: 18px; font-weight: bold; color: #4C8BF5; }
          table { width: 100%; border-collapse: collapse; margin-top: 20px; }
          th, td { border: 1px solid #ddd; padding: 12px; text-align: left; }
          th { background-color: #4C8BF5; color: white; font-weight: bold; }
          tr:nth-child(even) { background-color: #f9f9f9; }
          .footer { text-align: center; margin-top: 30px; font-size: 12px; color: #666; }
        </style>
      </head><body>
        <h1>Lotes da Produção</h1>
        <div class="production-header"><p class="production-code">${group.productionCode}</p></div>
        <table>
          <thead><tr><th>Código do Lote</th><th>Costureira</th><th>Quantidade</th><th>Valor</th><th>Status</th></tr></thead>
          <tbody>${batchRows}</tbody>
        </table>
        <div class="footer">
          <p>Relatório gerado em ${new Date().toLocaleDateString("pt-BR")} às ${new Date().toLocaleTimeString("pt-BR")}</p>
          <p>GoFast Produções - Sistema de Gestão</p>
        </div>
      </body></html>`;
    }

    printHtml(content);
  };

  // Group batches by production
  const groupedByProduction: Record<string, any[]> = {};
  filteredBatches.forEach((batch: any) => {
    const key = batch.productionId;
    if (!groupedByProduction[key]) {
      groupedByProduction[key] = [];
    }
    groupedByProduction[key].push(batch);
  });

  const productionGroups = Object.entries(groupedByProduction).map(([prodId, batchList]) => ({
    productionId: prodId,
    productionCode: getProductionName(prodId),
    batches: batchList,
  }));

  return (
    <div className="p-8 space-y-6">
      <div className="flex items-center gap-4">
        <Button
          variant="ghost"
          size="icon"
          onClick={() => navigate("/")}
          data-testid="button-back-to-dashboard"
        >
          <ArrowLeft className="w-4 h-4" />
        </Button>
        <h1 className="text-3xl font-semibold">{getFilterLabel()}</h1>
        <span className="text-muted-foreground">({filteredBatches.length})</span>
      </div>

      {filteredBatches.length === 0 ? (
        <Card className="p-8">
          <p className="text-center text-muted-foreground">Nenhum lote encontrado com este filtro.</p>
        </Card>
      ) : (
        <>
          <div className="flex gap-3">
            <Button 
              onClick={openPrintAllDialog}
              className="gap-2"
              data-testid="button-print-all-batches"
            >
              <Printer className="w-4 h-4" />
              Imprimir Todos os Lotes
            </Button>
          </div>

          <div className="space-y-6">
          {productionGroups.map((group) => (
            <div key={group.productionId} className="space-y-3">
              <div className="flex items-center gap-3 px-4 py-3 bg-accent/20 rounded-lg border border-border justify-between">
                <div className="flex items-center gap-3">
                  <Package className="w-5 h-5 text-primary" />
                  <h2 className="text-xl font-semibold">{group.productionCode}</h2>
                  <span className="text-sm text-muted-foreground">({group.batches.length} lote{group.batches.length !== 1 ? 's' : ''})</span>
                </div>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => openPrintByProductionDialog(group)}
                  className="gap-2"
                  data-testid={`button-print-production-${group.productionId}`}
                >
                  <Printer className="w-4 h-4" />
                  Imprimir
                </Button>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pl-4">
                {group.batches.map((batch: any) => (
                  <Card key={batch.id} className="p-4 hover:bg-accent/50 transition-colors cursor-pointer border border-border">
                    <div className="space-y-3">
                      <div>
                        <p className="font-semibold text-lg">
                          {batch.batchCode}
                          <span className="text-muted-foreground text-sm ml-2">({group.productionCode})</span>
                        </p>
                        <p className="text-sm text-muted-foreground">Quantidade: {batch.quantity} un</p>
                      </div>

                      {batch.seamstressId && (
                        <div className="flex items-center gap-2 pt-2 border-t border-border">
                          <User className="w-4 h-4 text-muted-foreground" />
                          <span className="text-sm font-medium">{getSeamstressName(batch.seamstressId)}</span>
                        </div>
                      )}

                      <div className="flex items-center justify-between pt-2">
                        <span className="text-xs text-muted-foreground uppercase">R$ {(batch.quantity * parseFloat(batch.pricePerUnit || 0)).toFixed(2)}</span>
                        <span className="text-xs font-medium px-2 py-1 rounded bg-accent text-accent-foreground">{batch.status}</span>
                      </div>
                    </div>
                  </Card>
                ))}
              </div>
            </div>
          ))}
          </div>
        </>
      )}

      <PrintFormatDialog
        open={printFormatDialogOpen}
        onOpenChange={setPrintFormatDialogOpen}
        onSelectFormat={handlePrintFormatSelect}
      />
    </div>
  );
};

export default FilteredBatches;
