import { useQuery } from "@tanstack/react-query";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useLocation } from "wouter";
import { ArrowLeft, Printer } from "lucide-react";
import { useState } from "react";
import { PrintFormatDialog, PrintFormat, getCupomBaseStyles, printContent as printHtml } from "@/components/print-format-dialog";

const FilteredProductions = () => {
  const [, navigate] = useLocation();
  const queryParams = new URLSearchParams(window.location.search);
  const filterType = queryParams.get("type") || "em_separacao";
  const [filterSupplier, setFilterSupplier] = useState<string>("todos");
  
  // Print format dialog state
  const [printFormatDialogOpen, setPrintFormatDialogOpen] = useState(false);

  const { data: productions = [] } = useQuery<any[]>({
    queryKey: ["/api/productions"],
  });

  const { data: batches = [] } = useQuery<any[]>({
    queryKey: ["/api/batches"],
  });

  const getProductionCost = (productionId: string) => {
    const productionBatches = batches.filter((b: any) => b.productionId === productionId);
    return productionBatches.reduce((sum: number, b: any) => 
      sum + ((b.quantity || 0) * parseFloat(b.pricePerUnit || 0)), 0
    );
  };

  // Get unique suppliers from productions
  const uniqueSuppliers = Array.from(new Set(productions.map((p: any) => p.supplier).filter(Boolean))).sort();

  const filterProductions = () => {
    let filtered = productions;
    
    // Filter by status
    switch (filterType) {
      case "em_separacao":
        filtered = filtered.filter((p: any) => p.status === "em_separacao");
        break;
      case "para_entrega":
        filtered = filtered.filter((p: any) => p.status === "para_entrega");
        break;
      case "em_producao":
        filtered = filtered.filter((p: any) => p.status === "em_producao");
        break;
      case "para_recolha":
        filtered = filtered.filter((p: any) => p.status === "para_recolha");
        break;
      case "concluida":
        filtered = filtered.filter((p: any) => p.status === "concluido" && p.paymentStatus !== "Recebido");
        break;
    }
    
    // Filter by supplier
    if (filterSupplier !== "todos") {
      filtered = filtered.filter((p: any) => p.supplier === filterSupplier);
    }
    
    return filtered;
  };

  const getFilterLabel = () => {
    const labels: Record<string, string> = {
      em_separacao: "Produções em Separação",
      para_entrega: "Produções para Entrega",
      em_producao: "Produções em Produção",
      para_recolha: "Produções para Recolha",
      concluida: "Produções Concluídas",
    };
    return labels[filterType] || "Produções";
  };

  const filteredProductions = filterProductions();

  const openPrintDialog = () => {
    setPrintFormatDialogOpen(true);
  };

  const handlePrintFormatSelect = (format: PrintFormat) => {
    setPrintFormatDialogOpen(false);
    handlePrint(format);
  };

  const handlePrint = (format: PrintFormat = 'a4') => {
    const totalReceita = filteredProductions.reduce((sum: number, p: any) => 
      sum + (p.quantity * parseFloat(p.pricePerUnit || 0)), 0
    );
    const totalCusto = filteredProductions.reduce((sum: number, p: any) => 
      sum + getProductionCost(p.id), 0
    );
    const totalLucro = totalReceita - totalCusto;
    const totalLucroPercent = totalReceita > 0 ? (totalLucro / totalReceita) * 100 : 0;

    let content = '';

    if (format === 'cupom') {
      let prodLines = '';
      filteredProductions.forEach((p: any) => {
        const receita = p.quantity * parseFloat(p.pricePerUnit || 0);
        const custo = getProductionCost(p.id);
        const lucro = receita - custo;
        prodLines += `
          <div class="item">
            <div class="item-header">${p.productionCode}</div>
            <div class="item-row"><span>Prod:</span><span>${p.productName.substring(0, 12)}</span></div>
            <div class="item-row"><span>Forn:</span><span>${p.supplier?.substring(0, 12) || 'N/A'}</span></div>
            <div class="item-row"><span>Qtd:</span><span>${p.quantity}</span></div>
            <div class="item-row"><span>Lucro:</span><span>R$ ${lucro.toFixed(2)}</span></div>
          </div>
        `;
      });

      content = `<!DOCTYPE html><html lang="pt-BR"><head><meta charset="UTF-8">
        <title>${getFilterLabel()}</title>
        <style>${getCupomBaseStyles()}</style>
      </head><body>
        <div class="cupom">
          <div class="header">GOFAST PRODUCOES</div>
          <div class="title">${getFilterLabel()}</div>
          <div class="info">Fornecedor: ${filterSupplier === "todos" ? "Todos" : filterSupplier}</div>
          <div class="divider"></div>
          ${prodLines}
          <div class="divider"></div>
          <div class="total">RECEITA: R$ ${totalReceita.toFixed(2)}</div>
          <div class="total">CUSTO: R$ ${totalCusto.toFixed(2)}</div>
          <div class="total">LUCRO: R$ ${totalLucro.toFixed(2)}</div>
          <div class="footer">${new Date().toLocaleString('pt-BR')}</div>
        </div>
      </body></html>`;
    } else {
      content = `<!DOCTYPE html><html><head><title>${getFilterLabel()}</title>
        <style>
          body { font-family: Arial, sans-serif; padding: 20px; }
          h1 { text-align: center; margin-bottom: 10px; }
          .subtitle { text-align: center; color: #666; margin-bottom: 20px; }
          table { width: 100%; border-collapse: collapse; margin-top: 20px; }
          th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
          th { background-color: #f5f5f5; }
          .total-row { font-weight: bold; background-color: #f0f0f0; }
          .text-right { text-align: right; }
          .positive { color: #16a34a; }
          .negative { color: #dc2626; }
        </style>
      </head><body>
        <h1>${getFilterLabel()}</h1>
        <p class="subtitle">Fornecedor: ${filterSupplier === "todos" ? "Todos" : filterSupplier} | Total: ${filteredProductions.length} produções</p>
        <table><thead><tr><th>Código</th><th>Produto</th><th>Fornecedor</th><th>Qtd</th><th class="text-right">Receita</th><th class="text-right">Custo</th><th class="text-right">Lucro</th></tr></thead>
        <tbody>
          ${filteredProductions.map((p: any) => {
            const receita = p.quantity * parseFloat(p.pricePerUnit || 0);
            const custo = getProductionCost(p.id);
            const lucro = receita - custo;
            const lucroPercent = receita > 0 ? (lucro / receita) * 100 : 0;
            return `<tr><td>${p.productionCode}</td><td>${p.productName}</td><td>${p.supplier}</td><td>${p.quantity}</td><td class="text-right">R$ ${receita.toFixed(2)}</td><td class="text-right">R$ ${custo.toFixed(2)}</td><td class="text-right ${lucro >= 0 ? 'positive' : 'negative'}">R$ ${lucro.toFixed(2)} (${lucroPercent.toFixed(1)}%)</td></tr>`;
          }).join('')}
          <tr class="total-row"><td colspan="4">TOTAL GERAL</td><td class="text-right">R$ ${totalReceita.toFixed(2)}</td><td class="text-right">R$ ${totalCusto.toFixed(2)}</td><td class="text-right ${totalLucro >= 0 ? 'positive' : 'negative'}">R$ ${totalLucro.toFixed(2)} (${totalLucroPercent.toFixed(1)}%)</td></tr>
        </tbody></table>
        <p style="margin-top: 20px; text-align: center; color: #888; font-size: 12px;">Impresso em ${new Date().toLocaleDateString('pt-BR')} às ${new Date().toLocaleTimeString('pt-BR')}</p>
      </body></html>`;
    }

    printHtml(content);
  };

  return (
    <div className="p-8 space-y-6">
      <div className="flex items-center justify-between gap-4 flex-wrap">
        <div className="flex items-center gap-4">
          <Button
            variant="ghost"
            size="icon"
            onClick={() => navigate("/")}
            data-testid="button-back-to-dashboard"
          >
            <ArrowLeft className="w-4 h-4" />
          </Button>
          <h1 className="text-3xl font-semibold">{getFilterLabel()}</h1>
          <span className="text-muted-foreground">({filteredProductions.length})</span>
        </div>
        <Button
          onClick={openPrintDialog}
          className="gap-2"
          data-testid="button-print-productions"
        >
          <Printer className="w-4 h-4" />
          Imprimir
        </Button>
      </div>

      {/* Supplier Filter */}
      <Card className="p-4">
        <div className="flex flex-wrap items-center gap-4">
          <label className="text-sm font-medium">Filtrar por Fornecedor:</label>
          <select
            value={filterSupplier}
            onChange={(e) => setFilterSupplier(e.target.value)}
            className="p-2 border rounded-md bg-background min-w-[200px]"
            data-testid="select-supplier-filter"
          >
            <option value="todos">Todos os Fornecedores</option>
            {uniqueSuppliers.map((supplier: string) => (
              <option key={supplier} value={supplier}>
                {supplier}
              </option>
            ))}
          </select>
        </div>
      </Card>

      {filteredProductions.length === 0 ? (
        <Card className="p-8">
          <p className="text-center text-muted-foreground">Nenhuma produção encontrada com este filtro.</p>
        </Card>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {filteredProductions.map((prod: any) => {
            const receita = prod.quantity * parseFloat(prod.pricePerUnit || 0);
            const custo = getProductionCost(prod.id);
            const lucro = receita - custo;
            const lucroPercent = receita > 0 ? (lucro / receita) * 100 : 0;
            
            return (
              <Card key={prod.id} className="p-4 hover:bg-accent/50 transition-colors cursor-pointer">
                <div>
                  <p className="font-semibold text-lg">{prod.productionCode}</p>
                  <p className="text-sm text-muted-foreground">{prod.productName}</p>
                  <p className="text-sm text-muted-foreground">Fornecedor: {prod.supplier}</p>
                  <p className="text-sm text-muted-foreground">Quantidade: {prod.quantity} un</p>
                  
                  <div className="mt-3 pt-3 border-t space-y-1">
                    <div className="flex justify-between">
                      <span className="text-sm text-muted-foreground">Receita:</span>
                      <span className="font-semibold">R$ {receita.toFixed(2)}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-sm text-muted-foreground">Custo:</span>
                      <span className="font-semibold text-orange-600">R$ {custo.toFixed(2)}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-sm text-muted-foreground">Lucro:</span>
                      <span className={`font-bold ${lucro >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                        R$ {lucro.toFixed(2)} ({lucroPercent.toFixed(1)}%)
                      </span>
                    </div>
                  </div>
                </div>
              </Card>
            );
          })}
        </div>
      )}

      <PrintFormatDialog
        open={printFormatDialogOpen}
        onOpenChange={setPrintFormatDialogOpen}
        onSelectFormat={handlePrintFormatSelect}
      />
    </div>
  );
};

export default FilteredProductions;
