import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { DollarSign, ChevronDown, ChevronUp, AlertCircle, Printer, CheckCircle, FileText, X, Plus, Trash2 } from "lucide-react";
import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useLocation } from "wouter";
import { useToast } from "@/hooks/use-toast";
import { formatDistanceToNow, format, isPast, isToday } from "date-fns";
import { ptBR } from "date-fns/locale";
import { Drawer, DrawerContent, DrawerHeader, DrawerTitle, DrawerClose } from "@/components/ui/drawer";
import { PrintFormatDialog, PrintFormat, getCupomBaseStyles, printContent as printHtml } from "@/components/print-format-dialog";

interface Seamstress {
  id: string;
  name: string;
  phone: string;
  address: string;
}

interface Payment {
  id: string;
  seamstressId: string;
  batchId: string;
  amount: string;
  status: "pending" | "paid" | "overdue";
  dueDate?: string;
  paidDate?: string;
  createdAt: string;
  isOverdue?: boolean;
}

interface Batch {
  id: string;
  seamstressId: string;
  status: string;
  batchCode: string;
  productionId?: string;
  quantity?: number;
  sendDate?: string;
  expectedReturnDate?: string;
  pricePerUnit?: string;
}

interface Production {
  id: string;
  supplier: string;
  productName: string;
  paymentStatus?: string;
}

interface Advance {
  id: string;
  seamstressId: string;
  amount: string;
  date: string;
  notes?: string;
}

const Payments = () => {
  const { toast } = useToast();
  const [, navigate] = useLocation();
  const [expandedSeamstress, setExpandedSeamstress] = useState<string | null>(null);
  const [filterMonth, setFilterMonth] = useState("");
  const [filterStatus, setFilterStatus] = useState("pendente");
  const [selectedSeamstress, setSelectedSeamstress] = useState("all");
  const [activeCardFilter, setActiveCardFilter] = useState<"paid" | "pending" | "overdue" | "all" | null>(null);
  const [selectedBatch, setSelectedBatch] = useState<Batch | null>(null);
  const [drawerOpen, setDrawerOpen] = useState(false);
  const [selectedCardType, setSelectedCardType] = useState<"paid" | "pending" | "overdue" | "all" | null>(null);
  const [cardDrawerOpen, setCardDrawerOpen] = useState(false);
  const [filterSupplier, setFilterSupplier] = useState<string>("todos");
  const [advanceDialogOpen, setAdvanceDialogOpen] = useState(false);
  const [advanceSeamstressId, setAdvanceSeamstressId] = useState("");
  const [advanceAmount, setAdvanceAmount] = useState("");
  const [advanceNotes, setAdvanceNotes] = useState("");
  
  // Print format dialog state
  const [printFormatDialogOpen, setPrintFormatDialogOpen] = useState(false);
  const [pendingPrintAction, setPendingPrintAction] = useState<{
    type: 'allPayments' | 'pendingNet' | 'seamstress';
    data?: any;
  } | null>(null);

  // Helper to check if payment is overdue
  const isPaymentOverdue = (payment: Payment) => {
    if (!payment.dueDate) return false;
    return new Date(payment.dueDate) < new Date() && payment.status !== "paid";
  };

  const { data: seamstresses = [] } = useQuery({
    queryKey: ["/api/tenant/seamstresses"],
  }) as { data: Seamstress[] };

  const { data: payments = [] } = useQuery({
    queryKey: ["/api/tenant/payments"],
  }) as { data: Payment[] };

  const { data: batches = [] } = useQuery({
    queryKey: ["/api/tenant/batches"],
  }) as { data: Batch[] };

  const { data: productions = [] } = useQuery({
    queryKey: ["/api/tenant/productions"],
  }) as { data: Production[] };

  const { data: dashboardData } = useQuery({
    queryKey: ["/api/tenant/dashboard"],
  });

  const { data: advances = [] } = useQuery({
    queryKey: ["/api/tenant/advances"],
  }) as { data: Advance[] };

  const createAdvanceMutation = useMutation({
    mutationFn: async (data: { seamstressId: string; amount: number; notes: string }) => {
      return await apiRequest("POST", "/api/tenant/advances", {
        ...data,
        date: new Date().toISOString(),
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/tenant/advances"] });
      setAdvanceDialogOpen(false);
      setAdvanceSeamstressId("");
      setAdvanceAmount("");
      setAdvanceNotes("");
      toast({ title: "Sucesso", description: "Adiantamento registrado!" });
    },
    onError: (error: any) => {
      toast({ title: "Erro ao registrar adiantamento", description: error.message, variant: "destructive" });
    },
  });

  const deleteAdvanceMutation = useMutation({
    mutationFn: async (id: string) => {
      return await apiRequest("DELETE", `/api/tenant/advances/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/tenant/advances"] });
      toast({ title: "Sucesso", description: "Adiantamento removido!" });
    },
    onError: (error: any) => {
      toast({ title: "Erro ao remover adiantamento", description: error.message, variant: "destructive" });
    },
  });

  // Get advances for a seamstress
  const getSeamstressAdvances = (seamstressId: string) => {
    return advances.filter((a: Advance) => a.seamstressId === seamstressId);
  };

  // Calculate total advances for a seamstress
  const getSeamstressTotalAdvances = (seamstressId: string) => {
    return getSeamstressAdvances(seamstressId).reduce((sum, a) => sum + parseFloat(a.amount), 0);
  };

  // Get unique suppliers from productions
  const uniqueSuppliers = Array.from(new Set(productions.map((p: Production) => p.supplier).filter(Boolean))).sort();

  // Helper to get supplier from payment
  const getSupplierForPayment = (payment: Payment): string | null => {
    const batch = batches.find((b: Batch) => b.id === payment.batchId);
    if (!batch) return null;
    const production = productions.find((p: Production) => p.id === batch.productionId);
    return production?.supplier || null;
  };

  // Helper to check if production is paid
  const isProductionPaid = (payment: Payment): boolean => {
    const batch = batches.find((b: Batch) => b.id === payment.batchId);
    if (!batch) return false;
    const production = productions.find((p: Production) => p.id === batch.productionId);
    return production?.paymentStatus === "Pago";
  };

  // Helper to get production for payment
  const getProductionForPayment = (payment: Payment): Production | null => {
    const batch = batches.find((b: Batch) => b.id === payment.batchId);
    if (!batch) return null;
    return productions.find((p: Production) => p.id === batch.productionId) || null;
  };

  const handleOpenBatchDetails = (batch: Batch) => {
    setSelectedBatch(batch);
    setDrawerOpen(true);
  };

  const handleOpenCardDetails = (cardType: "paid" | "pending" | "overdue" | "all") => {
    setSelectedCardType(cardType);
    setCardDrawerOpen(true);
  };

  // Get payments by card type
  const getPaymentsByCardType = (type: "paid" | "pending" | "overdue" | "all") => {
    if (type === "paid") {
      return payments.filter((p: Payment) => p.status === "paid");
    } else if (type === "pending") {
      return payments.filter((p: Payment) => p.status === "pending" && !isPaymentOverdue(p));
    } else if (type === "overdue") {
      return payments.filter((p: Payment) => isPaymentOverdue(p));
    } else {
      return payments;
    }
  };

  // Mark payment as paid
  const markPaidMutation = useMutation({
    mutationFn: async (paymentId: string) => {
      return await apiRequest("PATCH", `/api/tenant/payments/${paymentId}`, {
        status: "paid",
        paidDate: new Date().toISOString(),
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/tenant/payments"] });
      queryClient.invalidateQueries({ queryKey: ["/api/tenant/dashboard"] });
      toast({
        title: "Sucesso",
        description: "Pagamento marcado como pago!",
      });
    },
    onError: (error: any) => {
      toast({ title: "Erro ao marcar pagamento", description: error.message, variant: "destructive" });
    },
  });

  // Calcular totais
  const totalPaid = payments
    .filter((p: Payment) => p.status === "paid")
    .reduce((sum: number, p: Payment) => sum + parseFloat(p.amount), 0);

  const totalPending = payments
    .filter((p: Payment) => p.status === "pending" && !isPaymentOverdue(p))
    .reduce((sum: number, p: Payment) => sum + parseFloat(p.amount), 0);

  const totalOverdue = payments
    .filter((p: Payment) => isPaymentOverdue(p))
    .reduce((sum: number, p: Payment) => sum + parseFloat(p.amount), 0);

  const producaoConcluida = (dashboardData as any)?.producaoConcluida || 0;

  // Filter payments by seamstress
  const getSeamstressPayments = (seamstressId: string) => {
    let filtered = payments.filter((p: Payment) => p.seamstressId === seamstressId);

    // Exclude payments for productions that are marked as paid
    filtered = filtered.filter((p: Payment) => !isProductionPaid(p));

    // Filter by supplier
    if (filterSupplier !== "todos") {
      filtered = filtered.filter((p: Payment) => getSupplierForPayment(p) === filterSupplier);
    }

    // Apply card filter if active
    if (activeCardFilter === "paid") {
      filtered = filtered.filter((p: Payment) => p.status === "paid");
    } else if (activeCardFilter === "pending") {
      filtered = filtered.filter((p: Payment) => p.status === "pending" && !isPaymentOverdue(p));
    } else if (activeCardFilter === "overdue") {
      filtered = filtered.filter((p: Payment) => isPaymentOverdue(p));
    } else if (activeCardFilter === "all") {
      // Show all payments
    } else {
      // Default filter (no card filter active)
      if (filterStatus === "todos") {
        // Show all payments (including paid)
      } else {
        // Show all non-paid payments (both pending and overdue)
        filtered = filtered.filter((p: Payment) => p.status !== "paid");
        if (filterStatus === "pendente") {
          // Show only on-time pending (not overdue)
          filtered = filtered.filter((p: Payment) => !isPaymentOverdue(p));
        } else if (filterStatus === "atrasados") {
          filtered = filtered.filter((p: Payment) => isPaymentOverdue(p));
        } else if (filterStatus === "atrasados_pendentes") {
          // Show both atrasados and pendentes together - already filtered to non-paid above
        }
      }
    }

    return filtered;
  };

  const getSeamstressBalance = (seamstressId: string) => {
    const sPayments = getSeamstressPayments(seamstressId);
    const paid = sPayments
      .filter((p: Payment) => p.status === "paid")
      .reduce((sum: number, p: Payment) => sum + parseFloat(p.amount), 0);

    const pending = sPayments
      .filter((p: Payment) => p.status === "pending" || p.status === "overdue")
      .reduce((sum: number, p: Payment) => sum + parseFloat(p.amount), 0);

    return { paid, pending };
  };

  // Check if payment is overdue
  const getPaymentStatus = (payment: Payment) => {
    if (payment.status === "paid") return "paid";
    if (!payment.dueDate) return payment.status || "pending";
    
    const dueDate = new Date(payment.dueDate);
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    
    if (isPast(dueDate) && !isToday(dueDate)) {
      return "overdue";
    }
    return payment.status || "pending";
  };

  // Update due date mutation
  const updateDueDateMutation = useMutation({
    mutationFn: async ({ paymentId, dueDate }: { paymentId: string; dueDate: string }) => {
      return await apiRequest("PATCH", `/api/tenant/payments/${paymentId}`, {
        dueDate: new Date(dueDate).toISOString(),
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/tenant/payments"] });
      toast({
        title: "Sucesso",
        description: "Data de vencimento atualizada!",
      });
    },
    onError: (error: any) => {
      toast({ title: "Erro ao atualizar vencimento", description: error.message, variant: "destructive" });
    },
  });

  // Only show seamstresses that have pending payments
  const filteredSeamstresses = seamstresses.filter((s: Seamstress) => {
    let sPendingPayments = payments.filter((p: Payment) => {
      if (p.seamstressId !== s.id) return false;
      
      // Exclude payments for productions that are marked as paid
      if (isProductionPaid(p)) return false;
      
      // Filter by supplier
      if (filterSupplier !== "todos" && getSupplierForPayment(p) !== filterSupplier) return false;
      
      // Apply card filter if active
      if (activeCardFilter === "paid") {
        return p.status === "paid";
      } else if (activeCardFilter === "pending") {
        return p.status === "pending" && !isPaymentOverdue(p);
      } else if (activeCardFilter === "overdue") {
        return isPaymentOverdue(p);
      } else {
        // Default filter (not card filtered)
        if (filterStatus === "todos") {
          return true; // Show all payments
        }
        if (p.status === "paid") return false;
        if (filterStatus === "pendente") {
          return !isPaymentOverdue(p);
        } else if (filterStatus === "atrasados") {
          return isPaymentOverdue(p);
        } else if (filterStatus === "atrasados_pendentes") {
          return true; // Show both
        }
        return true;
      }
    });
    
    return sPendingPayments.length > 0 && (selectedSeamstress === "all" || s.id === selectedSeamstress);
  });

  // Print format dialog functions
  const openPrintAllPaymentsDialog = () => {
    setPendingPrintAction({ type: 'allPayments' });
    setPrintFormatDialogOpen(true);
  };

  const openPrintPendingNetDialog = () => {
    setPendingPrintAction({ type: 'pendingNet' });
    setPrintFormatDialogOpen(true);
  };

  const openPrintSeamstressDialog = (seamstress: Seamstress) => {
    setPendingPrintAction({ type: 'seamstress', data: seamstress });
    setPrintFormatDialogOpen(true);
  };

  const handlePrintFormatSelect = (format: PrintFormat) => {
    setPrintFormatDialogOpen(false);
    if (!pendingPrintAction) return;

    switch (pendingPrintAction.type) {
      case 'allPayments':
        handlePrintAllPayments(format);
        break;
      case 'pendingNet':
        handlePrintPendingWithNet(format);
        break;
      case 'seamstress':
        handlePrintSeamstress(pendingPrintAction.data, format);
        break;
    }
    setPendingPrintAction(null);
  };

  const handlePrintAllPayments = (format: PrintFormat = 'a4') => {
    const totalPaidAmount = payments
      .filter((p: Payment) => p.status === "paid")
      .reduce((sum: number, p: Payment) => sum + parseFloat(p.amount), 0);

    const totalPendingAmount = payments
      .filter((p: Payment) => p.status === "pending" || p.status === "overdue")
      .reduce((sum: number, p: Payment) => sum + parseFloat(p.amount), 0);

    let paymentRows = '';
    seamstresses.forEach((seamstress: Seamstress) => {
      const sPayments = payments.filter((p: Payment) => p.seamstressId === seamstress.id);
      if (sPayments.length === 0) return;

      sPayments.forEach((payment: Payment) => {
        const batch = Array.isArray(batches) ? batches.find((b: Batch) => b.id === payment.batchId) : undefined;
        const production = batch ? productions.find((p: Production) => p.id === batch.productionId) : undefined;
        const dueDate = payment.dueDate ? new Date(payment.dueDate).toLocaleDateString('pt-BR') : 'N/A';
        const status = getPaymentStatus(payment);
        const statusLabel = status === "paid" ? "Pago" : status === "overdue" ? "Atrasado" : "Pendente";
        const quantity = batch?.quantity || 0;
        const unitPrice = batch?.pricePerUnit ? parseFloat(batch.pricePerUnit) : 0;

        paymentRows += `
          <tr>
            <td>${seamstress.name}</td>
            <td>${production?.productName || '-'}</td>
            <td>${batch?.batchCode || payment.batchId.slice(0, 8)}</td>
            <td>${quantity}</td>
            <td>R$ ${unitPrice.toFixed(2)}</td>
            <td>R$ ${parseFloat(payment.amount).toFixed(2)}</td>
            <td>${statusLabel}</td>
            <td>${dueDate}</td>
          </tr>
        `;
      });
      
      // Add advances (vales) for this seamstress
      const seamstressAdvances = advances.filter((a: Advance) => a.seamstressId === seamstress.id);
      seamstressAdvances.forEach((advance: Advance) => {
        const advanceDate = new Date(advance.date).toLocaleDateString('pt-BR');
        paymentRows += `
          <tr style="background-color: #FEF3C7;">
            <td>${seamstress.name}</td>
            <td colspan="4"><strong>VALE</strong> ${advance.notes || ''}</td>
            <td style="color: #DC2626;">- R$ ${parseFloat(advance.amount).toFixed(2)}</td>
            <td>Vale</td>
            <td>${advanceDate}</td>
          </tr>
        `;
      });
    });

    const printContent = `
      <!DOCTYPE html>
      <html lang="pt-BR">
      <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Relatório de Pagamentos</title>
        <style>
          * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
          }
          body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #fff;
            padding: 20px;
          }
          .container {
            max-width: 210mm;
            margin: 0 auto;
          }
          .header {
            text-align: center;
            margin-bottom: 30px;
            border-bottom: 3px solid #8B5CF6;
            padding-bottom: 15px;
          }
          .header h1 {
            font-size: 28px;
            color: #1F2937;
            margin-bottom: 5px;
          }
          .header p {
            font-size: 12px;
            color: #6B7280;
            margin-bottom: 10px;
          }
          .summary {
            display: grid;
            grid-template-columns: 1fr 1fr 1fr;
            gap: 15px;
            margin-bottom: 30px;
          }
          .summary-box {
            border: 1px solid #E5E7EB;
            padding: 15px;
            border-radius: 6px;
            text-align: center;
          }
          .summary-box.green {
            background-color: #ECFDF5;
            border-color: #10B981;
          }
          .summary-box.red {
            background-color: #FEF2F2;
            border-color: #EF4444;
          }
          .summary-box.purple {
            background-color: #F3E8FF;
            border-color: #A855F7;
          }
          .summary-box .label {
            font-size: 12px;
            color: #6B7280;
            font-weight: 600;
          }
          .summary-box .value {
            font-size: 20px;
            font-weight: 700;
            margin-top: 8px;
            color: #1F2937;
          }
          .summary-box.green .value {
            color: #10B981;
          }
          .summary-box.red .value {
            color: #EF4444;
          }
          .summary-box.purple .value {
            color: #A855F7;
          }
          table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
          }
          table thead {
            background-color: #8B5CF6;
            color: white;
          }
          table th {
            padding: 10px;
            text-align: left;
            font-size: 12px;
            font-weight: 600;
          }
          table td {
            padding: 10px;
            border-bottom: 1px solid #E5E7EB;
            font-size: 12px;
          }
          table tbody tr:hover {
            background-color: #F9FAFB;
          }
          .footer {
            text-align: center;
            margin-top: 30px;
            padding-top: 20px;
            border-top: 1px solid #E5E7EB;
            font-size: 11px;
            color: #6B7280;
          }
          @media print {
            body {
              padding: 0;
            }
          }
        </style>
      </head>
      <body>
        <div class="container">
          <div class="header">
            <h1>Relatório de Pagamentos</h1>
            <p>GoFast Produções</p>
            <p>Gerado em: ${new Date().toLocaleDateString('pt-BR')} às ${new Date().toLocaleTimeString('pt-BR')}</p>
          </div>

          <div class="summary">
            <div class="summary-box green">
              <div class="label">Total Pago</div>
              <div class="value">R$ ${totalPaidAmount.toFixed(2)}</div>
            </div>
            <div class="summary-box red">
              <div class="label">Total Pendente/Atrasado</div>
              <div class="value">R$ ${totalPendingAmount.toFixed(2)}</div>
            </div>
            <div class="summary-box purple">
              <div class="label">Total Geral</div>
              <div class="value">R$ ${(totalPaidAmount + totalPendingAmount).toFixed(2)}</div>
            </div>
          </div>

          <h2 style="margin-bottom: 15px; font-size: 14px; font-weight: 700; color: #1F2937;">Detalhes dos Pagamentos</h2>
          <table>
            <thead>
              <tr>
                <th>Costureira</th>
                <th>Produção</th>
                <th>Código Lote</th>
                <th>Qtd</th>
                <th>Valor Unit.</th>
                <th>Total</th>
                <th>Status</th>
                <th>Vencimento</th>
              </tr>
            </thead>
            <tbody>
              ${paymentRows}
            </tbody>
          </table>

          <div class="footer">
            <p>Este é um documento gerado automaticamente por GoFast Produções</p>
          </div>
        </div>
      </body>
      </html>
    `;

    let content = '';
    if (format === 'cupom') {
      let paymentLines = '';
      seamstresses.forEach((seamstress: Seamstress) => {
        const sPayments = payments.filter((p: Payment) => p.seamstressId === seamstress.id);
        sPayments.forEach((payment: Payment) => {
          const batch = Array.isArray(batches) ? batches.find((b: Batch) => b.id === payment.batchId) : undefined;
          const status = getPaymentStatus(payment);
          const statusLabel = status === "paid" ? "Pago" : status === "overdue" ? "Atraso" : "Pend";
          paymentLines += `
            <div class="item">
              <div class="item-row"><span>${seamstress.name.substring(0, 15)}</span><span>${statusLabel}</span></div>
              <div class="item-row"><span>${batch?.batchCode || payment.batchId.slice(0, 8)}</span><span>R$ ${parseFloat(payment.amount).toFixed(2)}</span></div>
            </div>
          `;
        });
      });

      content = `<!DOCTYPE html><html lang="pt-BR"><head><meta charset="UTF-8">
        <title>Pagamentos</title>
        <style>${getCupomBaseStyles()}</style>
      </head><body>
        <div class="cupom">
          <div class="header">GOFAST PRODUCOES</div>
          <div class="title">PAGAMENTOS</div>
          <div class="divider"></div>
          <div class="total">PAGO: R$ ${totalPaidAmount.toFixed(2)}</div>
          <div class="total">PEND: R$ ${totalPendingAmount.toFixed(2)}</div>
          <div class="total">TOTAL: R$ ${(totalPaidAmount + totalPendingAmount).toFixed(2)}</div>
          <div class="divider"></div>
          ${paymentLines}
          <div class="divider"></div>
          <div class="footer">${new Date().toLocaleString('pt-BR')}</div>
        </div>
      </body></html>`;
    } else {
      content = printContent;
    }
    
    printHtml(content);
  };

  // Print only pending/overdue payments with net amounts (total - advances)
  const handlePrintPendingWithNet = (format: PrintFormat = 'a4') => {
    // Group pending/overdue payments by seamstress and calculate net amounts
    const seamstressData: { 
      seamstress: Seamstress; 
      payments: Payment[]; 
      totalPending: number;
      totalAdvances: number;
      netAmount: number;
    }[] = [];

    seamstresses.forEach((seamstress: Seamstress) => {
      // Get only pending/overdue payments for this seamstress
      const pendingPayments = payments.filter((p: Payment) => 
        p.seamstressId === seamstress.id && 
        p.status !== "paid" && 
        !isProductionPaid(p)
      );
      
      if (pendingPayments.length === 0) return;

      const totalPending = pendingPayments.reduce((sum, p) => sum + parseFloat(p.amount), 0);
      const totalAdvances = getSeamstressTotalAdvances(seamstress.id);
      const netAmount = totalPending - totalAdvances;

      seamstressData.push({
        seamstress,
        payments: pendingPayments,
        totalPending,
        totalAdvances,
        netAmount
      });
    });

    // Calculate grand totals
    const grandTotalPending = seamstressData.reduce((sum, s) => sum + s.totalPending, 0);
    const grandTotalAdvances = seamstressData.reduce((sum, s) => sum + s.totalAdvances, 0);
    const grandTotalNet = seamstressData.reduce((sum, s) => sum + s.netAmount, 0);

    let tableRows = '';
    seamstressData.forEach(({ seamstress, payments, totalPending, totalAdvances, netAmount }) => {
      // Add payment rows for this seamstress
      payments.forEach((payment: Payment, index: number) => {
        const batch = batches.find((b: Batch) => b.id === payment.batchId);
        const production = batch ? productions.find((p: Production) => p.id === batch.productionId) : undefined;
        const dueDate = payment.dueDate ? new Date(payment.dueDate).toLocaleDateString('pt-BR') : 'N/A';
        const status = getPaymentStatus(payment);
        const statusLabel = status === "overdue" ? "Atrasado" : "Pendente";
        const statusColor = status === "overdue" ? "#DC2626" : "#F59E0B";
        const quantity = batch?.quantity || 0;
        const unitPrice = batch?.pricePerUnit ? parseFloat(batch.pricePerUnit) : 0;

        tableRows += `
          <tr>
            ${index === 0 ? `<td rowspan="${payments.length + 1}" style="vertical-align: top; font-weight: 600; background-color: #F9FAFB;">${seamstress.name}</td>` : ''}
            <td>${production?.productName || '-'}</td>
            <td style="font-family: monospace; font-size: 11px;">${batch?.batchCode || '-'}</td>
            <td>${quantity}</td>
            <td>R$ ${unitPrice.toFixed(2)}</td>
            <td>R$ ${parseFloat(payment.amount).toFixed(2)}</td>
            <td><span style="color: ${statusColor}; font-weight: 500;">${statusLabel}</span></td>
            <td>${dueDate}</td>
          </tr>
        `;
      });

      // Add summary row for this seamstress
      tableRows += `
        <tr style="background-color: ${netAmount > 0 ? '#E0F2FE' : '#FEE2E2'}; font-weight: 600;">
          <td colspan="4" style="text-align: right;">
            ${totalAdvances > 0 ? `<span style="color: #92400E;">Vales: - R$ ${totalAdvances.toFixed(2)}</span>` : ''}
          </td>
          <td colspan="3" style="text-align: right;">
            <span style="color: ${netAmount > 0 ? '#0369A1' : '#DC2626'};">
              LÍQUIDO: R$ ${netAmount.toFixed(2)}
            </span>
          </td>
          <td></td>
        </tr>
        <tr><td colspan="8" style="height: 10px; border: none;"></td></tr>
      `;
    });

    const printContent = `
      <!DOCTYPE html>
      <html lang="pt-BR">
      <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Pagamentos Pendentes - Valor Líquido</title>
        <style>
          * { margin: 0; padding: 0; box-sizing: border-box; }
          body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #fff;
            padding: 20px;
            font-size: 12px;
          }
          .container { max-width: 210mm; margin: 0 auto; }
          .header {
            text-align: center;
            margin-bottom: 25px;
            border-bottom: 3px solid #F97316;
            padding-bottom: 15px;
          }
          .header h1 { font-size: 22px; color: #1F2937; margin-bottom: 5px; }
          .header p { font-size: 11px; color: #6B7280; margin-bottom: 5px; }
          .summary {
            display: grid;
            grid-template-columns: 1fr 1fr 1fr;
            gap: 12px;
            margin-bottom: 25px;
          }
          .summary-box {
            border: 2px solid;
            padding: 12px;
            border-radius: 6px;
            text-align: center;
          }
          .summary-box.orange { background-color: #FFF7ED; border-color: #F97316; }
          .summary-box.amber { background-color: #FFFBEB; border-color: #F59E0B; }
          .summary-box.blue { background-color: #EFF6FF; border-color: #3B82F6; }
          .summary-box .label { font-size: 11px; color: #6B7280; font-weight: 600; }
          .summary-box .value { font-size: 18px; font-weight: 700; margin-top: 6px; }
          .summary-box.orange .value { color: #EA580C; }
          .summary-box.amber .value { color: #D97706; }
          .summary-box.blue .value { color: #2563EB; }
          table { width: 100%; border-collapse: collapse; margin-bottom: 20px; }
          table thead { background-color: #F97316; color: white; }
          table th { padding: 8px; text-align: left; font-size: 11px; font-weight: 600; }
          table td { padding: 8px; border-bottom: 1px solid #E5E7EB; font-size: 11px; }
          .footer {
            text-align: center;
            margin-top: 25px;
            padding-top: 15px;
            border-top: 1px solid #E5E7EB;
            font-size: 10px;
            color: #6B7280;
          }
          @media print { body { padding: 0; } }
        </style>
      </head>
      <body>
        <div class="container">
          <div class="header">
            <h1>Pagamentos Pendentes - Valor Líquido</h1>
            <p>GoFast Produções</p>
            <p>Gerado em: ${new Date().toLocaleDateString('pt-BR')} às ${new Date().toLocaleTimeString('pt-BR')}</p>
          </div>

          <div class="summary">
            <div class="summary-box orange">
              <div class="label">Total Pendente/Atrasado</div>
              <div class="value">R$ ${grandTotalPending.toFixed(2)}</div>
            </div>
            <div class="summary-box amber">
              <div class="label">Total de Vales</div>
              <div class="value">- R$ ${grandTotalAdvances.toFixed(2)}</div>
            </div>
            <div class="summary-box blue">
              <div class="label">TOTAL LÍQUIDO A PAGAR</div>
              <div class="value">R$ ${grandTotalNet.toFixed(2)}</div>
            </div>
          </div>

          <h2 style="margin-bottom: 12px; font-size: 13px; font-weight: 700; color: #1F2937;">Detalhes por Costureira</h2>
          <table>
            <thead>
              <tr>
                <th>Costureira</th>
                <th>Produção</th>
                <th>Lote</th>
                <th>Qtd</th>
                <th>Valor Unit.</th>
                <th>Total</th>
                <th>Status</th>
                <th>Vencimento</th>
              </tr>
            </thead>
            <tbody>
              ${tableRows}
            </tbody>
          </table>

          <div class="footer">
            <p>Este é um documento gerado automaticamente por GoFast Produções</p>
            <p style="margin-top: 5px;">Valores líquidos = Total pendente - Vales (adiantamentos)</p>
          </div>
        </div>
      </body>
      </html>
    `;

    let content = '';
    if (format === 'cupom') {
      let seamstressLines = '';
      seamstressData.forEach(({ seamstress, totalPending, totalAdvances, netAmount }) => {
        seamstressLines += `
          <div class="item">
            <div class="item-header">${seamstress.name.substring(0, 20)}</div>
            <div class="item-row"><span>Bruto:</span><span>R$ ${totalPending.toFixed(2)}</span></div>
            ${totalAdvances > 0 ? `<div class="item-row"><span>Vales:</span><span>-R$ ${totalAdvances.toFixed(2)}</span></div>` : ''}
            <div class="item-row"><strong>Liquido:</strong><strong>R$ ${netAmount.toFixed(2)}</strong></div>
          </div>
        `;
      });

      content = `<!DOCTYPE html><html lang="pt-BR"><head><meta charset="UTF-8">
        <title>Pagamentos Pendentes</title>
        <style>${getCupomBaseStyles()}</style>
      </head><body>
        <div class="cupom">
          <div class="header">GOFAST PRODUCOES</div>
          <div class="title">PENDENTES LIQUIDO</div>
          <div class="divider"></div>
          <div class="total">BRUTO: R$ ${grandTotalPending.toFixed(2)}</div>
          <div class="total">VALES: -R$ ${grandTotalAdvances.toFixed(2)}</div>
          <div class="total">LIQUIDO: R$ ${grandTotalNet.toFixed(2)}</div>
          <div class="divider"></div>
          ${seamstressLines}
          <div class="divider"></div>
          <div class="footer">${new Date().toLocaleString('pt-BR')}</div>
        </div>
      </body></html>`;
    } else {
      content = printContent;
    }
    
    printHtml(content);
  };

  const handlePrintSinglePayment = (payment: Payment, seamstress: Seamstress) => {
    const batch = Array.isArray(batches) ? batches.find((b: Batch) => b.id === payment.batchId) : undefined;
    const production = batch ? productions.find((p: Production) => p.id === batch.productionId) : undefined;
    const dueDate = payment.dueDate ? new Date(payment.dueDate).toLocaleDateString('pt-BR') : 'N/A';
    const paidDate = payment.paidDate ? new Date(payment.paidDate).toLocaleDateString('pt-BR') : 'N/A';
    const status = getPaymentStatus(payment);
    const statusLabel = status === "paid" ? "Pago" : status === "overdue" ? "Atrasado" : "Pendente";
    const quantity = batch?.quantity || 0;
    const unitPrice = batch?.pricePerUnit ? parseFloat(batch.pricePerUnit) : 0;

    const printContent = `
      <!DOCTYPE html>
      <html lang="pt-BR">
      <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Comprovante de Pagamento</title>
        <style>
          * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
          }
          body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #fff;
            padding: 40px;
          }
          .container {
            max-width: 210mm;
            margin: 0 auto;
            border: 2px solid #8B5CF6;
            border-radius: 8px;
            padding: 40px;
            background-color: #F9FAFB;
          }
          .header {
            text-align: center;
            margin-bottom: 40px;
            border-bottom: 3px solid #8B5CF6;
            padding-bottom: 20px;
          }
          .header h1 {
            font-size: 32px;
            color: #1F2937;
            margin-bottom: 10px;
            font-weight: 700;
          }
          .header p {
            font-size: 13px;
            color: #6B7280;
            margin-bottom: 5px;
          }
          .section {
            margin-bottom: 30px;
          }
          .section-title {
            font-size: 13px;
            font-weight: 700;
            color: #8B5CF6;
            text-transform: uppercase;
            margin-bottom: 15px;
            border-bottom: 2px solid #E5E7EB;
            padding-bottom: 10px;
          }
          .info-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 20px;
            margin-bottom: 20px;
          }
          .info-item {
            display: flex;
            flex-direction: column;
          }
          .info-label {
            font-size: 12px;
            font-weight: 600;
            color: #6B7280;
            text-transform: uppercase;
            margin-bottom: 5px;
          }
          .info-value {
            font-size: 14px;
            color: #1F2937;
            font-weight: 500;
          }
          .status-box {
            padding: 15px;
            border-radius: 6px;
            text-align: center;
            margin-bottom: 20px;
          }
          .status-box.pending {
            background-color: #FEF3C7;
            border: 2px solid #FCD34D;
          }
          .status-box.paid {
            background-color: #ECFDF5;
            border: 2px solid #10B981;
          }
          .status-box.overdue {
            background-color: #FEE2E2;
            border: 2px solid #EF4444;
          }
          .status-text {
            font-size: 16px;
            font-weight: 700;
          }
          .amount-display {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 20px;
            background-color: white;
            border: 2px solid #8B5CF6;
            border-radius: 6px;
            margin-bottom: 20px;
          }
          .amount-label {
            font-size: 14px;
            font-weight: 600;
            color: #6B7280;
          }
          .amount-value {
            font-size: 28px;
            font-weight: 700;
            color: #8B5CF6;
          }
          .footer {
            text-align: center;
            margin-top: 40px;
            padding-top: 20px;
            border-top: 1px solid #E5E7EB;
            font-size: 11px;
            color: #6B7280;
          }
          @media print {
            body {
              padding: 0;
            }
            .container {
              border: none;
              box-shadow: none;
            }
          }
        </style>
      </head>
      <body>
        <div class="container">
          <div class="header">
            <h1>Comprovante de Pagamento</h1>
            <p>GoFast Produções</p>
            <p>Gerado em: ${new Date().toLocaleDateString('pt-BR')} às ${new Date().toLocaleTimeString('pt-BR')}</p>
          </div>

          <div class="section">
            <div class="section-title">Dados da Costureira</div>
            <div class="info-grid">
              <div class="info-item">
                <span class="info-label">Nome</span>
                <span class="info-value">${seamstress.name}</span>
              </div>
              <div class="info-item">
                <span class="info-label">Telefone</span>
                <span class="info-value">${seamstress.phone}</span>
              </div>
              <div class="info-item">
                <span class="info-label">Endereço</span>
                <span class="info-value">${seamstress.address}</span>
              </div>
              <div class="info-item">
                <span class="info-label">Código do Lote</span>
                <span class="info-value">${batch?.batchCode || payment.batchId.slice(0, 8)}</span>
              </div>
              <div class="info-item">
                <span class="info-label">Produção</span>
                <span class="info-value">${production?.productName || '-'}</span>
              </div>
              <div class="info-item">
                <span class="info-label">Quantidade de Peças</span>
                <span class="info-value">${quantity} peças</span>
              </div>
              <div class="info-item">
                <span class="info-label">Valor por Unidade</span>
                <span class="info-value">R$ ${unitPrice.toFixed(2)}</span>
              </div>
            </div>
          </div>

          <div class="section">
            <div class="section-title">Detalhes do Pagamento</div>
            <div class="status-box ${status}">
              <div class="status-text">${statusLabel}</div>
            </div>
            <div class="amount-display">
              <span class="amount-label">Valor do Pagamento</span>
              <span class="amount-value">R$ ${parseFloat(payment.amount).toFixed(2)}</span>
            </div>
            <div class="info-grid">
              <div class="info-item">
                <span class="info-label">Data de Vencimento</span>
                <span class="info-value">${dueDate}</span>
              </div>
              <div class="info-item">
                <span class="info-label">Data do Pagamento</span>
                <span class="info-value">${status === 'paid' ? paidDate : '---'}</span>
              </div>
              <div class="info-item">
                <span class="info-label">ID do Pagamento</span>
                <span class="info-value" style="font-family: monospace; font-size: 12px;">${payment.id.slice(0, 12)}...</span>
              </div>
            </div>
          </div>

          <div class="footer">
            <p>Este é um documento gerado automaticamente por GoFast Produções</p>
            <p style="margin-top: 10px;">Guarde este comprovante para fins de controle</p>
          </div>
        </div>
      </body>
      </html>
    `;

    const printWindow = window.open('', '', 'width=800,height=600');
    printWindow?.document.write(printContent);
    printWindow?.document.close();
    printWindow?.print();
  };

  const handlePrintSeamstress = (seamstress: Seamstress, format: PrintFormat = 'a4') => {
    const sPayments = getSeamstressPayments(seamstress.id);
    const balance = getSeamstressBalance(seamstress.id);
    const seamstressAdvances = getSeamstressAdvances(seamstress.id);
    const totalAdvances = getSeamstressTotalAdvances(seamstress.id);

    let paymentRows = '';
    sPayments.forEach((payment: Payment) => {
      const batch = Array.isArray(batches) ? batches.find((b: Batch) => b.id === payment.batchId) : undefined;
      const production = batch ? productions.find((p: Production) => p.id === batch.productionId) : undefined;
      const dueDate = payment.dueDate ? new Date(payment.dueDate).toLocaleDateString('pt-BR') : 'N/A';
      const status = getPaymentStatus(payment);
      const statusLabel = status === "paid" ? "Pago" : status === "overdue" ? "Atrasado" : "Pendente";
      const quantity = batch?.quantity || 0;
      const unitPrice = batch?.pricePerUnit ? parseFloat(batch.pricePerUnit) : 0;

      paymentRows += `
        <tr>
          <td>${production?.productName || '-'}</td>
          <td>${batch?.batchCode || payment.batchId.slice(0, 8)}</td>
          <td>${quantity}</td>
          <td>R$ ${unitPrice.toFixed(2)}</td>
          <td>R$ ${parseFloat(payment.amount).toFixed(2)}</td>
          <td>${statusLabel}</td>
          <td>${dueDate}</td>
        </tr>
      `;
    });
    
    // Add advances (vales)
    seamstressAdvances.forEach((advance: Advance) => {
      const advanceDate = new Date(advance.date).toLocaleDateString('pt-BR');
      paymentRows += `
        <tr style="background-color: #FEF3C7;">
          <td colspan="4"><strong>VALE</strong> ${advance.notes || ''}</td>
          <td style="color: #DC2626;">- R$ ${parseFloat(advance.amount).toFixed(2)}</td>
          <td>Vale</td>
          <td>${advanceDate}</td>
        </tr>
      `;
    });

    const printContent = `
      <!DOCTYPE html>
      <html lang="pt-BR">
      <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Extrato de Pagamentos</title>
        <style>
          * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
          }
          body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #fff;
            padding: 20px;
          }
          .container {
            max-width: 210mm;
            margin: 0 auto;
          }
          .header {
            text-align: center;
            margin-bottom: 30px;
            border-bottom: 3px solid #8B5CF6;
            padding-bottom: 15px;
          }
          .header h1 {
            font-size: 24px;
            color: #1F2937;
            margin-bottom: 10px;
          }
          .header p {
            font-size: 12px;
            color: #6B7280;
            margin-bottom: 5px;
          }
          .seamstress-info {
            background-color: #F3E8FF;
            border: 1px solid #A855F7;
            padding: 15px;
            border-radius: 6px;
            margin-bottom: 20px;
          }
          .seamstress-info .info-row {
            display: grid;
            grid-template-columns: 150px 1fr;
            margin-bottom: 8px;
            font-size: 12px;
          }
          .seamstress-info .label {
            font-weight: 600;
            color: #7C3AED;
          }
          .seamstress-info .value {
            color: #1F2937;
          }
          .summary {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 15px;
            margin-bottom: 30px;
          }
          .summary-box {
            border: 1px solid #E5E7EB;
            padding: 15px;
            border-radius: 6px;
            text-align: center;
          }
          .summary-box.green {
            background-color: #ECFDF5;
            border-color: #10B981;
          }
          .summary-box.red {
            background-color: #FEF2F2;
            border-color: #EF4444;
          }
          .summary-box .label {
            font-size: 12px;
            color: #6B7280;
            font-weight: 600;
          }
          .summary-box .value {
            font-size: 18px;
            font-weight: 700;
            margin-top: 8px;
          }
          .summary-box.green .value {
            color: #10B981;
          }
          .summary-box.red .value {
            color: #EF4444;
          }
          table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
          }
          table thead {
            background-color: #8B5CF6;
            color: white;
          }
          table th {
            padding: 10px;
            text-align: left;
            font-size: 12px;
            font-weight: 600;
          }
          table td {
            padding: 10px;
            border-bottom: 1px solid #E5E7EB;
            font-size: 12px;
          }
          table tbody tr:hover {
            background-color: #F9FAFB;
          }
          .footer {
            text-align: center;
            margin-top: 30px;
            padding-top: 20px;
            border-top: 1px solid #E5E7EB;
            font-size: 11px;
            color: #6B7280;
          }
          @media print {
            body {
              padding: 0;
            }
          }
        </style>
      </head>
      <body>
        <div class="container">
          <div class="header">
            <h1>Extrato de Pagamentos</h1>
            <p>GoFast Produções</p>
            <p>Gerado em: ${new Date().toLocaleDateString('pt-BR')} às ${new Date().toLocaleTimeString('pt-BR')}</p>
          </div>

          <div class="seamstress-info">
            <div class="info-row">
              <span class="label">Costureira:</span>
              <span class="value">${seamstress.name}</span>
            </div>
            <div class="info-row">
              <span class="label">Telefone:</span>
              <span class="value">${seamstress.phone}</span>
            </div>
            <div class="info-row">
              <span class="label">Endereço:</span>
              <span class="value">${seamstress.address}</span>
            </div>
          </div>

          <div class="summary">
            <div class="summary-box green">
              <div class="label">Total Pago</div>
              <div class="value">R$ ${balance.paid.toFixed(2)}</div>
            </div>
            <div class="summary-box red">
              <div class="label">Total Pendente</div>
              <div class="value">R$ ${balance.pending.toFixed(2)}</div>
            </div>
          </div>

          <h2 style="margin-bottom: 15px; font-size: 14px; font-weight: 700; color: #1F2937;">Histórico de Pagamentos</h2>
          <table>
            <thead>
              <tr>
                <th>Produção</th>
                <th>Código Lote</th>
                <th>Qtd</th>
                <th>Valor Unit.</th>
                <th>Total</th>
                <th>Status</th>
                <th>Vencimento</th>
              </tr>
            </thead>
            <tbody>
              ${paymentRows}
            </tbody>
          </table>
          
          ${totalAdvances > 0 ? `
          <div style="background-color: #FEF3C7; border: 2px solid #F59E0B; padding: 15px; border-radius: 6px; margin-top: 20px;">
            <h3 style="font-size: 14px; font-weight: 700; color: #92400E; margin-bottom: 10px;">Total de Vales (Adiantamentos)</h3>
            <p style="font-size: 18px; font-weight: 700; color: #DC2626;">- R$ ${totalAdvances.toFixed(2)}</p>
          </div>
          ` : ''}
          
          <div style="background-color: #E0E7FF; border: 2px solid #6366F1; padding: 15px; border-radius: 6px; margin-top: 20px;">
            <h3 style="font-size: 14px; font-weight: 700; color: #3730A3; margin-bottom: 10px;">Saldo Líquido</h3>
            <p style="font-size: 20px; font-weight: 700; color: #1E40AF;">R$ ${(balance.pending - totalAdvances).toFixed(2)}</p>
          </div>

          <div class="footer">
            <p>Este é um documento gerado automaticamente por GoFast Produções</p>
          </div>
        </div>
      </body>
      </html>
    `;

    let content = '';
    if (format === 'cupom') {
      let paymentLines = '';
      sPayments.forEach((payment: Payment) => {
        const batch = Array.isArray(batches) ? batches.find((b: Batch) => b.id === payment.batchId) : undefined;
        const status = getPaymentStatus(payment);
        const statusLabel = status === "paid" ? "Pago" : status === "overdue" ? "Atraso" : "Pend";
        paymentLines += `
          <div class="item">
            <div class="item-row"><span>${batch?.batchCode || payment.batchId.slice(0, 8)}</span><span>${statusLabel}</span></div>
            <div class="item-row"><span>Valor:</span><span>R$ ${parseFloat(payment.amount).toFixed(2)}</span></div>
          </div>
        `;
      });
      
      let advanceLines = '';
      seamstressAdvances.forEach((advance: Advance) => {
        advanceLines += `
          <div class="item">
            <div class="item-row"><span>VALE</span><span>-R$ ${parseFloat(advance.amount).toFixed(2)}</span></div>
          </div>
        `;
      });

      content = `<!DOCTYPE html><html lang="pt-BR"><head><meta charset="UTF-8">
        <title>Extrato ${seamstress.name}</title>
        <style>${getCupomBaseStyles()}</style>
      </head><body>
        <div class="cupom">
          <div class="header">GOFAST PRODUCOES</div>
          <div class="title">EXTRATO</div>
          <div class="divider"></div>
          <div class="info">${seamstress.name}</div>
          <div class="info">Tel: ${seamstress.phone}</div>
          <div class="divider"></div>
          <div class="total">PAGO: R$ ${balance.paid.toFixed(2)}</div>
          <div class="total">PEND: R$ ${balance.pending.toFixed(2)}</div>
          ${totalAdvances > 0 ? `<div class="total">VALES: -R$ ${totalAdvances.toFixed(2)}</div>` : ''}
          <div class="total">LIQUIDO: R$ ${(balance.pending - totalAdvances).toFixed(2)}</div>
          <div class="divider"></div>
          ${paymentLines}
          ${advanceLines}
          <div class="divider"></div>
          <div class="footer">${new Date().toLocaleString('pt-BR')}</div>
        </div>
      </body></html>`;
    } else {
      content = printContent;
    }
    
    printHtml(content);
  };

  return (
    <div className="p-8 space-y-8">
      <div>
        <h1 className="text-4xl font-bold bg-gradient-to-r from-cyan-400 to-purple-500 bg-clip-text text-transparent">
          Pagamentos das Costureiras
        </h1>
        <p className="text-muted-foreground mt-2">Controle financeiro completo com histórico e alertas</p>
        <Dialog open={advanceDialogOpen} onOpenChange={setAdvanceDialogOpen}>
          <DialogTrigger asChild>
            <Button className="mt-4" data-testid="button-new-advance">
              <Plus className="w-4 h-4 mr-2" /> Registrar Adiantamento
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Novo Adiantamento</DialogTitle>
            </DialogHeader>
            <div className="space-y-4 mt-4">
              <div>
                <Label>Costureira</Label>
                <Select value={advanceSeamstressId} onValueChange={setAdvanceSeamstressId}>
                  <SelectTrigger data-testid="select-advance-seamstress">
                    <SelectValue placeholder="Selecione a costureira" />
                  </SelectTrigger>
                  <SelectContent>
                    {seamstresses.map((s: Seamstress) => (
                      <SelectItem key={s.id} value={s.id}>{s.name}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label>Valor (R$)</Label>
                <Input
                  type="number"
                  value={advanceAmount}
                  onChange={(e) => setAdvanceAmount(e.target.value)}
                  placeholder="Ex: 100.00"
                  data-testid="input-advance-amount"
                />
              </div>
              <div>
                <Label>Observações</Label>
                <Input
                  value={advanceNotes}
                  onChange={(e) => setAdvanceNotes(e.target.value)}
                  placeholder="Opcional"
                  data-testid="input-advance-notes"
                />
              </div>
              <Button
                className="w-full"
                onClick={() => {
                  if (advanceSeamstressId && advanceAmount) {
                    createAdvanceMutation.mutate({
                      seamstressId: advanceSeamstressId,
                      amount: parseFloat(advanceAmount),
                      notes: advanceNotes,
                    });
                  }
                }}
                disabled={!advanceSeamstressId || !advanceAmount || createAdvanceMutation.isPending}
                data-testid="button-submit-advance"
              >
                {createAdvanceMutation.isPending ? "Salvando..." : "Salvar Adiantamento"}
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {/* Summary Cards as Buttons */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Button
          onClick={() => handleOpenCardDetails("paid")}
          variant="ghost"
          className={`p-6 h-auto bg-gradient-to-br from-green-900/20 to-green-800/10 border border-green-600/30 rounded-lg hover:from-green-900/30 hover:to-green-800/20 transition-all cursor-pointer`}
          data-testid="button-filter-paid"
        >
          <div className="flex items-start justify-between w-full">
            <div className="text-left">
              <p className="text-sm font-medium text-green-400">Total Pago</p>
              <p className="text-3xl font-bold mt-2">R$ {totalPaid.toFixed(2)}</p>
            </div>
            <DollarSign className="w-8 h-8 text-green-500 flex-shrink-0" />
          </div>
        </Button>

        <Button
          onClick={() => handleOpenCardDetails("pending")}
          variant="ghost"
          className={`p-6 h-auto bg-gradient-to-br from-emerald-900/20 to-emerald-800/10 border border-emerald-600/30 rounded-lg hover:from-emerald-900/30 hover:to-emerald-800/20 transition-all cursor-pointer`}
          data-testid="button-filter-pending"
        >
          <div className="flex items-start justify-between w-full">
            <div className="text-left">
              <p className="text-sm font-medium text-emerald-400">Pagamentos a Receber</p>
              <p className="text-3xl font-bold mt-2">R$ {totalPending.toFixed(2)}</p>
            </div>
            <CheckCircle className="w-8 h-8 text-emerald-500 flex-shrink-0" />
          </div>
        </Button>

        <Button
          onClick={() => handleOpenCardDetails("overdue")}
          variant="ghost"
          className={`p-6 h-auto bg-gradient-to-br from-orange-900/20 to-orange-800/10 border border-orange-600/30 rounded-lg hover:from-orange-900/30 hover:to-orange-800/20 transition-all cursor-pointer`}
          data-testid="button-filter-overdue"
        >
          <div className="flex items-start justify-between w-full">
            <div className="text-left">
              <p className="text-sm font-medium text-orange-400">Total Pendente/Atrasado</p>
              <p className="text-3xl font-bold mt-2">R$ {totalPending.toFixed(2)}</p>
            </div>
            <AlertCircle className="w-8 h-8 text-orange-500 flex-shrink-0" />
          </div>
        </Button>

        <Button
          onClick={() => handleOpenCardDetails("all")}
          variant="ghost"
          className={`p-6 h-auto bg-gradient-to-br from-purple-900/20 to-purple-800/10 border border-purple-600/30 rounded-lg hover:from-purple-900/30 hover:to-purple-800/20 transition-all cursor-pointer`}
          data-testid="button-filter-all"
        >
          <div className="flex items-start justify-between w-full">
            <div className="text-left">
              <p className="text-sm font-medium text-purple-400">Total Geral</p>
              <p className="text-3xl font-bold mt-2">R$ {(totalPaid + totalPending).toFixed(2)}</p>
            </div>
            <DollarSign className="w-8 h-8 text-purple-500 flex-shrink-0" />
          </div>
        </Button>
      </div>

      {/* Active Filter Indicator and Buttons */}
      <div className="flex gap-3 items-center flex-wrap">
        <Button 
          onClick={openPrintAllPaymentsDialog}
          className="gap-2"
          data-testid="button-print-all-payments"
        >
          <Printer className="w-4 h-4" />
          Imprimir Todos os Pagamentos
        </Button>
        
        <Button 
          onClick={openPrintPendingNetDialog}
          className="gap-2 bg-orange-600 hover:bg-orange-700"
          data-testid="button-print-pending-net"
        >
          <Printer className="w-4 h-4" />
          Imprimir Pendentes (Valor Líquido)
        </Button>
        
        {activeCardFilter && (
          <>
            <div className="text-sm text-muted-foreground">
              Filtro ativo: 
              <span className="font-semibold ml-2">
                {activeCardFilter === "paid" ? "Total Pago" : 
                 activeCardFilter === "pending" ? "Pagamentos a Receber" :
                 activeCardFilter === "overdue" ? "Total Pendente/Atrasado" :
                 "Total Geral"}
              </span>
            </div>
            <Button 
              onClick={() => setActiveCardFilter(null)}
              variant="outline"
              size="sm"
              data-testid="button-clear-filter"
            >
              Limpar Filtro
            </Button>
          </>
        )}
      </div>

      {/* Filters */}
      <Card className="p-6">
        <h3 className="font-semibold mb-4">Filtros</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          <div>
            <label className="text-sm font-medium">Costureira</label>
            <select
              value={selectedSeamstress}
              onChange={(e) => setSelectedSeamstress(e.target.value)}
              className="w-full mt-2 p-2 border rounded-md bg-background"
              data-testid="select-seamstress-filter"
            >
              <option value="all">Todas as costureiras</option>
              {seamstresses.map((s: Seamstress) => {
                const hasPendingPayments = payments.some((p: Payment) => p.seamstressId === s.id && p.status === "pending");
                if (!hasPendingPayments) return null;
                return (
                  <option key={s.id} value={s.id}>
                    {s.name}
                  </option>
                );
              })}
            </select>
          </div>

          <div>
            <label className="text-sm font-medium">Fornecedor</label>
            <select
              value={filterSupplier}
              onChange={(e) => setFilterSupplier(e.target.value)}
              className="w-full mt-2 p-2 border rounded-md bg-background"
              data-testid="select-supplier-filter"
            >
              <option value="todos">Todos os Fornecedores</option>
              {uniqueSuppliers.map((supplier) => (
                <option key={supplier} value={supplier}>
                  {supplier}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="text-sm font-medium">Status</label>
            <select
              value={filterStatus}
              onChange={(e) => setFilterStatus(e.target.value)}
              className="w-full mt-2 p-2 border rounded-md bg-background"
              data-testid="select-status-filter"
            >
              <option value="todos">Todos</option>
              <option value="pendente">Pendente</option>
              <option value="atrasados">Atrasados</option>
              <option value="atrasados_pendentes">Atrasados + Pendentes</option>
            </select>
          </div>

          <div>
            <label className="text-sm font-medium">Mês</label>
            <input
              type="month"
              value={filterMonth}
              onChange={(e) => setFilterMonth(e.target.value)}
              className="w-full mt-2 p-2 border rounded-md bg-background"
              data-testid="input-month-filter"
            />
          </div>
        </div>
      </Card>

      {/* Seamstress Payment Details */}
      <div className="space-y-4">
        {filteredSeamstresses.length === 0 ? (
          <Card className="p-6">
            <p className="text-muted-foreground text-center">Nenhuma costureira com pagamentos pendentes encontrada.</p>
          </Card>
        ) : (
          filteredSeamstresses.map((seamstress: Seamstress) => {
            const sPayments = getSeamstressPayments(seamstress.id);
            const balance = getSeamstressBalance(seamstress.id);
            const isExpanded = expandedSeamstress === seamstress.id;

            return (
              <Card key={seamstress.id} className="p-6 border-blue-500/30">
                <div className="flex items-center justify-between gap-4">
                  <Button
                    variant="ghost"
                    className="flex-1 h-auto justify-start text-left p-0 hover:bg-transparent"
                    onClick={() => navigate(`/seamstresses/${seamstress.id}`)}
                    data-testid={`button-seamstress-details-${seamstress.id}`}
                  >
                    <div className="flex-1">
                      <h3 className="text-lg font-semibold">{seamstress.name}</h3>
                      <p className="text-sm text-muted-foreground">{seamstress.phone} • {seamstress.address}</p>
                      <div className="flex gap-6 mt-2 text-sm">
                        <span className="text-green-400">
                          Pago: <span className="font-bold">R$ {balance.paid.toFixed(2)}</span>
                        </span>
                        <span className="text-orange-400">
                          Pendente: <span className="font-bold">R$ {balance.pending.toFixed(2)}</span>
                        </span>
                      </div>
                    </div>
                  </Button>
                  <div className="flex gap-2 flex-shrink-0">
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={() =>
                        setExpandedSeamstress(isExpanded ? null : seamstress.id)
                      }
                      data-testid={`button-expand-${seamstress.id}`}
                    >
                      {isExpanded ? (
                        <ChevronUp className="w-6 h-6" />
                      ) : (
                        <ChevronDown className="w-6 h-6" />
                      )}
                    </Button>
                    <Button 
                      size="sm"
                      variant="outline"
                      onClick={() => openPrintSeamstressDialog(seamstress)}
                      data-testid={`button-print-seamstress-${seamstress.id}`}
                    >
                      <Printer className="w-4 h-4" />
                    </Button>
                  </div>
                </div>

                {isExpanded && (
                  <div className="mt-6 border-t border-border pt-6">
                    {/* Vales Section */}
                    {getSeamstressAdvances(seamstress.id).length > 0 && (
                      <div className="mb-6 p-4 bg-amber-900/20 border border-amber-600/30 rounded-lg">
                        <h4 className="font-semibold mb-3 text-amber-400 flex items-center gap-2">
                          <DollarSign className="w-4 h-4" />
                          Vales (Adiantamentos)
                        </h4>
                        <div className="space-y-2">
                          {getSeamstressAdvances(seamstress.id).map((advance: Advance) => (
                            <div key={advance.id} className="flex items-center justify-between p-2 bg-amber-900/30 rounded">
                              <div>
                                <span className="text-amber-400 font-bold">VALE</span>
                                <span className="text-muted-foreground ml-2">{advance.notes || ''}</span>
                                <span className="text-xs text-muted-foreground ml-2">
                                  ({new Date(advance.date).toLocaleDateString('pt-BR')})
                                </span>
                              </div>
                              <div className="flex items-center gap-2">
                                <span className="text-red-400 font-bold">- R$ {parseFloat(advance.amount).toFixed(2)}</span>
                                <Button
                                  size="sm"
                                  variant="ghost"
                                  onClick={() => deleteAdvanceMutation.mutate(advance.id)}
                                  className="text-red-400 hover:text-red-300"
                                  data-testid={`button-delete-advance-${advance.id}`}
                                >
                                  <Trash2 className="w-4 h-4" />
                                </Button>
                              </div>
                            </div>
                          ))}
                        </div>
                        <div className="mt-3 pt-3 border-t border-amber-600/30 flex justify-between">
                          <span className="text-amber-400 font-semibold">Total de Vales:</span>
                          <span className="text-red-400 font-bold">- R$ {getSeamstressTotalAdvances(seamstress.id).toFixed(2)}</span>
                        </div>
                      </div>
                    )}
                    
                    {/* Pending Payments Section */}
                    {(() => {
                      const pendingPayments = sPayments.filter((p: Payment) => getPaymentStatus(p) !== "paid");
                      const paidPayments = sPayments.filter((p: Payment) => getPaymentStatus(p) === "paid");
                      
                      return (
                        <div className="space-y-6">
                          {/* Pending/Overdue Payments */}
                          <div className="p-4 bg-orange-900/10 border border-orange-600/30 rounded-lg">
                            <h4 className="font-semibold mb-4 text-orange-400 flex items-center gap-2">
                              <AlertCircle className="w-4 h-4" />
                              Pagamentos Pendentes ({pendingPayments.length})
                            </h4>
                            {pendingPayments.length === 0 ? (
                              <p className="text-muted-foreground text-sm">Nenhum pagamento pendente</p>
                            ) : (
                              <div className="overflow-x-auto">
                                <table className="w-full text-sm">
                                  <thead className="border-b border-orange-600/30">
                                    <tr>
                                      <th className="text-left py-2 px-3">Produção</th>
                                      <th className="text-left py-2 px-3">Fornecedor</th>
                                      <th className="text-left py-2 px-3">Valor</th>
                                      <th className="text-left py-2 px-3">Status</th>
                                      <th className="text-left py-2 px-3">Vencimento</th>
                                      <th className="text-left py-2 px-3">Ação</th>
                                    </tr>
                                  </thead>
                                  <tbody>
                                    {pendingPayments.map((payment: Payment) => {
                                      const batch = batches.find((b: Batch) => b.id === payment.batchId);
                                      const production = getProductionForPayment(payment);
                                      const status = getPaymentStatus(payment);
                                      const dueDate = payment.dueDate ? new Date(payment.dueDate) : null;
                                      const isOverdue = status === "overdue";
                                      
                                      return (
                                        <tr
                                          key={payment.id}
                                          className={`border-b border-orange-600/20 hover:bg-orange-900/20 cursor-pointer ${isOverdue ? "bg-red-900/20" : ""}`}
                                          data-testid={`row-pending-payment-${payment.id}`}
                                          onClick={() => batch && handleOpenBatchDetails(batch)}
                                        >
                                          <td className="py-2 px-3 text-xs font-medium">
                                            {production?.productName || "-"}
                                          </td>
                                          <td className="py-2 px-3 text-xs text-muted-foreground">
                                            {production?.supplier || "-"}
                                          </td>
                                          <td className="py-2 px-3">R$ {parseFloat(payment.amount).toFixed(2)}</td>
                                          <td className="py-2 px-3">
                                            <span className={`px-2 py-1 text-xs rounded-full ${
                                              isOverdue
                                                ? "bg-red-900/50 text-red-400 border border-red-600/50"
                                                : "bg-orange-900/50 text-orange-400 border border-orange-600/50"
                                            }`}>
                                              {isOverdue ? "Atrasado" : "Pendente"}
                                            </span>
                                          </td>
                                          <td className="py-2 px-3">
                                            <input
                                              type="date"
                                              value={dueDate ? format(dueDate, "yyyy-MM-dd") : ""}
                                              onChange={(e) => {
                                                if (e.target.value) {
                                                  updateDueDateMutation.mutate({
                                                    paymentId: payment.id,
                                                    dueDate: e.target.value,
                                                  });
                                                }
                                              }}
                                              className="text-xs px-2 py-1 border rounded bg-background"
                                              data-testid={`input-duedate-${payment.id}`}
                                            />
                                          </td>
                                          <td className="py-2 px-3">
                                            <div className="flex gap-2">
                                              <Button
                                                size="sm"
                                                variant="outline"
                                                onClick={(e) => { e.stopPropagation(); handlePrintSinglePayment(payment, seamstress); }}
                                                className="gap-1"
                                                data-testid={`button-print-payment-${payment.id}`}
                                              >
                                                <FileText className="w-3 h-3" />
                                              </Button>
                                              <Button
                                                size="sm"
                                                variant="outline"
                                                onClick={(e) => { e.stopPropagation(); markPaidMutation.mutate(payment.id); }}
                                                disabled={markPaidMutation.isPending}
                                                data-testid={`button-mark-paid-${payment.id}`}
                                              >
                                                Marcar Pago
                                              </Button>
                                            </div>
                                          </td>
                                        </tr>
                                      );
                                    })}
                                  </tbody>
                                </table>
                              </div>
                            )}
                          </div>

                          {/* Paid Payments */}
                          <div className="p-4 bg-green-900/10 border border-green-600/30 rounded-lg">
                            <h4 className="font-semibold mb-4 text-green-400 flex items-center gap-2">
                              <CheckCircle className="w-4 h-4" />
                              Pagamentos Realizados ({paidPayments.length})
                            </h4>
                            {paidPayments.length === 0 ? (
                              <p className="text-muted-foreground text-sm">Nenhum pagamento realizado</p>
                            ) : (
                              <div className="overflow-x-auto">
                                <table className="w-full text-sm">
                                  <thead className="border-b border-green-600/30">
                                    <tr>
                                      <th className="text-left py-2 px-3">Produção</th>
                                      <th className="text-left py-2 px-3">Fornecedor</th>
                                      <th className="text-left py-2 px-3">Valor</th>
                                      <th className="text-left py-2 px-3">Status</th>
                                      <th className="text-left py-2 px-3">Data Pagto</th>
                                      <th className="text-left py-2 px-3">Ação</th>
                                    </tr>
                                  </thead>
                                  <tbody>
                                    {paidPayments.map((payment: Payment) => {
                                      const batch = batches.find((b: Batch) => b.id === payment.batchId);
                                      const production = getProductionForPayment(payment);
                                      const paidDate = payment.paidDate ? new Date(payment.paidDate) : null;
                                      
                                      return (
                                        <tr
                                          key={payment.id}
                                          className="border-b border-green-600/20 hover:bg-green-900/20 cursor-pointer"
                                          data-testid={`row-paid-payment-${payment.id}`}
                                          onClick={() => batch && handleOpenBatchDetails(batch)}
                                        >
                                          <td className="py-2 px-3 text-xs font-medium">
                                            {production?.productName || "-"}
                                          </td>
                                          <td className="py-2 px-3 text-xs text-muted-foreground">
                                            {production?.supplier || "-"}
                                          </td>
                                          <td className="py-2 px-3">R$ {parseFloat(payment.amount).toFixed(2)}</td>
                                          <td className="py-2 px-3">
                                            <span className="px-2 py-1 text-xs rounded-full bg-green-900/50 text-green-400 border border-green-600/50">
                                              Pago
                                            </span>
                                          </td>
                                          <td className="py-2 px-3 text-xs">
                                            {paidDate ? format(paidDate, "dd/MM/yyyy") : "-"}
                                          </td>
                                          <td className="py-2 px-3">
                                            <Button
                                              size="sm"
                                              variant="outline"
                                              onClick={(e) => { e.stopPropagation(); handlePrintSinglePayment(payment, seamstress); }}
                                              className="gap-1"
                                              data-testid={`button-print-paid-${payment.id}`}
                                            >
                                              <FileText className="w-3 h-3" />
                                            </Button>
                                          </td>
                                        </tr>
                                      );
                                    })}
                                  </tbody>
                                </table>
                              </div>
                            )}
                          </div>
                        </div>
                      );
                    })()}
                  </div>
                )}
              </Card>
            );
          })
        )}
      </div>

      {/* Batch Details Drawer */}
      <Drawer open={drawerOpen} onOpenChange={setDrawerOpen}>
        <DrawerContent className="max-w-2xl">
          <DrawerHeader className="flex items-center justify-between">
            <DrawerTitle>Detalhes do Lote</DrawerTitle>
            <DrawerClose asChild>
              <Button variant="ghost" size="icon" data-testid="button-close-drawer">
                <X className="w-4 h-4" />
              </Button>
            </DrawerClose>
          </DrawerHeader>

          {selectedBatch && (
            <div className="p-6 space-y-4">
              {/* Batch Info */}
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <p className="text-xs text-muted-foreground">Código do Lote</p>
                  <p className="font-mono font-semibold mt-1">{selectedBatch.batchCode}</p>
                </div>
                <div>
                  <p className="text-xs text-muted-foreground">Status</p>
                  <p className="font-semibold mt-1">
                    <span
                      className={`inline-block px-2 py-1 rounded text-xs font-bold ${
                        selectedBatch.status === "concluido"
                          ? "bg-green-900/50 text-green-400"
                          : selectedBatch.status === "em_producao"
                          ? "bg-blue-900/50 text-blue-400"
                          : selectedBatch.status === "para_recolha"
                          ? "bg-yellow-900/50 text-yellow-400"
                          : selectedBatch.status === "para_entrega"
                          ? "bg-purple-900/50 text-purple-400"
                          : "bg-gray-900/50 text-gray-400"
                      }`}
                    >
                      {selectedBatch.status === "concluido"
                        ? "Concluído"
                        : selectedBatch.status === "em_producao"
                        ? "Em Produção"
                        : selectedBatch.status === "para_recolha"
                        ? "Para Recolha"
                        : selectedBatch.status === "para_entrega"
                        ? "Para Entrega"
                        : "Em Separação"}
                    </span>
                  </p>
                </div>
              </div>

              {/* Quantity and Price */}
              <div className="grid grid-cols-2 gap-4 pt-4 border-t">
                <div>
                  <p className="text-xs text-muted-foreground">Quantidade</p>
                  <p className="text-lg font-semibold mt-1">{selectedBatch.quantity || "N/A"} un.</p>
                </div>
                <div>
                  <p className="text-xs text-muted-foreground">Preço Unitário</p>
                  <p className="text-lg font-semibold mt-1">R$ {parseFloat(selectedBatch.pricePerUnit || "0").toFixed(2)}</p>
                </div>
              </div>

              {/* Dates */}
              <div className="grid grid-cols-2 gap-4 pt-4 border-t">
                <div>
                  <p className="text-xs text-muted-foreground">Data de Envio</p>
                  <p className="font-semibold mt-1">
                    {selectedBatch.sendDate
                      ? new Date(selectedBatch.sendDate).toLocaleDateString("pt-BR")
                      : "N/A"}
                  </p>
                </div>
                <div>
                  <p className="text-xs text-muted-foreground">Data Esperada de Retorno</p>
                  <p className="font-semibold mt-1">
                    {selectedBatch.expectedReturnDate
                      ? new Date(selectedBatch.expectedReturnDate).toLocaleDateString("pt-BR")
                      : "N/A"}
                  </p>
                </div>
              </div>

              {/* Production Info */}
              {selectedBatch.productionId && (() => {
                const production = (productions as any[]).find((p: any) => p.id === selectedBatch.productionId);
                return production ? (
                  <div className="pt-4 border-t space-y-2">
                    <p className="text-xs text-muted-foreground">Produção</p>
                    <div className="bg-muted/50 p-3 rounded-md space-y-1">
                      <p className="font-semibold text-sm">{production.productName}</p>
                      <p className="text-xs text-muted-foreground">Fornecedor: {production.supplier}</p>
                      <p className="text-xs text-muted-foreground">Código: {production.code}</p>
                    </div>
                  </div>
                ) : null;
              })()}
            </div>
          )}
        </DrawerContent>
      </Drawer>

      {/* Card Filter Details Drawer */}
      <Drawer open={cardDrawerOpen} onOpenChange={setCardDrawerOpen}>
        <DrawerContent className="max-w-3xl max-h-[80vh] overflow-y-auto">
          <DrawerHeader className="flex items-center justify-between sticky top-0 bg-background z-10">
            <DrawerTitle>
              {selectedCardType === "paid"
                ? "Pagamentos Realizados"
                : selectedCardType === "pending"
                ? "Pagamentos a Receber"
                : selectedCardType === "overdue"
                ? "Pagamentos Atrasados"
                : "Todos os Pagamentos"}
            </DrawerTitle>
            <DrawerClose asChild>
              <Button variant="ghost" size="icon" data-testid="button-close-card-drawer">
                <X className="w-4 h-4" />
              </Button>
            </DrawerClose>
          </DrawerHeader>

          <div className="p-6 space-y-4">
            {selectedCardType && (() => {
              const cardPayments = getPaymentsByCardType(selectedCardType);
              return (
                <>
                  <div className="grid grid-cols-3 gap-4 pb-4 border-b">
                    <div>
                      <p className="text-xs text-muted-foreground">Total de Pagamentos</p>
                      <p className="text-2xl font-bold mt-1">{cardPayments.length}</p>
                    </div>
                    <div>
                      <p className="text-xs text-muted-foreground">Valor Total</p>
                      <p className="text-2xl font-bold mt-1 text-green-400">
                        R$ {cardPayments.reduce((sum: number, p: Payment) => sum + parseFloat(p.amount), 0).toFixed(2)}
                      </p>
                    </div>
                    <div>
                      <p className="text-xs text-muted-foreground">Costureiras</p>
                      <p className="text-2xl font-bold mt-1">
                        {new Set(cardPayments.map((p: Payment) => p.seamstressId)).size}
                      </p>
                    </div>
                  </div>

                  {cardPayments.length === 0 ? (
                    <div className="text-center py-8 text-muted-foreground">
                      Nenhum pagamento encontrado nesta categoria
                    </div>
                  ) : (
                    <div className="overflow-x-auto">
                      <table className="w-full text-sm">
                        <thead className="border-b border-border sticky top-0 bg-muted">
                          <tr>
                            <th className="text-left py-2 px-3">Costureira</th>
                            <th className="text-left py-2 px-3">Lote</th>
                            <th className="text-left py-2 px-3">Valor</th>
                            <th className="text-left py-2 px-3">Status</th>
                            <th className="text-left py-2 px-3">Vencimento</th>
                          </tr>
                        </thead>
                        <tbody>
                          {cardPayments.map((payment: Payment) => {
                            const seamstress = seamstresses.find((s: Seamstress) => s.id === payment.seamstressId);
                            const batch = batches.find((b: Batch) => b.id === payment.batchId);
                            const status = getPaymentStatus(payment);
                            const dueDate = payment.dueDate ? new Date(payment.dueDate).toLocaleDateString("pt-BR") : "N/A";
                            return (
                              <tr key={payment.id} className="border-b hover:bg-muted/50">
                                <td className="py-2 px-3 font-semibold">{seamstress?.name || "N/A"}</td>
                                <td className="py-2 px-3 font-mono text-xs cursor-pointer hover:text-blue-400" onClick={() => batch && handleOpenBatchDetails(batch)}>
                                  {batch?.batchCode || payment.batchId.slice(0, 8)}
                                </td>
                                <td className="py-2 px-3">R$ {parseFloat(payment.amount).toFixed(2)}</td>
                                <td className="py-2 px-3">
                                  <span
                                    className={`px-2 py-1 text-xs rounded-full ${
                                      status === "paid"
                                        ? "bg-green-900/50 text-green-400"
                                        : status === "overdue"
                                        ? "bg-red-900/50 text-red-400"
                                        : "bg-orange-900/50 text-orange-400"
                                    }`}
                                  >
                                    {status === "paid" ? "Pago" : status === "overdue" ? "Atrasado" : "Pendente"}
                                  </span>
                                </td>
                                <td className="py-2 px-3">{dueDate}</td>
                              </tr>
                            );
                          })}
                        </tbody>
                      </table>
                    </div>
                  )}
                </>
              );
            })()}
          </div>
        </DrawerContent>
      </Drawer>

      <PrintFormatDialog
        open={printFormatDialogOpen}
        onOpenChange={setPrintFormatDialogOpen}
        onSelectFormat={handlePrintFormatSelect}
      />
    </div>
  );
};

export default Payments;
