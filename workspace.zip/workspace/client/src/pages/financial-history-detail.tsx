import { useParams, Link } from 'wouter';
import { useQuery } from '@tanstack/react-query';
import { ArrowLeft } from 'lucide-react';

interface DashboardData {
  totalReceita: number;
  totalCusto: number;
  monthlyData: Array<{ month: string; profit: number }>;
}

export default function FinancialHistoryDetail() {
  const { type } = useParams();

  const { data: dashboardData } = useQuery<DashboardData>({
    queryKey: ['/api/tenant/dashboard'],
  });

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL',
    }).format(value);
  };

  const getCardInfo = () => {
    const percentages: { [key: string]: { percent: number; label: string; icon: string; description: string } } = {
      leonardo: { percent: 0.2, label: 'Leonardo (Você)', icon: '👤', description: 'Seu salário' },
      hugo: { percent: 0.2, label: 'Hugo', icon: '👤', description: 'Salário do Hugo' },
      manutencao: { percent: 0.1, label: 'Manutenção do Carro', icon: '🚗', description: 'Custos de manutenção' },
      caixa: { percent: 0.2, label: 'Caixa de Segurança', icon: '🏦', description: 'Reserva de emergência' },
      reinvestimento: { percent: 0.2, label: 'Reinvestimento', icon: '📈', description: 'Crescimento da empresa' },
      folga: { percent: 0.1, label: 'Folga / Lucro Líquido', icon: '💰', description: 'Lucro final disponível' },
    };
    return percentages[type || 'leonardo'] || percentages['leonardo'];
  };

  const cardInfo = getCardInfo();

  // Generate monthly history
  const monthlyHistory = (dashboardData?.monthlyData || []).map((item) => {
    const profit = item.profit || 0;
    return {
      month: item.month,
      profit,
      allocation: profit * cardInfo.percent,
    };
  });

  const totalAllocation = monthlyHistory.reduce((sum, item) => sum + item.allocation, 0);
  const averageAllocation = monthlyHistory.length > 0 ? totalAllocation / monthlyHistory.length : 0;

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-slate-950 p-8">
      <style>{`
        .neon-text {
          background: linear-gradient(135deg, #00f2ff, #8a2be2);
          -webkit-background-clip: text;
          -webkit-text-fill-color: transparent;
          background-clip: text;
        }
        
        .neon-card {
          background: linear-gradient(135deg, rgba(0, 242, 255, 0.05) 0%, rgba(138, 43, 226, 0.05) 100%);
          border: 2px solid #00f2ff;
          border-radius: 15px;
          backdrop-filter: blur(10px);
          transition: all 0.3s;
        }
        
        .fadeInUp {
          animation: fadeInUp 0.8s ease-out;
        }
        
        @keyframes fadeInUp {
          from {
            opacity: 0;
            transform: translateY(30px);
          }
          to {
            opacity: 1;
            transform: translateY(0);
          }
        }
      `}</style>

      <div className="max-w-4xl mx-auto">
        {/* BACK BUTTON */}
        <Link href="/financial-dashboard">
          <button className="flex items-center gap-2 text-cyan-400 hover:text-cyan-300 mb-8 transition">
            <ArrowLeft className="w-5 h-5" />
            Voltar ao Plano Financeiro
          </button>
        </Link>

        {/* HEADER */}
        <div className="text-center mb-12 fadeInUp">
          <div className="neon-card p-10 mb-8">
            <p className="text-4xl mb-4">{cardInfo.icon}</p>
            <h1 className="text-4xl font-bold neon-text mb-2">{cardInfo.label}</h1>
            <p className="text-gray-400 text-lg mb-6">{cardInfo.description}</p>
            <div className="grid grid-cols-3 gap-4 mt-8">
              <div className="bg-slate-800/50 rounded p-4">
                <p className="text-gray-400 text-sm">Total Alocado</p>
                <p className="text-2xl font-bold text-green-400 mt-2">{formatCurrency(totalAllocation)}</p>
              </div>
              <div className="bg-slate-800/50 rounded p-4">
                <p className="text-gray-400 text-sm">Média Mensal</p>
                <p className="text-2xl font-bold text-cyan-400 mt-2">{formatCurrency(averageAllocation)}</p>
              </div>
              <div className="bg-slate-800/50 rounded p-4">
                <p className="text-gray-400 text-sm">Meses</p>
                <p className="text-2xl font-bold text-purple-400 mt-2">{monthlyHistory.length}</p>
              </div>
            </div>
          </div>
        </div>

        {/* MONTHLY HISTORY TABLE */}
        <div className="neon-card p-8 mb-12 fadeInUp">
          <h2 className="text-2xl font-bold text-cyan-400 mb-6">📅 Histórico Mensal</h2>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-cyan-400/30">
                  <th className="text-left py-3 px-4 text-gray-400">Mês</th>
                  <th className="text-right py-3 px-4 text-gray-400">Lucro Total</th>
                  <th className="text-right py-3 px-4 text-cyan-400 font-bold">Alocação ({(cardInfo.percent * 100).toFixed(0)}%)</th>
                </tr>
              </thead>
              <tbody>
                {monthlyHistory.length === 0 ? (
                  <tr>
                    <td colSpan={3} className="py-6 text-center text-gray-500">
                      Nenhum dado disponível
                    </td>
                  </tr>
                ) : (
                  monthlyHistory.map((item, idx) => (
                    <tr key={idx} className="border-b border-gray-700/50 hover:bg-slate-800/30 transition">
                      <td className="py-3 px-4 text-gray-300">{item.month}</td>
                      <td className="py-3 px-4 text-right text-white">{formatCurrency(item.profit)}</td>
                      <td className="py-3 px-4 text-right text-green-400 font-semibold">{formatCurrency(item.allocation)}</td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>

        {/* CHART */}
        <div className="neon-card p-8 fadeInUp">
          <h2 className="text-2xl font-bold text-cyan-400 mb-6">📊 Evolução Mensal</h2>
          <div className="h-64 bg-slate-800/30 rounded-lg flex items-end justify-around p-4 gap-2">
            {monthlyHistory.length === 0 ? (
              <p className="text-gray-500 w-full text-center">Sem dados para exibir</p>
            ) : (
              monthlyHistory.map((item, idx) => {
                const maxAllocation = Math.max(...monthlyHistory.map((i) => i.allocation), 1);
                const heightPercent = (item.allocation / maxAllocation) * 100;
                return (
                  <div key={idx} className="flex-1 flex flex-col items-center gap-2">
                    <div
                      className="w-full bg-gradient-to-t from-cyan-400 to-purple-600 rounded-t transition-all hover:from-cyan-300 hover:to-purple-500"
                      style={{ height: `${heightPercent}%`, minHeight: '20px' }}
                      title={formatCurrency(item.allocation)}
                    />
                    <p className="text-xs text-gray-400 whitespace-nowrap">{item.month.substring(0, 3)}</p>
                  </div>
                );
              })
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
