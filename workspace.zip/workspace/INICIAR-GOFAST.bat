@echo off
setlocal EnableExtensions
cd /d "%~dp0"

title GoFast Produções - Inicializador

if not exist local-env.bat (
  echo ================================================
  echo      GOFAST PRODUCOES - PRIMEIRA EXECUCAO
  echo ================================================
  echo.
  echo O sistema ainda nao foi configurado nesta maquina.
  echo.
  echo Execute CONFIGURAR-GOFAST.bat primeiro.
  echo.
  pause
  exit /b 1
)

where node >nul 2>&1
if errorlevel 1 (
  echo ERRO: Node.js nao foi encontrado.
  echo Instale o Node.js LTS em https://nodejs.org/
  pause
  exit /b 1
)

where npm >nul 2>&1
if errorlevel 1 (
  echo ERRO: npm nao foi encontrado.
  pause
  exit /b 1
)

call local-env.bat
set "NODE_ENV=development"

if not exist node_modules (
  echo Instalando dependencias...
  call npm install
  if errorlevel 1 (
    echo ERRO ao instalar dependencias.
    pause
    exit /b 1
  )
)

echo.
echo ================================================
echo          GOFAST PRODUCOES - INICIANDO
echo ================================================
echo.
echo URL local: http://localhost:5000
 echo.

start "GoFast Produções - Servidor" cmd /k "cd /d "%~dp0" && call local-env.bat && set NODE_ENV=development && set PORT=5000 && npx tsx server/index-dev.ts"

powershell -NoProfile -ExecutionPolicy Bypass -Command "$ok=$false; for($i=0;$i -lt 60;$i++){try{$r=Invoke-WebRequest -UseBasicParsing -Uri 'http://localhost:5000' -TimeoutSec 2;if($r.StatusCode -ge 200){$ok=$true;break}}catch{};Start-Sleep -Milliseconds 500}; if($ok){Start-Process 'http://localhost:5000'; exit 0}else{exit 1}"

if errorlevel 1 (
  echo.
  echo O servidor nao respondeu em http://localhost:5000.
  echo Veja a janela "GoFast Produções - Servidor" para identificar o erro.
  pause
  exit /b 1
)

echo.
echo GoFast Produções iniciado com sucesso.
echo Feche o servidor pela janela do GoFast ou execute PARAR-GOFAST.bat.
echo.
exit /b 0
