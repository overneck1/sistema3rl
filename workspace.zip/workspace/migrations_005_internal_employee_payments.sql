CREATE TABLE IF NOT EXISTS internal_employee_payments (
  id varchar PRIMARY KEY DEFAULT gen_random_uuid(),
  empresa_id varchar NOT NULL,
  employee_id varchar NOT NULL REFERENCES internal_employees(id),
  payment_type varchar NOT NULL CHECK (payment_type IN ('salary','salary_advance','transport','transport_advance')),
  competence varchar NOT NULL,
  amount numeric(12,2) NOT NULL,
  payment_date timestamp NOT NULL,
  payment_method varchar NOT NULL DEFAULT 'pix' CHECK (payment_method IN ('pix','bank_transfer','cash','other')),
  status varchar NOT NULL DEFAULT 'paid' CHECK (status IN ('pending','paid','cancelled')),
  receipt_number varchar NOT NULL,
  notes text,
  created_at timestamp NOT NULL DEFAULT now(),
  updated_at timestamp NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_internal_employee_payments_empresa ON internal_employee_payments(empresa_id);
CREATE INDEX IF NOT EXISTS idx_internal_employee_payments_employee ON internal_employee_payments(employee_id);
CREATE INDEX IF NOT EXISTS idx_internal_employee_payments_competence ON internal_employee_payments(competence);
