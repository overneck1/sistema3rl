import { 
  Seamstress, InsertSeamstress, Production, InsertProduction, 
  Batch, InsertBatch, QualityControl, InsertQualityControl, 
  Payment, InsertPayment, ExtraCost, InsertExtraCost, seamstresses, productions, batches, 
  qualityControls, payments, extraCosts, productionVariants, ProductionVariant, InsertProductionVariant,
  batchVariantAllocations, BatchVariantAllocation, InsertBatchVariantAllocation, insertPaymentSchema,
  whatsappMessages, WhatsAppMessage, InsertWhatsAppMessage,
  suppliers, Supplier, InsertSupplier,
  advances, Advance, InsertAdvance,
  batchDeliveries, BatchDelivery, InsertBatchDelivery
} from "@shared/schema";
import { db } from "./db";
import { eq, desc, and, gte, lte, like, sql } from "drizzle-orm";

export interface IStorage {
  // Seamstresses
  getSeamstress(id: string): Promise<Seamstress | undefined>;
  listSeamstresses(): Promise<Seamstress[]>;
  createSeamstress(data: InsertSeamstress): Promise<Seamstress>;
  updateSeamstress(id: string, data: Partial<InsertSeamstress>): Promise<Seamstress>;
  
  // Productions
  getProduction(id: string): Promise<Production | undefined>;
  listProductions(): Promise<Production[]>;
  createProduction(data: InsertProduction): Promise<Production>;
  updateProduction(id: string, data: Partial<InsertProduction>): Promise<Production>;
  deleteProduction(id: string): Promise<void>;
  getSeamstressesByProduction(productionId: string): Promise<(Seamstress & { batchCount: number })[]>;
  
  // Production Variants
  getProductionVariants(productionId: string): Promise<ProductionVariant[]>;
  getProductionVariantsWithAvailable(productionId: string): Promise<(ProductionVariant & { availableQuantity: number })[]>;
  getProductionVariant(variantId: string): Promise<ProductionVariant | undefined>;
  createProductionVariant(data: InsertProductionVariant): Promise<ProductionVariant>;
  updateProductionVariant(variantId: string, data: Partial<ProductionVariant>): Promise<ProductionVariant>;
  deleteProductionVariantsByProduction(productionId: string): Promise<void>;
  
  // Batches
  getBatch(id: string): Promise<Batch | undefined>;
  listBatches(): Promise<Batch[]>;
  listBatchesByProduction(productionId: string): Promise<Batch[]>;
  listBatchesBySeamstress(seamstressId: string): Promise<Batch[]>;
  createBatch(data: InsertBatch): Promise<Batch>;
  updateBatch(id: string, data: Partial<InsertBatch>): Promise<Batch>;
  deleteBatch(id: string): Promise<void>;
  
  // Quality Control
  getQualityControl(id: string): Promise<QualityControl | undefined>;
  getQualityControlByBatch(batchId: string): Promise<QualityControl | undefined>;
  createQualityControl(data: InsertQualityControl): Promise<QualityControl>;
  updateQualityControl(id: string, data: Partial<InsertQualityControl>): Promise<QualityControl>;
  
  // Batch Variant Allocations
  getBatchVariantAllocations(batchId: string): Promise<BatchVariantAllocation[]>;
  createBatchVariantAllocation(data: InsertBatchVariantAllocation): Promise<BatchVariantAllocation>;
  deleteBatchVariantAllocations(batchId: string): Promise<void>;
  
  // Payments
  getPayment(id: string): Promise<Payment | undefined>;
  listPaymentsBySeamstress(seamstressId: string): Promise<Payment[]>;
  listPaymentsByBatch(batchId: string): Promise<Payment[]>;
  createPayment(data: InsertPayment): Promise<Payment>;
  updatePayment(id: string, data: Partial<InsertPayment>): Promise<Payment>;
  getSeamstressPaymentDetails(seamstressId: string): Promise<any>;
  getAlerts(): Promise<any>;

  // Extra Costs
  getExtraCost(id: string): Promise<ExtraCost | undefined>;
  listExtraCosts(): Promise<ExtraCost[]>;
  createExtraCost(data: InsertExtraCost): Promise<ExtraCost>;
  deleteExtraCost(id: string): Promise<void>;

  // Advances (adiantamentos)
  listAdvances(): Promise<Advance[]>;
  listAdvancesBySeamstress(seamstressId: string): Promise<Advance[]>;
  createAdvance(data: InsertAdvance): Promise<Advance>;
  deleteAdvance(id: string): Promise<void>;

  // Batch Deliveries (entregas parciais)
  listBatchDeliveries(batchId: string): Promise<BatchDelivery[]>;
  createBatchDelivery(data: InsertBatchDelivery): Promise<BatchDelivery>;
  deleteBatchDelivery(id: string): Promise<void>;
  getTotalDeliveredByBatch(batchId: string): Promise<number>;

  // List all payments
  listPayments?(): Promise<Payment[]>;
  
  // Generate missing payments
  generateMissingPayments?(): Promise<void>;

  // WhatsApp Messages
  getWhatsAppMessages(limit?: number): Promise<WhatsAppMessage[]>;
  getWhatsAppMessagesByJid(remoteJid: string, limit?: number): Promise<WhatsAppMessage[]>;
  createWhatsAppMessage(data: InsertWhatsAppMessage): Promise<WhatsAppMessage>;
  markWhatsAppMessageAsRead(messageId: string): Promise<WhatsAppMessage>;

  // Suppliers
  getSupplier(id: string): Promise<Supplier | undefined>;
  listSuppliers(): Promise<Supplier[]>;
  createSupplier(data: InsertSupplier): Promise<Supplier>;
  updateSupplier(id: string, data: Partial<InsertSupplier>): Promise<Supplier>;
  deleteSupplier(id: string): Promise<void>;
}

export class DatabaseStorage implements IStorage {
  // Seamstresses
  async getSeamstress(id: string): Promise<Seamstress | undefined> {
    const [result] = await db.select().from(seamstresses).where(eq(seamstresses.id, id));
    return result;
  }

  async listSeamstresses(): Promise<(Seamstress & { batches: Batch[] })[]> {
    const allSeamstresses = await db.select().from(seamstresses).orderBy(desc(seamstresses.createdAt));
    
    const seamstressesWithBatches = await Promise.all(
      allSeamstresses.map(async (seamstress) => {
        const batchList = await db.select().from(batches).where(eq(batches.seamstressId, seamstress.id));
        return {
          ...seamstress,
          batches: batchList,
        };
      })
    );
    
    return seamstressesWithBatches;
  }

  async createSeamstress(data: InsertSeamstress): Promise<Seamstress> {
    const [result] = await db.insert(seamstresses).values(data).returning();
    return result;
  }

  async updateSeamstress(id: string, data: Partial<InsertSeamstress>): Promise<Seamstress> {
    const [result] = await db.update(seamstresses).set(data).where(eq(seamstresses.id, id)).returning();
    return result;
  }

  async deleteSeamstress(id: string): Promise<void> {
    // Delete all batches for this seamstress
    const seamstressBatches = await db.select().from(batches).where(eq(batches.seamstressId, id));
    for (const batch of seamstressBatches) {
      await db.delete(batchVariantAllocations).where(eq(batchVariantAllocations.batchId, batch.id));
    }
    await db.delete(batches).where(eq(batches.seamstressId, id));
    
    // Delete all payments for this seamstress
    await db.delete(payments).where(eq(payments.seamstressId, id));
    
    // Delete the seamstress
    await db.delete(seamstresses).where(eq(seamstresses.id, id));
  }

  // Productions
  async getProduction(id: string): Promise<Production | undefined> {
    const [result] = await db.select().from(productions).where(eq(productions.id, id));
    return result;
  }

  async listProductions(): Promise<any[]> {
    // Fetch all data in parallel for better performance
    const [allProductions, allBatches, allVariants, allSeamstresses] = await Promise.all([
      db.select().from(productions).orderBy(desc(productions.createdAt)),
      db.select().from(batches),
      db.select().from(productionVariants),
      db.select().from(seamstresses),
    ]);
    
    // Create lookup maps for O(1) access
    const seamstressMap = new Map(allSeamstresses.map(s => [s.id, s]));
    const batchesByProduction = new Map<string, typeof allBatches>();
    const variantsByProduction = new Map<string, typeof allVariants>();
    
    allBatches.forEach(batch => {
      const list = batchesByProduction.get(batch.productionId) || [];
      list.push(batch);
      batchesByProduction.set(batch.productionId, list);
    });
    
    allVariants.forEach(variant => {
      const list = variantsByProduction.get(variant.productionId) || [];
      list.push(variant);
      variantsByProduction.set(variant.productionId, list);
    });
    
    // Build production data with all needed info
    const prodWithData = allProductions.map(prod => {
      const productionBatches = batchesByProduction.get(prod.id) || [];
      const variants = variantsByProduction.get(prod.id) || [];
      
      // Calculate allocated quantity from batches
      const allocatedQuantity = productionBatches.reduce((sum, b) => sum + (b.quantity || 0), 0);
      
      // Calculate cost from batches (quantity × pricePerUnit)
      const totalCost = productionBatches.reduce((sum, b) => {
        const qty = b.quantity || 0;
        const price = parseFloat(b.pricePerUnit as any) || 0;
        return sum + (qty * price);
      }, 0);
      
      // Available = production.quantity - allocated batches
      const totalQuantity = prod.quantity || 0;
      const availableQuantity = Math.max(0, totalQuantity - allocatedQuantity);
      
      // Include batches with seamstress info for frontend
      const batchesWithSeamstress = productionBatches.map(batch => ({
        batch,
        seamstress: seamstressMap.get(batch.seamstressId) || null,
      }));
      
      return { 
        ...prod, 
        variants,
        allocatedQuantity,
        availableQuantity,
        totalCost,
        batches: batchesWithSeamstress,
      };
    });
    
    return prodWithData;
  }

  async createProduction(data: InsertProduction): Promise<Production> {
    const productionCode = `PROD-${Date.now()}`;
    const [result] = await db.insert(productions).values({ ...data, productionCode } as any).returning();
    return result;
  }

  async updateProduction(id: string, data: Partial<InsertProduction>): Promise<Production> {
    const [result] = await db.update(productions).set(data).where(eq(productions.id, id)).returning();
    return result;
  }

  async deleteProduction(id: string): Promise<void> {
    // Delete batch variant allocations for batches of this production
    const productionBatches = await db.select().from(batches).where(eq(batches.productionId, id));
    for (const batch of productionBatches) {
      await db.delete(batchVariantAllocations).where(eq(batchVariantAllocations.batchId, batch.id));
    }
    
    // Delete batches for this production
    await db.delete(batches).where(eq(batches.productionId, id));
    
    // Delete production variants
    await this.deleteProductionVariantsByProduction(id);
    
    // Delete the production itself
    await db.delete(productions).where(eq(productions.id, id));
  }

  async getSeamstressesByProduction(productionId: string): Promise<(Seamstress & { batchCount: number })[]> {
    const productionBatches = await db.select().from(batches).where(eq(batches.productionId, productionId));
    
    const seamstressMap = new Map<string, { seamstress: Seamstress; count: number }>();
    
    for (const batch of productionBatches) {
      const seamstress = await this.getSeamstress(batch.seamstressId);
      if (seamstress) {
        if (!seamstressMap.has(seamstress.id)) {
          seamstressMap.set(seamstress.id, { seamstress, count: 0 });
        }
        seamstressMap.get(seamstress.id)!.count += 1;
      }
    }
    
    return Array.from(seamstressMap.values()).map(({ seamstress, count }) => ({
      ...seamstress,
      batchCount: count,
    }));
  }

  // Production Variants
  async listAllProductionVariants(): Promise<(ProductionVariant & { availableQuantity: number })[]> {
    const allVariants = await db.select().from(productionVariants);
    
    const variantsWithAvailable = await Promise.all(allVariants.map(async (variant) => {
      const allocations = await db.select().from(batchVariantAllocations).where(eq(batchVariantAllocations.variantId, variant.id));
      const allocatedQty = allocations.reduce((sum: number, a: any) => sum + a.quantity, 0);
      const availableQuantity = Math.max(0, variant.quantity - allocatedQty);
      return { ...variant, availableQuantity };
    }));
    
    return variantsWithAvailable;
  }

  async listOpenProductionsWithAvailable(): Promise<(Production & { availableQuantity: number })[]> {
    // Get ONLY productions in "em_separacao" status that have available quantities
    const allProductions = await db.select().from(productions).where(eq(productions.status, "em_separacao"));
    
    const prodWithAvailable = await Promise.all(allProductions.map(async (prod) => {
      // Use production.quantity as the base (this is the actual production order)
      const totalQuantity = prod.quantity || 0;
      
      // Count batches directly - sum of all batch quantities for this production
      const batchesForProd = await db.select().from(batches).where(eq(batches.productionId, prod.id));
      const totalAllocated = batchesForProd.reduce((sum: number, b: any) => sum + (b.quantity || 0), 0);
      
      // Calculate available: production quantity minus batches quantity
      const availableQuantity = Math.max(0, totalQuantity - totalAllocated);
      
      return { ...prod, availableQuantity };
    }));
    
    // Filter to only return productions with availableQuantity > 0
    return prodWithAvailable.filter(p => p.availableQuantity > 0);
  }

  async updateProductionStatusIfFullyAllocated(productionId: string): Promise<void> {
    const production = await this.getProduction(productionId);
    if (!production) return;
    
    // Use production.quantity as the base
    const totalQuantity = production.quantity || 0;
    
    // Count batches directly
    const batchesForProd = await db.select().from(batches).where(eq(batches.productionId, productionId));
    const totalAllocated = batchesForProd.reduce((sum: number, b: any) => sum + (b.quantity || 0), 0);
    
    const availableQuantity = Math.max(0, totalQuantity - totalAllocated);
    
    // If everything is allocated, move to "em_producao"
    if (availableQuantity === 0 && totalAllocated > 0 && production.status === "em_separacao") {
      await db.update(productions).set({ status: "em_producao" as any }).where(eq(productions.id, productionId));
    }
    // If there's still available quantity, move back to "em_separacao"
    else if (availableQuantity > 0 && production.status !== "em_separacao") {
      await db.update(productions).set({ status: "em_separacao" as any }).where(eq(productions.id, productionId));
    }
  }

  async getProductionVariants(productionId: string): Promise<ProductionVariant[]> {
    return await db.select().from(productionVariants).where(eq(productionVariants.productionId, productionId));
  }

  async getProductionVariantsWithAvailable(productionId: string): Promise<(ProductionVariant & { availableQuantity: number })[]> {
    const variants = await db.select().from(productionVariants).where(eq(productionVariants.productionId, productionId));
    
    const variantsWithAvailable = await Promise.all(variants.map(async (variant) => {
      const allocations = await db.select().from(batchVariantAllocations).where(eq(batchVariantAllocations.variantId, variant.id));
      const allocatedQty = allocations.reduce((sum: number, a: any) => sum + a.quantity, 0);
      const availableQuantity = Math.max(0, variant.quantity - allocatedQty);
      return { ...variant, availableQuantity };
    }));
    
    return variantsWithAvailable;
  }

  async getProductionVariant(variantId: string): Promise<ProductionVariant | undefined> {
    const [result] = await db.select().from(productionVariants).where(eq(productionVariants.id, variantId));
    return result;
  }

  async createProductionVariant(data: InsertProductionVariant): Promise<ProductionVariant> {
    const [result] = await db.insert(productionVariants).values(data).returning();
    return result;
  }

  async updateProductionVariant(variantId: string, data: Partial<ProductionVariant>): Promise<ProductionVariant> {
    const [result] = await db.update(productionVariants).set(data as any).where(eq(productionVariants.id, variantId)).returning();
    return result;
  }

  async deleteProductionVariantsByProduction(productionId: string): Promise<void> {
    // Get all variants for this production
    const variantsToDelete = await db.select().from(productionVariants).where(eq(productionVariants.productionId, productionId));
    
    // Delete batch variant allocations that reference these variants
    for (const variant of variantsToDelete) {
      await db.delete(batchVariantAllocations).where(eq(batchVariantAllocations.variantId, variant.id));
    }
    
    // Delete the production variants
    await db.delete(productionVariants).where(eq(productionVariants.productionId, productionId));
  }

  // Batches
  async getBatch(id: string): Promise<Batch | undefined> {
    const [result] = await db.select().from(batches).where(eq(batches.id, id));
    return result;
  }

  async listBatches(): Promise<any[]> {
    const { seamstresses, productions } = await import("@shared/schema");
    return await db
      .select({
        id: batches.id,
        batchCode: batches.batchCode,
        productionId: batches.productionId,
        seamstressId: batches.seamstressId,
        quantity: batches.quantity,
        status: batches.status,
        sendDate: batches.sendDate,
        expectedReturnDate: batches.expectedReturnDate,
        returnedDate: batches.returnedDate,
        pricePerUnit: batches.pricePerUnit,
        createdAt: batches.createdAt,
        seamstress: seamstresses,
        production: productions,
      })
      .from(batches)
      .leftJoin(seamstresses, eq(batches.seamstressId, seamstresses.id))
      .leftJoin(productions, eq(batches.productionId, productions.id))
      .orderBy(desc(batches.createdAt));
  }

  async listBatchesByProduction(productionId: string): Promise<any[]> {
    const { seamstresses } = await import("@shared/schema");
    return await db
      .select({
        batch: batches,
        seamstress: seamstresses,
      })
      .from(batches)
      .leftJoin(seamstresses, eq(batches.seamstressId, seamstresses.id))
      .where(eq(batches.productionId, productionId));
  }

  async listBatchesBySeamstress(seamstressId: string): Promise<Batch[]> {
    return await db.select().from(batches).where(eq(batches.seamstressId, seamstressId));
  }

  async createBatch(data: InsertBatch): Promise<Batch> {
    // Gerar código de lote com 4 dígitos - buscar o maior número existente
    const allBatches = await db.select().from(batches);
    let maxNumber = 0;
    for (const batch of allBatches) {
      const match = batch.batchCode.match(/L-(\d+)/);
      if (match) {
        const num = parseInt(match[1], 10);
        if (num > maxNumber) {
          maxNumber = num;
        }
      }
    }
    const nextNumber = maxNumber + 1;
    const paddedNumber = String(nextNumber).padStart(4, "0");
    const batchCode = `L-${paddedNumber}`;
    const [result] = await db.insert(batches).values({ ...data, batchCode } as any).returning();
    return result;
  }

  async updateBatch(id: string, data: Partial<InsertBatch>): Promise<Batch> {
    const [result] = await db.update(batches).set(data).where(eq(batches.id, id)).returning();
    
    // If batch status changed to "concluido", check if all batches for this production are done
    if (data.status === "concluido" && result.productionId) {
      const productionBatches = await db.select().from(batches).where(eq(batches.productionId, result.productionId));
      const allConcluded = productionBatches.every((b: any) => b.status === "concluido" || b.id === id);
      
      if (allConcluded) {
        await db.update(productions).set({ status: "concluido" as any }).where(eq(productions.id, result.productionId));
      }
    }
    
    return result;
  }

  async deleteBatch(id: string): Promise<void> {
    // First delete payments associated with this batch
    await db.delete(payments).where(eq(payments.batchId, id));
    // Then delete batch variant allocations
    await db.delete(batchVariantAllocations).where(eq(batchVariantAllocations.batchId, id));
    // Then delete quality control if exists
    await db.delete(qualityControls).where(eq(qualityControls.batchId, id));
    // Finally delete the batch itself
    await db.delete(batches).where(eq(batches.id, id));
  }

  async deleteSeamstress(id: string): Promise<void> {
    // Delete advances for this seamstress
    await db.delete(advances).where(eq(advances.seamstressId, id));
    // Delete payments for this seamstress  
    await db.delete(payments).where(eq(payments.seamstressId, id));
    // Then delete the seamstress
    await db.delete(seamstresses).where(eq(seamstresses.id, id));
  }

  // Quality Control
  async getQualityControl(id: string): Promise<QualityControl | undefined> {
    const [result] = await db.select().from(qualityControls).where(eq(qualityControls.id, id));
    return result;
  }

  async getQualityControlByBatch(batchId: string): Promise<QualityControl | undefined> {
    const [result] = await db.select().from(qualityControls).where(eq(qualityControls.batchId, batchId));
    return result;
  }

  async createQualityControl(data: InsertQualityControl): Promise<QualityControl> {
    const [result] = await db.insert(qualityControls).values(data).returning();
    return result;
  }

  async updateQualityControl(id: string, data: Partial<InsertQualityControl>): Promise<QualityControl> {
    const [result] = await db.update(qualityControls).set(data).where(eq(qualityControls.id, id)).returning();
    return result;
  }

  // Payments
  async getPayment(id: string): Promise<Payment | undefined> {
    const [result] = await db.select().from(payments).where(eq(payments.id, id));
    return result;
  }

  async listPaymentsBySeamstress(seamstressId: string): Promise<Payment[]> {
    return await db.select().from(payments).where(eq(payments.seamstressId, seamstressId));
  }

  async listPaymentsByBatch(batchId: string): Promise<Payment[]> {
    return await db.select().from(payments).where(eq(payments.batchId, batchId));
  }

  async createPayment(data: InsertPayment): Promise<Payment> {
    const [result] = await db.insert(payments).values(data).returning();
    return result;
  }

  async updatePayment(id: string, data: Partial<InsertPayment>): Promise<Payment> {
    // Convert ISO date strings to Date objects if present
    const processedData: any = {
      ...data,
      dueDate: data.dueDate ? (typeof data.dueDate === 'string' ? new Date(data.dueDate) : data.dueDate) : undefined,
      paidDate: data.paidDate ? (typeof data.paidDate === 'string' ? new Date(data.paidDate) : data.paidDate) : undefined,
    };
    // Remove undefined fields to avoid overwriting with null
    Object.keys(processedData).forEach(key => processedData[key] === undefined && delete processedData[key]);
    const [result] = await db.update(payments).set(processedData).where(eq(payments.id, id)).returning();
    return result;
  }

  // Get detailed payment info for seamstress
  async getSeamstressPaymentDetails(seamstressId: string) {
    const seamstress = await this.getSeamstress(seamstressId);
    const paymentList = await this.listPaymentsBySeamstress(seamstressId);
    const batchList = await this.listBatchesBySeamstress(seamstressId);
    
    const totalToPay = paymentList
      .filter(p => p.status === "pending")
      .reduce((sum, p) => sum + parseFloat(p.amount.toString()), 0);

    const totalPaid = paymentList
      .filter(p => p.status === "paid")
      .reduce((sum, p) => sum + parseFloat(p.amount.toString()), 0);

    return {
      seamstress,
      payments: paymentList,
      batches: batchList,
      totalToPay,
      totalPaid,
    };
  }

  // Get alerts for payments and overdue batches
  async getAlerts() {
    const batchList = await this.listBatches();
    const productionList = await this.listProductions();
    const paymentList = await db.select().from(payments);
    
    const alerts = {
      overduePayments: [] as any[],
      overdueBatches: [] as any[],
      overdueProductions: [] as any[],
      completedNoPayment: [] as any[],
    };

    const now = new Date();
    const thirtyDaysAgo = new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000);

    // Payments pending for more than 30 days
    for (const payment of paymentList.filter(p => p.status === "pending")) {
      if (new Date(payment.createdAt) < thirtyDaysAgo) {
        const batch = batchList.find(b => b.id === payment.batchId);
        const seamstress = await this.getSeamstress(payment.seamstressId);
        alerts.overduePayments.push({
          paymentId: payment.id,
          seamstress,
          amount: parseFloat(payment.amount.toString()),
          daysOverdue: Math.floor((now.getTime() - new Date(payment.createdAt).getTime()) / (24 * 60 * 60 * 1000)),
        });
      }
    }

    // Overdue batches (past return date) - for em_producao and para_recolha status
    for (const batch of batchList.filter(b => b.status === "em_producao" || b.status === "para_recolha")) {
      if (new Date(batch.expectedReturnDate) < now) {
        const seamstress = await this.getSeamstress(batch.seamstressId);
        alerts.overdueBatches.push({
          batchId: batch.id,
          batchCode: batch.batchCode,
          seamstress,
          daysLate: Math.floor((now.getTime() - new Date(batch.expectedReturnDate).getTime()) / (24 * 60 * 60 * 1000)),
        });
      }
    }

    // Overdue productions (past delivery date)
    for (const production of productionList.filter(p => p.status !== "concluido")) {
      if (new Date(production.deliveryDate) < now) {
        alerts.overdueProductions.push({
          productionId: production.id,
          productionCode: production.productionCode,
          productName: production.productName,
          supplier: production.supplier,
          daysLate: Math.floor((now.getTime() - new Date(production.deliveryDate).getTime()) / (24 * 60 * 60 * 1000)),
        });
      }
    }

    return alerts;
  }

  // Extra Costs
  async getExtraCost(id: string): Promise<ExtraCost | undefined> {
    const [result] = await db.select().from(extraCosts).where(eq(extraCosts.id, id));
    return result;
  }

  async listExtraCosts(): Promise<ExtraCost[]> {
    return await db.select().from(extraCosts).orderBy(desc(extraCosts.createdAt));
  }

  async createExtraCost(data: InsertExtraCost): Promise<ExtraCost> {
    const [result] = await db.insert(extraCosts).values(data).returning();
    return result;
  }

  async deleteExtraCost(id: string): Promise<void> {
    await db.delete(extraCosts).where(eq(extraCosts.id, id));
  }

  // Advances (adiantamentos)
  async listAdvances(): Promise<Advance[]> {
    return await db.select().from(advances).orderBy(desc(advances.createdAt));
  }

  async listAdvancesBySeamstress(seamstressId: string): Promise<Advance[]> {
    return await db.select().from(advances).where(eq(advances.seamstressId, seamstressId)).orderBy(desc(advances.createdAt));
  }

  async createAdvance(data: InsertAdvance): Promise<Advance> {
    const [result] = await db.insert(advances).values(data).returning();
    return result;
  }

  async deleteAdvance(id: string): Promise<void> {
    await db.delete(advances).where(eq(advances.id, id));
  }

  // Batch Deliveries (entregas parciais)
  async listBatchDeliveries(batchId: string): Promise<BatchDelivery[]> {
    return await db.select().from(batchDeliveries).where(eq(batchDeliveries.batchId, batchId)).orderBy(desc(batchDeliveries.deliveredAt));
  }

  async createBatchDelivery(data: InsertBatchDelivery): Promise<BatchDelivery> {
    const [result] = await db.insert(batchDeliveries).values(data).returning();
    return result;
  }

  async deleteBatchDelivery(id: string): Promise<void> {
    await db.delete(batchDeliveries).where(eq(batchDeliveries.id, id));
  }

  async getTotalDeliveredByBatch(batchId: string): Promise<number> {
    const deliveries = await db.select().from(batchDeliveries).where(eq(batchDeliveries.batchId, batchId));
    return deliveries.reduce((sum, d) => sum + d.deliveredQuantity, 0);
  }

  // WhatsApp Messages
  async getWhatsAppMessages(limit: number = 100): Promise<WhatsAppMessage[]> {
    return db.select().from(whatsappMessages).orderBy(desc(whatsappMessages.timestamp)).limit(limit);
  }

  async getWhatsAppMessagesByJid(remoteJid: string, limit: number = 50): Promise<WhatsAppMessage[]> {
    return db.select().from(whatsappMessages)
      .where(eq(whatsappMessages.remoteJid, remoteJid))
      .orderBy(desc(whatsappMessages.timestamp))
      .limit(limit);
  }

  async createWhatsAppMessage(data: InsertWhatsAppMessage): Promise<WhatsAppMessage> {
    const [result] = await db.insert(whatsappMessages).values(data).returning();
    return result;
  }

  async markWhatsAppMessageAsRead(messageId: string): Promise<WhatsAppMessage> {
    const [result] = await db.update(whatsappMessages).set({ isRead: true }).where(eq(whatsappMessages.id, messageId)).returning();
    return result;
  }

  async listPayments(): Promise<Payment[]> {
    return await db.select().from(payments).orderBy(desc(payments.createdAt));
  }

  // Batch Variant Allocations
  async getBatchVariantAllocations(batchId: string): Promise<BatchVariantAllocation[]> {
    return await db.select().from(batchVariantAllocations).where(eq(batchVariantAllocations.batchId, batchId));
  }

  async createBatchVariantAllocation(data: InsertBatchVariantAllocation): Promise<BatchVariantAllocation> {
    const [result] = await db.insert(batchVariantAllocations).values(data).returning();
    return result;
  }

  async deleteBatchVariantAllocations(batchId: string): Promise<void> {
    await db.delete(batchVariantAllocations).where(eq(batchVariantAllocations.batchId, batchId));
  }

  // Update batch statuses automatically based on dates
  async updateBatchStatusesBasedOnDates() {
    try {
      try {
        const batchList = await this.listBatches();
        const now = new Date();

        for (const batch of batchList) {
          const expectedReturnDate = new Date(batch.expectedReturnDate);
          
          // Se está em "em_producao" e chegou a data de recolha, muda para "para_recolha"
          if (batch.status === "em_producao" && expectedReturnDate <= now) {
            await this.updateBatch(batch.id, { status: "para_recolha" });
          }
        }
      } catch (dbError: any) {
        // If database is unavailable, silently log and continue
        if (dbError?.message?.includes("endpoint has been disabled") || dbError?.code === "XX000") {
          console.warn("Database endpoint unavailable, skipping batch status update");
          return;
        }
        throw dbError;
      }
    } catch (error) {
      console.error("Erro ao atualizar status dos lotes:", error);
    }
  }

  // Generate missing payments for batches that need payment
  async generateMissingPayments() {
    try {
      try {
        const batchList = await this.listBatches();
        // Create payments ONLY for concluido batches
        const batchesToPay = batchList.filter(b => b.status === "concluido");
        
        for (const batch of batchesToPay) {
          try {
            // Double-check: verify no payments exist for this batch
            const [existingPayment] = await db.select().from(payments).where(eq(payments.batchId, batch.id)).limit(1);
            
            // Only create payment if it doesn't exist AND batch has a seamstress
            if (!existingPayment && batch.seamstressId) {
              try {
                const paymentAmount = batch.quantity * parseFloat(batch.pricePerUnit.toString());
                // Set due date to 7 days from now
                const futureDate = new Date(Date.now() + 7 * 24 * 60 * 60 * 1000);
                
                // Use try-catch to handle any unique constraint violations
                try {
                  await db.insert(payments).values({
                    batchId: batch.id,
                    seamstressId: batch.seamstressId,
                    amount: paymentAmount.toString(),
                    status: "pending",
                    dueDate: futureDate,
                  } as any).returning();
                } catch (insertErr: any) {
                  console.error(`Payment creation error for batch ${batch.id}:`, insertErr.message);
                }
              } catch (err) {
                console.error(`Error processing batch ${batch.id}:`, err);
              }
            }
          } catch (batchErr: any) {
            console.error(`Error processing batch:`, batchErr.message);
          }
        }
      } catch (dbError: any) {
        // If database is unavailable, silently log and continue
        if (dbError?.message?.includes("endpoint has been disabled") || dbError?.code === "XX000") {
          console.warn("Database endpoint unavailable, skipping payment generation");
          return;
        }
        throw dbError;
      }
    } catch (error) {
      console.error("Error in generateMissingPayments:", error);
    }
  }

  // Dashboard data
  async getDashboardData() {
    try {
      // Update batch statuses based on dates first
      await this.updateBatchStatusesBasedOnDates();
      
      // Generate missing payments
      await this.generateMissingPayments();
      
      const prods = await this.listProductions();
      const batchList = await this.listBatches();
      const seamstressList = await this.listSeamstresses();
      const paymentsList = await db.select().from(payments);
      const extraCostsList = await this.listExtraCosts();

      const now = new Date();

      // Calcula métricas
      const activeProductions = prods.filter(p => p.status !== "concluido").length;
      
      // Lotes atrasados: em "para_recolha" com data passada
      const delayedBatches = batchList.filter(b => {
        if (b.status !== "para_recolha") return false;
        return new Date(b.expectedReturnDate) < now;
      }).length;
      
      // Lotes pendentes: em "em_separacao", "para_entrega" ou "em_producao"
      const pendingBatches = batchList.filter(b => b.status === "em_separacao" || b.status === "para_entrega" || b.status === "em_producao").length;
      const totalSeamstresses = seamstressList.length;

      // Calcula receita total (baseada na quantidade de PRODUÇÃO original)
      const totalReceita = prods.reduce((sum, p) => {
        const qty = p.quantity || 0;
        return sum + (qty * parseFloat(p.pricePerUnit.toString()));
      }, 0);

      // Calcula receita das produções concluídas e pendentes de pagamento
      const producaoConcluida = prods
        .filter(p => p.status === "concluido" && p.paymentStatus === "Pendente")
        .reduce((sum, p) => {
          const qty = p.quantity || 0;
          return sum + (qty * parseFloat(p.pricePerUnit.toString()));
        }, 0);

      // Calcula receita das produções que já foram pagas (recebidas)
      const pagamentosRecebidos = prods
        .filter(p => p.paymentStatus === "Recebido")
        .reduce((sum, p) => {
          const qty = p.quantity || 0;
          return sum + (qty * parseFloat(p.pricePerUnit.toString()));
        }, 0);

      // Calcula custo total: SUM(batch.quantity × batch.pricePerUnit) para TODOS os batches
      const batchesCost = batchList.reduce((sum, b) => {
        const qty = b.quantity || 0;
        const batchCost = qty * parseFloat(b.pricePerUnit.toString());
        return sum + batchCost;
      }, 0);

      const extraCostsTotal = extraCostsList.reduce((sum, cost) => {
        return sum + parseFloat(cost.amount.toString());
      }, 0);

      const totalCusto = batchesCost + extraCostsTotal;

      // Calcula pagamentos pendentes e feitos (apenas para referência)
      const pagamentosPendentes = paymentsList
        .filter(p => p.status === "pending")
        .reduce((sum, p) => sum + parseFloat(p.amount.toString()), 0);

      const pagamentosFeitos = paymentsList
        .filter(p => p.status === "paid")
        .reduce((sum, p) => sum + parseFloat(p.amount.toString()), 0);

      // Calcula lucro
      const lucroAbsoluto = totalReceita - totalCusto;
      const lucroPercentual = totalReceita > 0 ? (lucroAbsoluto / totalReceita) * 100 : 0;

      // Calcula dados mensais com receita, custo e lucro
      const monthlyData: Record<string, { productions: number; completed: number; revenue: number; cost: number; profit: number }> = {};
      const monthNames = ["Jan", "Fev", "Mar", "Abr", "Mai", "Jun", "Jul", "Ago", "Set", "Out", "Nov", "Dez"];
      
      // Agrupa produções (receita) por mês
      prods.forEach(prod => {
        const date = new Date(prod.date);
        const monthKey = monthNames[date.getMonth()];
        
        if (!monthlyData[monthKey]) {
          monthlyData[monthKey] = { productions: 0, completed: 0, revenue: 0, cost: 0, profit: 0 };
        }
        monthlyData[monthKey].productions += 1;
        if (prod.status === "concluido") {
          monthlyData[monthKey].completed += 1;
        }
        
        // Adiciona receita da produção
        const qty = prod.quantity || 0;
        monthlyData[monthKey].revenue += qty * parseFloat(prod.pricePerUnit.toString());
      });

      // Agrupa batches (custo) por mês usando sendDate
      batchList.forEach(batch => {
        const date = new Date(batch.sendDate);
        if (isNaN(date.getTime())) return; // Ignora datas inválidas
        
        const monthKey = monthNames[date.getMonth()];
        
        if (!monthlyData[monthKey]) {
          monthlyData[monthKey] = { productions: 0, completed: 0, revenue: 0, cost: 0, profit: 0 };
        }
        
        // Adiciona custo do batch
        const qty = batch.quantity || 0;
        monthlyData[monthKey].cost += qty * parseFloat(batch.pricePerUnit.toString());
      });

      // Agrupa custos extras por mês
      extraCostsList.forEach(cost => {
        const date = new Date(cost.date);
        const monthKey = monthNames[date.getMonth()];
        
        if (!monthlyData[monthKey]) {
          monthlyData[monthKey] = { productions: 0, completed: 0, revenue: 0, cost: 0, profit: 0 };
        }
        
        // Adiciona custo extra
        monthlyData[monthKey].cost += parseFloat(cost.amount.toString());
      });

      // Calcula lucro de cada mês
      Object.keys(monthlyData).forEach(month => {
        monthlyData[month].profit = monthlyData[month].revenue - monthlyData[month].cost;
      });

      // Formata para o gráfico - filtra meses indefinidos e ordena
      const chartData = Object.entries(monthlyData)
        .filter(([month]) => month !== 'undefined' && month.length > 0)
        .map(([month, data]) => ({
          month,
          productions: data.productions,
          completed: data.completed,
          profit: data.profit,
        }))
        .slice(-6);

      return {
        activeProductions,
        delayedBatches,
        pendingBatches,
        totalSeamstresses,
        totalReceita,
        totalCusto,
        pagamentosPendentes,
        pagamentosFeitos,
        lucroAbsoluto,
        lucroPercentual,
        producaoConcluida,
        pagamentosRecebidos,
        monthlyData: chartData,
      };
    } catch (error: any) {
      console.error("Error in getDashboardData:", error?.message);
      // Return default empty data if database is unavailable
      return {
        activeProductions: 0,
        delayedBatches: 0,
        pendingBatches: 0,
        totalSeamstresses: 0,
        totalReceita: 0,
        totalCusto: 0,
        pagamentosPendentes: 0,
        pagamentosFeitos: 0,
        lucroAbsoluto: 0,
        lucroPercentual: 0,
        producaoConcluida: 0,
        pagamentosRecebidos: 0,
        monthlyData: [],
      };
    }
  }

  // Suppliers
  async getSupplier(id: string): Promise<Supplier | undefined> {
    const [result] = await db.select().from(suppliers).where(eq(suppliers.id, id));
    return result;
  }

  async listSuppliers(): Promise<Supplier[]> {
    return await db.select().from(suppliers).orderBy(desc(suppliers.createdAt));
  }

  async createSupplier(data: InsertSupplier): Promise<Supplier> {
    const [result] = await db.insert(suppliers).values(data).returning();
    return result;
  }

  async updateSupplier(id: string, data: Partial<InsertSupplier>): Promise<Supplier> {
    const [result] = await db.update(suppliers).set(data).where(eq(suppliers.id, id)).returning();
    return result;
  }

  async deleteSupplier(id: string): Promise<void> {
    await db.delete(suppliers).where(eq(suppliers.id, id));
  }
}

export const storage = new DatabaseStorage();
