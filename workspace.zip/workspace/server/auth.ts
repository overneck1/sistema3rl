import jwt from "jsonwebtoken";
import bcrypt from "bcryptjs";
import { db } from "./db";
import { admins, empresas, usuarios } from "@shared/schema";
import { eq } from "drizzle-orm";

const JWT_SECRET = process.env.JWT_SECRET;
if (!JWT_SECRET) throw new Error("JWT_SECRET não configurado. Defina a variável JWT_SECRET antes de iniciar o servidor.");
const JWT_EXPIRES_IN = "24h";

export interface AdminPayload {
  id: string;
  email: string;
  name: string;
  role: "superadmin" | "admin";
  type: "admin";
}

export interface UsuarioPayload {
  id: string;
  email: string;
  name: string;
  role: "admin_empresa" | "operador" | "financeiro" | "visualizador";
  empresaId: string;
  empresaCode: string;
  empresaName: string;
  databaseName: string;
  type: "usuario";
}

export type AuthPayload = AdminPayload | UsuarioPayload;

export async function hashPassword(password: string): Promise<string> {
  return bcrypt.hash(password, 12);
}

export async function verifyPassword(password: string, hash: string): Promise<boolean> {
  return bcrypt.compare(password, hash);
}

export function generateToken(payload: AuthPayload): string {
  return jwt.sign(payload, JWT_SECRET, { expiresIn: JWT_EXPIRES_IN });
}

export function verifyToken(token: string): AuthPayload | null {
  try {
    return jwt.verify(token, JWT_SECRET) as AuthPayload;
  } catch {
    return null;
  }
}

export async function loginAdmin(email: string, password: string): Promise<{ token: string; admin: AdminPayload } | null> {
  const [admin] = await db.select().from(admins).where(eq(admins.email, email)).limit(1);
  
  if (!admin || !admin.isActive) {
    return null;
  }

  const isValid = await verifyPassword(password, admin.password);
  if (!isValid) {
    return null;
  }

  const payload: AdminPayload = {
    id: admin.id,
    email: admin.email,
    name: admin.name,
    role: admin.role as "superadmin" | "admin",
    type: "admin",
  };

  return { token: generateToken(payload), admin: payload };
}

export async function loginUsuario(email: string, password: string): Promise<{ token: string; usuario: UsuarioPayload } | null> {
  const [usuario] = await db.select().from(usuarios).where(eq(usuarios.email, email)).limit(1);
  
  if (!usuario || !usuario.isActive) {
    return null;
  }

  const isValid = await verifyPassword(password, usuario.password);
  if (!isValid) {
    return null;
  }

  const [empresa] = await db.select().from(empresas).where(eq(empresas.id, usuario.empresaId)).limit(1);
  
  if (!empresa || empresa.status !== "active") {
    return null;
  }

  const payload: UsuarioPayload = {
    id: usuario.id,
    email: usuario.email,
    name: usuario.name,
    role: usuario.role as "admin_empresa" | "operador" | "financeiro" | "visualizador",
    empresaId: empresa.id,
    empresaCode: empresa.code,
    empresaName: empresa.name,
    databaseName: empresa.databaseName,
    type: "usuario",
  };

  await db.update(usuarios).set({ lastLoginAt: new Date() }).where(eq(usuarios.id, usuario.id));

  return { token: generateToken(payload), usuario: payload };
}

export async function createAdmin(name: string, email: string, password: string, role: "superadmin" | "admin" = "admin") {
  const hashedPassword = await hashPassword(password);
  
  const [admin] = await db.insert(admins).values({
    name,
    email,
    password: hashedPassword,
    role,
  }).returning();

  return admin;
}

export async function createUsuario(
  empresaId: string,
  name: string,
  email: string,
  password: string,
  role: "admin_empresa" | "operador" | "financeiro" | "visualizador" = "operador"
) {
  const hashedPassword = await hashPassword(password);
  
  const [usuario] = await db.insert(usuarios).values({
    empresaId,
    name,
    email,
    password: hashedPassword,
    role,
  }).returning();

  return usuario;
}
