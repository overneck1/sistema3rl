import { Router, Request, Response, NextFunction } from "express";
import { db } from "./db";
import { admins, empresas, usuarios, auditLogs } from "@shared/schema";
import { eq, desc } from "drizzle-orm";
import { randomBytes } from "node:crypto";
import { loginAdmin, loginUsuario, verifyToken, hashPassword, createAdmin, createUsuario, AuthPayload, AdminPayload, UsuarioPayload } from "./auth";
import { sendCompanyCredentialsEmail } from "./email-service";

const router = Router();

declare global {
  namespace Express {
    interface Request {
      user?: AuthPayload;
    }
  }
}

function authMiddleware(req: Request, res: Response, next: NextFunction) {
  const authHeader = req.headers.authorization;
  
  if (!authHeader || !authHeader.startsWith("Bearer ")) {
    return res.status(401).json({ error: "Token não fornecido" });
  }

  const token = authHeader.split(" ")[1];
  const payload = verifyToken(token);

  if (!payload) {
    return res.status(401).json({ error: "Token inválido ou expirado" });
  }

  req.user = payload;
  next();
}

function adminOnly(req: Request, res: Response, next: NextFunction) {
  if (!req.user || req.user.type !== "admin") {
    return res.status(403).json({ error: "Acesso negado. Apenas administradores." });
  }
  next();
}

function superadminOnly(req: Request, res: Response, next: NextFunction) {
  if (!req.user || req.user.type !== "admin" || (req.user as AdminPayload).role !== "superadmin") {
    return res.status(403).json({ error: "Acesso negado. Apenas superadmins." });
  }
  next();
}

router.post("/auth/login", async (req: Request, res: Response) => {
  try {
    const { email, password, type } = req.body;

    if (!email || !password) {
      return res.status(400).json({ error: "Email e senha são obrigatórios" });
    }

    if (type === "admin") {
      const result = await loginAdmin(email, password);
      if (!result) {
        return res.status(401).json({ error: "Credenciais inválidas" });
      }
      return res.json({ success: true, ...result });
    } else {
      const result = await loginUsuario(email, password);
      if (!result) {
        return res.status(401).json({ error: "Credenciais inválidas ou empresa inativa" });
      }
      return res.json({ success: true, ...result });
    }
  } catch (error) {
    console.error("Login error:", error);
    res.status(500).json({ error: "Erro interno do servidor" });
  }
});

router.get("/auth/me", authMiddleware, async (req: Request, res: Response) => {
  res.json({ user: req.user });
});

router.get("/admin/empresas", authMiddleware, adminOnly, async (req: Request, res: Response) => {
  try {
    const allEmpresas = await db.select().from(empresas).orderBy(desc(empresas.createdAt));
    res.json(allEmpresas);
  } catch (error) {
    console.error("Error fetching empresas:", error);
    res.status(500).json({ error: "Erro ao buscar empresas" });
  }
});

router.post("/admin/empresas", authMiddleware, adminOnly, async (req: Request, res: Response) => {
  try {
    const { name, code, subdomain, plan, ownerName, ownerEmail, ownerPhone } = req.body;

    if (!name || !code) {
      return res.status(400).json({ error: "Nome e código são obrigatórios" });
    }

    const existingCode = await db.select().from(empresas).where(eq(empresas.code, code)).limit(1);
    if (existingCode.length > 0) {
      return res.status(400).json({ error: "Código da empresa já existe" });
    }

    const databaseName = `empresa_${code.toLowerCase().replace(/[^a-z0-9]/g, "_")}_db`;

    const [empresa] = await db.insert(empresas).values({
      name,
      code,
      subdomain: subdomain || null,
      databaseName,
      plan: plan || "basic",
      status: "active",
      ownerName: ownerName || null,
      ownerEmail: ownerEmail || null,
      ownerPhone: ownerPhone || null,
    }).returning();

    let temporaryPassword: string | undefined;
    let emailDelivery: any = { sent: false, configured: false };
    if (ownerEmail) {
      temporaryPassword = randomBytes(12).toString("base64url");
      await createUsuario(empresa.id, ownerName || name, ownerEmail, temporaryPassword, "admin_empresa");
      emailDelivery = await sendCompanyCredentialsEmail({
        to: ownerEmail,
        companyName: name,
        login: ownerEmail,
        password: temporaryPassword,
        code,
      });
    }

    await db.insert(auditLogs).values({
      userId: req.user!.id,
      userType: "admin",
      action: "CREATE",
      entity: "empresa",
      entityId: empresa.id,
      details: { name, code },
      ipAddress: req.ip,
    });

    res.status(201).json({ ...empresa, temporaryPassword, emailDelivery });
  } catch (error) {
    console.error("Error creating empresa:", error);
    res.status(500).json({ error: "Erro ao criar empresa" });
  }
});

router.patch("/admin/empresas/:id", authMiddleware, adminOnly, async (req: Request, res: Response) => {
  try {
    const { id } = req.params;
    const { name, status, plan, ownerName, ownerEmail, ownerPhone, expiresAt } = req.body;

    const [updated] = await db.update(empresas).set({
      name,
      status,
      plan,
      ownerName,
      ownerEmail,
      ownerPhone,
      expiresAt: expiresAt ? new Date(expiresAt) : null,
      updatedAt: new Date(),
    }).where(eq(empresas.id, id)).returning();

    if (!updated) {
      return res.status(404).json({ error: "Empresa não encontrada" });
    }

    await db.insert(auditLogs).values({
      userId: req.user!.id,
      userType: "admin",
      action: "UPDATE",
      entity: "empresa",
      entityId: id,
      details: req.body,
      ipAddress: req.ip,
    });

    res.json(updated);
  } catch (error) {
    console.error("Error updating empresa:", error);
    res.status(500).json({ error: "Erro ao atualizar empresa" });
  }
});

router.delete("/admin/empresas/:id", authMiddleware, superadminOnly, async (req: Request, res: Response) => {
  try {
    const { id } = req.params;

    await db.delete(usuarios).where(eq(usuarios.empresaId, id));

    const [deleted] = await db.delete(empresas).where(eq(empresas.id, id)).returning();

    if (!deleted) {
      return res.status(404).json({ error: "Empresa não encontrada" });
    }

    await db.insert(auditLogs).values({
      userId: req.user!.id,
      userType: "admin",
      action: "DELETE",
      entity: "empresa",
      entityId: id,
      details: { name: deleted.name },
      ipAddress: req.ip,
    });

    res.json({ success: true });
  } catch (error) {
    console.error("Error deleting empresa:", error);
    res.status(500).json({ error: "Erro ao excluir empresa" });
  }
});

router.get("/admin/empresas/:id/usuarios", authMiddleware, adminOnly, async (req: Request, res: Response) => {
  try {
    const { id } = req.params;
    const allUsuarios = await db.select({
      id: usuarios.id,
      name: usuarios.name,
      email: usuarios.email,
      role: usuarios.role,
      isActive: usuarios.isActive,
      lastLoginAt: usuarios.lastLoginAt,
      createdAt: usuarios.createdAt,
    }).from(usuarios).where(eq(usuarios.empresaId, id));
    
    res.json(allUsuarios);
  } catch (error) {
    console.error("Error fetching usuarios:", error);
    res.status(500).json({ error: "Erro ao buscar usuários" });
  }
});

router.post("/admin/empresas/:id/usuarios", authMiddleware, adminOnly, async (req: Request, res: Response) => {
  try {
    const { id } = req.params;
    const { name, email, password, role } = req.body;

    if (!name || !email || !password) {
      return res.status(400).json({ error: "Nome, email e senha são obrigatórios" });
    }

    const usuario = await createUsuario(id, name, email, password, role || "operador");

    res.status(201).json({
      id: usuario.id,
      name: usuario.name,
      email: usuario.email,
      role: usuario.role,
      isActive: usuario.isActive,
    });
  } catch (error) {
    console.error("Error creating usuario:", error);
    res.status(500).json({ error: "Erro ao criar usuário" });
  }
});

router.get("/admin/admins", authMiddleware, superadminOnly, async (req: Request, res: Response) => {
  try {
    const allAdmins = await db.select({
      id: admins.id,
      name: admins.name,
      email: admins.email,
      role: admins.role,
      isActive: admins.isActive,
      createdAt: admins.createdAt,
    }).from(admins).orderBy(desc(admins.createdAt));
    
    res.json(allAdmins);
  } catch (error) {
    console.error("Error fetching admins:", error);
    res.status(500).json({ error: "Erro ao buscar administradores" });
  }
});

router.post("/admin/admins", authMiddleware, superadminOnly, async (req: Request, res: Response) => {
  try {
    const { name, email, password, role } = req.body;

    if (!name || !email || !password) {
      return res.status(400).json({ error: "Nome, email e senha são obrigatórios" });
    }

    const admin = await createAdmin(name, email, password, role || "admin");

    res.status(201).json({
      id: admin.id,
      name: admin.name,
      email: admin.email,
      role: admin.role,
      isActive: admin.isActive,
    });
  } catch (error) {
    console.error("Error creating admin:", error);
    res.status(500).json({ error: "Erro ao criar administrador" });
  }
});

// Superadmin: Get all users from all companies with their credentials info
router.get("/admin/all-usuarios", authMiddleware, superadminOnly, async (req: Request, res: Response) => {
  try {
    const allUsuarios = await db.select({
      id: usuarios.id,
      empresaId: usuarios.empresaId,
      name: usuarios.name,
      email: usuarios.email,
      role: usuarios.role,
      isActive: usuarios.isActive,
      lastLoginAt: usuarios.lastLoginAt,
      createdAt: usuarios.createdAt,
    }).from(usuarios);
    
    // Get empresa names for each user
    const allEmpresas = await db.select().from(empresas);
    const empresaMap = new Map(allEmpresas.map(e => [e.id, e]));
    
    const usuariosWithEmpresa = allUsuarios.map(u => ({
      ...u,
      empresaName: empresaMap.get(u.empresaId)?.name || "Desconhecida",
      empresaCode: empresaMap.get(u.empresaId)?.code || "???",
    }));
    
    res.json(usuariosWithEmpresa);
  } catch (error) {
    console.error("Error fetching all usuarios:", error);
    res.status(500).json({ error: "Erro ao buscar usuários" });
  }
});

// Superadmin: Reset user password and return the new temporary password
router.post("/admin/usuarios/:id/reset-password", authMiddleware, superadminOnly, async (req: Request, res: Response) => {
  try {
    const { id } = req.params;
    
    // Generate a new temporary password
    const tempPassword = `Temp${randomBytes(10).toString("base64url")}`;
    const hashedPassword = await hashPassword(tempPassword);
    
    const [updated] = await db.update(usuarios)
      .set({ password: hashedPassword, updatedAt: new Date() })
      .where(eq(usuarios.id, id))
      .returning();
    
    if (!updated) {
      return res.status(404).json({ error: "Usuário não encontrado" });
    }
    
    await db.insert(auditLogs).values({
      userId: req.user!.id,
      userType: "admin",
      action: "RESET_PASSWORD",
      entity: "usuario",
      entityId: id,
      details: { userName: updated.name },
      ipAddress: req.ip,
    });
    
    res.json({
      success: true,
      message: "Senha resetada com sucesso",
      temporaryPassword: tempPassword,
      userName: updated.name,
      userEmail: updated.email,
    });
  } catch (error) {
    console.error("Error resetting password:", error);
    res.status(500).json({ error: "Erro ao resetar senha" });
  }
});

// Superadmin: Create user with generated password (returns password)
router.post("/admin/usuarios-with-password", authMiddleware, superadminOnly, async (req: Request, res: Response) => {
  try {
    const { empresaId, name, email, role } = req.body;

    if (!empresaId || !name || !email) {
      return res.status(400).json({ error: "Empresa, nome e email são obrigatórios" });
    }

    // Check if empresa exists
    const [empresa] = await db.select().from(empresas).where(eq(empresas.id, empresaId)).limit(1);
    if (!empresa) {
      return res.status(404).json({ error: "Empresa não encontrada" });
    }

    // Generate password based on company code
    const generatedPassword = `${empresa.code}@${new Date().getFullYear()}`;
    const hashedPassword = await hashPassword(generatedPassword);
    
    const [usuario] = await db.insert(usuarios).values({
      empresaId,
      name,
      email,
      password: hashedPassword,
      role: role || "operador",
    }).returning();

    await db.insert(auditLogs).values({
      userId: req.user!.id,
      userType: "admin",
      action: "CREATE",
      entity: "usuario",
      entityId: usuario.id,
      details: { name, email, empresaId },
      ipAddress: req.ip,
    });

    res.status(201).json({
      id: usuario.id,
      name: usuario.name,
      email: usuario.email,
      role: usuario.role,
      isActive: usuario.isActive,
      empresaName: empresa.name,
      generatedPassword: generatedPassword,
    });
  } catch (error) {
    console.error("Error creating usuario:", error);
    res.status(500).json({ error: "Erro ao criar usuário" });
  }
});

router.get("/admin/dashboard", authMiddleware, adminOnly, async (req: Request, res: Response) => {
  try {
    const allEmpresas = await db.select().from(empresas);
    const allUsuarios = await db.select().from(usuarios);

    const stats = {
      totalEmpresas: allEmpresas.length,
      empresasAtivas: allEmpresas.filter(e => e.status === "active").length,
      empresasSuspensas: allEmpresas.filter(e => e.status === "suspended").length,
      empresasPendentes: allEmpresas.filter(e => e.status === "pending").length,
      totalUsuarios: allUsuarios.length,
      planos: {
        basic: allEmpresas.filter(e => e.plan === "basic").length,
        premium: allEmpresas.filter(e => e.plan === "premium").length,
        enterprise: allEmpresas.filter(e => e.plan === "enterprise").length,
      },
    };

    res.json(stats);
  } catch (error) {
    console.error("Error fetching dashboard:", error);
    res.status(500).json({ error: "Erro ao buscar dashboard" });
  }
});

router.post("/admin/setup", async (req: Request, res: Response) => {
  try {
    const existingAdmins = await db.select().from(admins).limit(1);
    
    if (existingAdmins.length > 0) {
      return res.status(400).json({ error: "Sistema já configurado" });
    }

    const admin = await createAdmin(
      "Super Admin",
      "admin@gofast.com",
      "admin123",
      "superadmin"
    );

    res.json({
      success: true,
      message: "Super admin criado com sucesso",
      credentials: {
        email: "admin@gofast.com",
        password: "admin123",
      },
    });
  } catch (error) {
    console.error("Error in setup:", error);
    res.status(500).json({ error: "Erro na configuração inicial" });
  }
});

export { router as adminRouter, authMiddleware, adminOnly };
