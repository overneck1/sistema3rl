/**
 * Email service for transactional messages.
 * Uses Resend when RESEND_API_KEY is configured. The system keeps company
 * creation successful even when email delivery is not configured, but reports
 * the delivery status to the caller.
 */
export async function sendCompanyCredentialsEmail(params: {
  to: string;
  companyName: string;
  login: string;
  password: string;
  code: string;
}) {
  const apiKey = process.env.RESEND_API_KEY;
  const from = process.env.EMAIL_FROM || "GoFast Produções <onboarding@resend.dev>";

  if (!apiKey) {
    console.warn("[Email] RESEND_API_KEY não configurada; credenciais não foram enviadas por email.");
    return { sent: false, configured: false, reason: "RESEND_API_KEY não configurada" };
  }

  const html = `
  <div style="font-family:Arial,sans-serif;max-width:640px;margin:0 auto;color:#111827">
    <div style="padding:28px;border-radius:18px;background:#111827;color:white">
      <div style="font-size:12px;letter-spacing:3px;opacity:.7">GOFAST PRODUÇÕES</div>
      <h1 style="margin:10px 0 0;font-size:28px">Empresa criada com sucesso</h1>
    </div>
    <div style="padding:28px;border:1px solid #e5e7eb;border-top:0;border-radius:0 0 18px 18px">
      <p>Olá,</p>
      <p>A empresa <strong>${escapeHtml(params.companyName)}</strong> foi cadastrada na plataforma GoFast Produções.</p>
      <div style="background:#f3f4f6;border-radius:14px;padding:18px;margin:22px 0">
        <p style="margin:0 0 8px"><strong>Empresa:</strong> ${escapeHtml(params.companyName)}</p>
        <p style="margin:0 0 8px"><strong>Código:</strong> ${escapeHtml(params.code)}</p>
        <p style="margin:0 0 8px"><strong>Login:</strong> ${escapeHtml(params.login)}</p>
        <p style="margin:0"><strong>Senha:</strong> ${escapeHtml(params.password)}</p>
      </div>
      <p>Use essas credenciais para acessar o sistema. Recomendamos alterar a senha após o primeiro acesso.</p>
      <p style="color:#6b7280;font-size:13px">Mensagem automática — GoFast Produções.</p>
    </div>
  </div>`;

  const response = await fetch("https://api.resend.com/emails", {
    method: "POST",
    headers: { Authorization: `Bearer ${apiKey}`, "Content-Type": "application/json" },
    body: JSON.stringify({ from, to: [params.to], subject: `Acesso à empresa ${params.companyName} — GoFast Produções`, html }),
  });

  if (!response.ok) {
    const detail = await response.text();
    console.error("[Email] Falha ao enviar email:", detail);
    return { sent: false, configured: true, reason: detail };
  }

  return { sent: true, configured: true };
}

function escapeHtml(value: string) {
  const entities: Record<string, string> = { "&": "&amp;", "<": "&lt;", ">": "&gt;", "'": "&#39;", '"': "&quot;" };
  return value.replace(/[&<>'"]/g, (char) => entities[char] || char);
}
