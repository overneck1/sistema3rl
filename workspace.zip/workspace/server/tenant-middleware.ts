import { Request, Response, NextFunction } from "express";
import jwt from "jsonwebtoken";
import { db } from "./db";
import { empresas } from "@shared/schema";
import { eq } from "drizzle-orm";

const JWT_SECRET = process.env.JWT_SECRET;
if (!JWT_SECRET) throw new Error("JWT_SECRET não configurado. Defina a variável JWT_SECRET antes de iniciar o servidor.");

export interface TenantContext {
  empresaId: string;
  empresaCode: string;
  empresaName: string;
  userId: string;
  userName: string;
  userRole: string;
  userType: "admin" | "usuario";
}

declare global {
  namespace Express {
    interface Request {
      tenant?: TenantContext;
    }
  }
}

export async function tenantMiddleware(req: Request, res: Response, next: NextFunction) {
  const authHeader = req.headers.authorization;
  
  if (!authHeader || !authHeader.startsWith("Bearer ")) {
    return res.status(401).json({ message: "Token não fornecido" });
  }
  
  const token = authHeader.split(" ")[1];
  
  try {
    const decoded = jwt.verify(token, JWT_SECRET) as any;
    
    if (decoded.type === "usuario") {
      const [empresa] = await db.select().from(empresas).where(eq(empresas.id, decoded.empresaId)).limit(1);
      
      if (!empresa || empresa.status !== "active") {
        return res.status(403).json({ message: "Empresa inativa ou não encontrada" });
      }
      
      req.tenant = {
        empresaId: decoded.empresaId,
        empresaCode: decoded.empresaCode,
        empresaName: decoded.empresaName,
        userId: decoded.id,
        userName: decoded.name,
        userRole: decoded.role,
        userType: "usuario",
      };
    } else if (decoded.type === "admin") {
      req.tenant = {
        empresaId: "",
        empresaCode: "",
        empresaName: "",
        userId: decoded.id,
        userName: decoded.name,
        userRole: decoded.role,
        userType: "admin",
      };
    } else {
      return res.status(401).json({ message: "Token inválido" });
    }
    
    next();
  } catch (error) {
    return res.status(401).json({ message: "Token inválido ou expirado" });
  }
}

export function requireTenant(req: Request, res: Response, next: NextFunction) {
  if (!req.tenant || !req.tenant.empresaId) {
    return res.status(403).json({ message: "Acesso negado: contexto de empresa não encontrado" });
  }
  next();
}

export function requireAdmin(req: Request, res: Response, next: NextFunction) {
  if (!req.tenant || req.tenant.userType !== "admin") {
    return res.status(403).json({ message: "Acesso negado: requer permissão de administrador" });
  }
  next();
}


export function requireRole(...allowedRoles: string[]) {
  return (req: Request, res: Response, next: NextFunction) => {
    if (!req.tenant || !allowedRoles.includes(req.tenant.userRole)) {
      return res.status(403).json({ message: "Acesso negado: permissão insuficiente" });
    }
    next();
  };
}
