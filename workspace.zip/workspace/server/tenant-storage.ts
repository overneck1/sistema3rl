import { 
  Seamstress, InsertSeamstress, Production, InsertProduction, 
  Batch, InsertBatch, QualityControl, InsertQualityControl, 
  Payment, InsertPayment, ExtraCost, InsertExtraCost, seamstresses, productions, batches, 
  qualityControls, payments, extraCosts, productionVariants, ProductionVariant, InsertProductionVariant,
  batchVariantAllocations, BatchVariantAllocation, InsertBatchVariantAllocation,
  whatsappMessages, WhatsAppMessage, InsertWhatsAppMessage,
  suppliers, Supplier, InsertSupplier,
  advances, Advance, InsertAdvance,
  batchDeliveries, BatchDelivery, InsertBatchDelivery
} from "@shared/schema";
import { db } from "./db";
import { eq, desc, and, ne, lt, inArray } from "drizzle-orm";

export class TenantStorage {
  private empresaId: string;

  constructor(empresaId: string) {
    this.empresaId = empresaId;
  }

  async getSeamstress(id: string): Promise<Seamstress | undefined> {
    const [result] = await db.select().from(seamstresses)
      .where(and(eq(seamstresses.id, id), eq(seamstresses.empresaId, this.empresaId)));
    return result;
  }

  async listSeamstresses(): Promise<(Seamstress & { batches: Batch[] })[]> {
    const allSeamstresses = await db.select().from(seamstresses)
      .where(eq(seamstresses.empresaId, this.empresaId))
      .orderBy(desc(seamstresses.createdAt));
    
    const seamstressesWithBatches = await Promise.all(
      allSeamstresses.map(async (seamstress) => {
        const batchList = await db.select().from(batches)
          .where(and(eq(batches.seamstressId, seamstress.id), eq(batches.empresaId, this.empresaId)));
        return {
          ...seamstress,
          batches: batchList,
        };
      })
    );
    
    return seamstressesWithBatches;
  }

  async createSeamstress(data: InsertSeamstress): Promise<Seamstress> {
    const [result] = await db.insert(seamstresses).values({ ...data, empresaId: this.empresaId }).returning();
    return result;
  }

  async updateSeamstress(id: string, data: Partial<InsertSeamstress>): Promise<Seamstress> {
    const [result] = await db.update(seamstresses).set(data)
      .where(and(eq(seamstresses.id, id), eq(seamstresses.empresaId, this.empresaId))).returning();
    return result;
  }

  async deleteSeamstress(id: string): Promise<void> {
    const [linked] = await db.select({ id: batches.id }).from(batches)
      .where(and(eq(batches.seamstressId, id), eq(batches.empresaId, this.empresaId))).limit(1);
    if (linked) {
      throw new Error("Não é possível excluir: existem lotes vinculados a esta costureira");
    }
    await db.delete(advances).where(and(eq(advances.seamstressId, id), eq(advances.empresaId, this.empresaId)));
    await db.delete(payments).where(and(eq(payments.seamstressId, id), eq(payments.empresaId, this.empresaId)));
    await db.delete(seamstresses).where(and(eq(seamstresses.id, id), eq(seamstresses.empresaId, this.empresaId)));
  }

  async getProduction(id: string): Promise<Production | undefined> {
    const [result] = await db.select().from(productions)
      .where(and(eq(productions.id, id), eq(productions.empresaId, this.empresaId)));
    return result;
  }

  async listProductions(): Promise<any[]> {
    const [allProductions, allBatches, allVariants, allSeamstresses] = await Promise.all([
      db.select().from(productions).where(eq(productions.empresaId, this.empresaId)).orderBy(desc(productions.createdAt)),
      db.select().from(batches).where(eq(batches.empresaId, this.empresaId)),
      db.select().from(productionVariants).where(eq(productionVariants.empresaId, this.empresaId)),
      db.select().from(seamstresses).where(eq(seamstresses.empresaId, this.empresaId)),
    ]);
    
    const seamstressMap = new Map(allSeamstresses.map(s => [s.id, s]));
    const batchesByProduction = new Map<string, typeof allBatches>();
    const variantsByProduction = new Map<string, typeof allVariants>();
    
    allBatches.forEach(batch => {
      const list = batchesByProduction.get(batch.productionId) || [];
      list.push(batch);
      batchesByProduction.set(batch.productionId, list);
    });
    
    allVariants.forEach(variant => {
      const list = variantsByProduction.get(variant.productionId) || [];
      list.push(variant);
      variantsByProduction.set(variant.productionId, list);
    });
    
    const prodWithData = allProductions.map(prod => {
      const productionBatches = batchesByProduction.get(prod.id) || [];
      const variants = variantsByProduction.get(prod.id) || [];
      
      const allocatedQuantity = productionBatches.reduce((sum, b) => sum + (b.quantity || 0), 0);
      
      const totalCost = productionBatches.reduce((sum, b) => {
        const qty = b.quantity || 0;
        const price = parseFloat(b.pricePerUnit as any) || 0;
        return sum + (qty * price);
      }, 0);
      
      const totalQuantity = prod.quantity || 0;
      const availableQuantity = Math.max(0, totalQuantity - allocatedQuantity);
      
      const batchesWithSeamstress = productionBatches.map(batch => ({
        batch,
        seamstress: seamstressMap.get(batch.seamstressId) || null,
      }));
      
      return { 
        ...prod, 
        variants,
        allocatedQuantity,
        availableQuantity,
        totalCost,
        batches: batchesWithSeamstress,
      };
    });
    
    return prodWithData;
  }

  async createProduction(data: InsertProduction): Promise<Production> {
    const productionCode = `PROD-${Date.now()}`;
    const [result] = await db.insert(productions).values({ ...data, productionCode, empresaId: this.empresaId } as any).returning();
    return result;
  }

  async updateProduction(id: string, data: Partial<InsertProduction>): Promise<Production> {
    const [result] = await db.update(productions).set(data)
      .where(and(eq(productions.id, id), eq(productions.empresaId, this.empresaId))).returning();
    return result;
  }

  async deleteProduction(id: string): Promise<void> {
    const productionBatches = await db.select().from(batches)
      .where(and(eq(batches.productionId, id), eq(batches.empresaId, this.empresaId)));
    for (const batch of productionBatches) {
      await db.delete(batchVariantAllocations).where(and(eq(batchVariantAllocations.batchId, batch.id), eq(batchVariantAllocations.empresaId, this.empresaId)));
    }
    await db.delete(batches).where(and(eq(batches.productionId, id), eq(batches.empresaId, this.empresaId)));
    await db.delete(productionVariants).where(and(eq(productionVariants.productionId, id), eq(productionVariants.empresaId, this.empresaId)));
    await db.delete(productions).where(and(eq(productions.id, id), eq(productions.empresaId, this.empresaId)));
  }

  async getSeamstressesByProduction(productionId: string): Promise<(Seamstress & { batchCount: number })[]> {
    const productionBatches = await db.select().from(batches)
      .where(and(eq(batches.productionId, productionId), eq(batches.empresaId, this.empresaId)));
    
    const seamstressMap = new Map<string, { seamstress: Seamstress; count: number }>();
    
    for (const batch of productionBatches) {
      const seamstress = await this.getSeamstress(batch.seamstressId);
      if (seamstress) {
        if (!seamstressMap.has(seamstress.id)) {
          seamstressMap.set(seamstress.id, { seamstress, count: 0 });
        }
        seamstressMap.get(seamstress.id)!.count += 1;
      }
    }
    
    return Array.from(seamstressMap.values()).map(({ seamstress, count }) => ({
      ...seamstress,
      batchCount: count,
    }));
  }

  async getProductionVariants(productionId: string): Promise<ProductionVariant[]> {
    const production = await this.getProduction(productionId);
    if (!production) return [];
    return await db.select().from(productionVariants).where(and(eq(productionVariants.productionId, productionId), eq(productionVariants.empresaId, this.empresaId)));
  }

  async listAllProductionVariants(): Promise<ProductionVariant[]> {
    // Get only variants from productions belonging to this empresa
    const empresaProductions = await db.select({ id: productions.id }).from(productions)
      .where(eq(productions.empresaId, this.empresaId));
    
    const productionIds = empresaProductions.map(p => p.id);
    
    if (productionIds.length === 0) {
      return [];
    }
    
    // Use inArray to filter variants by production IDs
    const { inArray } = await import("drizzle-orm");
    const variants = await db.select().from(productionVariants)
      .where(and(inArray(productionVariants.productionId, productionIds), eq(productionVariants.empresaId, this.empresaId)));
    
    return variants;
  }

  async getProductionVariantsWithAvailable(productionId: string): Promise<(ProductionVariant & { availableQuantity: number })[]> {
    const variants = await this.getProductionVariants(productionId);
    
    const variantsWithAvailable = await Promise.all(variants.map(async (variant) => {
      const allocations = await db.select().from(batchVariantAllocations).where(and(eq(batchVariantAllocations.variantId, variant.id), eq(batchVariantAllocations.empresaId, this.empresaId)));
      const allocatedQty = allocations.reduce((sum: number, a: any) => sum + a.quantity, 0);
      const availableQuantity = Math.max(0, variant.quantity - allocatedQty);
      return { ...variant, availableQuantity };
    }));
    
    return variantsWithAvailable;
  }

  async createProductionVariant(data: InsertProductionVariant): Promise<ProductionVariant> {
    const production = await this.getProduction(data.productionId);
    if (!production) throw new Error("Produção não encontrada ou não pertence à empresa");
    const [result] = await db.insert(productionVariants).values({ ...data, empresaId: this.empresaId }).returning();
    return result;
  }

  async updateProductionVariant(variantId: string, data: Partial<ProductionVariant>): Promise<ProductionVariant> {
    const [result] = await db.update(productionVariants).set(data as any).where(and(eq(productionVariants.id, variantId), eq(productionVariants.empresaId, this.empresaId))).returning();
    if (!result) throw new Error("Variação não encontrada");
    return result;
  }

  async deleteProductionVariantsByProduction(productionId: string): Promise<void> {
    const variantsToDelete = await db.select().from(productionVariants).where(and(eq(productionVariants.productionId, productionId), eq(productionVariants.empresaId, this.empresaId)));
    for (const variant of variantsToDelete) {
      await db.delete(batchVariantAllocations).where(and(eq(batchVariantAllocations.variantId, variant.id), eq(batchVariantAllocations.empresaId, this.empresaId)));
    }
    await db.delete(productionVariants).where(and(eq(productionVariants.productionId, productionId), eq(productionVariants.empresaId, this.empresaId)));
  }

  async listOpenProductionsWithAvailable(): Promise<(Production & { availableQuantity: number })[]> {
    const allProductions = await db.select().from(productions)
      .where(and(eq(productions.status, "em_separacao"), eq(productions.empresaId, this.empresaId)));
    
    const prodWithAvailable = await Promise.all(allProductions.map(async (prod) => {
      const totalQuantity = prod.quantity || 0;
      const batchesForProd = await db.select().from(batches)
        .where(and(eq(batches.productionId, prod.id), eq(batches.empresaId, this.empresaId)));
      const totalAllocated = batchesForProd.reduce((sum: number, b: any) => sum + (b.quantity || 0), 0);
      const availableQuantity = Math.max(0, totalQuantity - totalAllocated);
      return { ...prod, availableQuantity };
    }));
    
    return prodWithAvailable.filter(p => p.availableQuantity > 0);
  }

  async updateProductionStatusIfFullyAllocated(productionId: string): Promise<void> {
    const production = await this.getProduction(productionId);
    if (!production) return;
    
    const totalQuantity = production.quantity || 0;
    const batchesForProd = await db.select().from(batches)
      .where(and(eq(batches.productionId, productionId), eq(batches.empresaId, this.empresaId)));
    const totalAllocated = batchesForProd.reduce((sum: number, b: any) => sum + (b.quantity || 0), 0);
    const availableQuantity = Math.max(0, totalQuantity - totalAllocated);
    
    if (availableQuantity === 0 && totalAllocated > 0 && production.status === "em_separacao") {
      await db.update(productions).set({ status: "em_producao" as any }).where(eq(productions.id, productionId));
    } else if (availableQuantity > 0 && production.status !== "em_separacao") {
      await db.update(productions).set({ status: "em_separacao" as any }).where(eq(productions.id, productionId));
    }
  }

  async getBatch(id: string): Promise<Batch | undefined> {
    const [result] = await db.select().from(batches)
      .where(and(eq(batches.id, id), eq(batches.empresaId, this.empresaId)));
    return result;
  }

  async listBatches(): Promise<any[]> {
    return await db
      .select({
        id: batches.id,
        batchCode: batches.batchCode,
        productionId: batches.productionId,
        seamstressId: batches.seamstressId,
        assignmentType: batches.assignmentType,
        quantity: batches.quantity,
        status: batches.status,
        sendDate: batches.sendDate,
        expectedReturnDate: batches.expectedReturnDate,
        returnedDate: batches.returnedDate,
        pricePerUnit: batches.pricePerUnit,
        createdAt: batches.createdAt,
        seamstress: seamstresses,
        production: productions,
      })
      .from(batches)
      .leftJoin(seamstresses, eq(batches.seamstressId, seamstresses.id))
      .leftJoin(productions, eq(batches.productionId, productions.id))
      .where(eq(batches.empresaId, this.empresaId))
      .orderBy(desc(batches.createdAt));
  }

  async listBatchesByProduction(productionId: string): Promise<any[]> {
    return await db
      .select({
        batch: batches,
        seamstress: seamstresses,
      })
      .from(batches)
      .leftJoin(seamstresses, eq(batches.seamstressId, seamstresses.id))
      .where(and(eq(batches.productionId, productionId), eq(batches.empresaId, this.empresaId)));
  }

  async listBatchesBySeamstress(seamstressId: string): Promise<Batch[]> {
    return await db.select().from(batches)
      .where(and(eq(batches.seamstressId, seamstressId), eq(batches.empresaId, this.empresaId)));
  }

  async createBatch(data: InsertBatch): Promise<Batch> {
    const { randomInt } = await import("node:crypto");
    const batchCode = `L-${Date.now()}-${randomInt(100, 1000)}`;
    const [result] = await db.insert(batches).values({ ...data, batchCode, empresaId: this.empresaId } as any).returning();
    return result;
  }

  async updateBatch(id: string, data: Partial<InsertBatch>): Promise<Batch> {
    const oldBatch = await this.getBatch(id);
    const updateData: any = { ...data };
    if (updateData.status === "concluido" && !updateData.returnedDate) updateData.returnedDate = new Date();
    
    const [result] = await db.update(batches).set(updateData)
      .where(and(eq(batches.id, id), eq(batches.empresaId, this.empresaId))).returning();
    
    // Handle status change from concluido to something else
    if (oldBatch?.status === "concluido" && data.status && data.status !== "concluido") {
      // Find pending payments for this batch and remove them or set to zero
      await db.delete(payments)
        .where(and(
          eq(payments.batchId, id),
          eq(payments.status, "pending"),
          eq(payments.empresaId, this.empresaId)
        ));
        
      // Also update production status if it was completed
      if (result.productionId) {
        await db.update(productions)
          .set({ status: "em_producao" as any })
          .where(and(
            eq(productions.id, result.productionId),
            eq(productions.status, "concluido"),
            eq(productions.empresaId, this.empresaId)
          ));
      }
    }

    if (data.status === "concluido" && result.productionId) {
      const productionBatches = await db.select().from(batches)
        .where(and(eq(batches.productionId, result.productionId), eq(batches.empresaId, this.empresaId)));
      const allConcluded = productionBatches.every((b: any) => b.status === "concluido" || b.id === id);
      
      if (allConcluded) {
        await db.update(productions).set({ status: "concluido" as any }).where(eq(productions.id, result.productionId));
      }
    }
    
    return result;
  }

  async deleteBatch(id: string): Promise<void> {
    await db.delete(payments).where(and(eq(payments.batchId, id), eq(payments.empresaId, this.empresaId)));
    await db.delete(batchVariantAllocations).where(and(eq(batchVariantAllocations.batchId, id), eq(batchVariantAllocations.empresaId, this.empresaId)));
    await db.delete(qualityControls).where(and(eq(qualityControls.batchId, id), eq(qualityControls.empresaId, this.empresaId)));
    await db.delete(batches).where(and(eq(batches.id, id), eq(batches.empresaId, this.empresaId)));
  }

  async getBatchVariantAllocations(batchId: string): Promise<BatchVariantAllocation[]> {
    const batch = await this.getBatch(batchId);
    if (!batch) return [];
    return await db.select().from(batchVariantAllocations).where(and(eq(batchVariantAllocations.batchId, batchId), eq(batchVariantAllocations.empresaId, this.empresaId)));
  }

  async createBatchVariantAllocation(data: InsertBatchVariantAllocation): Promise<BatchVariantAllocation> {
    const batch = await this.getBatch(data.batchId);
    if (!batch) throw new Error("Lote não encontrado ou não pertence à empresa");
    const [variant] = await db.select().from(productionVariants).where(and(eq(productionVariants.id, data.variantId), eq(productionVariants.empresaId, this.empresaId))).limit(1);
    if (!variant || variant.productionId !== batch.productionId) throw new Error("Variação inválida para este lote");
    if (data.quantity <= 0) throw new Error("A quantidade alocada deve ser maior que zero");
    const [result] = await db.insert(batchVariantAllocations).values({ ...data, empresaId: this.empresaId }).returning();
    return result;
  }

  async deleteBatchVariantAllocations(batchId: string): Promise<void> {
    await db.delete(batchVariantAllocations).where(and(eq(batchVariantAllocations.batchId, batchId), eq(batchVariantAllocations.empresaId, this.empresaId)));
  }

  async getQualityControl(id: string): Promise<QualityControl | undefined> {
    const [result] = await db.select().from(qualityControls)
      .where(and(eq(qualityControls.id, id), eq(qualityControls.empresaId, this.empresaId)));
    return result;
  }

  async getQualityControlByBatch(batchId: string): Promise<QualityControl | undefined> {
    const [result] = await db.select().from(qualityControls)
      .where(and(eq(qualityControls.batchId, batchId), eq(qualityControls.empresaId, this.empresaId)));
    return result;
  }

  async createQualityControl(data: InsertQualityControl): Promise<QualityControl> {
    const [result] = await db.insert(qualityControls).values({ ...data, empresaId: this.empresaId }).returning();
    return result;
  }

  async updateQualityControl(id: string, data: Partial<InsertQualityControl>): Promise<QualityControl> {
    const [result] = await db.update(qualityControls).set(data)
      .where(and(eq(qualityControls.id, id), eq(qualityControls.empresaId, this.empresaId))).returning();
    return result;
  }

  async getPayment(id: string): Promise<Payment | undefined> {
    const [result] = await db.select().from(payments)
      .where(and(eq(payments.id, id), eq(payments.empresaId, this.empresaId)));
    return result;
  }

  async listPayments(): Promise<Payment[]> {
    return await db.select().from(payments)
      .where(eq(payments.empresaId, this.empresaId))
      .orderBy(desc(payments.createdAt));
  }

  async listPaymentsBySeamstress(seamstressId: string): Promise<Payment[]> {
    return await db.select().from(payments)
      .where(and(eq(payments.seamstressId, seamstressId), eq(payments.empresaId, this.empresaId)));
  }

  async listPaymentsByBatch(batchId: string): Promise<Payment[]> {
    return await db.select().from(payments)
      .where(and(eq(payments.batchId, batchId), eq(payments.empresaId, this.empresaId)));
  }

  async createPayment(data: InsertPayment): Promise<Payment> {
    const [result] = await db.insert(payments).values({ ...data, empresaId: this.empresaId }).returning();
    return result;
  }

  async updatePayment(id: string, data: Partial<InsertPayment>): Promise<Payment> {
    const processedData: any = {
      ...data,
      dueDate: data.dueDate ? (typeof data.dueDate === 'string' ? new Date(data.dueDate) : data.dueDate) : undefined,
      paidDate: data.paidDate ? (typeof data.paidDate === 'string' ? new Date(data.paidDate) : data.paidDate) : undefined,
    };
    Object.keys(processedData).forEach(key => processedData[key] === undefined && delete processedData[key]);
    const [result] = await db.update(payments).set(processedData)
      .where(and(eq(payments.id, id), eq(payments.empresaId, this.empresaId))).returning();
    return result;
  }

  async getSeamstressPaymentDetails(seamstressId: string) {
    const seamstress = await this.getSeamstress(seamstressId);
    const paymentList = await this.listPaymentsBySeamstress(seamstressId);
    const batchList = await this.listBatchesBySeamstress(seamstressId);
    
    const totalToPay = paymentList
      .filter(p => p.status === "pending")
      .reduce((sum, p) => sum + parseFloat(p.amount.toString()), 0);

    const totalPaid = paymentList
      .filter(p => p.status === "paid")
      .reduce((sum, p) => sum + parseFloat(p.amount.toString()), 0);

    return {
      seamstress,
      payments: paymentList,
      batches: batchList,
      totalToPay,
      totalPaid,
    };
  }

  async getDashboardData(): Promise<any> {
    const empresaId = this.empresaId;
    if (!empresaId) return this.getDefaultDashboardData();

    // Active productions
    const activeProds = await db.select().from(productions)
      .where(and(eq(productions.empresaId, empresaId), ne(productions.status, "concluido" as any)));

    // Pending batches
    const pendingBatch = await db.select().from(batches)
      .where(and(
        eq(batches.empresaId, empresaId),
        inArray(batches.status, ["em_separacao", "para_entrega", "em_producao"])
      ));

    // Delayed batches
    const delayedBatch = await db.select().from(batches)
      .where(and(
        eq(batches.empresaId, empresaId),
        eq(batches.status, "para_recolha"),
        lt(batches.expectedReturnDate, new Date())
      ));

    // Total active seamstresses
    const activeSeamstresses = await db.select().from(seamstresses)
      .where(and(eq(seamstresses.empresaId, empresaId), eq(seamstresses.status, "active")));

    // Financials
    const allProductions = await db.select().from(productions).where(eq(productions.empresaId, empresaId));
    const allBatches = await db.select().from(batches).where(eq(batches.empresaId, empresaId));
    const allPayments = await db.select().from(payments).where(eq(payments.empresaId, empresaId));
    const allExtraCosts = await db.select().from(extraCosts).where(eq(extraCosts.empresaId, empresaId));

    const receita = allProductions.reduce((sum, p) => sum + (Number(p.quantity || 0) * Number(p.pricePerUnit || 0)), 0);
    const custoLotes = allBatches.reduce((sum, b) => sum + (Number(b.quantity || 0) * Number(b.pricePerUnit || 0)), 0);
    const custoExtras = allExtraCosts.reduce((sum, ec) => sum + Number(ec.amount || 0), 0);
    const custoTotal = custoLotes + custoExtras;
    
    const lucroPercentual = receita > 0 ? ((receita - custoTotal) / receita) * 100 : 0;

    const prodConcluida = allProductions
      .filter(p => p.status === "concluido" && p.paymentStatus === "Pendente")
      .reduce((sum, p) => sum + (Number(p.quantity || 0) * Number(p.pricePerUnit || 0)), 0);

    const pagPendentes = allPayments
      .filter(p => p.status === "pending")
      .reduce((sum, p) => sum + Number(p.amount || 0), 0);

    const pagFeitos = allPayments
      .filter(p => p.status === "paid")
      .reduce((sum, p) => sum + Number(p.amount || 0), 0);

    const pagRecebidos = allProductions
      .filter(p => p.paymentStatus === "Recebido")
      .reduce((sum, p) => sum + (Number(p.quantity || 0) * Number(p.pricePerUnit || 0)), 0);

    return {
      activeProductions: activeProds.length,
      pendingBatches: pendingBatch.length,
      delayedBatches: delayedBatch.length,
      totalSeamstresses: activeSeamstresses.length,
      totalReceita: receita,
      totalCusto: custoTotal,
      lucroPercentual,
      producaoConcluida: prodConcluida,
      pagamentosPendentes: pagPendentes,
      pagamentosFeitos: pagFeitos,
      pagamentosRecebidos: pagRecebidos,
      monthlyData: [] 
    };
  }

  async getAlerts(): Promise<any[]> {
    // Basic alerts implementation for the dashboard
    const empresaId = this.empresaId;
    const delayedBatches = await db.select().from(batches)
      .where(and(
        eq(batches.empresaId, empresaId),
        ne(batches.status, "concluido"),
        lt(batches.expectedReturnDate, new Date())
      ));

    return delayedBatches.map(b => ({
      id: b.id,
      type: "delay",
      severity: "high",
      message: `Lote ${b.batchCode} está atrasado!`,
      date: b.expectedReturnDate
    }));
  }

  private getDefaultDashboardData() {
    return {
      activeProductions: 0, delayedBatches: 0, pendingBatches: 0,
      totalSeamstresses: 0, totalReceita: 0, totalCusto: 0,
      pagamentosPendentes: 0, pagamentosFeitos: 0, lucroAbsoluto: 0,
      lucroPercentual: 0, producaoConcluida: 0, pagamentosRecebidos: 0, monthlyData: [],
    };
  }

  async listExtraCosts(): Promise<ExtraCost[]> {
    return await db.select().from(extraCosts)
      .where(eq(extraCosts.empresaId, this.empresaId))
      .orderBy(desc(extraCosts.createdAt));
  }

  async getExtraCost(id: string): Promise<ExtraCost | undefined> {
    const [result] = await db.select().from(extraCosts)
      .where(and(eq(extraCosts.id, id), eq(extraCosts.empresaId, this.empresaId)));
    return result;
  }

  async createExtraCost(data: InsertExtraCost): Promise<ExtraCost> {
    const [result] = await db.insert(extraCosts).values({ ...data, empresaId: this.empresaId }).returning();
    return result;
  }

  async deleteExtraCost(id: string): Promise<void> {
    await db.delete(extraCosts).where(and(eq(extraCosts.id, id), eq(extraCosts.empresaId, this.empresaId)));
  }

  async listAdvances(): Promise<Advance[]> {
    return await db.select().from(advances)
      .where(eq(advances.empresaId, this.empresaId))
      .orderBy(desc(advances.createdAt));
  }

  async listAdvancesBySeamstress(seamstressId: string): Promise<Advance[]> {
    return await db.select().from(advances)
      .where(and(eq(advances.seamstressId, seamstressId), eq(advances.empresaId, this.empresaId)));
  }

  async createAdvance(data: InsertAdvance): Promise<Advance> {
    const [result] = await db.insert(advances).values({ ...data, empresaId: this.empresaId }).returning();
    return result;
  }

  async deleteAdvance(id: string): Promise<void> {
    await db.delete(advances).where(and(eq(advances.id, id), eq(advances.empresaId, this.empresaId)));
  }

  async listBatchDeliveries(batchId: string): Promise<BatchDelivery[]> {
    return await db.select().from(batchDeliveries)
      .where(and(eq(batchDeliveries.batchId, batchId), eq(batchDeliveries.empresaId, this.empresaId)));
  }

  async createBatchDelivery(data: InsertBatchDelivery): Promise<BatchDelivery> {
    const [result] = await db.insert(batchDeliveries).values({ ...data, empresaId: this.empresaId }).returning();
    return result;
  }

  async deleteBatchDelivery(id: string): Promise<void> {
    await db.delete(batchDeliveries).where(and(eq(batchDeliveries.id, id), eq(batchDeliveries.empresaId, this.empresaId)));
  }

  async getTotalDeliveredByBatch(batchId: string): Promise<number> {
    const deliveries = await this.listBatchDeliveries(batchId);
    return deliveries.reduce((sum, d) => sum + d.deliveredQuantity, 0);
  }

  async listSuppliers(): Promise<Supplier[]> {
    return await db.select().from(suppliers)
      .where(eq(suppliers.empresaId, this.empresaId))
      .orderBy(desc(suppliers.createdAt));
  }

  async getSupplier(id: string): Promise<Supplier | undefined> {
    const [result] = await db.select().from(suppliers)
      .where(and(eq(suppliers.id, id), eq(suppliers.empresaId, this.empresaId)));
    return result;
  }

  async createSupplier(data: InsertSupplier): Promise<Supplier> {
    const [result] = await db.insert(suppliers).values({ ...data, empresaId: this.empresaId }).returning();
    return result;
  }

  async updateSupplier(id: string, data: Partial<InsertSupplier>): Promise<Supplier> {
    const [result] = await db.update(suppliers).set(data)
      .where(and(eq(suppliers.id, id), eq(suppliers.empresaId, this.empresaId))).returning();
    return result;
  }

  async deleteSupplier(id: string): Promise<void> {
    await db.delete(suppliers).where(and(eq(suppliers.id, id), eq(suppliers.empresaId, this.empresaId)));
  }

  async getWhatsAppMessages(limit?: number): Promise<WhatsAppMessage[]> {
    return await db.select().from(whatsappMessages)
      .where(eq(whatsappMessages.empresaId, this.empresaId))
      .orderBy(desc(whatsappMessages.createdAt))
      .limit(limit || 100);
  }

  async getWhatsAppMessagesByJid(remoteJid: string, limit?: number): Promise<WhatsAppMessage[]> {
    return await db.select().from(whatsappMessages)
      .where(and(eq(whatsappMessages.remoteJid, remoteJid), eq(whatsappMessages.empresaId, this.empresaId)))
      .orderBy(desc(whatsappMessages.createdAt))
      .limit(limit || 100);
  }

  async createWhatsAppMessage(data: InsertWhatsAppMessage): Promise<WhatsAppMessage> {
    const [result] = await db.insert(whatsappMessages).values({ ...data, empresaId: this.empresaId }).returning();
    return result;
  }

  async markWhatsAppMessageAsRead(messageId: string): Promise<WhatsAppMessage> {
    const [result] = await db.update(whatsappMessages).set({ isRead: true }).where(and(eq(whatsappMessages.id, messageId), eq(whatsappMessages.empresaId, this.empresaId))).returning();
    return result;
  }

  async getAlertsData(): Promise<any> {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    
    const overduePayments = await db.select().from(payments)
      .where(and(eq(payments.status, "pending"), eq(payments.empresaId, this.empresaId)));
    
    const delayedBatches = await db.select().from(batches)
      .where(and(eq(batches.empresaId, this.empresaId)));
    
    const delayedBatchesFiltered = delayedBatches.filter(batch => {
      if (batch.status === "concluido") return false;
      const expectedDate = new Date(batch.expectedReturnDate);
      return expectedDate < today;
    });
    
    return {
      overduePayments: overduePayments.length,
      delayedBatches: delayedBatchesFiltered.length,
    };
  }
}

export function createTenantStorage(empresaId: string): TenantStorage {
  return new TenantStorage(empresaId);
}
