import * as fs from 'fs';
import * as path from 'path';

const ALLOWED_DIRECTORIES = [
  'client/src',
  'server',
  'shared',
];

const ALLOWED_EXTENSIONS = [
  '.ts', '.tsx', '.js', '.jsx', '.css', '.md'
];

const FORBIDDEN_FILES = [
  'package.json',
  'package-lock.json',
  'drizzle.config.ts',
  'vite.config.ts',
  '.env',
];

const FORBIDDEN_PATHS = [
  'data/',
  'auth/',
  'whatsapp',
  '.json',
];

export interface FileInfo {
  name: string;
  path: string;
  isDirectory: boolean;
  size?: number;
}

export interface FileChange {
  filePath: string;
  action: 'create' | 'modify' | 'delete';
  oldContent?: string;
  newContent?: string;
  timestamp: string;
}

class AgentFileSystemService {
  private changeHistory: FileChange[] = [];

  private normalizePath(filePath: string): string {
    const normalized = path.normalize(filePath).replace(/\\/g, '/');
    if (normalized.startsWith('/')) {
      return normalized.slice(1);
    }
    return normalized;
  }

  private isPathAllowed(filePath: string): boolean {
    const normalized = this.normalizePath(filePath);
    
    if (normalized.includes('..')) {
      return false;
    }
    
    if (FORBIDDEN_FILES.some(f => normalized.endsWith(f))) {
      return false;
    }
    
    if (FORBIDDEN_PATHS.some(p => normalized.includes(p))) {
      return false;
    }
    
    const isInAllowedDir = ALLOWED_DIRECTORIES.some(dir => 
      normalized.startsWith(dir + '/') || normalized === dir
    );
    
    if (!isInAllowedDir) {
      return false;
    }
    
    const ext = path.extname(normalized);
    if (ext && !ALLOWED_EXTENSIONS.includes(ext)) {
      return false;
    }
    
    return true;
  }

  async listFiles(directory: string = '.'): Promise<FileInfo[]> {
    const results: FileInfo[] = [];
    
    for (const allowedDir of ALLOWED_DIRECTORIES) {
      const targetDir = directory === '.' ? allowedDir : path.join(allowedDir, directory);
      
      try {
        await this.listFilesRecursive(targetDir, results);
      } catch (e) {
      }
    }
    
    return results;
  }

  private async listFilesRecursive(dir: string, results: FileInfo[]): Promise<void> {
    try {
      const entries = fs.readdirSync(dir, { withFileTypes: true });
      
      for (const entry of entries) {
        const fullPath = path.join(dir, entry.name);
        const normalized = this.normalizePath(fullPath);
        
        if (entry.isDirectory()) {
          results.push({
            name: entry.name,
            path: normalized,
            isDirectory: true,
          });
          await this.listFilesRecursive(fullPath, results);
        } else {
          const ext = path.extname(entry.name);
          if (ALLOWED_EXTENSIONS.includes(ext)) {
            const stats = fs.statSync(fullPath);
            results.push({
              name: entry.name,
              path: normalized,
              isDirectory: false,
              size: stats.size,
            });
          }
        }
      }
    } catch (e) {
    }
  }

  async readFile(filePath: string): Promise<{ success: boolean; content?: string; error?: string }> {
    const normalized = this.normalizePath(filePath);
    
    if (!this.isPathAllowed(normalized)) {
      return { success: false, error: 'Acesso negado a este arquivo' };
    }
    
    try {
      const content = fs.readFileSync(normalized, 'utf-8');
      return { success: true, content };
    } catch (e: any) {
      return { success: false, error: `Erro ao ler arquivo: ${e.message}` };
    }
  }

  async writeFile(filePath: string, content: string): Promise<{ success: boolean; error?: string }> {
    const normalized = this.normalizePath(filePath);
    
    if (!this.isPathAllowed(normalized)) {
      return { success: false, error: 'Acesso negado a este arquivo' };
    }
    
    try {
      let oldContent: string | undefined;
      const action: 'create' | 'modify' = fs.existsSync(normalized) ? 'modify' : 'create';
      
      if (action === 'modify') {
        oldContent = fs.readFileSync(normalized, 'utf-8');
      }
      
      const dir = path.dirname(normalized);
      if (!fs.existsSync(dir)) {
        fs.mkdirSync(dir, { recursive: true });
      }
      
      fs.writeFileSync(normalized, content, 'utf-8');
      
      this.changeHistory.push({
        filePath: normalized,
        action,
        oldContent,
        newContent: content,
        timestamp: new Date().toISOString(),
      });
      
      return { success: true };
    } catch (e: any) {
      return { success: false, error: `Erro ao escrever arquivo: ${e.message}` };
    }
  }

  async applyEdit(filePath: string, oldString: string, newString: string): Promise<{ success: boolean; error?: string }> {
    const readResult = await this.readFile(filePath);
    
    if (!readResult.success || !readResult.content) {
      return { success: false, error: readResult.error || 'Arquivo não encontrado' };
    }
    
    const content = readResult.content;
    
    if (!content.includes(oldString)) {
      return { success: false, error: 'Texto original não encontrado no arquivo' };
    }
    
    const occurrences = content.split(oldString).length - 1;
    if (occurrences > 1) {
      return { success: false, error: `Texto aparece ${occurrences} vezes. Forneça mais contexto para ser único.` };
    }
    
    const newContent = content.replace(oldString, newString);
    return this.writeFile(filePath, newContent);
  }

  getChangeHistory(): FileChange[] {
    return [...this.changeHistory];
  }

  getSystemDocumentation(): string {
    return `
# DOCUMENTAÇÃO DO SISTEMA GOFAST PRODUÇÕES

## ARQUITETURA DO SISTEMA

### Stack Tecnológico
- **Frontend**: React 18 + TypeScript + Vite
- **Backend**: Express.js + TypeScript
- **Banco de Dados**: PostgreSQL (Neon serverless)
- **ORM**: Drizzle ORM
- **UI**: Shadcn/UI + Tailwind CSS
- **Estado**: TanStack Query (React Query)
- **Roteamento**: Wouter

### Estrutura de Pastas
\`\`\`
client/src/
  ├── pages/           # Páginas da aplicação
  │   ├── dashboard.tsx       # Dashboard principal
  │   ├── seamstresses.tsx    # Gestão de costureiras
  │   ├── productions.tsx     # Gestão de produções
  │   ├── batches.tsx         # Gestão de lotes
  │   ├── payments.tsx        # Gestão de pagamentos
  │   ├── agente-gofast.tsx   # Agente AI
  │   └── ...
  ├── components/ui/   # Componentes Shadcn
  ├── hooks/           # Hooks customizados
  ├── lib/             # Utilitários
  └── App.tsx          # Roteador principal

server/
  ├── routes.ts        # Endpoints da API
  ├── storage.ts       # Interface de armazenamento
  ├── db.ts            # Conexão com banco de dados
  └── ...

shared/
  └── schema.ts        # Modelos de dados (Drizzle + Zod)
\`\`\`

## MODELO DE DADOS (shared/schema.ts)

### Tabelas Principais

#### 1. Costureiras (seamstresses)
- id, name, phone, pix, address, neighborhood
- numberOfWorkers: número de funcionários
- skills: array de habilidades
- machines: array de máquinas
- status: 'active' | 'paused' | 'blocked'
- ratingDeadline, ratingFinish: avaliações (0-5)

#### 2. Produções (productions)
- id, productionCode (único)
- supplier: fornecedor
- productName, quantity, pricePerUnit
- date, deliveryDate
- status: 'em_separacao' | 'para_entrega' | 'em_producao' | 'para_recolha' | 'concluido'
- paymentStatus: 'Pendente' | 'Recebido'

#### 3. Variantes de Produção (productionVariants)
- id, productionId
- size, color, quantity

#### 4. Lotes (batches)
- id, batchCode (único)
- productionId, seamstressId
- quantity, pricePerUnit
- sendDate, expectedReturnDate, returnedDate
- status: mesmos da produção

#### 5. Alocações de Variantes (batchVariantAllocations)
- batchId, variantId, quantity

#### 6. Controle de Qualidade (qualityControls)
- batchId
- sewingQuality, measurements, cleaning, trims, labels (boolean)
- classification: 'approved' | 'rejected' | 'rework'

#### 7. Pagamentos (payments)
- batchId, seamstressId
- amount, status: 'pending' | 'paid' | 'overdue'
- dueDate, paidDate

#### 8. Custos Extras (extraCosts)
- description, amount, category, date

#### 9. Fornecedores (suppliers)
- name, phone, email, address

## FLUXO DE NEGÓCIO

1. **Entrada de Produção**: Fornecedor envia peças → Criar produção com variantes
2. **Distribuição**: Criar lotes → Atribuir a costureiras
3. **Produção**: Costureiras trabalham → Status atualizado
4. **Recolha**: Peças retornam → Data de retorno registrada
5. **Qualidade**: Inspeção → Aprovado/Rejeitado/Retrabalho
6. **Pagamento**: Gerar pagamento → Marcar como pago
7. **Entrega**: Entregar ao fornecedor → Produção concluída

## CÁLCULOS FINANCEIROS

### Receita Total
\`\`\`typescript
totalReceita = sum(production.quantity * production.pricePerUnit)
\`\`\`

### Custo de Produção
\`\`\`typescript
custoProducao = sum(batch.quantity * batch.pricePerUnit)
\`\`\`

### Lucro
\`\`\`typescript
lucro = totalReceita - custoProducao - custosExtras
margem = (lucro / totalReceita) * 100
\`\`\`

### Pagamento de Costureira
\`\`\`typescript
valorPagamento = batch.quantity * batch.pricePerUnit
\`\`\`

## ENDPOINTS DA API (server/routes.ts)

### Costureiras
- GET /api/seamstresses - Listar todas
- GET /api/seamstresses/:id - Buscar uma
- POST /api/seamstresses - Criar
- PATCH /api/seamstresses/:id - Atualizar
- DELETE /api/seamstresses/:id - Deletar

### Produções
- GET /api/productions - Listar todas
- GET /api/productions/available - Produções com estoque
- GET /api/productions/:id - Buscar uma
- POST /api/productions - Criar (com variantes)
- PATCH /api/productions/:id - Atualizar
- DELETE /api/productions/:id - Deletar

### Lotes
- GET /api/batches - Listar todos
- POST /api/batches - Criar (com alocações)
- PATCH /api/batches/:id - Atualizar
- DELETE /api/batches/:id - Deletar

### Pagamentos
- GET /api/payments - Listar todos
- POST /api/payments - Criar
- PATCH /api/payments/:id - Atualizar

### Dashboard
- GET /api/dashboard - Dados consolidados

## PADRÕES DE CÓDIGO

### Frontend
- Usar TanStack Query para buscar dados
- Usar apiRequest() de @/lib/queryClient para mutações
- Invalidar cache após mutações com queryClient.invalidateQueries()
- Componentes Shadcn em @/components/ui/

### Backend
- Usar asyncHandler() para rotas async
- Validar com Zod schemas de @shared/schema
- Usar storage.* para operações de banco

### Cores e Estilos (Tailwind)
- Cards com cores: amber (ativo), blue (experiente), green (iniciante)
- Textos em cards coloridos: usar text-{cor}-900 dark:text-{cor}-100
- Sempre incluir variante dark mode

## COMO FAZER ALTERAÇÕES

### Para modificar lógica de cálculo:
1. Localizar função em server/storage.ts ou server/routes.ts
2. Usar applyEdit() com o trecho exato a modificar

### Para modificar UI:
1. Localizar componente em client/src/pages/
2. Usar applyEdit() com contexto suficiente

### Para adicionar campo:
1. Adicionar coluna em shared/schema.ts
2. Atualizar insertSchema correspondente
3. Atualizar storage.ts se necessário
4. Atualizar componentes que usam o modelo
`;
  }
}

export const agentFsService = new AgentFileSystemService();
