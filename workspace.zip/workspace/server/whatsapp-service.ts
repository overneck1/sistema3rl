import {
  default as makeWASocket,
  useMultiFileAuthState,
  DisconnectReason,
  isJidBroadcast,
} from "@whiskeysockets/baileys";
import { Boom } from "@hapi/boom";
import pino from "pino";
import * as QRCode from "qrcode";
import * as fs from "fs";
import * as path from "path";
import { createTenantStorage } from "./tenant-storage";

export type WhatsAppStatus = "disconnected" | "connecting" | "scanning" | "connected";
interface WhatsAppState { status: WhatsAppStatus; qrCode: string | null; phoneNumber: string | null; lastSync: Date | null; }
interface Session { state: WhatsAppState; socket: any; initPromise: Promise<boolean> | null; }

class WhatsAppService {
  private sessions = new Map<string, Session>();
  private authRoot = path.join(process.cwd(), "data/whatsapp-auth");

  constructor() { if (!fs.existsSync(this.authRoot)) fs.mkdirSync(this.authRoot, { recursive: true }); }

  private getSession(empresaId: string): Session {
    let session = this.sessions.get(empresaId);
    if (!session) {
      session = { state: { status: "disconnected", qrCode: null, phoneNumber: null, lastSync: null }, socket: null, initPromise: null };
      this.sessions.set(empresaId, session);
    }
    return session;
  }

  async initialize(empresaId: string): Promise<boolean> {
    const session = this.getSession(empresaId);
    if (session.initPromise) return session.initPromise;
    if (session.socket) return true;
    session.initPromise = this.doInitialize(empresaId, session);
    return session.initPromise;
  }

  private async doInitialize(empresaId: string, session: Session): Promise<boolean> {
    try {
      session.state.status = "connecting";
      const authPath = path.join(this.authRoot, empresaId);
      if (!fs.existsSync(authPath)) fs.mkdirSync(authPath, { recursive: true });
      const { state: authState, saveCreds } = await useMultiFileAuthState(authPath);
      const logger = pino({ level: "error" });
      session.socket = makeWASocket({ auth: authState, printQRInTerminal: false, browser: ["GoFast Produções", "Chrome", "1.0.0"], logger });

      session.socket.ev.on("connection.update", async (update: any) => {
        const { connection, lastDisconnect, qr } = update;
        if (qr) {
          session.state.status = "scanning";
          try { session.state.qrCode = await QRCode.toDataURL(qr, { errorCorrectionLevel: "H", type: "image/png", margin: 2, width: 320 }); } catch (e) { console.error("[Baileys] QR error", e); }
        }
        if (connection === "open") {
          session.state.status = "connected"; session.state.qrCode = null; session.state.lastSync = new Date();
          session.state.phoneNumber = session.socket.user?.id?.replace(/@s\.whatsapp\.net.*/, "") || null;
        }
        if (connection === "close") {
          const shouldReconnect = (lastDisconnect?.error as Boom)?.output?.statusCode !== DisconnectReason.loggedOut;
          session.state.status = "disconnected"; session.state.qrCode = null; session.socket = null; session.initPromise = null;
          if (shouldReconnect) setTimeout(() => this.initialize(empresaId).catch(console.error), 3000);
        }
      });

      session.socket.ev.on("creds.update", saveCreds);
      session.socket.ev.on("messages.upsert", async (m: any) => {
        for (const msg of m.messages || []) {
          if (msg.key.fromMe || !msg.message) continue;
          const from = msg.key.remoteJid || "";
          const text = msg.message.conversation || msg.message.extendedTextMessage?.text || "";
          if (!text || isJidBroadcast(from)) continue;
          try {
            await createTenantStorage(empresaId).createWhatsAppMessage({
              remoteJid: from,
              senderPhone: from.replace("@s.whatsapp.net", ""),
              message: text,
              direction: "incoming",
              timestamp: new Date(Number(msg.messageTimestamp || Math.floor(Date.now()/1000)) * 1000),
              isRead: false,
            });
          } catch (e) { console.error("[Baileys] Erro ao salvar mensagem:", e); }
        }
      });
      session.initPromise = null;
      return true;
    } catch (error) {
      console.error("[Baileys] Erro na inicialização:", error);
      session.state.status = "disconnected"; session.socket = null; session.initPromise = null;
      return false;
    }
  }

  getStatus(empresaId: string) { return this.getSession(empresaId).state.status; }
  getQRCode(empresaId: string) { return this.getSession(empresaId).state.qrCode; }
  getPhoneNumber(empresaId: string) { return this.getSession(empresaId).state.phoneNumber; }
  getLastSync(empresaId: string) { return this.getSession(empresaId).state.lastSync; }

  async disconnect(empresaId: string): Promise<boolean> {
    const session = this.getSession(empresaId);
    try { if (session.socket) await session.socket.logout?.(); } catch (e) { console.error("[Baileys] logout error", e); }
    session.socket = null; session.initPromise = null; session.state = { status: "disconnected", qrCode: null, phoneNumber: null, lastSync: null };
    return true;
  }

  async sendMessage(empresaId: string, phoneNumber: string, message: string): Promise<boolean> {
    const session = this.getSession(empresaId);
    try {
      if (!session.socket || session.state.status !== "connected") return false;
      const jid = phoneNumber.includes("@") ? phoneNumber : `${phoneNumber.replace(/\D/g, "")}@s.whatsapp.net`;
      await session.socket.sendMessage(jid, { text: message });
      return true;
    } catch (error) { console.error("[Baileys] Erro ao enviar mensagem:", error); return false; }
  }
}
export const whatsappService = new WhatsAppService();
