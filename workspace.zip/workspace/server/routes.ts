import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertSeamstressSchema, insertProductionSchema, insertBatchSchema, insertQualityControlSchema, insertPaymentSchema, insertExtraCostSchema, insertProductionVariantSchema, insertBatchVariantAllocationSchema, insertSupplierSchema } from "@shared/schema";
import { whatsappService } from "./whatsapp-service";
import { agentFsService } from "./agent-fs-service";
import OpenAI from "openai";
import { adminRouter } from "./admin-routes";
import { tenantRouter } from "./tenant-routes";
import { tenantMiddleware, requireTenant, requireRole } from "./tenant-middleware";
import { createTenantStorage } from "./tenant-storage";
import { ensureDemoData } from "./demo-seed";

// Wrapper to catch async errors and pass to error handler middleware
const asyncHandler = (fn: any) => (req: any, res: any, next: any) => {
  Promise.resolve(fn(req, res, next)).catch((err) => {
    // Check if it's a database error
    const isDbError = err?.message?.includes("endpoint has been disabled") || err?.code === "XX000";
    
    if (isDbError) {
      console.warn("Database endpoint unavailable in route handler");
      // Determine response based on request path
      if (req.path.includes("/batches")) return res.json([]);
      if (req.path.includes("/seamstresses")) return res.json([]);
      if (req.path.includes("/productions")) return res.json([]);
      if (req.path.includes("/payments")) return res.json([]);
      if (req.path.includes("/variants")) return res.json([]);
      if (req.path.includes("/quality-controls")) return res.json({});
      if (req.path.includes("/dashboard")) return res.json({
        activeProductions: 0, delayedBatches: 0, pendingBatches: 0,
        totalSeamstresses: 0, totalReceita: 0, totalCusto: 0,
        pagamentosPendentes: 0, pagamentosFeitos: 0, lucroAbsoluto: 0,
        lucroPercentual: 0, producaoConcluida: 0, pagamentosRecebidos: 0, monthlyData: [],
      });
      if (req.path.includes("/alerts")) return res.json([]);
      if (req.path.includes("/extra-costs")) return res.json([]);
      return res.status(500).json({ error: "Database temporarily unavailable" });
    }
    
    console.error("Route error:", err?.message);
    res.status(500).json({ error: String(err?.message || "Unknown error") });
  });
};

export async function registerRoutes(app: Express): Promise<Server> {
  try {
    await ensureDemoData();
  } catch (error) {
    console.warn("Demo seed skipped:", (error as Error)?.message || error);
  }

  // Admin/Auth routes for multi-tenant SaaS
  app.use("/api", adminRouter);
  
  // Tenant-aware routes (require authentication with empresa context)
  app.use("/api/tenant", tenantRouter);

  // Health check endpoint - responds immediately without expensive operations
  app.get("/api/health", (req, res) => {
    res.status(200).json({ status: "ok", timestamp: new Date().toISOString() });
  });

  // Legacy business APIs are intentionally blocked. They use the old global storage
  // layer and could bypass tenant isolation. The frontend must use /api/tenant/* instead.
  const legacyBusinessPrefixes = [
    "/api/seamstresses", "/api/productions", "/api/batches", "/api/variants",
    "/api/payments", "/api/extra-costs", "/api/advances", "/api/batch-deliveries",
    "/api/quality-controls", "/api/suppliers", "/api/dashboard", "/api/alerts",
    "/api/production-variants", "/api/batch-variants",
  ];
  app.use((req, res, next) => {
    if (legacyBusinessPrefixes.some(prefix => req.path === prefix || req.path.startsWith(prefix + "/"))) {
      return res.status(410).json({ error: "Endpoint legado desativado. Use /api/tenant/*." });
    }
    next();
  });

  // Sensitive non-tenant routers below still need an authenticated company context.
  app.use("/api/whatsapp", tenantMiddleware, requireTenant);
  app.use("/api/agent/context", tenantMiddleware, requireTenant);
  app.use("/api/agent/chat", tenantMiddleware, requireTenant);
  app.use("/api/agent/fs", tenantMiddleware, requireTenant, requireRole("admin_empresa"));
  app.use("/api/agent/code-chat", tenantMiddleware, requireTenant, requireRole("admin_empresa"));

  // Seamstresses
  app.get("/api/seamstresses", asyncHandler(async (req, res) => {
    const seamstresses = await storage.listSeamstresses();
    res.json(seamstresses);
  }));

  app.get("/api/seamstresses/:id", asyncHandler(async (req, res) => {
    const seamstress = await storage.getSeamstress(req.params.id);
    if (!seamstress) return res.status(404).json({ message: "Not found" });
    res.json(seamstress);
  }));

  app.post("/api/seamstresses", asyncHandler(async (req, res) => {
    const data = insertSeamstressSchema.parse(req.body);
    const seamstress = await storage.createSeamstress(data);
    res.json(seamstress);
  }));

  app.patch("/api/seamstresses/:id", asyncHandler(async (req, res) => {
    const seamstress = await storage.updateSeamstress(req.params.id, req.body);
    res.json(seamstress);
  }));

  app.delete("/api/seamstresses/:id", asyncHandler(async (req, res) => {
    await storage.deleteSeamstress(req.params.id);
    res.json({ success: true });
  }));

  // Productions
  app.get("/api/productions", asyncHandler(async (req, res) => {
    const productions = await storage.listProductions();
    res.json(productions);
  }));

  // Get open productions with available quantities (MUST be before /:id)
  app.get("/api/productions/available", asyncHandler(async (req, res) => {
    const productions = await storage.listOpenProductionsWithAvailable();
    res.json(productions);
  }));

  app.get("/api/productions/:id", asyncHandler(async (req, res) => {
    const production = await storage.getProduction(req.params.id);
    if (!production) return res.status(404).json({ message: "Not found" });
    res.json(production);
  }));

  app.post("/api/productions", asyncHandler(async (req, res) => {
    const { variants, ...data } = req.body;
    const parsedData = insertProductionSchema.parse(data);
    const production = await storage.createProduction(parsedData);
    
    if (variants && Array.isArray(variants)) {
      for (const variant of variants) {
        if (variant.size && variant.color && variant.quantity > 0) {
          await storage.createProductionVariant({
            productionId: production.id,
            size: variant.size,
            color: variant.color,
            quantity: variant.quantity,
          });
        }
      }
    }
    
    res.json(production);
  }));

  app.patch("/api/productions/:id", asyncHandler(async (req, res) => {
    const { variants, ...data } = req.body;
    // Use partial schema for updates to allow partial field updates
    const parsedData = insertProductionSchema.partial().parse(data);
    const production = await storage.updateProduction(req.params.id, parsedData);
    
    if (variants && Array.isArray(variants)) {
      // Delete existing variants
      await storage.deleteProductionVariantsByProduction(req.params.id);
      
      // Create new variants
      for (const variant of variants) {
        if (variant.size && variant.color && variant.quantity > 0) {
          await storage.createProductionVariant({
            productionId: production.id,
            size: variant.size,
            color: variant.color,
            quantity: variant.quantity,
          });
        }
      }
    }
    
    res.json(production);
  }));

  app.delete("/api/productions/:id", asyncHandler(async (req, res) => {
    await storage.deleteProduction(req.params.id);
    res.json({ success: true });
  }));

  app.get("/api/productions/:productionId/seamstresses", asyncHandler(async (req, res) => {
    const seamstresses = await storage.getSeamstressesByProduction(req.params.productionId);
    res.json(seamstresses);
  }));

  app.get("/api/productions/:productionId/variants", asyncHandler(async (req, res) => {
    const variants = await storage.getProductionVariantsWithAvailable(req.params.productionId);
    res.json(variants);
  }));

  // Get all production variants across all productions
  app.get("/api/variants", asyncHandler(async (req, res) => {
    const variants = await storage.listAllProductionVariants();
    res.json(variants);
  }));

  // Batches
  app.get("/api/batches", asyncHandler(async (req, res) => {
    const batches = await storage.listBatches();
    res.json(batches);
  }));

  app.get("/api/batches/:id", asyncHandler(async (req, res) => {
    const batch = await storage.getBatch(req.params.id);
    if (!batch) return res.status(404).json({ message: "Not found" });
    res.json(batch);
  }));

  app.get("/api/productions/:productionId/batches", asyncHandler(async (req, res) => {
    const batches = await storage.listBatchesByProduction(req.params.productionId);
    res.json(batches);
  }));

  app.get("/api/seamstresses/:seamstressId/batches", asyncHandler(async (req, res) => {
    const batches = await storage.listBatchesBySeamstress(req.params.seamstressId);
    res.json(batches);
  }));

  app.post("/api/batches", asyncHandler(async (req, res) => {
    try {
      const { variantAllocations, ...data } = req.body;
      
      // Get production to validate expectedReturnDate
      const production = await storage.getProduction(data.productionId);
      if (!production) {
        return res.status(404).json({ error: "Produção não encontrada" });
      }
      
      // Validate that batch expectedReturnDate <= production deliveryDate
      const batchReturnDate = new Date(data.expectedReturnDate);
      const productionDeliveryDate = new Date(production.deliveryDate);
      
      if (batchReturnDate > productionDeliveryDate) {
        return res.status(400).json({ 
          error: "A data de retorno esperado do lote não pode ser maior que a data de entrega da produção. Máximo permitido: " + productionDeliveryDate.toLocaleDateString('pt-BR')
        });
      }
      
      // Calculate total quantity from variant allocations
      let totalQuantity = 0;
      if (variantAllocations && Array.isArray(variantAllocations)) {
        totalQuantity = variantAllocations.reduce((sum: number, alloc: any) => sum + (alloc.allocatedQty || 0), 0);
      }
      
      // Parse batch data
      const parsedData = insertBatchSchema.parse({ ...data, quantity: totalQuantity });
      // Create batch
      let batch = await storage.createBatch(parsedData);
      
      if (variantAllocations && Array.isArray(variantAllocations)) {
        for (const alloc of variantAllocations) {
          if (alloc.variantId && alloc.allocatedQty > 0) {
            // Create the allocation ONLY - DO NOT MODIFY VARIANT QUANTITY
            await storage.createBatchVariantAllocation({
              batchId: batch.id,
              variantId: alloc.variantId,
              quantity: alloc.allocatedQty,
            });
          }
        }
      }
      
      // Force status to "para_entrega" after creating the batch
      batch = await storage.updateBatch(batch.id, { status: "para_entrega" as any });
      
      // Check if production is now fully allocated and update status
      await storage.updateProductionStatusIfFullyAllocated(data.productionId);
      
      res.json(batch);
    } catch (error: any) {
      console.error("Error creating batch:", error);
      if (error.code === '23505' && error.constraint === 'batches_batch_code_unique') {
        res.status(409).json({ error: "Código do lote já existe. Por favor, tente novamente." });
      } else {
        res.status(400).json({ error: (error as Error).message });
      }
    }
  }));

  app.patch("/api/batches/:id", asyncHandler(async (req, res) => {
    const { variantAllocations, ...data } = req.body;
    
    // Convert returnedDate to Date if it's provided
    if (data.returnedDate && typeof data.returnedDate === 'string') {
      data.returnedDate = new Date(data.returnedDate);
    }
    
    // Get existing batch and allocations
    const existingBatch = await storage.getBatch(req.params.id);
    if (!existingBatch) {
      return res.status(404).json({ error: "Lote não encontrado" });
    }
    
    // Validate expectedReturnDate if it's being updated
    if (data.expectedReturnDate) {
      const production = await storage.getProduction(existingBatch.productionId);
      if (!production) {
        return res.status(404).json({ error: "Produção não encontrada" });
      }
      
      const batchReturnDate = new Date(data.expectedReturnDate);
      const productionDeliveryDate = new Date(production.deliveryDate);
      
      if (batchReturnDate > productionDeliveryDate) {
        return res.status(400).json({ 
          error: "A data de retorno esperado do lote não pode ser maior que a data de entrega da produção. Máximo permitido: " + productionDeliveryDate.toLocaleDateString('pt-BR')
        });
      }
    }
    
    const existingAllocations = await storage.getBatchVariantAllocations(req.params.id);
    
    // Calculate total quantity from existing allocations if no new allocations provided
    let newTotalQuantity = 0;
    if (variantAllocations && Array.isArray(variantAllocations)) {
      // New allocations provided - reverse old ones
      for (const alloc of existingAllocations) {
        const variant = await storage.getProductionVariant(alloc.variantId);
        if (variant) {
          const newQuantity = variant.quantity + alloc.quantity;
          await storage.updateProductionVariant(alloc.variantId, {
            quantity: newQuantity,
          });
        }
      }
      newTotalQuantity = variantAllocations.reduce((sum: number, alloc: any) => sum + (alloc.allocatedQty || 0), 0);
    } else {
      // No new allocations - keep existing quantity or calculate from existing allocations
      newTotalQuantity = existingAllocations.reduce((sum: number, alloc: any) => sum + (alloc.quantity || 0), 0);
    }
    
    // Update batch with new quantity and other data
    const batch = await storage.updateBatch(req.params.id, {
      ...data,
      quantity: newTotalQuantity > 0 ? newTotalQuantity : (data.quantity || existingBatch?.quantity || 0),
    });
    
    // Delete old allocations
    if (variantAllocations) {
      await storage.deleteBatchVariantAllocations(req.params.id);
      
      // Create new allocations ONLY - DO NOT MODIFY VARIANT QUANTITIES
      if (Array.isArray(variantAllocations)) {
        for (const alloc of variantAllocations) {
          if (alloc.variantId && alloc.allocatedQty > 0) {
            await storage.createBatchVariantAllocation({
              batchId: req.params.id,
              variantId: alloc.variantId,
              quantity: alloc.allocatedQty,
            });
          }
        }
      }
    }
    
    // Check if production status should be updated
    if (existingBatch) {
      await storage.updateProductionStatusIfFullyAllocated(existingBatch.productionId);
    }
    
    res.json(batch);
  }));

  app.get("/api/batches/:batchId/allocations", asyncHandler(async (req, res) => {
    const allocations = await storage.getBatchVariantAllocations(req.params.batchId);
    res.json(allocations);
  }));

  app.delete("/api/batches/:id", asyncHandler(async (req, res) => {
    try {
      // Get batch allocations to reverse them
      const batch = await storage.getBatch(req.params.id);
      const allocations = await storage.getBatchVariantAllocations(req.params.id);
      
      // Delete allocations and batch ONLY - variant quantities stay unchanged
      await storage.deleteBatchVariantAllocations(req.params.id);
      await storage.deleteBatch(req.params.id);
      
      // Check if production should revert to "aberto"
      if (batch) {
        await storage.updateProductionStatusIfFullyAllocated(batch.productionId);
      }
      
      res.json({ success: true });
    } catch (error: any) {
      console.error("Error deleting batch:", error);
      res.status(500).json({ error: (error as Error).message });
    }
  }));

  // Quality Control
  app.get("/api/quality-controls/:id", asyncHandler(async (req, res) => {
    const qc = await storage.getQualityControl(req.params.id);
    if (!qc) return res.status(404).json({ message: "Not found" });
    res.json(qc);
  }));

  app.get("/api/batches/:batchId/quality-control", asyncHandler(async (req, res) => {
    const qc = await storage.getQualityControlByBatch(req.params.batchId);
    res.json(qc);
  }));

  app.post("/api/quality-controls", asyncHandler(async (req, res) => {
    const data = insertQualityControlSchema.parse(req.body);
    const qc = await storage.createQualityControl(data);
    res.json(qc);
  }));

  app.patch("/api/quality-controls/:id", asyncHandler(async (req, res) => {
    const qc = await storage.updateQualityControl(req.params.id, req.body);
    res.json(qc);
  }));

  // Payments
  app.get("/api/payments", asyncHandler(async (req, res) => {
    const payments = await storage.listPayments();
    res.json(payments);
  }));

  app.get("/api/payments/:id", asyncHandler(async (req, res) => {
    const payment = await storage.getPayment(req.params.id);
    if (!payment) return res.status(404).json({ message: "Not found" });
    res.json(payment);
  }));

  app.get("/api/seamstresses/:seamstressId/payments", asyncHandler(async (req, res) => {
    const payments = await storage.listPaymentsBySeamstress(req.params.seamstressId);
    res.json(payments);
  }));

  app.get("/api/batches/:batchId/payments", asyncHandler(async (req, res) => {
    const payments = await storage.listPaymentsByBatch(req.params.batchId);
    res.json(payments);
  }));

  app.post("/api/payments", asyncHandler(async (req, res) => {
    const data = insertPaymentSchema.parse(req.body);
    const payment = await storage.createPayment(data);
    res.json(payment);
  }));

  app.patch("/api/payments/:id", asyncHandler(async (req, res) => {
    const payment = await storage.updatePayment(req.params.id, req.body);
    res.json(payment);
  }));

  // Extra Costs
  app.get("/api/extra-costs", asyncHandler(async (req, res) => {
    const costs = await storage.listExtraCosts();
    res.json(costs);
  }));

  app.get("/api/extra-costs/:id", asyncHandler(async (req, res) => {
    const cost = await storage.getExtraCost(req.params.id);
    if (!cost) return res.status(404).json({ message: "Not found" });
    res.json(cost);
  }));

  app.post("/api/extra-costs", asyncHandler(async (req, res) => {
    const data = insertExtraCostSchema.parse(req.body);
    const cost = await storage.createExtraCost(data);
    res.json(cost);
  }));

  app.delete("/api/extra-costs/:id", asyncHandler(async (req, res) => {
    await storage.deleteExtraCost(req.params.id);
    res.json({ success: true });
  }));

  // Advances (adiantamentos) routes
  app.get("/api/advances", asyncHandler(async (req, res) => {
    const advancesList = await storage.listAdvances();
    res.json(advancesList);
  }));

  app.get("/api/advances/seamstress/:seamstressId", asyncHandler(async (req, res) => {
    const advancesList = await storage.listAdvancesBySeamstress(req.params.seamstressId);
    res.json(advancesList);
  }));

  app.post("/api/advances", asyncHandler(async (req, res) => {
    const { seamstressId, amount, date, notes } = req.body;
    if (!seamstressId || amount === undefined || amount === null) {
      return res.status(400).json({ error: "seamstressId e amount são obrigatórios" });
    }
    const numAmount = typeof amount === 'string' ? parseFloat(amount) : amount;
    if (isNaN(numAmount) || numAmount <= 0) {
      return res.status(400).json({ error: "amount deve ser um número positivo" });
    }
    const advance = await storage.createAdvance({
      seamstressId,
      amount: numAmount.toFixed(2),
      date: date ? new Date(date) : new Date(),
      notes: notes || null,
    });
    res.json(advance);
  }));

  app.delete("/api/advances/:id", asyncHandler(async (req, res) => {
    await storage.deleteAdvance(req.params.id);
    res.json({ success: true });
  }));

  // Batch Deliveries (entregas parciais) routes
  app.get("/api/batch-deliveries/:batchId", asyncHandler(async (req, res) => {
    const deliveries = await storage.listBatchDeliveries(req.params.batchId);
    res.json(deliveries);
  }));

  app.post("/api/batch-deliveries", asyncHandler(async (req, res) => {
    const { batchId, deliveredQuantity, deliveredAt, notes } = req.body;
    if (!batchId || !deliveredQuantity) {
      return res.status(400).json({ error: "batchId e deliveredQuantity são obrigatórios" });
    }
    const numQuantity = typeof deliveredQuantity === 'string' ? parseInt(deliveredQuantity, 10) : deliveredQuantity;
    if (isNaN(numQuantity) || numQuantity <= 0) {
      return res.status(400).json({ error: "deliveredQuantity deve ser um número positivo" });
    }
    // Verificar se o lote existe
    const batch = await storage.getBatch(batchId);
    if (!batch) {
      return res.status(404).json({ error: "Lote não encontrado" });
    }
    // Verificar se não vai exceder a quantidade do lote
    const totalDelivered = await storage.getTotalDeliveredByBatch(batchId);
    if (totalDelivered + numQuantity > batch.quantity) {
      return res.status(400).json({ 
        error: `Quantidade excede o total do lote. Máximo permitido: ${batch.quantity - totalDelivered}` 
      });
    }
    const delivery = await storage.createBatchDelivery({
      batchId,
      deliveredQuantity: numQuantity,
      deliveredAt: deliveredAt ? new Date(deliveredAt) : new Date(),
      notes: notes || null,
    });
    res.json(delivery);
  }));

  app.delete("/api/batch-deliveries/:id", asyncHandler(async (req, res) => {
    await storage.deleteBatchDelivery(req.params.id);
    res.json({ success: true });
  }));

  app.get("/api/batch-deliveries/:batchId/total", asyncHandler(async (req, res) => {
    const total = await storage.getTotalDeliveredByBatch(req.params.batchId);
    res.json({ total });
  }));

  // Dashboard data
  app.get("/api/dashboard", asyncHandler(async (req, res) => {
    const dashboardData = await storage.getDashboardData();
    res.json(dashboardData);
  }));

  // Seamstress payment details
  app.get("/api/seamstresses/:seamstressId/payments/details", asyncHandler(async (req, res) => {
    const details = await storage.getSeamstressPaymentDetails(req.params.seamstressId);
    res.json(details);
  }));

  // Alerts
  app.get("/api/alerts", asyncHandler(async (req, res) => {
    const alerts = await storage.getAlerts();
    res.json(alerts);
  }));

  // Force regenerate payments
  app.post("/api/payments/regenerate", asyncHandler(async (req, res) => {
    await storage.generateMissingPayments();
    const payments = await storage.listPayments?.() || [];
    res.json({ success: true, paymentsCount: payments.length });
  }));

  // WhatsApp Routes
  app.get("/api/whatsapp/status", async (req, res) => {
    const empresaId = req.tenant!.empresaId;
    const status = whatsappService.getStatus(empresaId);
    const qrCode = whatsappService.getQRCode(empresaId);
    const phoneNumber = whatsappService.getPhoneNumber(empresaId);
    const lastSync = whatsappService.getLastSync(empresaId);

    res.json({
      status,
      qrCode,
      phoneNumber,
      lastSync: lastSync ? lastSync.toISOString() : null,
    });
  });

  app.post("/api/whatsapp/connect", async (req, res) => {
    try {
      const initialized = await whatsappService.initialize(req.tenant!.empresaId);
      if (initialized) {
        res.json({ success: true, message: "WhatsApp conectando..." });
      } else {
        res.status(500).json({ success: false, message: "Erro ao conectar" });
      }
    } catch (error) {
      console.error("[WhatsApp] Connection error:", error);
      res.status(500).json({ success: false, message: String(error) });
    }
  });

  app.post("/api/whatsapp/disconnect", async (req, res) => {
    try {
      const success = await whatsappService.disconnect(req.tenant!.empresaId);
      res.json({ success, message: success ? "Desconectado" : "Erro ao desconectar" });
    } catch (error) {
      console.error("[WhatsApp] Disconnect error:", error);
      res.status(500).json({ success: false, message: String(error) });
    }
  });

  app.post("/api/whatsapp/send-message", asyncHandler(async (req, res) => {
    const { phoneNumber, message } = req.body;
    const tenantStorage = createTenantStorage(req.tenant!.empresaId);
    if (!phoneNumber || !message) {
      return res.status(400).json({ success: false, message: "Telefone e mensagem são obrigatórios" });
    }

    const success = await whatsappService.sendMessage(req.tenant!.empresaId, phoneNumber, message);
    
    // Save outgoing message to database
    if (success) {
      try {
        const jid = phoneNumber.includes("@") ? phoneNumber : `${phoneNumber}@s.whatsapp.net`;
        await tenantStorage.createWhatsAppMessage({
          remoteJid: jid,
          senderPhone: phoneNumber,
          message: message,
          direction: "outgoing",
          isRead: true,
        });
      } catch (e) {
        console.error("[WhatsApp] Erro ao salvar mensagem enviada:", e);
      }
    }
    
    res.json({ success, message: success ? "Mensagem enviada" : "Erro ao enviar mensagem" });
  }));

  app.get("/api/whatsapp/messages", asyncHandler(async (req, res) => {
    const limit = req.query.limit ? parseInt(req.query.limit as string) : 100;
    const tenantStorage = createTenantStorage(req.tenant!.empresaId);
    const messages = await tenantStorage.getWhatsAppMessages(limit);
    res.json(messages);
  }));

  app.get("/api/whatsapp/messages/:jid", asyncHandler(async (req, res) => {
    const limit = req.query.limit ? parseInt(req.query.limit as string) : 50;
    const tenantStorage = createTenantStorage(req.tenant!.empresaId);
    const messages = await tenantStorage.getWhatsAppMessagesByJid(req.params.jid, limit);
    res.json(messages);
  }));

  // OCR endpoint for parsing variation tables from images
  app.post("/api/ocr/parse-variations", asyncHandler(async (req, res) => {
    const { imageBase64, mimeType } = req.body;
    
    if (!imageBase64) {
      return res.status(400).json({ error: "Imagem é obrigatória" });
    }
    
    try {
      const openai = new OpenAI({
        apiKey: process.env.AI_INTEGRATIONS_OPENAI_API_KEY,
        baseURL: process.env.AI_INTEGRATIONS_OPENAI_BASE_URL,
      });
      
      const response = await openai.chat.completions.create({
        model: "gpt-4o",
        messages: [
          {
            role: "system",
            content: `Você é um assistente especializado em OCR de tabelas de produção de confecção.
Analise a imagem e extraia todos os dados da tabela de variações.
Para cada linha da tabela, extraia:
- description: descrição do produto (ex: "CALCA BOLSO ADE")
- color: cor do produto (ex: "MARROM", "PRETO", "VERDE")
- size: tamanho (ex: "PP", "P", "M", "G", "GG")
- quantity: quantidade de envio (número inteiro)
- unitPrice: valor unitário da mão de obra (número decimal, sem "R$")

Responda APENAS com um JSON válido no formato:
{
  "variations": [
    {"description": "...", "color": "...", "size": "...", "quantity": 0, "unitPrice": 0.00},
    ...
  ]
}

Se não conseguir ler algum campo, use string vazia ou 0.
Ignore cabeçalhos e linhas vazias.
Extraia TODAS as linhas de dados da tabela.`
          },
          {
            role: "user",
            content: [
              {
                type: "text",
                text: "Extraia todas as variações desta tabela de produção. Retorne apenas o JSON com os dados."
              },
              {
                type: "image_url",
                image_url: {
                  url: `data:${mimeType || "image/jpeg"};base64,${imageBase64}`
                }
              }
            ]
          }
        ],
        max_tokens: 4096,
        temperature: 0.1,
      });
      
      const content = response.choices[0]?.message?.content || "{}";
      
      // Try to parse the JSON from the response
      let jsonStr = content;
      // Extract JSON if wrapped in markdown code blocks
      const jsonMatch = content.match(/```(?:json)?\s*([\s\S]*?)```/);
      if (jsonMatch) {
        jsonStr = jsonMatch[1].trim();
      }
      
      const parsed = JSON.parse(jsonStr);
      res.json(parsed);
    } catch (error: any) {
      console.error("[OCR] Error parsing image:", error);
      res.status(500).json({ error: "Erro ao processar imagem: " + (error?.message || "Erro desconhecido") });
    }
  }));

  // Suppliers
  app.get("/api/suppliers", asyncHandler(async (req, res) => {
    const suppliersList = await storage.listSuppliers();
    res.json(suppliersList);
  }));

  app.get("/api/suppliers/:id", asyncHandler(async (req, res) => {
    const supplier = await storage.getSupplier(req.params.id);
    if (!supplier) return res.status(404).json({ message: "Not found" });
    res.json(supplier);
  }));

  app.post("/api/suppliers", asyncHandler(async (req, res) => {
    const data = insertSupplierSchema.parse(req.body);
    const supplier = await storage.createSupplier(data);
    res.json(supplier);
  }));

  app.patch("/api/suppliers/:id", asyncHandler(async (req, res) => {
    const data = insertSupplierSchema.partial().parse(req.body);
    const supplier = await storage.updateSupplier(req.params.id, data);
    res.json(supplier);
  }));

  app.delete("/api/suppliers/:id", asyncHandler(async (req, res) => {
    await storage.deleteSupplier(req.params.id);
    res.json({ success: true });
  }));

  // ================== AGENTE GOFAST ==================

  // Endpoint para obter contexto completo do sistema para o agente
  app.get("/api/agent/context", asyncHandler(async (req, res) => {
    const tenantStorage = createTenantStorage(req.tenant!.empresaId);
    const [productions, batches, seamstresses, payments, extraCosts] = await Promise.all([
      tenantStorage.listProductions(), tenantStorage.listBatches(), tenantStorage.listSeamstresses(),
      tenantStorage.listPayments(), tenantStorage.listExtraCosts(),
    ]);

    const now = new Date();

    // Calcular métricas do sistema
    const activeProductions = productions.filter((p: any) => p.status !== "concluido").length;
    const completedProductions = productions.filter((p: any) => p.status === "concluido").length;
    
    const pendingBatches = batches.filter((b: any) => 
      ["em_separacao", "para_entrega", "em_producao"].includes(b.status)
    ).length;
    
    const delayedBatches = batches.filter((b: any) => {
      if (b.status === "concluido" || b.status === "pago") return false;
      return new Date(b.expectedReturnDate) < now;
    });
    
    const activeSeamstresses = seamstresses.filter((s: any) => s.status === "active").length;
    const pausedSeamstresses = seamstresses.filter((s: any) => s.status === "paused").length;
    const blockedSeamstresses = seamstresses.filter((s: any) => s.status === "blocked").length;

    const pendingPayments = payments.filter((p: any) => p.status === "pending");
    const paidPayments = payments.filter((p: any) => p.status === "paid");

    const totalReceita = productions.reduce((sum: number, p: any) => 
      sum + ((p.quantity || 0) * parseFloat(p.pricePerUnit || 0)), 0
    );
    const totalCusto = batches.reduce((sum: number, b: any) => 
      sum + ((b.quantity || 0) * parseFloat(b.pricePerUnit || 0)), 0
    );
    const totalExtraCosts = extraCosts.reduce((sum: number, e: any) => 
      sum + parseFloat(e.amount || 0), 0
    );

    // Produtividade por costureira
    const seamstressProductivity = seamstresses.map((s: any) => {
      const seamstressBatches = batches.filter((b: any) => b.seamstressId === s.id);
      const completedBatches = seamstressBatches.filter((b: any) => b.status === "concluido" || b.status === "pago");
      const totalPieces = completedBatches.reduce((sum: number, b: any) => sum + (b.quantity || 0), 0);
      const delayedCount = seamstressBatches.filter((b: any) => {
        if (b.status === "concluido" || b.status === "pago") return false;
        return new Date(b.expectedReturnDate) < now;
      }).length;
      
      return {
        id: s.id,
        name: s.name,
        status: s.status,
        totalBatches: seamstressBatches.length,
        completedBatches: completedBatches.length,
        totalPieces,
        delayedBatches: delayedCount,
        rating: s.rating,
      };
    });

    // Produções com problemas
    const productionsWithIssues = productions.filter((p: any) => {
      if (!p.quantity || p.quantity <= 0) return true;
      if (!p.pricePerUnit || parseFloat(p.pricePerUnit) <= 0) return true;
      if (!p.supplier) return true;
      return false;
    });

    // Lotes sem costureira ou com dados incompletos
    const batchesWithIssues = batches.filter((b: any) => {
      if (!b.seamstressId) return true;
      if (!b.quantity || b.quantity <= 0) return true;
      if (!b.expectedReturnDate) return true;
      return false;
    });

    const context = {
      resumoGeral: {
        totalProducoes: productions.length,
        producoesAtivas: activeProductions,
        producoesConcluidas: completedProductions,
        totalLotes: batches.length,
        lotesPendentes: pendingBatches,
        lotesAtrasados: delayedBatches.length,
        totalCostureiras: seamstresses.length,
        costureirasAtivas: activeSeamstresses,
        costureirasPausadas: pausedSeamstresses,
        costureirasBloqueadas: blockedSeamstresses,
        pagamentosPendentes: pendingPayments.length,
        pagamentosFeitos: paidPayments.length,
      },
      financeiro: {
        receitaTotal: totalReceita,
        custoProducao: totalCusto,
        custosExtras: totalExtraCosts,
        lucroEstimado: totalReceita - totalCusto - totalExtraCosts,
        margemLucro: totalReceita > 0 ? ((totalReceita - totalCusto - totalExtraCosts) / totalReceita * 100).toFixed(1) : 0,
        valorPagamentosPendentes: pendingPayments.reduce((sum: number, p: any) => sum + parseFloat(p.amount || 0), 0),
        valorPagamentosFeitos: paidPayments.reduce((sum: number, p: any) => sum + parseFloat(p.amount || 0), 0),
      },
      alertas: {
        lotesAtrasados: delayedBatches.map((b: any) => ({
          id: b.id,
          codigo: b.batchCode,
          costureira: seamstresses.find((s: any) => s.id === b.seamstressId)?.name || "Não atribuído",
          diasAtraso: Math.floor((now.getTime() - new Date(b.expectedReturnDate).getTime()) / (1000 * 60 * 60 * 24)),
          quantidade: b.quantity,
        })),
        producoesComProblemas: productionsWithIssues.map((p: any) => ({
          id: p.id,
          codigo: p.productionCode,
          problema: !p.quantity ? "Sem quantidade" : !p.pricePerUnit ? "Sem preço" : "Sem fornecedor",
        })),
        lotesComProblemas: batchesWithIssues.map((b: any) => ({
          id: b.id,
          codigo: b.batchCode,
          problema: !b.seamstressId ? "Sem costureira" : !b.quantity ? "Sem quantidade" : "Sem data prevista",
        })),
        pagamentosPendentes: pendingPayments.map((p: any) => ({
          id: p.id,
          costureira: seamstresses.find((s: any) => s.id === p.seamstressId)?.name || "N/A",
          valor: parseFloat(p.amount || 0),
        })),
      },
      produtividadeCostureiras: seamstressProductivity,
      producoes: productions.slice(0, 50).map((p: any) => ({
        id: p.id,
        codigo: p.productionCode,
        fornecedor: p.supplier,
        produto: p.productName,
        quantidade: p.quantity,
        status: p.status,
        preco: parseFloat(p.pricePerUnit || 0),
        valorTotal: (p.quantity || 0) * parseFloat(p.pricePerUnit || 0),
      })),
      lotes: batches.slice(0, 50).map((b: any) => ({
        id: b.id,
        codigo: b.batchCode,
        costureira: seamstresses.find((s: any) => s.id === b.seamstressId)?.name || "N/A",
        quantidade: b.quantity,
        status: b.status,
        dataEnvio: b.sendDate,
        dataPrevisao: b.expectedReturnDate,
        atrasado: new Date(b.expectedReturnDate) < now && !["concluido", "pago"].includes(b.status),
      })),
      dataAtualizacao: now.toISOString(),
    };

    res.json(context);
  }));

  // Endpoint de chat com o agente
  app.post("/api/agent/chat", asyncHandler(async (req, res) => {
    const { message, history = [] } = req.body;

    if (!message) {
      return res.status(400).json({ error: "Mensagem é obrigatória" });
    }

    // Buscar contexto atual do sistema
    const tenantStorage = createTenantStorage(req.tenant!.empresaId);
    const [productions, batches, seamstresses, payments, extraCosts] = await Promise.all([
      tenantStorage.listProductions(), tenantStorage.listBatches(), tenantStorage.listSeamstresses(),
      tenantStorage.listPayments(), tenantStorage.listExtraCosts(),
    ]);

    const now = new Date();
    
    // Construir contexto resumido para o agente
    const activeProductions = productions.filter((p: any) => p.status !== "concluido").length;
    const delayedBatches = batches.filter((b: any) => {
      if (["concluido", "pago"].includes(b.status)) return false;
      return new Date(b.expectedReturnDate) < now;
    });
    const pendingPayments = payments.filter((p: any) => p.status === "pending");
    
    const totalReceita = productions.reduce((sum: number, p: any) => 
      sum + ((p.quantity || 0) * parseFloat(p.pricePerUnit || 0)), 0
    );
    const totalCusto = batches.reduce((sum: number, b: any) => 
      sum + ((b.quantity || 0) * parseFloat(b.pricePerUnit || 0)), 0
    );

    const systemContext = `
CONTEXTO ATUAL DO SISTEMA GOFAST CONFECÇÃO (${now.toLocaleDateString('pt-BR')}):

📊 RESUMO GERAL:
- Total de Produções: ${productions.length} (${activeProductions} ativas)
- Total de Lotes: ${batches.length}
- Lotes Atrasados: ${delayedBatches.length}
- Total de Costureiras: ${seamstresses.length} (${seamstresses.filter((s: any) => s.status === "active").length} ativas)
- Pagamentos Pendentes: ${pendingPayments.length}

💰 FINANCEIRO:
- Receita Total: R$ ${totalReceita.toFixed(2)}
- Custo Produção: R$ ${totalCusto.toFixed(2)}
- Lucro Estimado: R$ ${(totalReceita - totalCusto).toFixed(2)}
- Margem: ${totalReceita > 0 ? ((totalReceita - totalCusto) / totalReceita * 100).toFixed(1) : 0}%

⚠️ ALERTAS ATIVOS:
${delayedBatches.length > 0 ? `- ${delayedBatches.length} lote(s) atrasado(s)` : '- Nenhum lote atrasado'}
${pendingPayments.length > 0 ? `- ${pendingPayments.length} pagamento(s) pendente(s)` : '- Nenhum pagamento pendente'}

📋 DADOS DETALHADOS DISPONÍVEIS:
- Produções: ${JSON.stringify(productions.slice(0, 20).map((p: any) => ({ codigo: p.productionCode, fornecedor: p.supplier, status: p.status, qtd: p.quantity })))}
- Lotes atrasados: ${JSON.stringify(delayedBatches.slice(0, 10).map((b: any) => ({ codigo: b.batchCode, costureira: seamstresses.find((s: any) => s.id === b.seamstressId)?.name, diasAtraso: Math.floor((now.getTime() - new Date(b.expectedReturnDate).getTime()) / (1000 * 60 * 60 * 24)) })))}
- Costureiras: ${JSON.stringify(seamstresses.slice(0, 15).map((s: any) => ({ nome: s.name, status: s.status, rating: s.rating })))}
`;

    const systemPrompt = `Você é o AGENTE GOFAST, um consultor de operações e tecnologia especializado em gestão de confecção.

SUAS RESPONSABILIDADES:
1. Analisar o sistema GoFast Confecção em tempo real
2. Identificar problemas, gargalos e oportunidades de melhoria
3. Fornecer insights baseados em dados reais
4. Sugerir melhorias operacionais e sistêmicas
5. Responder perguntas sobre o negócio de forma clara e direta

REGRAS DE COMPORTAMENTO:
- Sempre baseie suas respostas nos dados reais fornecidos no contexto
- Seja direto, profissional e técnico quando necessário
- Forneça análises detalhadas e acionáveis
- Identifique problemas graves proativamente
- Sugira melhorias sempre que identificar oportunidades
- Use formatação markdown para organizar suas respostas
- Quando não tiver dados suficientes, informe claramente

FLUXO DO NEGÓCIO GOFAST:
1. Entrada de Produção (fornecedor envia peças)
2. Criação de Lotes (distribuição para costureiras)
3. Produção (costureiras trabalham nos lotes)
4. Recolha (peças retornam)
5. Qualidade (inspeção e aprovação)
6. Pagamento (costureiras recebem)
7. Entrega ao Fornecedor

${systemContext}`;

    const messages: any[] = [
      { role: "system", content: systemPrompt },
      ...history.slice(-10).map((h: any) => ({ role: h.role, content: h.content })),
      { role: "user", content: message }
    ];

    let response = "";
    const apiKey = process.env.AI_INTEGRATIONS_OPENAI_API_KEY || process.env.OPENAI_API_KEY;
    if (apiKey) {
      try {
        const openai = new OpenAI({ apiKey, baseURL: process.env.AI_INTEGRATIONS_OPENAI_BASE_URL || "https://api.openai.com/v1" });
        const completion = await openai.chat.completions.create({
          model: process.env.GOFast_AGENT_MODEL || "gpt-4o",
          messages, max_tokens: 2000, temperature: 0.7,
        });
        response = completion.choices[0]?.message?.content?.trim() || "";
      } catch (aiError: any) {
        console.error("[Agent] Falha na IA; usando resposta operacional local:", aiError?.message || aiError);
      }
    }

    if (!response) {
      const question = String(message).toLowerCase();
      if (question.includes("atras") || question.includes("lote")) {
        response = `**Situação dos lotes**\n\n- Lotes cadastrados: **${batches.length}**\n- Lotes atrasados: **${delayedBatches.length}**\n- Pagamentos pendentes: **${pendingPayments.length}**\n\n${delayedBatches.length ? delayedBatches.slice(0, 8).map((b: any) => `- **${b.batchCode || "Lote"}** — ${Math.max(0, Math.floor((now.getTime()-new Date(b.expectedReturnDate).getTime())/86400000))} dia(s) de atraso`).join("\n") : "Não há lotes atrasados no momento."}`;
      } else if (question.includes("finance") || question.includes("lucro") || question.includes("margem")) {
        response = `**Resumo financeiro**\n\n- Receita registrada: **R$ ${totalReceita.toFixed(2)}**\n- Custo de produção: **R$ ${totalCusto.toFixed(2)}**\n- Resultado estimado: **R$ ${(totalReceita-totalCusto).toFixed(2)}**\n- Margem: **${totalReceita > 0 ? ((totalReceita-totalCusto)/totalReceita*100).toFixed(1) : "0.0"}%**\n
A resposta automática local está ativa porque a integração de IA não respondeu. Configure/valide a chave OpenAI para análises conversacionais completas.`;
      } else {
        response = `**Agente GoFast — status operacional**\n\nEstou conectado aos dados da empresa. Hoje há **${productions.length} produções**, **${batches.length} lotes**, **${seamstresses.filter((s:any)=>s.status === "active").length} costureiras ativas** e **${pendingPayments.length} pagamentos pendentes**.\n\nA integração de IA não respondeu nesta tentativa; por isso entreguei um resumo local em vez de deixar a conversa vazia.`;
      }
    }

    res.json({ response, timestamp: now.toISOString(), source: apiKey ? "openai_or_fallback" : "local_fallback" });
  }));

  // ================== AGENTE GOFAST - FILE SYSTEM ACCESS ==================

  // List files in the codebase
  app.get("/api/agent/fs/list", asyncHandler(async (req, res) => {
    const directory = (req.query.directory as string) || '.';
    const files = await agentFsService.listFiles(directory);
    res.json({ files });
  }));

  // Read a file
  app.get("/api/agent/fs/read", asyncHandler(async (req, res) => {
    const filePath = req.query.path as string;
    if (!filePath) {
      return res.status(400).json({ error: "Path é obrigatório" });
    }
    const result = await agentFsService.readFile(filePath);
    res.json(result);
  }));

  // Write/create a file
  app.post("/api/agent/fs/write", asyncHandler(async (req, res) => {
    const { path: filePath, content } = req.body;
    if (!filePath || content === undefined) {
      return res.status(400).json({ error: "Path e content são obrigatórios" });
    }
    const result = await agentFsService.writeFile(filePath, content);
    res.json(result);
  }));

  // Apply an edit (find and replace)
  app.post("/api/agent/fs/edit", asyncHandler(async (req, res) => {
    const { path: filePath, oldString, newString } = req.body;
    if (!filePath || oldString === undefined || newString === undefined) {
      return res.status(400).json({ error: "Path, oldString e newString são obrigatórios" });
    }
    const result = await agentFsService.applyEdit(filePath, oldString, newString);
    res.json(result);
  }));

  // Get system documentation
  app.get("/api/agent/fs/docs", (req, res) => {
    const docs = agentFsService.getSystemDocumentation();
    res.json({ documentation: docs });
  });

  // Get change history
  app.get("/api/agent/fs/history", (req, res) => {
    const history = agentFsService.getChangeHistory();
    res.json({ changes: history });
  });

  // ================== AGENTE GOFAST - CODE MODIFICATION CHAT ==================

  app.post("/api/agent/code-chat", asyncHandler(async (req, res) => {
    const { message, history = [] } = req.body;

    if (!message) {
      return res.status(400).json({ error: "Mensagem é obrigatória" });
    }

    const systemDocs = agentFsService.getSystemDocumentation();
    const files = await agentFsService.listFiles();
    
    const apiKey = process.env.AI_INTEGRATIONS_OPENAI_API_KEY || process.env.OPENAI_API_KEY;
    if (!apiKey) {
      return res.json({ response: "O agente de código está disponível, mas a chave de IA não está configurada. Configure AI_INTEGRATIONS_OPENAI_API_KEY ou OPENAI_API_KEY para habilitar comandos de leitura e edição por linguagem natural.", actions: [], timestamp: new Date().toISOString() });
    }
    const openai = new OpenAI({ apiKey, baseURL: process.env.AI_INTEGRATIONS_OPENAI_BASE_URL || "https://api.openai.com/v1" });

    const systemPrompt = `Você é o AGENTE GOFAST - um assistente que EXECUTA modificações de código imediatamente.

REGRA CRÍTICA: Quando o usuário pedir qualquer alteração, você DEVE responder com blocos JSON de ação. NÃO apenas descreva o que fazer - FAÇA.

ARQUIVOS DO SISTEMA:
${files.filter(f => !f.isDirectory).slice(0, 50).map(f => f.path).join('\n')}

FLUXO DE TRABALHO OBRIGATÓRIO:

1. Se precisar ver o código antes de editar, IMEDIATAMENTE emita:
\`\`\`json
{"action": "read", "filePath": "caminho/arquivo.ts"}
\`\`\`

2. Para editar código, IMEDIATAMENTE emita:
\`\`\`json
{"action": "edit", "filePath": "caminho/arquivo.ts", "oldString": "texto exato atual", "newString": "texto novo", "explanation": "o que mudou"}
\`\`\`

3. Para criar arquivo novo:
\`\`\`json
{"action": "create", "filePath": "caminho/novo.ts", "content": "conteúdo completo"}
\`\`\`

IMPORTANTE:
- SEMPRE emita o JSON de ação - não apenas fale sobre ele
- Se não souber o código exato, primeiro emita um "read" 
- O oldString deve ser ÚNICO no arquivo (inclua linhas de contexto)
- Você pode emitir MÚLTIPLOS blocos JSON na mesma resposta
- Após o JSON, adicione uma breve explicação em português

EXEMPLO DE RESPOSTA CORRETA quando pedem para mudar cor de um botão:

Vou ler o arquivo primeiro e depois fazer a alteração:

\`\`\`json
{"action": "read", "filePath": "client/src/pages/dashboard.tsx"}
\`\`\`

NUNCA responda apenas com "vou precisar ler o arquivo" sem emitir o comando JSON.
NUNCA descreva ações sem executá-las com blocos JSON.

${systemDocs}`;

    const messages: any[] = [
      { role: "system", content: systemPrompt },
      ...history.slice(-10).map((h: any) => ({ role: h.role, content: h.content })),
      { role: "user", content: message }
    ];

    let completion;
    try {
      completion = await openai.chat.completions.create({
        model: process.env.GOFast_AGENT_MODEL || "gpt-4o",
        messages, max_tokens: 4000, temperature: 0.3,
      });
    } catch (e: any) {
      return res.status(200).json({ response: `A IA não respondeu nesta tentativa. ${e?.message || "Verifique a configuração da chave/modelo."}`, actions: [], timestamp: new Date().toISOString() });
    }

    const aiResponse = completion.choices[0]?.message?.content || "";
    
    // Try to parse and execute any code modification commands
    let executedActions: any[] = [];
    let finalResponse = aiResponse;

    // Extract JSON blocks from the response
    const jsonMatches = aiResponse.matchAll(/```json\s*([\s\S]*?)```/g);
    
    for (const match of jsonMatches) {
      try {
        const command = JSON.parse(match[1].trim());
        
        if (command.action === 'read' && command.filePath) {
          const readResult = await agentFsService.readFile(command.filePath);
          executedActions.push({ action: 'read', filePath: command.filePath, result: readResult });
        }
        
        if (command.action === 'edit' && command.filePath && command.oldString !== undefined && command.newString !== undefined) {
          const editResult = await agentFsService.applyEdit(command.filePath, command.oldString, command.newString);
          executedActions.push({ action: 'edit', filePath: command.filePath, result: editResult, explanation: command.explanation });
        }
        
        if (command.action === 'create' && command.filePath && command.content) {
          const writeResult = await agentFsService.writeFile(command.filePath, command.content);
          executedActions.push({ action: 'create', filePath: command.filePath, result: writeResult });
        }
      } catch (e) {
        // Not valid JSON, skip
      }
    }

    // Build response with action results
    if (executedActions.length > 0) {
      const actionSummary = executedActions.map(a => {
        if (a.action === 'read') {
          return `📖 **Leu arquivo:** ${a.filePath}\n${a.result.success ? '✅ Sucesso' : '❌ Erro: ' + a.result.error}`;
        }
        if (a.action === 'edit') {
          return `✏️ **Editou arquivo:** ${a.filePath}\n${a.result.success ? '✅ Alteração aplicada com sucesso!' : '❌ Erro: ' + a.result.error}${a.explanation ? '\n📝 ' + a.explanation : ''}`;
        }
        if (a.action === 'create') {
          return `📄 **Criou arquivo:** ${a.filePath}\n${a.result.success ? '✅ Arquivo criado com sucesso!' : '❌ Erro: ' + a.result.error}`;
        }
        return '';
      }).join('\n\n');
      
      finalResponse = aiResponse + '\n\n---\n\n**AÇÕES EXECUTADAS:**\n\n' + actionSummary;
    }

    res.json({ 
      response: finalResponse,
      actions: executedActions,
      timestamp: new Date().toISOString(),
    });
  }));

  // Global error handler middleware for catching all async route errors
  app.use((error: any, req: any, res: any, next: any) => {
    const isDbError = error?.message?.includes("endpoint has been disabled") || error?.code === "XX000";
    
    if (isDbError) {
      console.warn("Database endpoint unavailable, returning graceful response");
      
      // Determine response based on request path
      if (req.path.includes("/api/")) {
        // For API routes, return empty data structure
        if (req.path.includes("/batches")) return res.json([]);
        if (req.path.includes("/seamstresses")) return res.json([]);
        if (req.path.includes("/productions")) return res.json([]);
        if (req.path.includes("/payments")) return res.json([]);
        if (req.path.includes("/variants")) return res.json([]);
        if (req.path.includes("/quality-controls")) return res.json({});
        if (req.path.includes("/dashboard")) return res.json({
          activeProductions: 0,
          delayedBatches: 0,
          pendingBatches: 0,
          totalSeamstresses: 0,
          totalReceita: 0,
          totalCusto: 0,
          pagamentosPendentes: 0,
          pagamentosFeitos: 0,
          lucroAbsoluto: 0,
          lucroPercentual: 0,
          producaoConcluida: 0,
          pagamentosRecebidos: 0,
          monthlyData: [],
        });
        if (req.path.includes("/alerts")) return res.json([]);
        if (req.path.includes("/extra-costs")) return res.json([]);
        
        // Default for unknown API routes
        return res.status(500).json({ error: "Database temporarily unavailable" });
      }
    }
    
    console.error("Unhandled route error:", error);
    res.status(500).json({ error: String(error?.message || error) });
  });

  const httpServer = createServer(app);
  return httpServer;
}
