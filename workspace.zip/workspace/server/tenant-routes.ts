import { Router, Request, Response } from "express";
import { db } from "./db";
import { eq, desc, and } from "drizzle-orm";
import { tenantMiddleware, requireTenant, requireRole } from "./tenant-middleware";
import { hashPassword } from "./auth";
import { createTenantStorage } from "./tenant-storage";
import { 
  insertSeamstressSchema, insertProductionSchema, insertBatchSchema, 
  insertQualityControlSchema, insertPaymentSchema, insertExtraCostSchema,
  insertProductionVariantSchema, insertBatchVariantAllocationSchema,
  insertSupplierSchema, insertAdvanceSchema, insertBatchDeliverySchema,
  usuarios,
  internalEmployees, internalCostItems, internalEmployeePayments, financialPlanAllocations, insertInternalEmployeeSchema, insertInternalCostItemSchema, insertInternalEmployeePaymentSchema, insertFinancialPlanAllocationSchema,
  batches, productions
} from "@shared/schema";

export const tenantRouter = Router();

tenantRouter.use(tenantMiddleware);
tenantRouter.use(requireTenant);

// Backend authorization: UI visibility is not a security boundary.
tenantRouter.use((req: Request, res: Response, next) => {
  const path = req.path;
  if (req.method === "DELETE") {
    return requireRole("admin_empresa")(req, res, next);
  }
  if (path.startsWith("/payments") && ["POST", "PATCH"].includes(req.method)) {
    return requireRole("admin_empresa", "financeiro")(req, res, next);
  }
  if (path.startsWith("/extra-costs") && ["POST", "DELETE"].includes(req.method)) {
    return requireRole("admin_empresa", "financeiro")(req, res, next);
  }
  next();
});

const ROLE_ACCESS: Record<string, string[]> = {
  admin_empresa: ["Dashboard", "Produções", "Lotes", "Costureiras", "Estrutura interna", "Pagamentos", "Financeiro", "Plano financeiro", "WhatsApp", "Agente GoFast", "Usuários e permissões", "Configurações"],
  operador: ["Dashboard", "Produções", "Lotes", "Costureiras", "WhatsApp"],
  financeiro: ["Dashboard", "Financeiro", "Pagamentos", "Custos extras", "Estrutura interna", "Plano financeiro"],
  visualizador: ["Dashboard", "Produções", "Lotes", "Costureiras", "Financeiro", "Visão geral"],
};

tenantRouter.get("/users", requireRole("admin_empresa"), async (req: Request, res: Response) => {
  try {
    const rows = await db.select({
      id: usuarios.id, name: usuarios.name, email: usuarios.email, role: usuarios.role,
      isActive: usuarios.isActive, lastLoginAt: usuarios.lastLoginAt, createdAt: usuarios.createdAt,
    }).from(usuarios).where(eq(usuarios.empresaId, req.tenant!.empresaId)).orderBy(usuarios.name);
    res.json(rows.map(row => ({ ...row, access: ROLE_ACCESS[row.role] || [] })));
  } catch (e: any) { res.status(500).json({ message: e.message }); }
});

tenantRouter.post("/users", requireRole("admin_empresa"), async (req: Request, res: Response) => {
  try {
    const { name, email, password, role = "operador" } = req.body;
    if (!name || !email || !password) return res.status(400).json({ message: "Nome, email e senha são obrigatórios" });
    if (!Object.prototype.hasOwnProperty.call(ROLE_ACCESS, role)) return res.status(400).json({ message: "Perfil inválido" });
    const existing = await db.select({ id: usuarios.id }).from(usuarios).where(eq(usuarios.email, email)).limit(1);
    if (existing.length) return res.status(409).json({ message: "Este email já está cadastrado" });
    const usuario = await createTenantUser(req.tenant!.empresaId, name, email, password, role);
    res.status(201).json({ ...usuario, access: ROLE_ACCESS[role] });
  } catch (e: any) { res.status(400).json({ message: e.message }); }
});

tenantRouter.patch("/users/:id", requireRole("admin_empresa"), async (req: Request, res: Response) => {
  try {
    const { name, email, role, isActive, password } = req.body;
    const patch: any = { updatedAt: new Date() };
    if (name !== undefined) patch.name = name;
    if (email !== undefined) patch.email = email;
    if (role !== undefined) { if (!Object.prototype.hasOwnProperty.call(ROLE_ACCESS, role)) return res.status(400).json({ message: "Perfil inválido" }); patch.role = role; }
    if (isActive !== undefined) patch.isActive = Boolean(isActive);
    if (password) patch.password = await hashPassword(password);
    const [row] = await db.update(usuarios).set(patch).where(and(eq(usuarios.id, req.params.id), eq(usuarios.empresaId, req.tenant!.empresaId))).returning();
    if (!row) return res.status(404).json({ message: "Usuário não encontrado" });
    res.json({ ...row, password: undefined, access: ROLE_ACCESS[row.role] || [] });
  } catch (e: any) { res.status(400).json({ message: e.message }); }
});

tenantRouter.delete("/users/:id", requireRole("admin_empresa"), async (req: Request, res: Response) => {
  try {
    const [row] = await db.update(usuarios).set({ isActive: false, updatedAt: new Date() }).where(and(eq(usuarios.id, req.params.id), eq(usuarios.empresaId, req.tenant!.empresaId))).returning({ id: usuarios.id });
    if (!row) return res.status(404).json({ message: "Usuário não encontrado" });
    res.json({ success: true });
  } catch (e: any) { res.status(400).json({ message: e.message }); }
});

async function createTenantUser(empresaId: string, name: string, email: string, password: string, role: "admin_empresa" | "operador" | "financeiro" | "visualizador") {
  const hashedPassword = await hashPassword(password);
  const [usuario] = await db.insert(usuarios).values({ empresaId, name, email, password: hashedPassword, role }).returning();
  const { password: _password, ...safe } = usuario;
  return safe;
}

function getStorage(req: Request) {
  if (!req.tenant?.empresaId) {
    throw new Error("Empresa ID não encontrado no contexto");
  }
  return createTenantStorage(req.tenant.empresaId);
}

tenantRouter.get("/seamstresses", async (req: Request, res: Response) => {
  try {
    const storage = getStorage(req);
    const seamstresses = await storage.listSeamstresses();
    res.json(seamstresses);
  } catch (error: any) {
    res.status(500).json({ message: error.message });
  }
});

tenantRouter.get("/seamstresses/:id", async (req: Request, res: Response) => {
  try {
    const storage = getStorage(req);
    const seamstress = await storage.getSeamstress(req.params.id);
    if (!seamstress) {
      return res.status(404).json({ message: "Costureira não encontrada" });
    }
    res.json(seamstress);
  } catch (error: any) {
    res.status(500).json({ message: error.message });
  }
});

tenantRouter.post("/seamstresses", async (req: Request, res: Response) => {
  try {
    const storage = getStorage(req);
    const data = insertSeamstressSchema.parse(req.body);
    const seamstress = await storage.createSeamstress(data);
    res.status(201).json(seamstress);
  } catch (error: any) {
    res.status(400).json({ message: error.message });
  }
});

tenantRouter.patch("/seamstresses/:id", async (req: Request, res: Response) => {
  try {
    const storage = getStorage(req);
    const seamstress = await storage.updateSeamstress(req.params.id, req.body);
    res.json(seamstress);
  } catch (error: any) {
    res.status(400).json({ message: error.message });
  }
});

tenantRouter.delete("/seamstresses/:id", async (req: Request, res: Response) => {
  try {
    const storage = getStorage(req);
    await storage.deleteSeamstress(req.params.id);
    res.status(204).send();
  } catch (error: any) {
    const conflict = String(error.message || "").includes("lotes vinculados");
    res.status(conflict ? 400 : 500).json({ message: error.message });
  }
});

tenantRouter.get("/seamstresses/:id/payments", async (req: Request, res: Response) => {
  try {
    const storage = getStorage(req);
    const details = await storage.getSeamstressPaymentDetails(req.params.id);
    res.json(details);
  } catch (error: any) {
    res.status(500).json({ message: error.message });
  }
});

tenantRouter.get("/productions", async (req: Request, res: Response) => {
  try {
    const storage = getStorage(req);
    const productions = await storage.listProductions();
    res.json(productions);
  } catch (error: any) {
    res.status(500).json({ message: error.message });
  }
});

tenantRouter.get("/productions/open", async (req: Request, res: Response) => {
  try {
    const storage = getStorage(req);
    const productions = await storage.listOpenProductionsWithAvailable();
    res.json(productions);
  } catch (error: any) {
    res.status(500).json({ message: error.message });
  }
});

// Alias for /productions/available (used by batches page)
tenantRouter.get("/productions/available", async (req: Request, res: Response) => {
  try {
    const storage = getStorage(req);
    const productions = await storage.listOpenProductionsWithAvailable();
    res.json(productions);
  } catch (error: any) {
    res.status(500).json({ message: error.message });
  }
});

tenantRouter.get("/dashboard", async (req: Request, res: Response) => {
  try {
    const storage = getStorage(req);
    const dashboardData = await storage.getDashboardData();
    res.json(dashboardData);
  } catch (error: any) {
    res.status(500).json({ message: error.message });
  }
});

// This endpoint was duplicated and missing getAlerts in storage
tenantRouter.get("/alerts", async (req: Request, res: Response) => {
  try {
    const storage = getStorage(req);
    // Fallback if getAlerts is missing or has issues, we'll check storage implementation next
    const alerts = typeof storage.getAlerts === 'function' ? await storage.getAlerts() : [];
    res.json(alerts);
  } catch (error: any) {
    res.status(500).json({ message: error.message });
  }
});
tenantRouter.get("/variants", async (req: Request, res: Response) => {
  try {
    const storage = getStorage(req);
    const variants = await storage.listAllProductionVariants();
    res.json(variants);
  } catch (error: any) {
    res.status(500).json({ message: error.message });
  }
});

tenantRouter.get("/productions/:id", async (req: Request, res: Response) => {
  try {
    const storage = getStorage(req);
    const production = await storage.getProduction(req.params.id);
    if (!production) {
      return res.status(404).json({ message: "Produção não encontrada" });
    }
    res.json(production);
  } catch (error: any) {
    res.status(500).json({ message: error.message });
  }
});

tenantRouter.post("/productions", async (req: Request, res: Response) => {
  try {
    const storage = getStorage(req);
    const { variants, ...data } = req.body;
    console.log("[POST /productions] Received body:", JSON.stringify(req.body, null, 2));
    console.log("[POST /productions] Variants:", JSON.stringify(variants, null, 2));
    const parsedData = insertProductionSchema.parse(data);
    const production = await storage.createProduction(parsedData);
    console.log("[POST /productions] Created production:", production.id);
    
    if (variants && Array.isArray(variants)) {
      console.log("[POST /productions] Processing", variants.length, "variants");
      for (const variant of variants) {
        console.log("[POST /productions] Variant:", variant);
        if (variant.size && variant.color && variant.quantity > 0) {
          const createdVariant = await storage.createProductionVariant({
            productionId: production.id,
            size: variant.size,
            color: variant.color,
            quantity: variant.quantity,
          });
          console.log("[POST /productions] Created variant:", createdVariant.id);
        } else {
          console.log("[POST /productions] Skipping variant - missing size/color/quantity:", variant);
        }
      }
    } else {
      console.log("[POST /productions] No variants to process");
    }
    
    res.status(201).json(production);
  } catch (error: any) {
    console.error("[POST /productions] Error:", error);
    res.status(400).json({ message: error.message });
  }
});

tenantRouter.patch("/productions/:id", async (req: Request, res: Response) => {
  try {
    const storage = getStorage(req);
    const { variants, ...data } = req.body;
    const patch = coerceDateFields(data, ["date", "deliveryDate", "expectedPaymentDate"]);
    
    // Update production data
    const production = await storage.updateProduction(req.params.id, patch);
    
    // Update variants if provided
    if (variants && Array.isArray(variants)) {
      await storage.deleteProductionVariantsByProduction(req.params.id);
      for (const variant of variants) {
        if (variant.size && variant.color && variant.quantity > 0) {
          await storage.createProductionVariant({
            productionId: production.id,
            size: variant.size,
            color: variant.color,
            quantity: variant.quantity,
          });
        }
      }
    }
    
    res.json(production);
  } catch (error: any) {
    res.status(400).json({ message: error.message });
  }
});

tenantRouter.delete("/productions/:id", async (req: Request, res: Response) => {
  try {
    const storage = getStorage(req);
    await storage.deleteProduction(req.params.id);
    res.status(204).send();
  } catch (error: any) {
    res.status(500).json({ message: error.message });
  }
});

tenantRouter.get("/productions/:id/variants", async (req: Request, res: Response) => {
  try {
    const storage = getStorage(req);
    const variants = await storage.getProductionVariantsWithAvailable(req.params.id);
    res.json(variants);
  } catch (error: any) {
    res.status(500).json({ message: error.message });
  }
});

tenantRouter.post("/productions/:id/variants", async (req: Request, res: Response) => {
  try {
    const storage = getStorage(req);
    const data = insertProductionVariantSchema.parse({ ...req.body, productionId: req.params.id });
    const variant = await storage.createProductionVariant(data);
    res.status(201).json(variant);
  } catch (error: any) {
    res.status(400).json({ message: error.message });
  }
});

tenantRouter.get("/productions/:id/seamstresses", async (req: Request, res: Response) => {
  try {
    const storage = getStorage(req);
    const seamstresses = await storage.getSeamstressesByProduction(req.params.id);
    res.json(seamstresses);
  } catch (error: any) {
    res.status(500).json({ message: error.message });
  }
});

tenantRouter.get("/batches", async (req: Request, res: Response) => {
  try {
    const storage = getStorage(req);
    const batches = await storage.listBatches();
    res.json(batches);
  } catch (error: any) {
    res.status(500).json({ message: error.message });
  }
});

tenantRouter.get("/batches/:id", async (req: Request, res: Response) => {
  try {
    const storage = getStorage(req);
    const batch = await storage.getBatch(req.params.id);
    if (!batch) {
      return res.status(404).json({ message: "Lote não encontrado" });
    }
    res.json(batch);
  } catch (error: any) {
    res.status(500).json({ message: error.message });
  }
});

tenantRouter.post("/batches", async (req: Request, res: Response) => {
  try {
    const storage = getStorage(req);
    const { variantAllocations, ...data } = req.body;

    // Internal lots are assigned to the company team, not an external seamstress.
    const assignmentType = data.assignmentType === "internal" ? "internal" : "external";
    if (assignmentType === "internal") {
      data.seamstressId = null;
      data.pricePerUnit = "0";
    } else if (!data.seamstressId) {
      throw new Error("Selecione uma costureira externa");
    }

    // Calculate total quantity from variant allocations if provided
    let totalQuantity = data.quantity || 0;
    if (variantAllocations && Array.isArray(variantAllocations)) {
      totalQuantity = variantAllocations.reduce((sum: number, alloc: any) => sum + (alloc.allocatedQty || 0), 0);
    }

    let internalDailyCostSnapshot: string | null = null;
    if (assignmentType === "internal") {
      const [employees, costItems] = await Promise.all([
        db.select().from(internalEmployees).where(eq(internalEmployees.empresaId, req.tenant!.empresaId)),
        db.select().from(internalCostItems).where(eq(internalCostItems.empresaId, req.tenant!.empresaId)),
      ]);
      internalDailyCostSnapshot = calculateInternalDailyCost(employees, costItems).toFixed(2);
    }

    const parsedData = insertBatchSchema.parse({ ...data, quantity: totalQuantity, internalDailyCostSnapshot });
    let batch = await storage.createBatch(parsedData);

    // Handle variant allocations if provided
    if (variantAllocations && Array.isArray(variantAllocations)) {
      for (const alloc of variantAllocations) {
        if (alloc.variantId && alloc.allocatedQty > 0) {
          await storage.createBatchVariantAllocation({
            batchId: batch.id,
            variantId: alloc.variantId,
            quantity: alloc.allocatedQty,
          });
        }
      }
    }

    // Force status to "para_entrega" after creating the batch as per legacy routes.ts
    batch = await storage.updateBatch(batch.id, { status: "para_entrega" as any });
    
    await storage.updateProductionStatusIfFullyAllocated(batch.productionId);
    res.status(201).json(batch);
  } catch (error: any) {
    console.error("Error creating batch in tenant route:", error);
    res.status(400).json({ message: error.message });
  }
});

function coerceDateFields<T extends Record<string, any>>(data: T, keys: string[]): T {
  const next: Record<string, any> = { ...data };
  for (const key of keys) {
    if (next[key] == null || next[key] === "") continue;
    if (next[key] instanceof Date) continue;
    const parsed = new Date(next[key]);
    if (!Number.isNaN(parsed.getTime())) next[key] = parsed;
  }
  return next as T;
}

tenantRouter.patch("/batches/:id", async (req: Request, res: Response) => {
  try {
    const storage = getStorage(req);
    const { variantAllocations, ...data } = req.body;
    const patch = coerceDateFields(data, ["sendDate", "expectedReturnDate", "returnedDate"]);
    
    // Update batch data
    const batch = await storage.updateBatch(req.params.id, patch);
    
    // Update allocations if provided
    if (variantAllocations && Array.isArray(variantAllocations)) {
      await storage.deleteBatchVariantAllocations(req.params.id);
      for (const alloc of variantAllocations) {
        if (alloc.variantId && alloc.allocatedQty > 0) {
          await storage.createBatchVariantAllocation({
            batchId: req.params.id,
            variantId: alloc.variantId,
            quantity: alloc.allocatedQty,
          });
        }
      }
    }
    
    res.json(batch);
  } catch (error: any) {
    res.status(400).json({ message: error.message });
  }
});

tenantRouter.delete("/batches/:id", async (req: Request, res: Response) => {
  try {
    const storage = getStorage(req);
    const batch = await storage.getBatch(req.params.id);
    if (batch) {
      await storage.deleteBatch(req.params.id);
      await storage.updateProductionStatusIfFullyAllocated(batch.productionId);
    }
    res.status(204).send();
  } catch (error: any) {
    res.status(500).json({ message: error.message });
  }
});

tenantRouter.get("/batches/:id/allocations", async (req: Request, res: Response) => {
  try {
    const storage = getStorage(req);
    const allocations = await storage.getBatchVariantAllocations(req.params.id);
    res.json(allocations);
  } catch (error: any) {
    res.status(500).json({ message: error.message });
  }
});

tenantRouter.post("/batches/:id/allocations", async (req: Request, res: Response) => {
  try {
    const storage = getStorage(req);
    const data = insertBatchVariantAllocationSchema.parse({ ...req.body, batchId: req.params.id });
    const allocation = await storage.createBatchVariantAllocation(data);
    res.status(201).json(allocation);
  } catch (error: any) {
    res.status(400).json({ message: error.message });
  }
});

tenantRouter.get("/batches/:id/deliveries", async (req: Request, res: Response) => {
  try {
    const storage = getStorage(req);
    const deliveries = await storage.listBatchDeliveries(req.params.id);
    res.json(deliveries);
  } catch (error: any) {
    res.status(500).json({ message: error.message });
  }
});

tenantRouter.post("/batches/:id/deliveries", async (req: Request, res: Response) => {
  try {
    const storage = getStorage(req);
    const data = insertBatchDeliverySchema.parse({ ...req.body, batchId: req.params.id });
    const delivery = await storage.createBatchDelivery(data);
    res.status(201).json(delivery);
  } catch (error: any) {
    res.status(400).json({ message: error.message });
  }
});

tenantRouter.get("/batch-deliveries/:batchId", async (req: Request, res: Response) => {
  try {
    const storage = getStorage(req);
    const deliveries = await storage.listBatchDeliveries(req.params.batchId);
    res.json(deliveries);
  } catch (error: any) {
    res.status(500).json({ message: error.message });
  }
});

tenantRouter.post("/batch-deliveries", async (req: Request, res: Response) => {
  try {
    const storage = getStorage(req);
    const { batchId, deliveredQuantity, deliveredAt, notes } = req.body;
    if (!batchId || !deliveredQuantity) {
      return res.status(400).json({ message: "batchId e deliveredQuantity são obrigatórios" });
    }
    const data = insertBatchDeliverySchema.parse({
      batchId,
      deliveredQuantity,
      deliveredAt: deliveredAt || new Date(),
      notes: notes || null,
    });
    const delivery = await storage.createBatchDelivery(data);
    res.status(201).json(delivery);
  } catch (error: any) {
    res.status(400).json({ message: error.message });
  }
});

tenantRouter.get("/quality-controls/:batchId", async (req: Request, res: Response) => {
  try {
    const storage = getStorage(req);
    const qc = await storage.getQualityControlByBatch(req.params.batchId);
    res.json(qc || null);
  } catch (error: any) {
    res.status(500).json({ message: error.message });
  }
});

tenantRouter.post("/quality-controls", async (req: Request, res: Response) => {
  try {
    const storage = getStorage(req);
    const data = insertQualityControlSchema.parse(req.body);
    const qc = await storage.createQualityControl(data);
    res.status(201).json(qc);
  } catch (error: any) {
    res.status(400).json({ message: error.message });
  }
});

tenantRouter.patch("/quality-controls/:id", async (req: Request, res: Response) => {
  try {
    const storage = getStorage(req);
    const qc = await storage.updateQualityControl(req.params.id, req.body);
    res.json(qc);
  } catch (error: any) {
    res.status(400).json({ message: error.message });
  }
});

tenantRouter.get("/payments", async (req: Request, res: Response) => {
  try {
    const storage = getStorage(req);
    const payments = await storage.listPayments();
    res.json(payments);
  } catch (error: any) {
    res.status(500).json({ message: error.message });
  }
});

tenantRouter.get("/payments/:id", async (req: Request, res: Response) => {
  try {
    const storage = getStorage(req);
    const payment = await storage.getPayment(req.params.id);
    if (!payment) {
      return res.status(404).json({ message: "Pagamento não encontrado" });
    }
    res.json(payment);
  } catch (error: any) {
    res.status(500).json({ message: error.message });
  }
});

tenantRouter.post("/payments", async (req: Request, res: Response) => {
  try {
    const storage = getStorage(req);
    const data = insertPaymentSchema.parse(req.body);
    const payment = await storage.createPayment(data);
    res.status(201).json(payment);
  } catch (error: any) {
    res.status(400).json({ message: error.message });
  }
});

tenantRouter.patch("/payments/:id", async (req: Request, res: Response) => {
  try {
    const storage = getStorage(req);
    const patch = coerceDateFields(req.body, ["dueDate", "paidDate"]);
    const payment = await storage.updatePayment(req.params.id, patch);
    res.json(payment);
  } catch (error: any) {
    res.status(400).json({ message: error.message });
  }
});

tenantRouter.get("/extra-costs", async (req: Request, res: Response) => {
  try {
    const storage = getStorage(req);
    const costs = await storage.listExtraCosts();
    res.json(costs);
  } catch (error: any) {
    res.status(500).json({ message: error.message });
  }
});

tenantRouter.post("/extra-costs", async (req: Request, res: Response) => {
  try {
    const storage = getStorage(req);
    const data = insertExtraCostSchema.parse(req.body);
    const cost = await storage.createExtraCost(data);
    res.status(201).json(cost);
  } catch (error: any) {
    res.status(400).json({ message: error.message });
  }
});

tenantRouter.delete("/extra-costs/:id", async (req: Request, res: Response) => {
  try {
    const storage = getStorage(req);
    await storage.deleteExtraCost(req.params.id);
    res.status(204).send();
  } catch (error: any) {
    res.status(500).json({ message: error.message });
  }
});

tenantRouter.get("/advances", async (req: Request, res: Response) => {
  try {
    const storage = getStorage(req);
    const advances = await storage.listAdvances();
    res.json(advances);
  } catch (error: any) {
    res.status(500).json({ message: error.message });
  }
});

tenantRouter.post("/advances", async (req: Request, res: Response) => {
  try {
    const storage = getStorage(req);
    const data = insertAdvanceSchema.parse(req.body);
    const advance = await storage.createAdvance(data);
    res.status(201).json(advance);
  } catch (error: any) {
    res.status(400).json({ message: error.message });
  }
});

tenantRouter.delete("/advances/:id", async (req: Request, res: Response) => {
  try {
    const storage = getStorage(req);
    await storage.deleteAdvance(req.params.id);
    res.status(204).send();
  } catch (error: any) {
    res.status(500).json({ message: error.message });
  }
});

tenantRouter.get("/suppliers", async (req: Request, res: Response) => {
  try {
    const storage = getStorage(req);
    const suppliers = await storage.listSuppliers();
    res.json(suppliers);
  } catch (error: any) {
    res.status(500).json({ message: error.message });
  }
});

tenantRouter.get("/suppliers/:id", async (req: Request, res: Response) => {
  try {
    const storage = getStorage(req);
    const supplier = await storage.getSupplier(req.params.id);
    if (!supplier) {
      return res.status(404).json({ message: "Fornecedor não encontrado" });
    }
    res.json(supplier);
  } catch (error: any) {
    res.status(500).json({ message: error.message });
  }
});

tenantRouter.post("/suppliers", async (req: Request, res: Response) => {
  try {
    const storage = getStorage(req);
    const data = insertSupplierSchema.parse(req.body);
    const supplier = await storage.createSupplier(data);
    res.status(201).json(supplier);
  } catch (error: any) {
    res.status(400).json({ message: error.message });
  }
});

tenantRouter.patch("/suppliers/:id", async (req: Request, res: Response) => {
  try {
    const storage = getStorage(req);
    const supplier = await storage.updateSupplier(req.params.id, req.body);
    res.json(supplier);
  } catch (error: any) {
    res.status(400).json({ message: error.message });
  }
});

tenantRouter.delete("/suppliers/:id", async (req: Request, res: Response) => {
  try {
    const storage = getStorage(req);
    await storage.deleteSupplier(req.params.id);
    res.status(204).send();
  } catch (error: any) {
    res.status(500).json({ message: error.message });
  }
});



// =============================================================
// INTERNAL OPERATION COSTS
// =============================================================

function monthlyEquivalent(amount: number, recurrence: string) {
  if (recurrence === "daily") return amount * 22;
  if (recurrence === "weekly") return amount * 4.333333;
  if (recurrence === "annual") return amount / 12;
  if (recurrence === "one_time") return 0;
  return amount;
}

function employeeMonthlyCost(e: any) {
  const salary = Number(e.salary || 0);
  const transport = Number(e.transportDaily || 0) * Number(e.workDaysPerMonth || 22);
  return salary + Number(e.benefitsMonthly || 0) + Number(e.employerChargesMonthly || 0) + transport;
}

function calculateInternalDailyCost(employees: any[], costItems: any[]) {
  const activeEmployees = employees.filter(e => e.active);
  const employeeMonthly = activeEmployees.reduce((sum, e) => sum + employeeMonthlyCost(e), 0);
  const fixedMonthly = costItems.filter(c => c.active && c.costType === "fixed").reduce((s, c) => s + monthlyEquivalent(Number(c.amount), c.recurrence), 0);
  const variableMonthly = costItems.filter(c => c.active && c.costType === "variable").reduce((s, c) => s + monthlyEquivalent(Number(c.amount), c.recurrence), 0);
  const semiVariableMonthly = costItems.filter(c => c.active && c.costType === "semi_variable").reduce((s, c) => s + monthlyEquivalent(Number(c.amount), c.recurrence), 0);
  const totalMonthly = employeeMonthly + fixedMonthly + variableMonthly + semiVariableMonthly;
  const workDays = activeEmployees.length ? Math.max(...activeEmployees.map(e => Number(e.workDaysPerMonth || 22))) : 22;
  return totalMonthly / Math.max(workDays, 1);
}

function operationalDaysBetween(startValue: Date | string, endValue: Date | string) {
  const start = new Date(startValue);
  const end = new Date(endValue);
  if (Number.isNaN(start.getTime()) || Number.isNaN(end.getTime())) return 0;
  start.setHours(0, 0, 0, 0);
  end.setHours(0, 0, 0, 0);
  if (end < start) return 0;
  let days = 0;
  const cursor = new Date(start);
  while (cursor <= end) {
    const day = cursor.getDay();
    if (day !== 0 && day !== 6) days++;
    cursor.setDate(cursor.getDate() + 1);
  }
  return Math.max(days, 1);
}

tenantRouter.get("/internal-costs/dashboard", async (req: Request, res: Response) => {
  try {
    const empresaId = req.tenant!.empresaId;
    const [employees, costItems] = await Promise.all([
      db.select().from(internalEmployees).where(eq(internalEmployees.empresaId, empresaId)).orderBy(desc(internalEmployees.createdAt)),
      db.select().from(internalCostItems).where(eq(internalCostItems.empresaId, empresaId)).orderBy(desc(internalCostItems.createdAt)),
    ]);

    const activeEmployees = employees.filter(e => e.active);
    const employeeMonthly = activeEmployees.reduce((sum, e) => sum + employeeMonthlyCost(e), 0);
    const fixedMonthly = costItems.filter(c => c.active && c.costType === "fixed").reduce((s, c) => s + monthlyEquivalent(Number(c.amount), c.recurrence), 0);
    const variableMonthly = costItems.filter(c => c.active && c.costType === "variable").reduce((s, c) => s + monthlyEquivalent(Number(c.amount), c.recurrence), 0);
    const semiVariableMonthly = costItems.filter(c => c.active && c.costType === "semi_variable").reduce((s, c) => s + monthlyEquivalent(Number(c.amount), c.recurrence), 0);
    const totalMonthly = employeeMonthly + fixedMonthly + variableMonthly + semiVariableMonthly;
    const workDays = activeEmployees.length ? Math.max(...activeEmployees.map(e => Number(e.workDaysPerMonth || 22))) : 22;
    const daily = totalMonthly / Math.max(workDays, 1);
    const weekly = daily * 5;
    const productiveHours = activeEmployees.reduce((sum, e) => sum + Number(e.hoursPerDay || 8) * Number(e.workDaysPerMonth || 22), 0);
    const costPerHour = productiveHours ? totalMonthly / productiveHours : 0;

    const completedInternalLots = await db
      .select({
        id: batches.id,
        batchCode: batches.batchCode,
        quantity: batches.quantity,
        sendDate: batches.sendDate,
        returnedDate: batches.returnedDate,
        pricePerUnit: batches.pricePerUnit,
        productionPricePerUnit: productions.pricePerUnit,
        internalDailyCostSnapshot: batches.internalDailyCostSnapshot,
        productionId: batches.productionId,
        productName: productions.productName,
      })
      .from(batches)
      .leftJoin(productions, eq(batches.productionId, productions.id))
      .where(and(eq(batches.empresaId, empresaId), eq(batches.assignmentType, "internal"), eq(batches.status, "concluido")))
      .orderBy(desc(batches.returnedDate), desc(batches.createdAt));

    const internalResults = completedInternalLots.map((lot: any) => {
      const unitRevenue = Number(lot.productionPricePerUnit ?? lot.pricePerUnit ?? 0);
      const revenue = Number(lot.quantity || 0) * unitRevenue;
      const dailyCost = Number(lot.internalDailyCostSnapshot || daily || 0);
      const operationalDays = operationalDaysBetween(lot.sendDate, lot.returnedDate || lot.sendDate);
      const actualCost = dailyCost * operationalDays;
      const gain = revenue - actualCost;
      const margin = revenue > 0 ? (gain / revenue) * 100 : 0;
      const targetGain35 = revenue * 0.35;
      return { ...lot, revenue, dailyCost, operationalDays, actualCost, gain, margin, targetGain35, paidStructure: gain >= 0 };
    });
    const completedRevenue = internalResults.reduce((s, l) => s + l.revenue, 0);
    const completedCost = internalResults.reduce((s, l) => s + l.actualCost, 0);
    const completedGain = completedRevenue - completedCost;
    const completedMargin = completedRevenue > 0 ? (completedGain / completedRevenue) * 100 : 0;
    const now = new Date();
    const monthKey = `${now.getFullYear()}-${String(now.getMonth()+1).padStart(2,'0')}`;
    const currentMonthLots = internalResults.filter((l:any) => {
      const d = l.returnedDate ? new Date(l.returnedDate) : null;
      return d && `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}` === monthKey;
    });
    const currentMonthRevenue = currentMonthLots.reduce((s:number,l:any)=>s+Number(l.revenue||0),0);
    const currentMonthCost = currentMonthLots.reduce((s:number,l:any)=>s+Number(l.actualCost||0),0);
    const currentMonthGain = currentMonthRevenue - currentMonthCost;
    const remainingToCover = Math.max(totalMonthly - currentMonthRevenue, 0);
    const coveragePercent = totalMonthly > 0 ? Math.min(100, currentMonthRevenue / totalMonthly * 100) : 0;
    const targetRevenue35 = totalMonthly / 0.65;
    const remainingTo35 = Math.max(targetRevenue35 - currentMonthRevenue, 0);

    const payments = await db.select().from(internalEmployeePayments).where(eq(internalEmployeePayments.empresaId, empresaId)).orderBy(desc(internalEmployeePayments.paymentDate), desc(internalEmployeePayments.createdAt));

    res.json({
      employees, costItems, payments,
      summary: { employeeMonthly, fixedMonthly, variableMonthly, semiVariableMonthly, totalMonthly, daily, weekly, workDays, productiveHours, costPerHour, completedRevenue, completedCost, completedGain, completedMargin, completedLots: internalResults.length, currentMonthRevenue, currentMonthCost, currentMonthGain, remainingToCover, coveragePercent, targetRevenue35, remainingTo35, monthKey },
      completedInternalLots: internalResults,
    });
  } catch (error: any) {
    res.status(500).json({ message: error.message });
  }
});

tenantRouter.get("/internal-employees", async (req: Request, res: Response) => {
  try { res.json(await db.select().from(internalEmployees).where(eq(internalEmployees.empresaId, req.tenant!.empresaId)).orderBy(desc(internalEmployees.createdAt))); }
  catch (e: any) { res.status(500).json({ message: e.message }); }
});

tenantRouter.post("/internal-employees", requireRole("admin_empresa", "financeiro"), async (req: Request, res: Response) => {
  try {
    const data = insertInternalEmployeeSchema.parse(req.body);
    const [employee] = await db.insert(internalEmployees).values({ ...data, empresaId: req.tenant!.empresaId }).returning();
    res.status(201).json(employee);
  } catch (e: any) { res.status(400).json({ message: e.message }); }
});

tenantRouter.patch("/internal-employees/:id", requireRole("admin_empresa", "financeiro"), async (req: Request, res: Response) => {
  try {
    const { empresaId: _ignoredEmpresaId, ...employeePatch } = req.body;
    const [employee] = await db.update(internalEmployees).set({ ...employeePatch, updatedAt: new Date() }).where(and(eq(internalEmployees.id, req.params.id), eq(internalEmployees.empresaId, req.tenant!.empresaId))).returning();
    if (!employee || employee.empresaId !== req.tenant!.empresaId) return res.status(404).json({ message: "Funcionário não encontrado" });
    res.json(employee);
  } catch (e: any) { res.status(400).json({ message: e.message }); }
});

tenantRouter.delete("/internal-employees/:id", requireRole("admin_empresa"), async (req: Request, res: Response) => {
  try {
    const [employee] = await db.update(internalEmployees).set({ active: false, updatedAt: new Date() }).where(and(eq(internalEmployees.id, req.params.id), eq(internalEmployees.empresaId, req.tenant!.empresaId))).returning();
    if (!employee || employee.empresaId !== req.tenant!.empresaId) return res.status(404).json({ message: "Funcionário não encontrado" });
    res.json(employee);
  } catch (e: any) { res.status(400).json({ message: e.message }); }
});

tenantRouter.get("/internal-cost-items", async (req: Request, res: Response) => {
  try { res.json(await db.select().from(internalCostItems).where(eq(internalCostItems.empresaId, req.tenant!.empresaId)).orderBy(desc(internalCostItems.createdAt))); }
  catch (e: any) { res.status(500).json({ message: e.message }); }
});

tenantRouter.post("/internal-cost-items", requireRole("admin_empresa", "financeiro"), async (req: Request, res: Response) => {
  try {
    const data = insertInternalCostItemSchema.parse(req.body);
    const [item] = await db.insert(internalCostItems).values({ ...data, empresaId: req.tenant!.empresaId }).returning();
    res.status(201).json(item);
  } catch (e: any) { res.status(400).json({ message: e.message }); }
});

tenantRouter.patch("/internal-cost-items/:id", requireRole("admin_empresa", "financeiro"), async (req: Request, res: Response) => {
  try {
    const { empresaId: _ignoredEmpresaId, ...itemPatch } = req.body;
    const [item] = await db.update(internalCostItems).set({ ...itemPatch, updatedAt: new Date() }).where(and(eq(internalCostItems.id, req.params.id), eq(internalCostItems.empresaId, req.tenant!.empresaId))).returning();
    if (!item || item.empresaId !== req.tenant!.empresaId) return res.status(404).json({ message: "Custo não encontrado" });
    res.json(item);
  } catch (e: any) { res.status(400).json({ message: e.message }); }
});

tenantRouter.delete("/internal-cost-items/:id", requireRole("admin_empresa"), async (req: Request, res: Response) => {
  try {
    const [item] = await db.update(internalCostItems).set({ active: false, updatedAt: new Date() }).where(and(eq(internalCostItems.id, req.params.id), eq(internalCostItems.empresaId, req.tenant!.empresaId))).returning();
    if (!item || item.empresaId !== req.tenant!.empresaId) return res.status(404).json({ message: "Custo não encontrado" });
    res.json(item);
  } catch (e: any) { res.status(400).json({ message: e.message }); }
});


// Editable financial plan: partners and configurable cash boxes.
tenantRouter.get("/financial-plan", async (req: Request, res: Response) => {
  try {
    let rows = await db.select().from(financialPlanAllocations)
      .where(eq(financialPlanAllocations.empresaId, req.tenant!.empresaId))
      .orderBy(financialPlanAllocations.sortOrder, financialPlanAllocations.createdAt);
    if (rows.length === 0) {
      const defaults = [
        { name: "Leonardo", allocationType: "partner" as const, percentage: "20", sortOrder: 0 },
        { name: "Hugo", allocationType: "partner" as const, percentage: "20", sortOrder: 1 },
        { name: "Caixa manutenção de carro", allocationType: "cash_box" as const, percentage: "10", sortOrder: 2 },
        { name: "Caixa de segurança", allocationType: "cash_box" as const, percentage: "20", sortOrder: 3 },
        { name: "Caixa reinvestimento no negócio", allocationType: "cash_box" as const, percentage: "20", sortOrder: 4 },
        { name: "Folga / lucro", allocationType: "cash_box" as const, percentage: "10", sortOrder: 5 },
      ];
      rows = await db.insert(financialPlanAllocations).values(defaults.map(x => ({ ...x, empresaId: req.tenant!.empresaId, active: true }))).returning();
    }
    res.json(rows);
  } catch (e: any) { res.status(500).json({ message: e.message }); }
});

tenantRouter.post("/financial-plan", requireRole("admin_empresa", "financeiro"), async (req: Request, res: Response) => {
  try {
    const data = insertFinancialPlanAllocationSchema.parse(req.body);
    const [row] = await db.insert(financialPlanAllocations).values({ ...data, empresaId: req.tenant!.empresaId }).returning();
    res.status(201).json(row);
  } catch (e: any) { res.status(400).json({ message: e.message }); }
});

tenantRouter.patch("/financial-plan/:id", requireRole("admin_empresa", "financeiro"), async (req: Request, res: Response) => {
  try {
    const { empresaId: _ignored, ...patch } = req.body;
    if (patch.percentage !== undefined) patch.percentage = String(patch.percentage);
    if (patch.sortOrder !== undefined) patch.sortOrder = Number(patch.sortOrder);
    const [row] = await db.update(financialPlanAllocations).set({ ...patch, updatedAt: new Date() })
      .where(and(eq(financialPlanAllocations.id, req.params.id), eq(financialPlanAllocations.empresaId, req.tenant!.empresaId))).returning();
    if (!row) return res.status(404).json({ message: "Item do plano financeiro não encontrado" });
    res.json(row);
  } catch (e: any) { res.status(400).json({ message: e.message }); }
});

tenantRouter.delete("/financial-plan/:id", requireRole("admin_empresa"), async (req: Request, res: Response) => {
  try {
    const [row] = await db.update(financialPlanAllocations).set({ active: false, updatedAt: new Date() })
      .where(and(eq(financialPlanAllocations.id, req.params.id), eq(financialPlanAllocations.empresaId, req.tenant!.empresaId))).returning();
    if (!row) return res.status(404).json({ message: "Item do plano financeiro não encontrado" });
    res.json(row);
  } catch (e: any) { res.status(400).json({ message: e.message }); }
});

// Internal employee payments: salary and transport are separate financial records.
tenantRouter.get("/internal-employee-payments", async (req: Request, res: Response) => {
  try {
    const rows = await db.select().from(internalEmployeePayments).where(eq(internalEmployeePayments.empresaId, req.tenant!.empresaId)).orderBy(desc(internalEmployeePayments.paymentDate), desc(internalEmployeePayments.createdAt));
    res.json(rows);
  } catch (e: any) { res.status(500).json({ message: e.message }); }
});

tenantRouter.post("/internal-employee-payments", requireRole("admin_empresa", "financeiro"), async (req: Request, res: Response) => {
  try {
    const data = insertInternalEmployeePaymentSchema.parse(req.body);
    const [employee] = await db.select().from(internalEmployees).where(and(eq(internalEmployees.id, data.employeeId), eq(internalEmployees.empresaId, req.tenant!.empresaId)));
    if (!employee) return res.status(404).json({ message: "Funcionário não encontrado" });
    const [row] = await db.insert(internalEmployeePayments).values({ ...data, empresaId: req.tenant!.empresaId, receiptNumber: data.receiptNumber || `REC-${Date.now()}` }).returning();
    res.status(201).json(row);
  } catch (e: any) { res.status(400).json({ message: e.message }); }
});

tenantRouter.patch("/internal-employee-payments/:id", requireRole("admin_empresa", "financeiro"), async (req: Request, res: Response) => {
  try {
    const { empresaId: _ignored, ...patch } = req.body;
    if (patch.amount !== undefined) patch.amount = String(patch.amount);
    if (patch.paymentDate) patch.paymentDate = new Date(patch.paymentDate);
    const [row] = await db.update(internalEmployeePayments).set({ ...patch, updatedAt: new Date() }).where(and(eq(internalEmployeePayments.id, req.params.id), eq(internalEmployeePayments.empresaId, req.tenant!.empresaId))).returning();
    if (!row) return res.status(404).json({ message: "Pagamento não encontrado" });
    res.json(row);
  } catch (e: any) { res.status(400).json({ message: e.message }); }
});
