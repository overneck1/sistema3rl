import { eq } from "drizzle-orm";
import { db } from "./db";
import { admins, empresas, usuarios, seamstresses, productions, productionVariants, batches, payments } from "@shared/schema";
import { hashPassword } from "./auth";

const DEMO_EMPRESA_CODE = "DEMO3RL";
const DEMO_EMAIL = "demo@3rltextil.com";
const DEMO_PASSWORD = "demo123";
const ADMIN_EMAIL = "admin@gofast.com";
const ADMIN_PASSWORD = "admin123";

export async function ensureDemoData(): Promise<void> {
  const existingAdmins = await db.select({ id: admins.id }).from(admins).limit(1);
  if (existingAdmins.length === 0) {
    await db.insert(admins).values({
      name: "Super Admin",
      email: ADMIN_EMAIL,
      password: await hashPassword(ADMIN_PASSWORD),
      role: "superadmin",
      isActive: true,
    });
  }

  let [empresa] = await db.select().from(empresas).where(eq(empresas.code, DEMO_EMPRESA_CODE)).limit(1);
  if (!empresa) {
    [empresa] = await db.insert(empresas).values({
      name: "3RL Textil Demo",
      code: DEMO_EMPRESA_CODE,
      subdomain: "demo",
      databaseName: "empresa_demo3rl_db",
      status: "active",
      plan: "premium",
      ownerName: "Avaliador Showcase",
      ownerEmail: DEMO_EMAIL,
      ownerPhone: "11999990000",
    }).returning();
  } else if (empresa.status !== "active") {
    [empresa] = await db.update(empresas)
      .set({ status: "active" })
      .where(eq(empresas.id, empresa.id))
      .returning();
  }

  const [existingUser] = await db.select().from(usuarios).where(eq(usuarios.email, DEMO_EMAIL)).limit(1);
  if (!existingUser) {
    await db.insert(usuarios).values({
      empresaId: empresa.id,
      name: "Demo 3RL Textil",
      email: DEMO_EMAIL,
      password: await hashPassword(DEMO_PASSWORD),
      role: "admin_empresa",
      isActive: true,
    });
  } else if (!existingUser.isActive || existingUser.empresaId !== empresa.id) {
    await db.update(usuarios).set({
      empresaId: empresa.id,
      password: await hashPassword(DEMO_PASSWORD),
      role: "admin_empresa",
      isActive: true,
    }).where(eq(usuarios.id, existingUser.id));
  }

  const existingSeamstresses = await db.select({ id: seamstresses.id }).from(seamstresses)
    .where(eq(seamstresses.empresaId, empresa.id)).limit(1);
  if (existingSeamstresses.length > 0) {
    return;
  }

  const [maria] = await db.insert(seamstresses).values({
    empresaId: empresa.id,
    name: "Maria Silva",
    phone: "11988887777",
    pix: "maria.silva@pix.com",
    address: "Rua das Costuras, 120",
    neighborhood: "Centro",
    numberOfWorkers: 2,
    skills: ["costura reta", "overloque"],
    machines: ["Reta", "Overloque"],
    status: "active",
    notes: "Costureira principal da demonstração",
  }).returning();

  const [ana] = await db.insert(seamstresses).values({
    empresaId: empresa.id,
    name: "Ana Costa",
    phone: "11977776666",
    pix: "ana.costa@pix.com",
    address: "Av. Industria, 45",
    neighborhood: "Industrial",
    numberOfWorkers: 1,
    skills: ["acabamento"],
    machines: ["Galoneira"],
    status: "active",
    notes: "Especialista em acabamento",
  }).returning();

  const now = new Date();
  const delivery = new Date(now.getTime() + 14 * 24 * 60 * 60 * 1000);

  const [camisa] = await db.insert(productions).values({
    empresaId: empresa.id,
    productionCode: "DEMO-PROD-001",
    supplier: "Malharia Central",
    productName: "Camiseta Básica",
    date: now,
    deliveryDate: delivery,
    quantity: 200,
    types: ["malha"],
    labels: "3RL",
    trims: "Gola canoa",
    pricePerUnit: "18.50",
    status: "em_producao",
    paymentStatus: "Pendente",
    notes: "Pedido de demonstração",
  }).returning();

  const [calca] = await db.insert(productions).values({
    empresaId: empresa.id,
    productionCode: "DEMO-PROD-002",
    supplier: "Tecidos União",
    productName: "Calça Moletom",
    date: now,
    deliveryDate: delivery,
    quantity: 80,
    types: ["moletom"],
    labels: "3RL",
    trims: "Cós elástico",
    pricePerUnit: "32.00",
    status: "em_separacao",
    paymentStatus: "Pendente",
    notes: "Segunda produção de demonstração",
  }).returning();

  const [variant] = await db.insert(productionVariants).values({
    empresaId: empresa.id,
    productionId: camisa.id,
    size: "M",
    color: "Preto",
    quantity: 120,
  }).returning();

  await db.insert(productionVariants).values({
    empresaId: empresa.id,
    productionId: camisa.id,
    size: "G",
    color: "Branco",
    quantity: 80,
  });

  const sendDate = new Date(now.getTime() - 3 * 24 * 60 * 60 * 1000);
  const expectedReturn = new Date(now.getTime() + 5 * 24 * 60 * 60 * 1000);

  const [loteMaria] = await db.insert(batches).values({
    empresaId: empresa.id,
    batchCode: "DEMO-LOTE-001",
    productionId: camisa.id,
    seamstressId: maria.id,
    assignmentType: "external",
    quantity: 80,
    sendDate,
    expectedReturnDate: expectedReturn,
    pricePerUnit: "6.50",
    status: "em_producao",
    notes: "Lote em produção com Maria",
  }).returning();

  await db.insert(batches).values({
    empresaId: empresa.id,
    batchCode: "DEMO-LOTE-002",
    productionId: calca.id,
    seamstressId: ana.id,
    assignmentType: "external",
    quantity: 40,
    sendDate,
    expectedReturnDate: expectedReturn,
    pricePerUnit: "9.00",
    status: "em_separacao",
    notes: "Lote em separação com Ana",
  });

  await db.insert(payments).values({
    empresaId: empresa.id,
    batchId: loteMaria.id,
    seamstressId: maria.id,
    amount: "520.00",
    status: "pending",
    dueDate: expectedReturn,
    notes: "Pagamento pendente da demonstração",
  });

  void variant;
}
