-- GoFast Produções - hardening migration
-- Run once against the existing PostgreSQL database before/alongside `npm run db:push`.

ALTER TABLE production_variants ADD COLUMN IF NOT EXISTS empresa_id varchar;
ALTER TABLE batch_variant_allocations ADD COLUMN IF NOT EXISTS empresa_id varchar;
ALTER TABLE whatsapp_messages ADD COLUMN IF NOT EXISTS empresa_id varchar;

-- Backfill tenant ownership from the parent records for data created before multi-tenant hardening.
UPDATE production_variants pv
SET empresa_id = p.empresa_id
FROM productions p
WHERE pv.production_id = p.id
  AND pv.empresa_id IS NULL
  AND p.empresa_id IS NOT NULL;

UPDATE batch_variant_allocations a
SET empresa_id = b.empresa_id
FROM batches b
WHERE a.batch_id = b.id
  AND a.empresa_id IS NULL
  AND b.empresa_id IS NOT NULL;

-- WhatsApp messages created before tenant isolation cannot be safely assigned to a company
-- from the current schema. They remain hidden from tenant-scoped queries until explicitly
-- reviewed/assigned. Do not guess ownership.

CREATE INDEX IF NOT EXISTS production_variants_empresa_id_idx
  ON production_variants (empresa_id);

CREATE INDEX IF NOT EXISTS batch_variant_allocations_empresa_id_idx
  ON batch_variant_allocations (empresa_id);

CREATE INDEX IF NOT EXISTS whatsapp_messages_empresa_id_created_at_idx
  ON whatsapp_messages (empresa_id, created_at DESC);
