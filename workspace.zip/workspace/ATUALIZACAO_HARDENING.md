# GoFast Produções — atualização de segurança e multiempresa

## O que foi alterado

- APIs antigas de negócio `/api/*` foram desativadas para impedir bypass do isolamento por empresa.
- Frontend foi ajustado para usar `/api/tenant/*` nos fluxos de produção e lotes que ainda usavam endpoints antigos diretamente.
- JWT agora exige `JWT_SECRET` real no ambiente; não existe mais chave padrão embutida no código.
- Logs de API não gravam mais o corpo completo das respostas.
- Limite de JSON caiu de 50 MB para 1 MB.
- `production_variants`, `batch_variant_allocations` e `whatsapp_messages` receberam `empresa_id`.
- Consultas e mutações dessas entidades passaram a respeitar o tenant.
- Alocações validam se o lote e a variação pertencem à mesma empresa e produção.
- Exclusões de alocações respeitam o tenant.
- Geração de novos códigos de lote deixou de usar `MAX()+1`, evitando colisões por concorrência.
- Senhas temporárias de novas empresas e resets usam `crypto.randomBytes`.
- Exclusões e alterações financeiras críticas receberam autorização de backend por função.
- Agente de código exige usuário autenticado e função `admin_empresa` para acesso ao filesystem e alteração de código.
- O contexto de dados do Agente GoFast passou a usar o armazenamento da empresa autenticada.

## Antes de iniciar no Replit

1. Configure um segredo forte:

```text
JWT_SECRET=<uma-chave-aleatória-forte-com-pelo-menos-32-caracteres>
```

2. Execute a migração SQL de `migrations/001_hardening.sql` no PostgreSQL existente.

3. Depois execute:

```text
npm run db:push
npm run check
npm run build
```

## Atenção sobre WhatsApp antigo

Mensagens antigas que foram gravadas antes da existência de `empresa_id` ficam sem empresa associada e, por segurança, não aparecem nas consultas tenant-scoped. Isso é proposital: atribuir essas mensagens automaticamente poderia entregar dados de uma empresa para outra.

## Observação sobre WhatsApp

O histórico de mensagens foi isolado por empresa. A conexão Baileys ainda utiliza o serviço de WhatsApp existente do projeto; se o objetivo for oferecer um número WhatsApp independente para cada empresa do SaaS, o próximo passo deve ser transformar a conexão em uma sessão por `empresaId`.
