-- GoFast Produções: rentabilidade real dos lotes internos
-- Guarda o custo diário da estrutura no momento em que o lote interno é criado,
-- evitando que alterações futuras de custos distorçam o histórico.
ALTER TABLE batches ADD COLUMN IF NOT EXISTS internal_daily_cost_snapshot numeric(12,2);

CREATE INDEX IF NOT EXISTS idx_batches_internal_completed ON batches(empresa_id, assignment_type, status, returned_date);
