# Design Guidelines: GoFast Produções Production Management System

## Design Approach

**System-Based Approach**: Carbon Design System principles adapted for enterprise manufacturing, enhanced with modern technological aesthetics. This data-intensive productivity application balances operational efficiency with visual sophistication through purposeful use of the purple brand palette.

**Core Principles**: Data clarity, operational efficiency, mobile-ready functionality, and print optimization remain paramount. The purple palette elevates the professional appearance while maintaining high readability and scannability critical for factory floor operations.

## Color System

**Brand Palette**:
- **Primary Dark** (#4c1d95): Navigation headers, primary buttons, key section backgrounds
- **Primary Medium** (#7c3aed): Interactive elements, links, active states, accent borders
- **Primary Light** (#c4b5fd): Hover states, subtle backgrounds, badge highlights, selection states
- **White** (#ffffff): Main content backgrounds, card surfaces, text on dark backgrounds
- **Neutrals**: Gray-50 through Gray-900 for text hierarchy, borders, and backgrounds

**Application Strategy**:
- Dark purple (#4c1d95): Top navigation bar, sidebar background, footer
- Medium purple (#7c3aed): Primary action buttons, focused inputs, active navigation items, data visualization accents
- Light purple (#c4b5fd): Hover backgrounds, selected rows, badge backgrounds, alert info states
- White: Content areas, cards, modals, form backgrounds
- Text: Gray-900 on white backgrounds, white on purple backgrounds

## Typography System

**Font Stack**: IBM Plex Sans (primary), IBM Plex Mono (codes/IDs) via Google Fonts

**Hierarchy**:
- H1: text-3xl font-semibold (Page titles - gray-900)
- H2: text-2xl font-semibold (Module sections - gray-800)
- H3: text-xl font-medium (Card headers - gray-800)
- Body: text-base (Primary content - gray-700)
- Small: text-sm (Metadata - gray-600)
- Labels: text-sm font-medium uppercase tracking-wide (Form labels - gray-700)
- Codes: text-base font-mono (Production IDs - gray-900)

## Layout System

**Spacing Units**: Tailwind units of **2, 4, 6, 8, 12, 16**

**Container Strategy**:
- Desktop: max-w-7xl mx-auto px-8
- Tablet: px-6
- Mobile: px-4

**Grid Patterns**:
- Dashboard: 3-column metrics grid (grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6)
- Data Tables: Full-width with horizontal scroll on mobile
- Forms: 2-column desktop, single mobile (grid-cols-1 md:grid-cols-2 gap-6)
- Detail Views: 2/3 main content, 1/3 sidebar metadata

## Component Library

### Navigation
- **Top Bar**: Dark purple (#4c1d95) fixed header, white text, company logo left, user menu/notifications right, height h-16
- **Sidebar** (Desktop): Dark purple background, medium purple active states, icons with labels, collapsible to icon-only
- **Bottom Tabs** (Mobile): White background with medium purple active indicators, fixed position
- **Breadcrumbs**: Gray-600 text with medium purple active link, separated by chevrons

### Data Display

**Tables**:
- White background with light purple (#c4b5fd) alternate row hover
- Sticky header with subtle border-b
- Medium purple sortable column indicators
- Row selection with medium purple checkboxes
- Inline action icons (edit, view, print, QR) in gray-600, hover medium purple
- Pagination controls with medium purple active page

**Cards**:
- White background, rounded-lg, border border-gray-200
- Header: flex justify-between with title (text-lg font-semibold) and action buttons
- Body: p-6, structured content with clear spacing
- Hover: subtle shadow-md transition
- Status badge top-right corner

**Status Badges**:
- Pill shape: rounded-full px-3 py-1 text-sm font-medium
- Active/In Progress: bg-purple-100 text-purple-800 (light purple background)
- Completed: bg-green-100 text-green-800
- Pending: bg-yellow-100 text-yellow-800
- Cancelled: bg-red-100 text-red-800

**Dashboard Stats Widgets**:
- White card with border, p-6
- Icon in medium purple circle top-left
- Large number: text-4xl font-bold gray-900
- Label: text-sm gray-600 below
- Trend indicator with arrow icon and percentage

### Forms

**Input Fields**:
- Border-gray-300, focus:border-medium-purple, focus:ring-2 focus:ring-light-purple
- Labels: text-sm font-medium gray-700 mb-2
- Helper text: text-xs gray-500 mt-1
- Error state: border-red-500 with red helper text
- Required asterisk in medium purple

**Buttons**:
- Primary: bg-medium-purple (#7c3aed) text-white, hover:bg-dark-purple, px-6 py-2 rounded-lg
- Secondary: border-2 border-medium-purple text-medium-purple, hover:bg-light-purple
- Danger: bg-red-600 text-white
- Icon buttons: p-2 rounded-md hover:bg-light-purple transition
- All buttons: font-medium text-sm min-h-[44px] for touch targets

### Specialized Components

**QR Code Display**:
- Centered in white modal/print area
- Medium purple border frame around QR
- Production ID below in monospace font
- Print button (primary style) below

**Quality Checklist**:
- White card with grouped checkboxes (medium purple when checked)
- Photo upload zones with dashed light purple borders
- Approval toggle: large switch in medium/dark purple
- Expandable notes textarea

**Kanban Board**:
- Columns: white background with light purple header
- Cards: white with border, compact design showing essential info
- Drag indicator in medium purple
- Column count badge in top-right

**Financial Cards**:
- Large monetary value: text-3xl font-bold with currency symbol
- Breakdown sections with light purple dividers
- Comparison metrics with medium purple positive indicators

## Responsive Behavior

**Breakpoints**: Mobile (<640px), Tablet (640-1024px), Desktop (>1024px)

**Mobile Optimizations**:
- Stacked card layouts replacing tables
- Bottom sheet modals (white with rounded-t-xl)
- Floating action button (medium purple, bottom-right, shadow-lg)
- Touch targets minimum 44px
- Swipeable batch lists

## Icons

**Library**: Heroicons via CDN (outline for navigation, solid for filled states)
**Size**: 20px standard, 24px for primary actions
**Color**: Inherit text color (gray-600 default, white on dark purple, medium purple for active/interactive)

## Print/PDF Layouts

**Headers**: Company logo + report title, document ID in monospace, date stamp
**Body**: Two-column metadata section, full-width tables, QR in top-right corner
**Footer**: Page numbers, generation timestamp
**Color**: Convert purple elements to grayscale for print, maintain hierarchy through weight

## Images

**Minimal Usage** - Operational tool focused on data:
- **Company Logo**: Header navigation (max-h-12, auto width)
- **Quality Control Photos**: User-uploaded inspection images in grids (aspect-ratio-square)
- **Empty State Illustrations**: Simple line art in light purple when tables/lists are empty
- **User Avatars**: Seamstress profiles (rounded-full, 32px or 40px)

No hero images or decorative photography. This is a production floor tool prioritizing function.

## Accessibility

- WCAG AA contrast ratios (purple on white, white on dark purple tested)
- Focus rings: 2px medium purple offset
- Keyboard navigation throughout
- Screen reader labels for icon-only buttons
- Form validation with clear error messages
- Skip navigation link for keyboard users