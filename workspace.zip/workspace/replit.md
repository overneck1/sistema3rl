# GoFast Produções - Production Management System

## Overview

GoFast Produções is a comprehensive multi-tenant SaaS production management system designed for garment manufacturing operations. The system manages the complete production workflow from receiving orders from suppliers, distributing work to seamstresses through batches, tracking quality control, and managing payments. It provides real-time visibility into production status, inventory management, and financial operations.

The application is built as a full-stack TypeScript solution with a React frontend, Express backend, and PostgreSQL database with row-level tenant isolation, optimized for both desktop and mobile use in warehouse/factory environments.

### Multi-Tenant Architecture

**Authentication System**:
- JWT-based authentication with role-based access control
- Two user types: Admin (superadmin/admin) and Usuario (company users)
- Login page (/login) is the default entry point
- Automatic redirection to login for unauthenticated users
- Company users see only their company's data (row-level isolation via empresaId)

**User Roles**:
- **Superadmin**: Full access to all companies and users, can reset passwords
- **Admin**: Access to admin panel for managing companies
- **Admin Empresa**: Company administrator with full company access
- **Operador/Financeiro/Visualizador**: Company-level roles with varying permissions

**Admin Panel (/admin)**:
- Dashboard with company statistics
- Company management (create, update, suspend, delete)
- User management per company
- Superadmin-only: View all users across all companies, reset passwords

**Default Superadmin Credentials**:
- Email: admin@gofast.com
- Password: admin123
- Created via POST /api/admin/setup (first-time setup only)

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture

**Framework**: React 18 with TypeScript, bundled via Vite

**UI Component System**: Shadcn/ui components built on Radix UI primitives
- Component library follows the "New York" style variant
- Fully accessible, keyboard-navigable components
- Responsive design with mobile-first approach

**Styling Strategy**: Tailwind CSS with custom design tokens
- Carbon Design System principles adapted for manufacturing context
- Custom color system supporting light/dark modes via CSS variables
- Typography using IBM Plex Sans (primary) and IBM Plex Mono (codes/IDs)
- Spacing system based on multiples of 2 (2, 4, 6, 8, 12, 16)

**State Management**: TanStack Query (React Query) for server state
- Automatic caching and invalidation
- Optimistic updates for better UX
- Centralized API request handling via custom `apiRequest` utility

**Routing**: Wouter (lightweight client-side routing)
- File-based route structure in `/client/src/pages`
- Main routes: Dashboard, Seamstresses, Productions, Batches, Payments

**Design Principles**:
- Data clarity first: optimized for quick scanning and decision-making
- Operational efficiency: minimal clicks for critical tasks
- Mobile-ready: full functionality on tablets/smartphones
- Print-optimized: clean layouts for PDF reports and labels

### Backend Architecture

**Runtime**: Node.js with Express.js framework

**API Pattern**: RESTful API design
- CRUD operations for all entities
- Consistent endpoint structure: `/api/{resource}` and `/api/{resource}/:id`
- JSON request/response format
- Error handling with appropriate HTTP status codes

**Development vs Production**:
- Development: Vite dev server with HMR via `server/index-dev.ts`
- Production: Static file serving from built assets via `server/index-prod.ts`
- Separate build and start scripts for each environment

**Request Handling**:
- Express JSON middleware with raw body preservation for webhooks
- URL-encoded form data support
- Request logging with timestamps and duration tracking
- API route filtering (logs only `/api` routes)

### Data Storage

**Database**: PostgreSQL via Neon serverless
- WebSocket-based connection pooling for serverless compatibility
- Connection string configured via `DATABASE_URL` environment variable

**ORM**: Drizzle ORM
- Type-safe database queries
- Schema-first approach with TypeScript types auto-generated
- Schema validation using Zod via `drizzle-zod`
- Migration support via Drizzle Kit

**Database Schema**:

1. **Seamstresses** (`seamstresses` table)
   - UUID primary key
   - Contact information (name, phone, address, neighborhood)
   - Skills and machines (array fields)
   - Status enum: active, paused, blocked
   - Rating system (numeric with 2 decimal precision)
   - Notes and creation timestamp

2. **Productions** (`productions` table)
   - UUID primary key with auto-generated production code
   - Supplier information
   - Inventory details (quantity, types, sizes, colors)
   - Material specifications (labels, trims)
   - Price per unit (numeric with 2 decimal precision)
   - Status enum: open, partial, completed
   - Tracks available inventory vs distributed to batches

3. **Batches** (`batches` table)
   - UUID primary key with auto-generated batch code
   - Foreign keys to productions and seamstresses
   - Quantity allocation (cannot exceed production inventory)
   - Date tracking (send date, expected return, actual return)
   - Price per unit for seamstress payment
   - Status enum: waiting, in_progress, delayed, returned, completed
   - Automatic status calculation based on dates

4. **Quality Control** (`qualityControls` table)
   - One-to-one relationship with batches
   - Inspection metrics (quantity inspected, approved, rejected)
   - Defect tracking and categories
   - Inspector information and timestamps

5. **Payments** (`payments` table)
   - Links to seamstresses and batches
   - Payment tracking (amount, date, method)
   - Status enum: pending, paid, cancelled
   - Notes field for payment details

**Data Relationships**:
- Productions → Batches (one-to-many)
- Seamstresses → Batches (one-to-many)
- Batches → Quality Control (one-to-one)
- Seamstresses → Payments (one-to-many)
- Batches → Payments (one-to-many)

**Storage Layer**: Abstract `IStorage` interface with `DatabaseStorage` implementation
- Separation of data access logic from route handlers
- Enables testing and alternative storage backends
- Type-safe methods using Drizzle schema types

### External Dependencies

**UI Component Libraries**:
- Radix UI: Accessible, unstyled component primitives (accordion, dialog, dropdown, select, etc.)
- Recharts: Data visualization for dashboard charts
- Embla Carousel: Touch-friendly carousel component
- Lucide React: Icon library
- React Hook Form + Zod Resolvers: Form handling and validation
- CMDK: Command palette component
- Vaul: Drawer component for mobile

**Styling & Design**:
- Tailwind CSS: Utility-first CSS framework
- class-variance-authority: Component variant management
- clsx + tailwind-merge: Conditional class name composition
- PostCSS + Autoprefixer: CSS processing

**Data & State**:
- TanStack Query: Async state management and data fetching
- date-fns: Date manipulation and formatting

**Database & Backend**:
- @neondatabase/serverless: PostgreSQL serverless client with WebSocket support
- Drizzle ORM + Drizzle Kit: Database ORM and migration tools
- drizzle-zod: Schema validation integration
- connect-pg-simple: PostgreSQL session store (configured but not actively used)
- ws: WebSocket library for Neon database connections

**Development Tools**:
- Vite: Build tool and dev server
- TypeScript: Type safety across frontend and backend
- ESBuild: Production bundling for server code
- TSX: TypeScript execution for development
- @replit/* plugins: Development environment enhancements (error overlay, cartographer, dev banner)

**Configuration**:
- Environment variable: `DATABASE_URL` (required for PostgreSQL connection)
- Path aliases: `@/` (client src), `@shared/` (shared types), `@assets/` (attached assets)
- Base URL configuration for module resolution

## Important Development Guidelines

### Tenant-Based API Routes (CRITICAL)

**ALWAYS use `/api/tenant/*` routes for all company-scoped operations**. The system is multi-tenant and uses `empresaId` for data isolation.

**Correct patterns:**
- `GET /api/tenant/payments` - Lists payments for the logged-in user's company
- `POST /api/tenant/payments` - Creates payment with automatic empresaId
- `PATCH /api/tenant/payments/:id` - Updates payment within company scope
- `GET /api/tenant/batches` - Lists batches for the company
- `GET /api/tenant/seamstresses` - Lists seamstresses for the company
- `GET /api/tenant/productions` - Lists productions for the company

**Avoid using non-tenant routes for company data:**
- `/api/payments` - Global scope, does NOT filter by empresaId
- `/api/batches` - Global scope
- `/api/seamstresses` - Global scope
- `/api/productions` - Global scope

**Cache invalidation must match query keys:**
When mutating data, invalidate both tenant and non-tenant caches:
```javascript
queryClient.invalidateQueries({ queryKey: ["/api/tenant/payments"] });
queryClient.invalidateQueries({ queryKey: ["/api/tenant/batches"] });
queryClient.invalidateQueries({ queryKey: ["/api/tenant/dashboard"] });
```

### Recent Fixes (2026-02-04)

1. **Payment Display Issue Fixed**: Corrected route usage in batches.tsx to use `/api/tenant/payments` instead of `/api/payments`, ensuring payments are created with correct empresaId
2. **Cache Invalidation Fixed**: Updated all payment-related mutations to invalidate tenant-specific query keys
3. **Batch Printing Enhanced**: Added fallback to use production variants when batch variant allocations are missing

### Recent Fixes (2026-02-27)

4. **Batch Creation Bug Fixed (Critical)**: `createBatch` in `tenant-storage.ts` was only querying the current company's batches when generating the unique batch code. Since `batch_code` has a global unique constraint, a new company's first batch would always fail with a duplicate key error (e.g., Overneck trying to create L-0001 when another company already had it). Fixed by querying ALL batches to find the global max code number.
5. **Error Feedback Added**: Added `onError` toast handlers to `createMutation` and `updateMutation` in batches.tsx so users see clear error messages when operations fail instead of silent failure.
6. **Date UX Fixed**: When a production's delivery date is in the past, `expectedReturnDate` now defaults to today +7 days instead of the past date. Removed the `max` attribute constraint on the date input. Removed the hard-block validation preventing batch creation when `expectedReturnDate > deliveryDate`. Added informational warning (in orange) when production deadline has passed.