CREATE TABLE IF NOT EXISTS financial_plan_allocations (
  id varchar PRIMARY KEY DEFAULT gen_random_uuid(),
  empresa_id varchar NOT NULL,
  name text NOT NULL,
  allocation_type varchar NOT NULL,
  percentage numeric(7,3) NOT NULL DEFAULT 0,
  active boolean NOT NULL DEFAULT true,
  sort_order integer NOT NULL DEFAULT 0,
  created_at timestamp NOT NULL DEFAULT now(),
  updated_at timestamp NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS financial_plan_allocations_empresa_idx ON financial_plan_allocations(empresa_id);
