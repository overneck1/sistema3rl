@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title GoFast Produções - Testes

if not exist local-env.bat (
  echo Execute CONFIGURAR-GOFAST.bat primeiro.
  pause
  exit /b 1
)

call local-env.bat
set NODE_ENV=development

where node >nul 2>&1 || (echo Node.js nao encontrado.&pause&exit /b 1)
where npm >nul 2>&1 || (echo npm nao encontrado.&pause&exit /b 1)

if not exist node_modules (
  echo Instalando dependencias...
  call npm install || (echo Falha no npm install.&pause&exit /b 1)
)

echo.
echo ================================================
echo         GOFAST - VALIDACAO LOCAL
 echo ================================================
echo.

echo [1/3] TypeScript...
call npx tsc --noEmit
if errorlevel 1 (
  echo.
  echo FALHA: TypeScript encontrou erros.
  pause
  exit /b 1
)

echo.
echo [2/3] Build do frontend/backend...
call npm run build
if errorlevel 1 (
  echo.
  echo FALHA: build do projeto.
  pause
  exit /b 1
)

echo.
echo [3/3] Banco de dados...
call npx drizzle-kit push
if errorlevel 1 (
  echo.
  echo FALHA: banco nao pode ser sincronizado.
  pause
  exit /b 1
)

echo.
echo ================================================
echo             VALIDACAO CONCLUIDA
 echo ================================================
echo TypeScript : OK
echo Build      : OK
echo Banco      : OK
echo.
echo Observacao: testes E2E completos precisam do servidor rodando e Playwright configurado.
echo.
pause
