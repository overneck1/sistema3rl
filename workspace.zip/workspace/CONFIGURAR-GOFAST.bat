@echo off
setlocal EnableExtensions
cd /d "%~dp0"

title GoFast Produções - Configuração

echo ================================================
echo       GOFAST PRODUCOES - CONFIGURACAO LOCAL
echo ================================================
echo.
echo Esta configuracao usa um banco PostgreSQL existente.
echo Voce precisara informar a DATABASE_URL do banco.
echo.

where node >nul 2>&1
if errorlevel 1 (
  echo ERRO: Node.js nao foi encontrado.
  echo Instale o Node.js LTS em https://nodejs.org/ e execute novamente.
  pause
  exit /b 1
)

where npm >nul 2>&1
if errorlevel 1 (
  echo ERRO: npm nao foi encontrado.
  pause
  exit /b 1
)

set "DATABASE_URL="
set /p "DATABASE_URL=Digite a DATABASE_URL do PostgreSQL: "
if "%DATABASE_URL%"=="" (
  echo.
  echo ERRO: DATABASE_URL nao pode ficar vazia.
  pause
  exit /b 1
)

for /f "usebackq delims=" %%A in (`powershell -NoProfile -Command "$a=[guid]::NewGuid().ToString('N');$b=[guid]::NewGuid().ToString('N');Write-Output ($a+$b)"`) do set "JWT_SECRET=%%A"

>local-env.bat echo @echo off
>>local-env.bat echo set "DATABASE_URL=%DATABASE_URL%"
>>local-env.bat echo set "JWT_SECRET=%JWT_SECRET%"
>>local-env.bat echo set "PORT=5000"

if not exist node_modules (
  echo.
  echo Instalando dependencias do projeto. Isso pode levar alguns minutos...
  call npm install
  if errorlevel 1 (
    echo.
    echo ERRO ao instalar dependencias.
    pause
    exit /b 1
  )
)

echo.
echo Configuracao concluida.
echo Arquivo criado: local-env.bat

echo.
echo Deseja sincronizar/criar as tabelas no banco agora? [S/N]
set /p "DBPUSH="
if /I "%DBPUSH%"=="S" (
  call local-env.bat
  echo.
  echo Executando Drizzle Push...
  call npx drizzle-kit push
  if errorlevel 1 (
    echo.
    echo ATENCAO: o banco nao foi sincronizado.
    echo Verifique a DATABASE_URL e tente novamente.
    pause
    exit /b 1
  )
)

echo.
echo Configuracao finalizada. Agora execute INICIAR-GOFAST.bat
pause
