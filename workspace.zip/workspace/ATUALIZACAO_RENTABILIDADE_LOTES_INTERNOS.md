# Atualização — Rentabilidade dos Lotes Internos

## O que foi incluído

A página **Estrutura Interna** agora mostra os resultados dos lotes internos já concluídos.

Para cada lote concluído o sistema apresenta:
- Código do lote
- Produto
- Quantidade
- Dias operacionais utilizados
- Receita gerada pela produção
- Custo da estrutura consumido
- Ganho realizado
- Margem realizada
- Custo diário usado no cálculo

Também há indicadores consolidados:
- Receita concluída
- Custo absorvido
- Ganho realizado
- Margem realizada

## Regra de cálculo

Receita do lote = quantidade do lote × preço por unidade da produção.

Custo do lote = custo diário da estrutura interna × dias operacionais entre envio e conclusão.

Ganho realizado = receita do lote − custo do lote.

Margem = ganho realizado ÷ receita × 100.

O custo diário é salvo no lote no momento da criação (`internalDailyCostSnapshot`). Isso evita que uma alteração futura de salários, aluguel ou outros custos altere retroativamente o resultado de lotes já produzidos.

## Exemplo

100 peças × R$ 1,00 = R$ 100,00 de receita.

Se o custo diário da estrutura era R$ 10,00 e o lote levou 6 dias operacionais:

- Receita: R$ 100,00
- Custo: R$ 60,00
- Ganho: R$ 40,00
- Margem: 40%

Se levar 7 dias:

- Receita: R$ 100,00
- Custo: R$ 70,00
- Ganho: R$ 30,00
- Margem: 30%

A referência de 35% continua sendo usada no cálculo do prazo máximo na criação do lote interno.


## Atualização 2.4 — Pagamentos internos e cobertura de custos
- Pagamentos de funcionários internos separados por salário, adiantamento salarial, passagem e adiantamento de passagem.
- Comprovante individual imprimível para cada pagamento.
- Estrutura Interna mostra receita gerada no mês, percentual de cobertura, valor que falta para pagar a estrutura e meta de faturamento para 35% de margem.
- Nova rota /internal-payments e tabela internal_employee_payments.
