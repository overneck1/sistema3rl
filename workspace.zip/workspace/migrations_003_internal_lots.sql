-- GoFast Produções: lotes internos
-- Permite direcionar um lote para a equipe interna sem costureira externa.
ALTER TABLE batches ADD COLUMN IF NOT EXISTS assignment_type varchar(20) NOT NULL DEFAULT 'external';
ALTER TABLE batches ALTER COLUMN seamstress_id DROP NOT NULL;

CREATE INDEX IF NOT EXISTS idx_batches_assignment_type ON batches(empresa_id, assignment_type);
